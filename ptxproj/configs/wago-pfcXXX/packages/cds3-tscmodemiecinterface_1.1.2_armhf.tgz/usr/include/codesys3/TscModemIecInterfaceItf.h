 /**
 * <interfacename>WagoSysModem_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSMODEM_INTERNAL_PFCITF_H_
#define _WAGOSYSMODEM_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eModemState</description>
 */
#define EMODEMSTATE_UNKNOWN    RTS_IEC_INT_C(0x0)	
#define EMODEMSTATE_NOT_READY    RTS_IEC_INT_C(0x1)	
#define EMODEMSTATE_DETECTION_FAILED    RTS_IEC_INT_C(0x2)	
#define EMODEMSTATE_READY    RTS_IEC_INT_C(0x3)	
/* Typed enum definition */
#define EMODEMSTATE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkOperatorState</description>
 */
#define ENETWORKOPERATORSTATE_AVAILABLE    RTS_IEC_INT_C(0x0)	
#define ENETWORKOPERATORSTATE_CURRENT    RTS_IEC_INT_C(0x1)	
#define ENETWORKOPERATORSTATE_FORBIDDEN    RTS_IEC_INT_C(0x2)	
#define ENETWORKOPERATORSTATE_UNKNOWN    RTS_IEC_INT_C(0x3)	
/* Typed enum definition */
#define ENETWORKOPERATORSTATE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkRegistrationMode</description>
 */
#define ENETWORKREGISTRATIONMODE_AUTO    RTS_IEC_INT_C(0x0)	
#define ENETWORKREGISTRATIONMODE_MANUAL    RTS_IEC_INT_C(0x1)	
/* Typed enum definition */
#define ENETWORKREGISTRATIONMODE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkState</description>
 */
#define ENETWORKSTATE_NOT_REGISTERED    RTS_IEC_INT_C(0x0)	
#define ENETWORKSTATE_REGISTERED_HOME    RTS_IEC_INT_C(0x1)	
#define ENETWORKSTATE_SEARCHING    RTS_IEC_INT_C(0x2)	
#define ENETWORKSTATE_REGISTRATION_DENIED    RTS_IEC_INT_C(0x3)	
#define ENETWORKSTATE_UNKNOWN    RTS_IEC_INT_C(0x4)	
#define ENETWORKSTATE_REGISTERED_ROAMING    RTS_IEC_INT_C(0x5)	
#define ENETWORKSTATE_REGISTERED_SMS_ONLY_HOME    RTS_IEC_INT_C(0x6)	
#define ENETWORKSTATE_REGISTERED_SMS_ONLY_ROAMING    RTS_IEC_INT_C(0x7)	
#define ENETWORKSTATE_EMERGENCY_SERVICE    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ENETWORKSTATE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkTechnology</description>
 */
#define ENETWORKTECHNOLOGY_GSM    RTS_IEC_INT_C(0x0)	
#define ENETWORKTECHNOLOGY_GSM_COMPACT    RTS_IEC_INT_C(0x1)	
#define ENETWORKTECHNOLOGY_UMTS    RTS_IEC_INT_C(0x2)	
#define ENETWORKTECHNOLOGY_GSM_EGPRS    RTS_IEC_INT_C(0x3)	
#define ENETWORKTECHNOLOGY_HSDPA    RTS_IEC_INT_C(0x4)	
#define ENETWORKTECHNOLOGY_HSUPA    RTS_IEC_INT_C(0x5)	
#define ENETWORKTECHNOLOGY_HSDPA_HSUPA    RTS_IEC_INT_C(0x6)	
#define ENETWORKTECHNOLOGY_LTE    RTS_IEC_INT_C(0x7)	
#define ENETWORKTECHNOLOGY_LTE_ADVANCED    RTS_IEC_INT_C(0x8)	
#define ENETWORKTECHNOLOGY_UNKNOWN    RTS_IEC_INT_C(0x63)	
#define ENETWORKTECHNOLOGY_AUTO    RTS_IEC_INT_C(0x64)	
/* Typed enum definition */
#define ENETWORKTECHNOLOGY    RTS_IEC_INT

/**
 * <description>Enum: eResult</description>
 */
#define ERESULT_OK    RTS_IEC_INT_C(0x0)	/* Success */
#define ERESULT_EINVAL    RTS_IEC_INT_C(0x16)	/* Invalid argument */
#define ERESULT_EUNSPECIFIC    RTS_IEC_INT_C(0x87)	/* Unspecific error, see sResultText for more details */
#define ERESULT_EDEVICE    RTS_IEC_INT_C(0xC9)	/* The device is not supported */
#define ERESULT_ESTATE    RTS_IEC_INT_C(0xCA)	/* The operation is in the current state not possible */
#define ERESULT_EPINPUK    RTS_IEC_INT_C(0xCB)	/* The pin/puk is not correct */
#define ERESULT_EMODEMBUSY    RTS_IEC_INT_C(0xCC)	/* The modem is currently busy */
/* Typed enum definition */
#define ERESULT    RTS_IEC_INT

/**
 * <description>Enum: eSimLockType</description>
 */
#define ESIMLOCKTYPE_UNKNOWN    RTS_IEC_INT_C(0x0)	
#define ESIMLOCKTYPE_UNLOCKED    RTS_IEC_INT_C(0x1)	
#define ESIMLOCKTYPE_PIN    RTS_IEC_INT_C(0x2)	
#define ESIMLOCKTYPE_PIN2    RTS_IEC_INT_C(0x3)	
#define ESIMLOCKTYPE_PUK    RTS_IEC_INT_C(0x4)	
#define ESIMLOCKTYPE_PUK2    RTS_IEC_INT_C(0x5)	
/* Typed enum definition */
#define ESIMLOCKTYPE    RTS_IEC_INT

/**
 * <description>Enum: eSimState</description>
 */
#define ESIMSTATE_NOT_INITIALIZED    RTS_IEC_INT_C(0x0)	
#define ESIMSTATE_PIN_READY    RTS_IEC_INT_C(0x1)	
#define ESIMSTATE_SMS_READY    RTS_IEC_INT_C(0x2)	
#define ESIMSTATE_PB_READY    RTS_IEC_INT_C(0x3)	
#define ESIMSTATE_READY    RTS_IEC_INT_C(0x4)	
#define ESIMSTATE_NOT_PRESENT    RTS_IEC_INT_C(0x5)	
#define ESIMSTATE_LOCKED    RTS_IEC_INT_C(0x6)	
#define ESIMSTATE_ERROR    RTS_IEC_INT_C(0x7)	
#define ESIMSTATE_UNKNOWN    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ESIMSTATE    RTS_IEC_INT

/**
 * <description>Enum: eWdsAuthType</description>
 */
#define EWDSAUTHTYPE_NONE    RTS_IEC_INT_C(0x0)	
#define EWDSAUTHTYPE_PAP    RTS_IEC_INT_C(0x1)	
#define EWDSAUTHTYPE_CHAP    RTS_IEC_INT_C(0x2)	
#define EWDSAUTHTYPE_PAP_OR_CHAP    RTS_IEC_INT_C(0x3)	
#define EWDSAUTHTYPE_UNKNOWN    RTS_IEC_INT_C(0x4)	
/* Typed enum definition */
#define EWDSAUTHTYPE    RTS_IEC_INT

/**
 * <description>Enum: eWdsState</description>
 */
#define EWDSSTATE_CONNECTING    RTS_IEC_INT_C(0x0)	
#define EWDSSTATE_CONNECTED    RTS_IEC_INT_C(0x1)	
#define EWDSSTATE_DISCONNECTING    RTS_IEC_INT_C(0x2)	
#define EWDSSTATE_DISCONNECTED    RTS_IEC_INT_C(0x3)	
#define EWDSSTATE_ERROR    RTS_IEC_INT_C(0x4)	
#define EWDSSTATE_UNKNOWN    RTS_IEC_INT_C(0x5)	
/* Typed enum definition */
#define EWDSSTATE    RTS_IEC_INT

/**
 * <description>Enum: eModemState</description>
 */
#define EMODEMSTATE_UNKNOWN    RTS_IEC_INT_C(0x0)	
#define EMODEMSTATE_NOT_READY    RTS_IEC_INT_C(0x1)	
#define EMODEMSTATE_DETECTION_FAILED    RTS_IEC_INT_C(0x2)	
#define EMODEMSTATE_READY    RTS_IEC_INT_C(0x3)	
/* Typed enum definition */
#define EMODEMSTATE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkState</description>
 */
#define ENETWORKSTATE_NOT_REGISTERED    RTS_IEC_INT_C(0x0)	
#define ENETWORKSTATE_REGISTERED_HOME    RTS_IEC_INT_C(0x1)	
#define ENETWORKSTATE_SEARCHING    RTS_IEC_INT_C(0x2)	
#define ENETWORKSTATE_REGISTRATION_DENIED    RTS_IEC_INT_C(0x3)	
#define ENETWORKSTATE_UNKNOWN    RTS_IEC_INT_C(0x4)	
#define ENETWORKSTATE_REGISTERED_ROAMING    RTS_IEC_INT_C(0x5)	
#define ENETWORKSTATE_REGISTERED_SMS_ONLY_HOME    RTS_IEC_INT_C(0x6)	
#define ENETWORKSTATE_REGISTERED_SMS_ONLY_ROAMING    RTS_IEC_INT_C(0x7)	
#define ENETWORKSTATE_EMERGENCY_SERVICE    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ENETWORKSTATE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkTechnology</description>
 */
#define ENETWORKTECHNOLOGY_GSM    RTS_IEC_INT_C(0x0)	
#define ENETWORKTECHNOLOGY_GSM_COMPACT    RTS_IEC_INT_C(0x1)	
#define ENETWORKTECHNOLOGY_UMTS    RTS_IEC_INT_C(0x2)	
#define ENETWORKTECHNOLOGY_GSM_EGPRS    RTS_IEC_INT_C(0x3)	
#define ENETWORKTECHNOLOGY_HSDPA    RTS_IEC_INT_C(0x4)	
#define ENETWORKTECHNOLOGY_HSUPA    RTS_IEC_INT_C(0x5)	
#define ENETWORKTECHNOLOGY_HSDPA_HSUPA    RTS_IEC_INT_C(0x6)	
#define ENETWORKTECHNOLOGY_LTE    RTS_IEC_INT_C(0x7)	
#define ENETWORKTECHNOLOGY_LTE_ADVANCED    RTS_IEC_INT_C(0x8)	
#define ENETWORKTECHNOLOGY_UNKNOWN    RTS_IEC_INT_C(0x63)	
#define ENETWORKTECHNOLOGY_AUTO    RTS_IEC_INT_C(0x64)	
/* Typed enum definition */
#define ENETWORKTECHNOLOGY    RTS_IEC_INT

/**
 * <description>Enum: eNetworkRegistrationMode</description>
 */
#define ENETWORKREGISTRATIONMODE_AUTO    RTS_IEC_INT_C(0x0)	
#define ENETWORKREGISTRATIONMODE_MANUAL    RTS_IEC_INT_C(0x1)	
/* Typed enum definition */
#define ENETWORKREGISTRATIONMODE    RTS_IEC_INT

/**
 * <description>Enum: eNetworkOperatorState</description>
 */
#define ENETWORKOPERATORSTATE_AVAILABLE    RTS_IEC_INT_C(0x0)	
#define ENETWORKOPERATORSTATE_CURRENT    RTS_IEC_INT_C(0x1)	
#define ENETWORKOPERATORSTATE_FORBIDDEN    RTS_IEC_INT_C(0x2)	
#define ENETWORKOPERATORSTATE_UNKNOWN    RTS_IEC_INT_C(0x3)	
/* Typed enum definition */
#define ENETWORKOPERATORSTATE    RTS_IEC_INT

/**
 * <description>Enum: eSimState</description>
 */
#define ESIMSTATE_NOT_INITIALIZED    RTS_IEC_INT_C(0x0)	
#define ESIMSTATE_PIN_READY    RTS_IEC_INT_C(0x1)	
#define ESIMSTATE_SMS_READY    RTS_IEC_INT_C(0x2)	
#define ESIMSTATE_PB_READY    RTS_IEC_INT_C(0x3)	
#define ESIMSTATE_READY    RTS_IEC_INT_C(0x4)	
#define ESIMSTATE_NOT_PRESENT    RTS_IEC_INT_C(0x5)	
#define ESIMSTATE_LOCKED    RTS_IEC_INT_C(0x6)	
#define ESIMSTATE_ERROR    RTS_IEC_INT_C(0x7)	
#define ESIMSTATE_UNKNOWN    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ESIMSTATE    RTS_IEC_INT

/**
 * <description>Enum: eSimLockType</description>
 */
#define ESIMLOCKTYPE_UNKNOWN    RTS_IEC_INT_C(0x0)	
#define ESIMLOCKTYPE_UNLOCKED    RTS_IEC_INT_C(0x1)	
#define ESIMLOCKTYPE_PIN    RTS_IEC_INT_C(0x2)	
#define ESIMLOCKTYPE_PIN2    RTS_IEC_INT_C(0x3)	
#define ESIMLOCKTYPE_PUK    RTS_IEC_INT_C(0x4)	
#define ESIMLOCKTYPE_PUK2    RTS_IEC_INT_C(0x5)	
/* Typed enum definition */
#define ESIMLOCKTYPE    RTS_IEC_INT

/**
 * <description>Enum: eWdsState</description>
 */
#define EWDSSTATE_CONNECTING    RTS_IEC_INT_C(0x0)	
#define EWDSSTATE_CONNECTED    RTS_IEC_INT_C(0x1)	
#define EWDSSTATE_DISCONNECTING    RTS_IEC_INT_C(0x2)	
#define EWDSSTATE_DISCONNECTED    RTS_IEC_INT_C(0x3)	
#define EWDSSTATE_ERROR    RTS_IEC_INT_C(0x4)	
#define EWDSSTATE_UNKNOWN    RTS_IEC_INT_C(0x5)	
/* Typed enum definition */
#define EWDSSTATE    RTS_IEC_INT

/**
 * <description>Enum: eWdsAuthType</description>
 */
#define EWDSAUTHTYPE_NONE    RTS_IEC_INT_C(0x0)	
#define EWDSAUTHTYPE_PAP    RTS_IEC_INT_C(0x1)	
#define EWDSAUTHTYPE_CHAP    RTS_IEC_INT_C(0x2)	
#define EWDSAUTHTYPE_PAP_OR_CHAP    RTS_IEC_INT_C(0x3)	
#define EWDSAUTHTYPE_UNKNOWN    RTS_IEC_INT_C(0x4)	
/* Typed enum definition */
#define EWDSAUTHTYPE    RTS_IEC_INT

/**
 * <description>typModemDeviceInfo</description>
 */
typedef struct tagtypModemDeviceInfo
{
	RTS_IEC_INT eState;		
	RTS_IEC_STRING sManufacturer[51];		
	RTS_IEC_STRING sModel[51];		
	RTS_IEC_STRING sVersion[51];		
	RTS_IEC_STRING sImei[17];		
} typModemDeviceInfo;

/**
 * <description>typNetworkAccessInfo</description>
 */
typedef struct tagtypNetworkAccessInfo
{
	RTS_IEC_INT eState;		
	RTS_IEC_STRING sOperator[81];		
	RTS_IEC_STRING sOperatorShort[81];		/* network operator name (short format) */
	RTS_IEC_STRING sOperatorId[11];		/* network operator name (MCC+MNC) */
	RTS_IEC_INT eTechnology;		
	RTS_IEC_USINT usiSignalStrength;		/* in percent */
	RTS_IEC_INT iSignalRssi;		
	RTS_IEC_STRING sLocalAreaCode[11];		
	RTS_IEC_STRING sCellId[11];		
} typNetworkAccessInfo;

/**
 * <description>typNetworkRegistrationSettings</description>
 */
typedef struct tagtypNetworkRegistrationSettings
{
	RTS_IEC_INT eMode;		
	RTS_IEC_STRING sOperatorIdentifier[81];		
	RTS_IEC_BOOL xFallbackToAuto;		
	RTS_IEC_INT eAccessTechnology;		
} typNetworkRegistrationSettings;

/**
 * <description>typNetworkScanInfo</description>
 */
typedef struct tagtypNetworkScanInfo
{
	RTS_IEC_INT eState;		
	RTS_IEC_STRING sOperLong[81];		/* network operator name (long format) */
	RTS_IEC_STRING sOperShort[81];		/* network operator name (short format) */
	RTS_IEC_STRING sOperId[81];		/* network operator name (MCC+MNC) */
	RTS_IEC_INT eTechnology;		
} typNetworkScanInfo;

/**
 * <description>typSimInfo</description>
 */
typedef struct tagtypSimInfo
{
	RTS_IEC_INT eState;		
	RTS_IEC_INT eLockType;		
	RTS_IEC_INT iRemainingAttempts;		
	RTS_IEC_STRING sICCID[21];		
} typSimInfo;

/**
 * <description>typSmsMetaData</description>
 */
typedef struct tagtypSmsMetaData
{
	RTS_IEC_UINT uiIndex;		/* Index in storage location */
	RTS_IEC_DATE_AND_TIME tTimeStamp;		/* Timestamp of the sms */
	RTS_IEC_STRING sSenderNumber[25];		
} typSmsMetaData;

/**
 * <description>typSmsMsgPDU</description>
 */
typedef struct tagtypSmsMsgPDU
{
	RTS_IEC_BYTE aData[257];		
	RTS_IEC_UINT uiDataLength;		
} typSmsMsgPDU;

/**
 * <description>typWdsInfo</description>
 */
typedef struct tagtypWdsInfo
{
	RTS_IEC_INT eState;		
	RTS_IEC_STRING sIp[46];		
} typWdsInfo;

/**
 * <description>typWdsSettings</description>
 */
typedef struct tagtypWdsSettings
{
	RTS_IEC_STRING sApn[31];		
	RTS_IEC_STRING sUser[31];		
	RTS_IEC_STRING sPassword[31];		
	RTS_IEC_INT eAuthType;		
} typWdsSettings;

/**
 * <description>fuget_modem_device_info</description>
 */
typedef struct tagfuget_modem_device_info_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	typModemDeviceInfo FuGet_modem_device_info;	/* VAR_OUTPUT */	
} fuget_modem_device_info_struct;

void CDECL CDECL_EXT fuget_modem_device_info(fuget_modem_device_info_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_MODEM_DEVICE_INFO_IEC) (fuget_modem_device_info_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_MODEM_DEVICE_INFO_NOTIMPLEMENTED)
	#define USE_fuget_modem_device_info
	#define EXT_fuget_modem_device_info
	#define GET_fuget_modem_device_info(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_modem_device_info(p0) 
	#define CHK_fuget_modem_device_info  FALSE
	#define EXP_fuget_modem_device_info  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_modem_device_info
	#define EXT_fuget_modem_device_info
	#define GET_fuget_modem_device_info(fl)  CAL_CMGETAPI( "fuget_modem_device_info" ) 
	#define CAL_fuget_modem_device_info  fuget_modem_device_info
	#define CHK_fuget_modem_device_info  TRUE
	#define EXP_fuget_modem_device_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_modem_device_info", (RTS_UINTPTR)fuget_modem_device_info, 1, 0x560E8BFE, 0x01010400) 
	#define EXTREF_ITF_fuget_modem_device_info {(RTS_VOID_FCTPTR)fuget_modem_device_info, "fuget_modem_device_info", 0x560E8BFE, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_modem_device_info
	#define EXT_fuget_modem_device_info
	#define GET_fuget_modem_device_info(fl)  CAL_CMGETAPI( "fuget_modem_device_info" ) 
	#define CAL_fuget_modem_device_info  fuget_modem_device_info
	#define CHK_fuget_modem_device_info  TRUE
	#define EXP_fuget_modem_device_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_modem_device_info", (RTS_UINTPTR)fuget_modem_device_info, 1, 0x560E8BFE, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_modem_device_info
	#define EXT_WagoSysModem_Internal_PFCfuget_modem_device_info
	#define GET_WagoSysModem_Internal_PFCfuget_modem_device_info  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_modem_device_info  fuget_modem_device_info
	#define CHK_WagoSysModem_Internal_PFCfuget_modem_device_info  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_modem_device_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_modem_device_info", (RTS_UINTPTR)fuget_modem_device_info, 1, 0x560E8BFE, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_modem_device_info
	#define EXT_fuget_modem_device_info
	#define GET_fuget_modem_device_info(fl)  CAL_CMGETAPI( "fuget_modem_device_info" ) 
	#define CAL_fuget_modem_device_info  fuget_modem_device_info
	#define CHK_fuget_modem_device_info  TRUE
	#define EXP_fuget_modem_device_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_modem_device_info", (RTS_UINTPTR)fuget_modem_device_info, 1, 0x560E8BFE, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_modem_device_info  PFFUGET_MODEM_DEVICE_INFO_IEC pffuget_modem_device_info;
	#define EXT_fuget_modem_device_info  extern PFFUGET_MODEM_DEVICE_INFO_IEC pffuget_modem_device_info;
	#define GET_fuget_modem_device_info(fl)  s_pfCMGetAPI2( "fuget_modem_device_info", (RTS_VOID_FCTPTR *)&pffuget_modem_device_info, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x560E8BFE, 0x01010400)
	#define CAL_fuget_modem_device_info  pffuget_modem_device_info
	#define CHK_fuget_modem_device_info  (pffuget_modem_device_info != NULL)
	#define EXP_fuget_modem_device_info   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_modem_device_info", (RTS_UINTPTR)fuget_modem_device_info, 1, 0x560E8BFE, 0x01010400) 
#endif


/**
 * <description>fuget_network_access_info</description>
 */
typedef struct tagfuget_network_access_info_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	typNetworkAccessInfo FuGet_network_access_info;	/* VAR_OUTPUT */	
} fuget_network_access_info_struct;

void CDECL CDECL_EXT fuget_network_access_info(fuget_network_access_info_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_NETWORK_ACCESS_INFO_IEC) (fuget_network_access_info_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_NETWORK_ACCESS_INFO_NOTIMPLEMENTED)
	#define USE_fuget_network_access_info
	#define EXT_fuget_network_access_info
	#define GET_fuget_network_access_info(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_network_access_info(p0) 
	#define CHK_fuget_network_access_info  FALSE
	#define EXP_fuget_network_access_info  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_network_access_info
	#define EXT_fuget_network_access_info
	#define GET_fuget_network_access_info(fl)  CAL_CMGETAPI( "fuget_network_access_info" ) 
	#define CAL_fuget_network_access_info  fuget_network_access_info
	#define CHK_fuget_network_access_info  TRUE
	#define EXP_fuget_network_access_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_access_info", (RTS_UINTPTR)fuget_network_access_info, 1, 0x70FD3085, 0x01010400) 
	#define EXTREF_ITF_fuget_network_access_info {(RTS_VOID_FCTPTR)fuget_network_access_info, "fuget_network_access_info", 0x70FD3085, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_network_access_info
	#define EXT_fuget_network_access_info
	#define GET_fuget_network_access_info(fl)  CAL_CMGETAPI( "fuget_network_access_info" ) 
	#define CAL_fuget_network_access_info  fuget_network_access_info
	#define CHK_fuget_network_access_info  TRUE
	#define EXP_fuget_network_access_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_access_info", (RTS_UINTPTR)fuget_network_access_info, 1, 0x70FD3085, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_network_access_info
	#define EXT_WagoSysModem_Internal_PFCfuget_network_access_info
	#define GET_WagoSysModem_Internal_PFCfuget_network_access_info  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_network_access_info  fuget_network_access_info
	#define CHK_WagoSysModem_Internal_PFCfuget_network_access_info  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_network_access_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_access_info", (RTS_UINTPTR)fuget_network_access_info, 1, 0x70FD3085, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_network_access_info
	#define EXT_fuget_network_access_info
	#define GET_fuget_network_access_info(fl)  CAL_CMGETAPI( "fuget_network_access_info" ) 
	#define CAL_fuget_network_access_info  fuget_network_access_info
	#define CHK_fuget_network_access_info  TRUE
	#define EXP_fuget_network_access_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_access_info", (RTS_UINTPTR)fuget_network_access_info, 1, 0x70FD3085, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_network_access_info  PFFUGET_NETWORK_ACCESS_INFO_IEC pffuget_network_access_info;
	#define EXT_fuget_network_access_info  extern PFFUGET_NETWORK_ACCESS_INFO_IEC pffuget_network_access_info;
	#define GET_fuget_network_access_info(fl)  s_pfCMGetAPI2( "fuget_network_access_info", (RTS_VOID_FCTPTR *)&pffuget_network_access_info, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x70FD3085, 0x01010400)
	#define CAL_fuget_network_access_info  pffuget_network_access_info
	#define CHK_fuget_network_access_info  (pffuget_network_access_info != NULL)
	#define EXP_fuget_network_access_info   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_access_info", (RTS_UINTPTR)fuget_network_access_info, 1, 0x70FD3085, 0x01010400) 
#endif


/**
 * <description>fuget_network_registration_settings</description>
 */
typedef struct tagfuget_network_registration_settings_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	typNetworkRegistrationSettings FuGet_network_registration_settings;	/* VAR_OUTPUT */	
} fuget_network_registration_settings_struct;

void CDECL CDECL_EXT fuget_network_registration_settings(fuget_network_registration_settings_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_NETWORK_REGISTRATION_SETTINGS_IEC) (fuget_network_registration_settings_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_NETWORK_REGISTRATION_SETTINGS_NOTIMPLEMENTED)
	#define USE_fuget_network_registration_settings
	#define EXT_fuget_network_registration_settings
	#define GET_fuget_network_registration_settings(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_network_registration_settings(p0) 
	#define CHK_fuget_network_registration_settings  FALSE
	#define EXP_fuget_network_registration_settings  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_network_registration_settings
	#define EXT_fuget_network_registration_settings
	#define GET_fuget_network_registration_settings(fl)  CAL_CMGETAPI( "fuget_network_registration_settings" ) 
	#define CAL_fuget_network_registration_settings  fuget_network_registration_settings
	#define CHK_fuget_network_registration_settings  TRUE
	#define EXP_fuget_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_registration_settings", (RTS_UINTPTR)fuget_network_registration_settings, 1, 0x06EAE8B1, 0x01010400) 
	#define EXTREF_ITF_fuget_network_registration_settings {(RTS_VOID_FCTPTR)fuget_network_registration_settings, "fuget_network_registration_settings", 0x06EAE8B1, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_network_registration_settings
	#define EXT_fuget_network_registration_settings
	#define GET_fuget_network_registration_settings(fl)  CAL_CMGETAPI( "fuget_network_registration_settings" ) 
	#define CAL_fuget_network_registration_settings  fuget_network_registration_settings
	#define CHK_fuget_network_registration_settings  TRUE
	#define EXP_fuget_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_registration_settings", (RTS_UINTPTR)fuget_network_registration_settings, 1, 0x06EAE8B1, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_network_registration_settings
	#define EXT_WagoSysModem_Internal_PFCfuget_network_registration_settings
	#define GET_WagoSysModem_Internal_PFCfuget_network_registration_settings  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_network_registration_settings  fuget_network_registration_settings
	#define CHK_WagoSysModem_Internal_PFCfuget_network_registration_settings  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_registration_settings", (RTS_UINTPTR)fuget_network_registration_settings, 1, 0x06EAE8B1, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_network_registration_settings
	#define EXT_fuget_network_registration_settings
	#define GET_fuget_network_registration_settings(fl)  CAL_CMGETAPI( "fuget_network_registration_settings" ) 
	#define CAL_fuget_network_registration_settings  fuget_network_registration_settings
	#define CHK_fuget_network_registration_settings  TRUE
	#define EXP_fuget_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_registration_settings", (RTS_UINTPTR)fuget_network_registration_settings, 1, 0x06EAE8B1, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_network_registration_settings  PFFUGET_NETWORK_REGISTRATION_SETTINGS_IEC pffuget_network_registration_settings;
	#define EXT_fuget_network_registration_settings  extern PFFUGET_NETWORK_REGISTRATION_SETTINGS_IEC pffuget_network_registration_settings;
	#define GET_fuget_network_registration_settings(fl)  s_pfCMGetAPI2( "fuget_network_registration_settings", (RTS_VOID_FCTPTR *)&pffuget_network_registration_settings, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x06EAE8B1, 0x01010400)
	#define CAL_fuget_network_registration_settings  pffuget_network_registration_settings
	#define CHK_fuget_network_registration_settings  (pffuget_network_registration_settings != NULL)
	#define EXP_fuget_network_registration_settings   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_network_registration_settings", (RTS_UINTPTR)fuget_network_registration_settings, 1, 0x06EAE8B1, 0x01010400) 
#endif


/**
 * <description>fuget_sim_info</description>
 */
typedef struct tagfuget_sim_info_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	typSimInfo FuGet_sim_info;			/* VAR_OUTPUT */	
} fuget_sim_info_struct;

void CDECL CDECL_EXT fuget_sim_info(fuget_sim_info_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_SIM_INFO_IEC) (fuget_sim_info_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_SIM_INFO_NOTIMPLEMENTED)
	#define USE_fuget_sim_info
	#define EXT_fuget_sim_info
	#define GET_fuget_sim_info(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_sim_info(p0) 
	#define CHK_fuget_sim_info  FALSE
	#define EXP_fuget_sim_info  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_sim_info
	#define EXT_fuget_sim_info
	#define GET_fuget_sim_info(fl)  CAL_CMGETAPI( "fuget_sim_info" ) 
	#define CAL_fuget_sim_info  fuget_sim_info
	#define CHK_fuget_sim_info  TRUE
	#define EXP_fuget_sim_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_sim_info", (RTS_UINTPTR)fuget_sim_info, 1, 0x20CCD04B, 0x01010400) 
	#define EXTREF_ITF_fuget_sim_info {(RTS_VOID_FCTPTR)fuget_sim_info, "fuget_sim_info", 0x20CCD04B, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_sim_info
	#define EXT_fuget_sim_info
	#define GET_fuget_sim_info(fl)  CAL_CMGETAPI( "fuget_sim_info" ) 
	#define CAL_fuget_sim_info  fuget_sim_info
	#define CHK_fuget_sim_info  TRUE
	#define EXP_fuget_sim_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_sim_info", (RTS_UINTPTR)fuget_sim_info, 1, 0x20CCD04B, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_sim_info
	#define EXT_WagoSysModem_Internal_PFCfuget_sim_info
	#define GET_WagoSysModem_Internal_PFCfuget_sim_info  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_sim_info  fuget_sim_info
	#define CHK_WagoSysModem_Internal_PFCfuget_sim_info  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_sim_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_sim_info", (RTS_UINTPTR)fuget_sim_info, 1, 0x20CCD04B, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_sim_info
	#define EXT_fuget_sim_info
	#define GET_fuget_sim_info(fl)  CAL_CMGETAPI( "fuget_sim_info" ) 
	#define CAL_fuget_sim_info  fuget_sim_info
	#define CHK_fuget_sim_info  TRUE
	#define EXP_fuget_sim_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_sim_info", (RTS_UINTPTR)fuget_sim_info, 1, 0x20CCD04B, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_sim_info  PFFUGET_SIM_INFO_IEC pffuget_sim_info;
	#define EXT_fuget_sim_info  extern PFFUGET_SIM_INFO_IEC pffuget_sim_info;
	#define GET_fuget_sim_info(fl)  s_pfCMGetAPI2( "fuget_sim_info", (RTS_VOID_FCTPTR *)&pffuget_sim_info, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x20CCD04B, 0x01010400)
	#define CAL_fuget_sim_info  pffuget_sim_info
	#define CHK_fuget_sim_info  (pffuget_sim_info != NULL)
	#define EXP_fuget_sim_info   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_sim_info", (RTS_UINTPTR)fuget_sim_info, 1, 0x20CCD04B, 0x01010400) 
#endif


/**
 * <description>fuget_wds_enable</description>
 */
typedef struct tagfuget_wds_enable_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	RTS_IEC_BOOL FuGet_wds_enable;		/* VAR_OUTPUT */	
} fuget_wds_enable_struct;

void CDECL CDECL_EXT fuget_wds_enable(fuget_wds_enable_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_WDS_ENABLE_IEC) (fuget_wds_enable_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_WDS_ENABLE_NOTIMPLEMENTED)
	#define USE_fuget_wds_enable
	#define EXT_fuget_wds_enable
	#define GET_fuget_wds_enable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_wds_enable(p0) 
	#define CHK_fuget_wds_enable  FALSE
	#define EXP_fuget_wds_enable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_wds_enable
	#define EXT_fuget_wds_enable
	#define GET_fuget_wds_enable(fl)  CAL_CMGETAPI( "fuget_wds_enable" ) 
	#define CAL_fuget_wds_enable  fuget_wds_enable
	#define CHK_fuget_wds_enable  TRUE
	#define EXP_fuget_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_enable", (RTS_UINTPTR)fuget_wds_enable, 1, 0x5D61BE0F, 0x01010400) 
	#define EXTREF_ITF_fuget_wds_enable {(RTS_VOID_FCTPTR)fuget_wds_enable, "fuget_wds_enable", 0x5D61BE0F, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_wds_enable
	#define EXT_fuget_wds_enable
	#define GET_fuget_wds_enable(fl)  CAL_CMGETAPI( "fuget_wds_enable" ) 
	#define CAL_fuget_wds_enable  fuget_wds_enable
	#define CHK_fuget_wds_enable  TRUE
	#define EXP_fuget_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_enable", (RTS_UINTPTR)fuget_wds_enable, 1, 0x5D61BE0F, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_wds_enable
	#define EXT_WagoSysModem_Internal_PFCfuget_wds_enable
	#define GET_WagoSysModem_Internal_PFCfuget_wds_enable  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_wds_enable  fuget_wds_enable
	#define CHK_WagoSysModem_Internal_PFCfuget_wds_enable  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_enable", (RTS_UINTPTR)fuget_wds_enable, 1, 0x5D61BE0F, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_wds_enable
	#define EXT_fuget_wds_enable
	#define GET_fuget_wds_enable(fl)  CAL_CMGETAPI( "fuget_wds_enable" ) 
	#define CAL_fuget_wds_enable  fuget_wds_enable
	#define CHK_fuget_wds_enable  TRUE
	#define EXP_fuget_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_enable", (RTS_UINTPTR)fuget_wds_enable, 1, 0x5D61BE0F, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_wds_enable  PFFUGET_WDS_ENABLE_IEC pffuget_wds_enable;
	#define EXT_fuget_wds_enable  extern PFFUGET_WDS_ENABLE_IEC pffuget_wds_enable;
	#define GET_fuget_wds_enable(fl)  s_pfCMGetAPI2( "fuget_wds_enable", (RTS_VOID_FCTPTR *)&pffuget_wds_enable, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5D61BE0F, 0x01010400)
	#define CAL_fuget_wds_enable  pffuget_wds_enable
	#define CHK_fuget_wds_enable  (pffuget_wds_enable != NULL)
	#define EXP_fuget_wds_enable   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_enable", (RTS_UINTPTR)fuget_wds_enable, 1, 0x5D61BE0F, 0x01010400) 
#endif


/**
 * <description>fuget_wds_info</description>
 */
typedef struct tagfuget_wds_info_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	typWdsInfo FuGet_wds_info;			/* VAR_OUTPUT */	
} fuget_wds_info_struct;

void CDECL CDECL_EXT fuget_wds_info(fuget_wds_info_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_WDS_INFO_IEC) (fuget_wds_info_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_WDS_INFO_NOTIMPLEMENTED)
	#define USE_fuget_wds_info
	#define EXT_fuget_wds_info
	#define GET_fuget_wds_info(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_wds_info(p0) 
	#define CHK_fuget_wds_info  FALSE
	#define EXP_fuget_wds_info  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_wds_info
	#define EXT_fuget_wds_info
	#define GET_fuget_wds_info(fl)  CAL_CMGETAPI( "fuget_wds_info" ) 
	#define CAL_fuget_wds_info  fuget_wds_info
	#define CHK_fuget_wds_info  TRUE
	#define EXP_fuget_wds_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_info", (RTS_UINTPTR)fuget_wds_info, 1, 0x3F3F0535, 0x01010400) 
	#define EXTREF_ITF_fuget_wds_info {(RTS_VOID_FCTPTR)fuget_wds_info, "fuget_wds_info", 0x3F3F0535, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_wds_info
	#define EXT_fuget_wds_info
	#define GET_fuget_wds_info(fl)  CAL_CMGETAPI( "fuget_wds_info" ) 
	#define CAL_fuget_wds_info  fuget_wds_info
	#define CHK_fuget_wds_info  TRUE
	#define EXP_fuget_wds_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_info", (RTS_UINTPTR)fuget_wds_info, 1, 0x3F3F0535, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_wds_info
	#define EXT_WagoSysModem_Internal_PFCfuget_wds_info
	#define GET_WagoSysModem_Internal_PFCfuget_wds_info  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_wds_info  fuget_wds_info
	#define CHK_WagoSysModem_Internal_PFCfuget_wds_info  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_wds_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_info", (RTS_UINTPTR)fuget_wds_info, 1, 0x3F3F0535, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_wds_info
	#define EXT_fuget_wds_info
	#define GET_fuget_wds_info(fl)  CAL_CMGETAPI( "fuget_wds_info" ) 
	#define CAL_fuget_wds_info  fuget_wds_info
	#define CHK_fuget_wds_info  TRUE
	#define EXP_fuget_wds_info  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_info", (RTS_UINTPTR)fuget_wds_info, 1, 0x3F3F0535, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_wds_info  PFFUGET_WDS_INFO_IEC pffuget_wds_info;
	#define EXT_fuget_wds_info  extern PFFUGET_WDS_INFO_IEC pffuget_wds_info;
	#define GET_fuget_wds_info(fl)  s_pfCMGetAPI2( "fuget_wds_info", (RTS_VOID_FCTPTR *)&pffuget_wds_info, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3F3F0535, 0x01010400)
	#define CAL_fuget_wds_info  pffuget_wds_info
	#define CHK_fuget_wds_info  (pffuget_wds_info != NULL)
	#define EXP_fuget_wds_info   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_info", (RTS_UINTPTR)fuget_wds_info, 1, 0x3F3F0535, 0x01010400) 
#endif


/**
 * <description>fuget_wds_settings</description>
 */
typedef struct tagfuget_wds_settings_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
	typWdsSettings FuGet_wds_settings;	/* VAR_OUTPUT */	
} fuget_wds_settings_struct;

void CDECL CDECL_EXT fuget_wds_settings(fuget_wds_settings_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGET_WDS_SETTINGS_IEC) (fuget_wds_settings_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGET_WDS_SETTINGS_NOTIMPLEMENTED)
	#define USE_fuget_wds_settings
	#define EXT_fuget_wds_settings
	#define GET_fuget_wds_settings(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuget_wds_settings(p0) 
	#define CHK_fuget_wds_settings  FALSE
	#define EXP_fuget_wds_settings  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuget_wds_settings
	#define EXT_fuget_wds_settings
	#define GET_fuget_wds_settings(fl)  CAL_CMGETAPI( "fuget_wds_settings" ) 
	#define CAL_fuget_wds_settings  fuget_wds_settings
	#define CHK_fuget_wds_settings  TRUE
	#define EXP_fuget_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_settings", (RTS_UINTPTR)fuget_wds_settings, 1, 0x577FE6EC, 0x01010400) 
	#define EXTREF_ITF_fuget_wds_settings {(RTS_VOID_FCTPTR)fuget_wds_settings, "fuget_wds_settings", 0x577FE6EC, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuget_wds_settings
	#define EXT_fuget_wds_settings
	#define GET_fuget_wds_settings(fl)  CAL_CMGETAPI( "fuget_wds_settings" ) 
	#define CAL_fuget_wds_settings  fuget_wds_settings
	#define CHK_fuget_wds_settings  TRUE
	#define EXP_fuget_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_settings", (RTS_UINTPTR)fuget_wds_settings, 1, 0x577FE6EC, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuget_wds_settings
	#define EXT_WagoSysModem_Internal_PFCfuget_wds_settings
	#define GET_WagoSysModem_Internal_PFCfuget_wds_settings  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuget_wds_settings  fuget_wds_settings
	#define CHK_WagoSysModem_Internal_PFCfuget_wds_settings  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuget_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_settings", (RTS_UINTPTR)fuget_wds_settings, 1, 0x577FE6EC, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuget_wds_settings
	#define EXT_fuget_wds_settings
	#define GET_fuget_wds_settings(fl)  CAL_CMGETAPI( "fuget_wds_settings" ) 
	#define CAL_fuget_wds_settings  fuget_wds_settings
	#define CHK_fuget_wds_settings  TRUE
	#define EXP_fuget_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_settings", (RTS_UINTPTR)fuget_wds_settings, 1, 0x577FE6EC, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuget_wds_settings  PFFUGET_WDS_SETTINGS_IEC pffuget_wds_settings;
	#define EXT_fuget_wds_settings  extern PFFUGET_WDS_SETTINGS_IEC pffuget_wds_settings;
	#define GET_fuget_wds_settings(fl)  s_pfCMGetAPI2( "fuget_wds_settings", (RTS_VOID_FCTPTR *)&pffuget_wds_settings, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x577FE6EC, 0x01010400)
	#define CAL_fuget_wds_settings  pffuget_wds_settings
	#define CHK_fuget_wds_settings  (pffuget_wds_settings != NULL)
	#define EXP_fuget_wds_settings   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuget_wds_settings", (RTS_UINTPTR)fuget_wds_settings, 1, 0x577FE6EC, 0x01010400) 
#endif


/**
 * <description>funetscan_list_get_element</description>
 */
typedef struct tagfunetscan_list_get_element_struct
{
	RTS_IEC_UINT uiIndex;				/* VAR_INPUT */	/* Index of the network info element in the netscan list */
	RTS_IEC_INT FuNetscan_list_get_element;	/* VAR_OUTPUT, Enum: ERESULT */
	typNetworkScanInfo NetInfo;			/* VAR_OUTPUT */	
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} funetscan_list_get_element_struct;

void CDECL CDECL_EXT funetscan_list_get_element(funetscan_list_get_element_struct *p);
typedef void (CDECL CDECL_EXT* PFFUNETSCAN_LIST_GET_ELEMENT_IEC) (funetscan_list_get_element_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUNETSCAN_LIST_GET_ELEMENT_NOTIMPLEMENTED)
	#define USE_funetscan_list_get_element
	#define EXT_funetscan_list_get_element
	#define GET_funetscan_list_get_element(fl)  ERR_NOTIMPLEMENTED
	#define CAL_funetscan_list_get_element(p0) 
	#define CHK_funetscan_list_get_element  FALSE
	#define EXP_funetscan_list_get_element  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_funetscan_list_get_element
	#define EXT_funetscan_list_get_element
	#define GET_funetscan_list_get_element(fl)  CAL_CMGETAPI( "funetscan_list_get_element" ) 
	#define CAL_funetscan_list_get_element  funetscan_list_get_element
	#define CHK_funetscan_list_get_element  TRUE
	#define EXP_funetscan_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_element", (RTS_UINTPTR)funetscan_list_get_element, 1, 0x92645CF6, 0x01010400) 
	#define EXTREF_ITF_funetscan_list_get_element {(RTS_VOID_FCTPTR)funetscan_list_get_element, "funetscan_list_get_element", 0x92645CF6, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_funetscan_list_get_element
	#define EXT_funetscan_list_get_element
	#define GET_funetscan_list_get_element(fl)  CAL_CMGETAPI( "funetscan_list_get_element" ) 
	#define CAL_funetscan_list_get_element  funetscan_list_get_element
	#define CHK_funetscan_list_get_element  TRUE
	#define EXP_funetscan_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_element", (RTS_UINTPTR)funetscan_list_get_element, 1, 0x92645CF6, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfunetscan_list_get_element
	#define EXT_WagoSysModem_Internal_PFCfunetscan_list_get_element
	#define GET_WagoSysModem_Internal_PFCfunetscan_list_get_element  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfunetscan_list_get_element  funetscan_list_get_element
	#define CHK_WagoSysModem_Internal_PFCfunetscan_list_get_element  TRUE
	#define EXP_WagoSysModem_Internal_PFCfunetscan_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_element", (RTS_UINTPTR)funetscan_list_get_element, 1, 0x92645CF6, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_funetscan_list_get_element
	#define EXT_funetscan_list_get_element
	#define GET_funetscan_list_get_element(fl)  CAL_CMGETAPI( "funetscan_list_get_element" ) 
	#define CAL_funetscan_list_get_element  funetscan_list_get_element
	#define CHK_funetscan_list_get_element  TRUE
	#define EXP_funetscan_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_element", (RTS_UINTPTR)funetscan_list_get_element, 1, 0x92645CF6, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_funetscan_list_get_element  PFFUNETSCAN_LIST_GET_ELEMENT_IEC pffunetscan_list_get_element;
	#define EXT_funetscan_list_get_element  extern PFFUNETSCAN_LIST_GET_ELEMENT_IEC pffunetscan_list_get_element;
	#define GET_funetscan_list_get_element(fl)  s_pfCMGetAPI2( "funetscan_list_get_element", (RTS_VOID_FCTPTR *)&pffunetscan_list_get_element, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x92645CF6, 0x01010400)
	#define CAL_funetscan_list_get_element  pffunetscan_list_get_element
	#define CHK_funetscan_list_get_element  (pffunetscan_list_get_element != NULL)
	#define EXP_funetscan_list_get_element   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_element", (RTS_UINTPTR)funetscan_list_get_element, 1, 0x92645CF6, 0x01010400) 
#endif


/**
 * <description>funetscan_list_get_size</description>
 */
typedef struct tagfunetscan_list_get_size_struct
{
	RTS_IEC_INT FuNetscan_list_get_size;	/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_UINT uiSize;				/* VAR_OUTPUT */	
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} funetscan_list_get_size_struct;

void CDECL CDECL_EXT funetscan_list_get_size(funetscan_list_get_size_struct *p);
typedef void (CDECL CDECL_EXT* PFFUNETSCAN_LIST_GET_SIZE_IEC) (funetscan_list_get_size_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUNETSCAN_LIST_GET_SIZE_NOTIMPLEMENTED)
	#define USE_funetscan_list_get_size
	#define EXT_funetscan_list_get_size
	#define GET_funetscan_list_get_size(fl)  ERR_NOTIMPLEMENTED
	#define CAL_funetscan_list_get_size(p0) 
	#define CHK_funetscan_list_get_size  FALSE
	#define EXP_funetscan_list_get_size  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_funetscan_list_get_size
	#define EXT_funetscan_list_get_size
	#define GET_funetscan_list_get_size(fl)  CAL_CMGETAPI( "funetscan_list_get_size" ) 
	#define CAL_funetscan_list_get_size  funetscan_list_get_size
	#define CHK_funetscan_list_get_size  TRUE
	#define EXP_funetscan_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_size", (RTS_UINTPTR)funetscan_list_get_size, 1, 0x85624958, 0x01010400) 
	#define EXTREF_ITF_funetscan_list_get_size {(RTS_VOID_FCTPTR)funetscan_list_get_size, "funetscan_list_get_size", 0x85624958, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_funetscan_list_get_size
	#define EXT_funetscan_list_get_size
	#define GET_funetscan_list_get_size(fl)  CAL_CMGETAPI( "funetscan_list_get_size" ) 
	#define CAL_funetscan_list_get_size  funetscan_list_get_size
	#define CHK_funetscan_list_get_size  TRUE
	#define EXP_funetscan_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_size", (RTS_UINTPTR)funetscan_list_get_size, 1, 0x85624958, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfunetscan_list_get_size
	#define EXT_WagoSysModem_Internal_PFCfunetscan_list_get_size
	#define GET_WagoSysModem_Internal_PFCfunetscan_list_get_size  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfunetscan_list_get_size  funetscan_list_get_size
	#define CHK_WagoSysModem_Internal_PFCfunetscan_list_get_size  TRUE
	#define EXP_WagoSysModem_Internal_PFCfunetscan_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_size", (RTS_UINTPTR)funetscan_list_get_size, 1, 0x85624958, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_funetscan_list_get_size
	#define EXT_funetscan_list_get_size
	#define GET_funetscan_list_get_size(fl)  CAL_CMGETAPI( "funetscan_list_get_size" ) 
	#define CAL_funetscan_list_get_size  funetscan_list_get_size
	#define CHK_funetscan_list_get_size  TRUE
	#define EXP_funetscan_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_size", (RTS_UINTPTR)funetscan_list_get_size, 1, 0x85624958, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_funetscan_list_get_size  PFFUNETSCAN_LIST_GET_SIZE_IEC pffunetscan_list_get_size;
	#define EXT_funetscan_list_get_size  extern PFFUNETSCAN_LIST_GET_SIZE_IEC pffunetscan_list_get_size;
	#define GET_funetscan_list_get_size(fl)  s_pfCMGetAPI2( "funetscan_list_get_size", (RTS_VOID_FCTPTR *)&pffunetscan_list_get_size, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x85624958, 0x01010400)
	#define CAL_funetscan_list_get_size  pffunetscan_list_get_size
	#define CHK_funetscan_list_get_size  (pffunetscan_list_get_size != NULL)
	#define EXP_funetscan_list_get_size   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_get_size", (RTS_UINTPTR)funetscan_list_get_size, 1, 0x85624958, 0x01010400) 
#endif


/**
 *Run a netscan and refresh the list of found networks
 */
typedef struct tagfunetscan_list_refresh_struct
{
	RTS_IEC_INT FuNetscan_list_refresh;	/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} funetscan_list_refresh_struct;

void CDECL CDECL_EXT funetscan_list_refresh(funetscan_list_refresh_struct *p);
typedef void (CDECL CDECL_EXT* PFFUNETSCAN_LIST_REFRESH_IEC) (funetscan_list_refresh_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUNETSCAN_LIST_REFRESH_NOTIMPLEMENTED)
	#define USE_funetscan_list_refresh
	#define EXT_funetscan_list_refresh
	#define GET_funetscan_list_refresh(fl)  ERR_NOTIMPLEMENTED
	#define CAL_funetscan_list_refresh(p0) 
	#define CHK_funetscan_list_refresh  FALSE
	#define EXP_funetscan_list_refresh  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_funetscan_list_refresh
	#define EXT_funetscan_list_refresh
	#define GET_funetscan_list_refresh(fl)  CAL_CMGETAPI( "funetscan_list_refresh" ) 
	#define CAL_funetscan_list_refresh  funetscan_list_refresh
	#define CHK_funetscan_list_refresh  TRUE
	#define EXP_funetscan_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_refresh", (RTS_UINTPTR)funetscan_list_refresh, 1, 0xC4759637, 0x01010400) 
	#define EXTREF_ITF_funetscan_list_refresh {(RTS_VOID_FCTPTR)funetscan_list_refresh, "funetscan_list_refresh", 0xC4759637, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_funetscan_list_refresh
	#define EXT_funetscan_list_refresh
	#define GET_funetscan_list_refresh(fl)  CAL_CMGETAPI( "funetscan_list_refresh" ) 
	#define CAL_funetscan_list_refresh  funetscan_list_refresh
	#define CHK_funetscan_list_refresh  TRUE
	#define EXP_funetscan_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_refresh", (RTS_UINTPTR)funetscan_list_refresh, 1, 0xC4759637, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfunetscan_list_refresh
	#define EXT_WagoSysModem_Internal_PFCfunetscan_list_refresh
	#define GET_WagoSysModem_Internal_PFCfunetscan_list_refresh  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfunetscan_list_refresh  funetscan_list_refresh
	#define CHK_WagoSysModem_Internal_PFCfunetscan_list_refresh  TRUE
	#define EXP_WagoSysModem_Internal_PFCfunetscan_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_refresh", (RTS_UINTPTR)funetscan_list_refresh, 1, 0xC4759637, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_funetscan_list_refresh
	#define EXT_funetscan_list_refresh
	#define GET_funetscan_list_refresh(fl)  CAL_CMGETAPI( "funetscan_list_refresh" ) 
	#define CAL_funetscan_list_refresh  funetscan_list_refresh
	#define CHK_funetscan_list_refresh  TRUE
	#define EXP_funetscan_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_refresh", (RTS_UINTPTR)funetscan_list_refresh, 1, 0xC4759637, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_funetscan_list_refresh  PFFUNETSCAN_LIST_REFRESH_IEC pffunetscan_list_refresh;
	#define EXT_funetscan_list_refresh  extern PFFUNETSCAN_LIST_REFRESH_IEC pffunetscan_list_refresh;
	#define GET_funetscan_list_refresh(fl)  s_pfCMGetAPI2( "funetscan_list_refresh", (RTS_VOID_FCTPTR *)&pffunetscan_list_refresh, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC4759637, 0x01010400)
	#define CAL_funetscan_list_refresh  pffunetscan_list_refresh
	#define CHK_funetscan_list_refresh  (pffunetscan_list_refresh != NULL)
	#define EXP_funetscan_list_refresh   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"funetscan_list_refresh", (RTS_UINTPTR)funetscan_list_refresh, 1, 0xC4759637, 0x01010400) 
#endif


/**
 * <description>fureset_modem</description>
 */
typedef struct tagfureset_modem_struct
{
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
} fureset_modem_struct;

void CDECL CDECL_EXT fureset_modem(fureset_modem_struct *p);
typedef void (CDECL CDECL_EXT* PFFURESET_MODEM_IEC) (fureset_modem_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FURESET_MODEM_NOTIMPLEMENTED)
	#define USE_fureset_modem
	#define EXT_fureset_modem
	#define GET_fureset_modem(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fureset_modem(p0) 
	#define CHK_fureset_modem  FALSE
	#define EXP_fureset_modem  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fureset_modem
	#define EXT_fureset_modem
	#define GET_fureset_modem(fl)  CAL_CMGETAPI( "fureset_modem" ) 
	#define CAL_fureset_modem  fureset_modem
	#define CHK_fureset_modem  TRUE
	#define EXP_fureset_modem  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureset_modem", (RTS_UINTPTR)fureset_modem, 1, 0x17593D23, 0x01010400) 
	#define EXTREF_ITF_fureset_modem {(RTS_VOID_FCTPTR)fureset_modem, "fureset_modem", 0x17593D23, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fureset_modem
	#define EXT_fureset_modem
	#define GET_fureset_modem(fl)  CAL_CMGETAPI( "fureset_modem" ) 
	#define CAL_fureset_modem  fureset_modem
	#define CHK_fureset_modem  TRUE
	#define EXP_fureset_modem  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureset_modem", (RTS_UINTPTR)fureset_modem, 1, 0x17593D23, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfureset_modem
	#define EXT_WagoSysModem_Internal_PFCfureset_modem
	#define GET_WagoSysModem_Internal_PFCfureset_modem  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfureset_modem  fureset_modem
	#define CHK_WagoSysModem_Internal_PFCfureset_modem  TRUE
	#define EXP_WagoSysModem_Internal_PFCfureset_modem  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureset_modem", (RTS_UINTPTR)fureset_modem, 1, 0x17593D23, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fureset_modem
	#define EXT_fureset_modem
	#define GET_fureset_modem(fl)  CAL_CMGETAPI( "fureset_modem" ) 
	#define CAL_fureset_modem  fureset_modem
	#define CHK_fureset_modem  TRUE
	#define EXP_fureset_modem  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureset_modem", (RTS_UINTPTR)fureset_modem, 1, 0x17593D23, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fureset_modem  PFFURESET_MODEM_IEC pffureset_modem;
	#define EXT_fureset_modem  extern PFFURESET_MODEM_IEC pffureset_modem;
	#define GET_fureset_modem(fl)  s_pfCMGetAPI2( "fureset_modem", (RTS_VOID_FCTPTR *)&pffureset_modem, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x17593D23, 0x01010400)
	#define CAL_fureset_modem  pffureset_modem
	#define CHK_fureset_modem  (pffureset_modem != NULL)
	#define EXP_fureset_modem   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureset_modem", (RTS_UINTPTR)fureset_modem, 1, 0x17593D23, 0x01010400) 
#endif


/**
 * <description>fuset_network_registration_settings</description>
 */
typedef struct tagfuset_network_registration_settings_struct
{
	typNetworkRegistrationSettings typNetworkRegistrationSettings;	/* VAR_INPUT */	
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
} fuset_network_registration_settings_struct;

void CDECL CDECL_EXT fuset_network_registration_settings(fuset_network_registration_settings_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSET_NETWORK_REGISTRATION_SETTINGS_IEC) (fuset_network_registration_settings_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSET_NETWORK_REGISTRATION_SETTINGS_NOTIMPLEMENTED)
	#define USE_fuset_network_registration_settings
	#define EXT_fuset_network_registration_settings
	#define GET_fuset_network_registration_settings(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuset_network_registration_settings(p0) 
	#define CHK_fuset_network_registration_settings  FALSE
	#define EXP_fuset_network_registration_settings  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuset_network_registration_settings
	#define EXT_fuset_network_registration_settings
	#define GET_fuset_network_registration_settings(fl)  CAL_CMGETAPI( "fuset_network_registration_settings" ) 
	#define CAL_fuset_network_registration_settings  fuset_network_registration_settings
	#define CHK_fuset_network_registration_settings  TRUE
	#define EXP_fuset_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_network_registration_settings", (RTS_UINTPTR)fuset_network_registration_settings, 1, 0xCA846228, 0x01010400) 
	#define EXTREF_ITF_fuset_network_registration_settings {(RTS_VOID_FCTPTR)fuset_network_registration_settings, "fuset_network_registration_settings", 0xCA846228, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuset_network_registration_settings
	#define EXT_fuset_network_registration_settings
	#define GET_fuset_network_registration_settings(fl)  CAL_CMGETAPI( "fuset_network_registration_settings" ) 
	#define CAL_fuset_network_registration_settings  fuset_network_registration_settings
	#define CHK_fuset_network_registration_settings  TRUE
	#define EXP_fuset_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_network_registration_settings", (RTS_UINTPTR)fuset_network_registration_settings, 1, 0xCA846228, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuset_network_registration_settings
	#define EXT_WagoSysModem_Internal_PFCfuset_network_registration_settings
	#define GET_WagoSysModem_Internal_PFCfuset_network_registration_settings  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuset_network_registration_settings  fuset_network_registration_settings
	#define CHK_WagoSysModem_Internal_PFCfuset_network_registration_settings  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuset_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_network_registration_settings", (RTS_UINTPTR)fuset_network_registration_settings, 1, 0xCA846228, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuset_network_registration_settings
	#define EXT_fuset_network_registration_settings
	#define GET_fuset_network_registration_settings(fl)  CAL_CMGETAPI( "fuset_network_registration_settings" ) 
	#define CAL_fuset_network_registration_settings  fuset_network_registration_settings
	#define CHK_fuset_network_registration_settings  TRUE
	#define EXP_fuset_network_registration_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_network_registration_settings", (RTS_UINTPTR)fuset_network_registration_settings, 1, 0xCA846228, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuset_network_registration_settings  PFFUSET_NETWORK_REGISTRATION_SETTINGS_IEC pffuset_network_registration_settings;
	#define EXT_fuset_network_registration_settings  extern PFFUSET_NETWORK_REGISTRATION_SETTINGS_IEC pffuset_network_registration_settings;
	#define GET_fuset_network_registration_settings(fl)  s_pfCMGetAPI2( "fuset_network_registration_settings", (RTS_VOID_FCTPTR *)&pffuset_network_registration_settings, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCA846228, 0x01010400)
	#define CAL_fuset_network_registration_settings  pffuset_network_registration_settings
	#define CHK_fuset_network_registration_settings  (pffuset_network_registration_settings != NULL)
	#define EXP_fuset_network_registration_settings   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_network_registration_settings", (RTS_UINTPTR)fuset_network_registration_settings, 1, 0xCA846228, 0x01010400) 
#endif


/**
 * <description>fuset_sim_pin</description>
 */
typedef struct tagfuset_sim_pin_struct
{
	RTS_IEC_STRING sPin[9];				/* VAR_INPUT */	
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
} fuset_sim_pin_struct;

void CDECL CDECL_EXT fuset_sim_pin(fuset_sim_pin_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSET_SIM_PIN_IEC) (fuset_sim_pin_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSET_SIM_PIN_NOTIMPLEMENTED)
	#define USE_fuset_sim_pin
	#define EXT_fuset_sim_pin
	#define GET_fuset_sim_pin(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuset_sim_pin(p0) 
	#define CHK_fuset_sim_pin  FALSE
	#define EXP_fuset_sim_pin  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuset_sim_pin
	#define EXT_fuset_sim_pin
	#define GET_fuset_sim_pin(fl)  CAL_CMGETAPI( "fuset_sim_pin" ) 
	#define CAL_fuset_sim_pin  fuset_sim_pin
	#define CHK_fuset_sim_pin  TRUE
	#define EXP_fuset_sim_pin  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_pin", (RTS_UINTPTR)fuset_sim_pin, 1, 0x7E19344F, 0x01010400) 
	#define EXTREF_ITF_fuset_sim_pin {(RTS_VOID_FCTPTR)fuset_sim_pin, "fuset_sim_pin", 0x7E19344F, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuset_sim_pin
	#define EXT_fuset_sim_pin
	#define GET_fuset_sim_pin(fl)  CAL_CMGETAPI( "fuset_sim_pin" ) 
	#define CAL_fuset_sim_pin  fuset_sim_pin
	#define CHK_fuset_sim_pin  TRUE
	#define EXP_fuset_sim_pin  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_pin", (RTS_UINTPTR)fuset_sim_pin, 1, 0x7E19344F, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuset_sim_pin
	#define EXT_WagoSysModem_Internal_PFCfuset_sim_pin
	#define GET_WagoSysModem_Internal_PFCfuset_sim_pin  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuset_sim_pin  fuset_sim_pin
	#define CHK_WagoSysModem_Internal_PFCfuset_sim_pin  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuset_sim_pin  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_pin", (RTS_UINTPTR)fuset_sim_pin, 1, 0x7E19344F, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuset_sim_pin
	#define EXT_fuset_sim_pin
	#define GET_fuset_sim_pin(fl)  CAL_CMGETAPI( "fuset_sim_pin" ) 
	#define CAL_fuset_sim_pin  fuset_sim_pin
	#define CHK_fuset_sim_pin  TRUE
	#define EXP_fuset_sim_pin  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_pin", (RTS_UINTPTR)fuset_sim_pin, 1, 0x7E19344F, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuset_sim_pin  PFFUSET_SIM_PIN_IEC pffuset_sim_pin;
	#define EXT_fuset_sim_pin  extern PFFUSET_SIM_PIN_IEC pffuset_sim_pin;
	#define GET_fuset_sim_pin(fl)  s_pfCMGetAPI2( "fuset_sim_pin", (RTS_VOID_FCTPTR *)&pffuset_sim_pin, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7E19344F, 0x01010400)
	#define CAL_fuset_sim_pin  pffuset_sim_pin
	#define CHK_fuset_sim_pin  (pffuset_sim_pin != NULL)
	#define EXP_fuset_sim_pin   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_pin", (RTS_UINTPTR)fuset_sim_pin, 1, 0x7E19344F, 0x01010400) 
#endif


/**
 * <description>fuset_sim_puk</description>
 */
typedef struct tagfuset_sim_puk_struct
{
	RTS_IEC_STRING sPuk[9];				/* VAR_INPUT */	
	RTS_IEC_STRING sNewPin[9];			/* VAR_INPUT */	
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
} fuset_sim_puk_struct;

void CDECL CDECL_EXT fuset_sim_puk(fuset_sim_puk_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSET_SIM_PUK_IEC) (fuset_sim_puk_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSET_SIM_PUK_NOTIMPLEMENTED)
	#define USE_fuset_sim_puk
	#define EXT_fuset_sim_puk
	#define GET_fuset_sim_puk(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuset_sim_puk(p0) 
	#define CHK_fuset_sim_puk  FALSE
	#define EXP_fuset_sim_puk  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuset_sim_puk
	#define EXT_fuset_sim_puk
	#define GET_fuset_sim_puk(fl)  CAL_CMGETAPI( "fuset_sim_puk" ) 
	#define CAL_fuset_sim_puk  fuset_sim_puk
	#define CHK_fuset_sim_puk  TRUE
	#define EXP_fuset_sim_puk  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_puk", (RTS_UINTPTR)fuset_sim_puk, 1, 0x8D7F0616, 0x01010400) 
	#define EXTREF_ITF_fuset_sim_puk {(RTS_VOID_FCTPTR)fuset_sim_puk, "fuset_sim_puk", 0x8D7F0616, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuset_sim_puk
	#define EXT_fuset_sim_puk
	#define GET_fuset_sim_puk(fl)  CAL_CMGETAPI( "fuset_sim_puk" ) 
	#define CAL_fuset_sim_puk  fuset_sim_puk
	#define CHK_fuset_sim_puk  TRUE
	#define EXP_fuset_sim_puk  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_puk", (RTS_UINTPTR)fuset_sim_puk, 1, 0x8D7F0616, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuset_sim_puk
	#define EXT_WagoSysModem_Internal_PFCfuset_sim_puk
	#define GET_WagoSysModem_Internal_PFCfuset_sim_puk  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuset_sim_puk  fuset_sim_puk
	#define CHK_WagoSysModem_Internal_PFCfuset_sim_puk  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuset_sim_puk  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_puk", (RTS_UINTPTR)fuset_sim_puk, 1, 0x8D7F0616, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuset_sim_puk
	#define EXT_fuset_sim_puk
	#define GET_fuset_sim_puk(fl)  CAL_CMGETAPI( "fuset_sim_puk" ) 
	#define CAL_fuset_sim_puk  fuset_sim_puk
	#define CHK_fuset_sim_puk  TRUE
	#define EXP_fuset_sim_puk  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_puk", (RTS_UINTPTR)fuset_sim_puk, 1, 0x8D7F0616, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuset_sim_puk  PFFUSET_SIM_PUK_IEC pffuset_sim_puk;
	#define EXT_fuset_sim_puk  extern PFFUSET_SIM_PUK_IEC pffuset_sim_puk;
	#define GET_fuset_sim_puk(fl)  s_pfCMGetAPI2( "fuset_sim_puk", (RTS_VOID_FCTPTR *)&pffuset_sim_puk, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8D7F0616, 0x01010400)
	#define CAL_fuset_sim_puk  pffuset_sim_puk
	#define CHK_fuset_sim_puk  (pffuset_sim_puk != NULL)
	#define EXP_fuset_sim_puk   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_sim_puk", (RTS_UINTPTR)fuset_sim_puk, 1, 0x8D7F0616, 0x01010400) 
#endif


/**
 * <description>fuset_wds_enable</description>
 */
typedef struct tagfuset_wds_enable_struct
{
	RTS_IEC_BOOL xEnable;				/* VAR_INPUT */	
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
} fuset_wds_enable_struct;

void CDECL CDECL_EXT fuset_wds_enable(fuset_wds_enable_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSET_WDS_ENABLE_IEC) (fuset_wds_enable_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSET_WDS_ENABLE_NOTIMPLEMENTED)
	#define USE_fuset_wds_enable
	#define EXT_fuset_wds_enable
	#define GET_fuset_wds_enable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuset_wds_enable(p0) 
	#define CHK_fuset_wds_enable  FALSE
	#define EXP_fuset_wds_enable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuset_wds_enable
	#define EXT_fuset_wds_enable
	#define GET_fuset_wds_enable(fl)  CAL_CMGETAPI( "fuset_wds_enable" ) 
	#define CAL_fuset_wds_enable  fuset_wds_enable
	#define CHK_fuset_wds_enable  TRUE
	#define EXP_fuset_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_enable", (RTS_UINTPTR)fuset_wds_enable, 1, 0x532F3601, 0x01010400) 
	#define EXTREF_ITF_fuset_wds_enable {(RTS_VOID_FCTPTR)fuset_wds_enable, "fuset_wds_enable", 0x532F3601, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuset_wds_enable
	#define EXT_fuset_wds_enable
	#define GET_fuset_wds_enable(fl)  CAL_CMGETAPI( "fuset_wds_enable" ) 
	#define CAL_fuset_wds_enable  fuset_wds_enable
	#define CHK_fuset_wds_enable  TRUE
	#define EXP_fuset_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_enable", (RTS_UINTPTR)fuset_wds_enable, 1, 0x532F3601, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuset_wds_enable
	#define EXT_WagoSysModem_Internal_PFCfuset_wds_enable
	#define GET_WagoSysModem_Internal_PFCfuset_wds_enable  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuset_wds_enable  fuset_wds_enable
	#define CHK_WagoSysModem_Internal_PFCfuset_wds_enable  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuset_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_enable", (RTS_UINTPTR)fuset_wds_enable, 1, 0x532F3601, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuset_wds_enable
	#define EXT_fuset_wds_enable
	#define GET_fuset_wds_enable(fl)  CAL_CMGETAPI( "fuset_wds_enable" ) 
	#define CAL_fuset_wds_enable  fuset_wds_enable
	#define CHK_fuset_wds_enable  TRUE
	#define EXP_fuset_wds_enable  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_enable", (RTS_UINTPTR)fuset_wds_enable, 1, 0x532F3601, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuset_wds_enable  PFFUSET_WDS_ENABLE_IEC pffuset_wds_enable;
	#define EXT_fuset_wds_enable  extern PFFUSET_WDS_ENABLE_IEC pffuset_wds_enable;
	#define GET_fuset_wds_enable(fl)  s_pfCMGetAPI2( "fuset_wds_enable", (RTS_VOID_FCTPTR *)&pffuset_wds_enable, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x532F3601, 0x01010400)
	#define CAL_fuset_wds_enable  pffuset_wds_enable
	#define CHK_fuset_wds_enable  (pffuset_wds_enable != NULL)
	#define EXP_fuset_wds_enable   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_enable", (RTS_UINTPTR)fuset_wds_enable, 1, 0x532F3601, 0x01010400) 
#endif


/**
 * <description>fuset_wds_settings</description>
 */
typedef struct tagfuset_wds_settings_struct
{
	typWdsSettings typWdsSettings;		/* VAR_INPUT */	
	RTS_IEC_INT *pResult;				/* VAR_INPUT */	
	RTS_IEC_STRING *pResultText;		/* VAR_INPUT */	
	RTS_IEC_UINT uiResultTextSize;		/* VAR_INPUT */	
} fuset_wds_settings_struct;

void CDECL CDECL_EXT fuset_wds_settings(fuset_wds_settings_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSET_WDS_SETTINGS_IEC) (fuset_wds_settings_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSET_WDS_SETTINGS_NOTIMPLEMENTED)
	#define USE_fuset_wds_settings
	#define EXT_fuset_wds_settings
	#define GET_fuset_wds_settings(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuset_wds_settings(p0) 
	#define CHK_fuset_wds_settings  FALSE
	#define EXP_fuset_wds_settings  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuset_wds_settings
	#define EXT_fuset_wds_settings
	#define GET_fuset_wds_settings(fl)  CAL_CMGETAPI( "fuset_wds_settings" ) 
	#define CAL_fuset_wds_settings  fuset_wds_settings
	#define CHK_fuset_wds_settings  TRUE
	#define EXP_fuset_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_settings", (RTS_UINTPTR)fuset_wds_settings, 1, 0xB4F4E174, 0x01010400) 
	#define EXTREF_ITF_fuset_wds_settings {(RTS_VOID_FCTPTR)fuset_wds_settings, "fuset_wds_settings", 0xB4F4E174, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuset_wds_settings
	#define EXT_fuset_wds_settings
	#define GET_fuset_wds_settings(fl)  CAL_CMGETAPI( "fuset_wds_settings" ) 
	#define CAL_fuset_wds_settings  fuset_wds_settings
	#define CHK_fuset_wds_settings  TRUE
	#define EXP_fuset_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_settings", (RTS_UINTPTR)fuset_wds_settings, 1, 0xB4F4E174, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfuset_wds_settings
	#define EXT_WagoSysModem_Internal_PFCfuset_wds_settings
	#define GET_WagoSysModem_Internal_PFCfuset_wds_settings  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfuset_wds_settings  fuset_wds_settings
	#define CHK_WagoSysModem_Internal_PFCfuset_wds_settings  TRUE
	#define EXP_WagoSysModem_Internal_PFCfuset_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_settings", (RTS_UINTPTR)fuset_wds_settings, 1, 0xB4F4E174, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fuset_wds_settings
	#define EXT_fuset_wds_settings
	#define GET_fuset_wds_settings(fl)  CAL_CMGETAPI( "fuset_wds_settings" ) 
	#define CAL_fuset_wds_settings  fuset_wds_settings
	#define CHK_fuset_wds_settings  TRUE
	#define EXP_fuset_wds_settings  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_settings", (RTS_UINTPTR)fuset_wds_settings, 1, 0xB4F4E174, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fuset_wds_settings  PFFUSET_WDS_SETTINGS_IEC pffuset_wds_settings;
	#define EXT_fuset_wds_settings  extern PFFUSET_WDS_SETTINGS_IEC pffuset_wds_settings;
	#define GET_fuset_wds_settings(fl)  s_pfCMGetAPI2( "fuset_wds_settings", (RTS_VOID_FCTPTR *)&pffuset_wds_settings, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB4F4E174, 0x01010400)
	#define CAL_fuset_wds_settings  pffuset_wds_settings
	#define CHK_fuset_wds_settings  (pffuset_wds_settings != NULL)
	#define EXP_fuset_wds_settings   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuset_wds_settings", (RTS_UINTPTR)fuset_wds_settings, 1, 0xB4F4E174, 0x01010400) 
#endif


/**
 * <description>fusms_delete</description>
 */
typedef struct tagfusms_delete_struct
{
	RTS_IEC_UINT uiIndex;				/* VAR_INPUT */	/* Index of the sms in the storage location */
	RTS_IEC_INT FuSms_delete;			/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_delete_struct;

void CDECL CDECL_EXT fusms_delete(fusms_delete_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_DELETE_IEC) (fusms_delete_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_DELETE_NOTIMPLEMENTED)
	#define USE_fusms_delete
	#define EXT_fusms_delete
	#define GET_fusms_delete(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_delete(p0) 
	#define CHK_fusms_delete  FALSE
	#define EXP_fusms_delete  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_delete
	#define EXT_fusms_delete
	#define GET_fusms_delete(fl)  CAL_CMGETAPI( "fusms_delete" ) 
	#define CAL_fusms_delete  fusms_delete
	#define CHK_fusms_delete  TRUE
	#define EXP_fusms_delete  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_delete", (RTS_UINTPTR)fusms_delete, 1, 0xF9283C58, 0x01010400) 
	#define EXTREF_ITF_fusms_delete {(RTS_VOID_FCTPTR)fusms_delete, "fusms_delete", 0xF9283C58, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_delete
	#define EXT_fusms_delete
	#define GET_fusms_delete(fl)  CAL_CMGETAPI( "fusms_delete" ) 
	#define CAL_fusms_delete  fusms_delete
	#define CHK_fusms_delete  TRUE
	#define EXP_fusms_delete  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_delete", (RTS_UINTPTR)fusms_delete, 1, 0xF9283C58, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_delete
	#define EXT_WagoSysModem_Internal_PFCfusms_delete
	#define GET_WagoSysModem_Internal_PFCfusms_delete  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_delete  fusms_delete
	#define CHK_WagoSysModem_Internal_PFCfusms_delete  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_delete  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_delete", (RTS_UINTPTR)fusms_delete, 1, 0xF9283C58, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_delete
	#define EXT_fusms_delete
	#define GET_fusms_delete(fl)  CAL_CMGETAPI( "fusms_delete" ) 
	#define CAL_fusms_delete  fusms_delete
	#define CHK_fusms_delete  TRUE
	#define EXP_fusms_delete  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_delete", (RTS_UINTPTR)fusms_delete, 1, 0xF9283C58, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_delete  PFFUSMS_DELETE_IEC pffusms_delete;
	#define EXT_fusms_delete  extern PFFUSMS_DELETE_IEC pffusms_delete;
	#define GET_fusms_delete(fl)  s_pfCMGetAPI2( "fusms_delete", (RTS_VOID_FCTPTR *)&pffusms_delete, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xF9283C58, 0x01010400)
	#define CAL_fusms_delete  pffusms_delete
	#define CHK_fusms_delete  (pffusms_delete != NULL)
	#define EXP_fusms_delete   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_delete", (RTS_UINTPTR)fusms_delete, 1, 0xF9283C58, 0x01010400) 
#endif


/**
 * <description>fusms_list_get_element</description>
 */
typedef struct tagfusms_list_get_element_struct
{
	RTS_IEC_UINT uiIndex;				/* VAR_INPUT */	/* Index of the element in the sms_list with meta information */
	RTS_IEC_INT FuSms_list_get_element;	/* VAR_OUTPUT, Enum: ERESULT */
	typSmsMetaData SMSMetaData;			/* VAR_OUTPUT */	
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_list_get_element_struct;

void CDECL CDECL_EXT fusms_list_get_element(fusms_list_get_element_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_LIST_GET_ELEMENT_IEC) (fusms_list_get_element_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_LIST_GET_ELEMENT_NOTIMPLEMENTED)
	#define USE_fusms_list_get_element
	#define EXT_fusms_list_get_element
	#define GET_fusms_list_get_element(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_list_get_element(p0) 
	#define CHK_fusms_list_get_element  FALSE
	#define EXP_fusms_list_get_element  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_list_get_element
	#define EXT_fusms_list_get_element
	#define GET_fusms_list_get_element(fl)  CAL_CMGETAPI( "fusms_list_get_element" ) 
	#define CAL_fusms_list_get_element  fusms_list_get_element
	#define CHK_fusms_list_get_element  TRUE
	#define EXP_fusms_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_element", (RTS_UINTPTR)fusms_list_get_element, 1, 0x972C974C, 0x01010400) 
	#define EXTREF_ITF_fusms_list_get_element {(RTS_VOID_FCTPTR)fusms_list_get_element, "fusms_list_get_element", 0x972C974C, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_list_get_element
	#define EXT_fusms_list_get_element
	#define GET_fusms_list_get_element(fl)  CAL_CMGETAPI( "fusms_list_get_element" ) 
	#define CAL_fusms_list_get_element  fusms_list_get_element
	#define CHK_fusms_list_get_element  TRUE
	#define EXP_fusms_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_element", (RTS_UINTPTR)fusms_list_get_element, 1, 0x972C974C, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_list_get_element
	#define EXT_WagoSysModem_Internal_PFCfusms_list_get_element
	#define GET_WagoSysModem_Internal_PFCfusms_list_get_element  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_list_get_element  fusms_list_get_element
	#define CHK_WagoSysModem_Internal_PFCfusms_list_get_element  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_element", (RTS_UINTPTR)fusms_list_get_element, 1, 0x972C974C, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_list_get_element
	#define EXT_fusms_list_get_element
	#define GET_fusms_list_get_element(fl)  CAL_CMGETAPI( "fusms_list_get_element" ) 
	#define CAL_fusms_list_get_element  fusms_list_get_element
	#define CHK_fusms_list_get_element  TRUE
	#define EXP_fusms_list_get_element  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_element", (RTS_UINTPTR)fusms_list_get_element, 1, 0x972C974C, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_list_get_element  PFFUSMS_LIST_GET_ELEMENT_IEC pffusms_list_get_element;
	#define EXT_fusms_list_get_element  extern PFFUSMS_LIST_GET_ELEMENT_IEC pffusms_list_get_element;
	#define GET_fusms_list_get_element(fl)  s_pfCMGetAPI2( "fusms_list_get_element", (RTS_VOID_FCTPTR *)&pffusms_list_get_element, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x972C974C, 0x01010400)
	#define CAL_fusms_list_get_element  pffusms_list_get_element
	#define CHK_fusms_list_get_element  (pffusms_list_get_element != NULL)
	#define EXP_fusms_list_get_element   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_element", (RTS_UINTPTR)fusms_list_get_element, 1, 0x972C974C, 0x01010400) 
#endif


/**
 * <description>fusms_list_get_size</description>
 */
typedef struct tagfusms_list_get_size_struct
{
	RTS_IEC_INT FuSms_list_get_size;	/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_UINT uiSize;				/* VAR_OUTPUT */	
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_list_get_size_struct;

void CDECL CDECL_EXT fusms_list_get_size(fusms_list_get_size_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_LIST_GET_SIZE_IEC) (fusms_list_get_size_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_LIST_GET_SIZE_NOTIMPLEMENTED)
	#define USE_fusms_list_get_size
	#define EXT_fusms_list_get_size
	#define GET_fusms_list_get_size(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_list_get_size(p0) 
	#define CHK_fusms_list_get_size  FALSE
	#define EXP_fusms_list_get_size  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_list_get_size
	#define EXT_fusms_list_get_size
	#define GET_fusms_list_get_size(fl)  CAL_CMGETAPI( "fusms_list_get_size" ) 
	#define CAL_fusms_list_get_size  fusms_list_get_size
	#define CHK_fusms_list_get_size  TRUE
	#define EXP_fusms_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_size", (RTS_UINTPTR)fusms_list_get_size, 1, 0x2D8BA0E5, 0x01010400) 
	#define EXTREF_ITF_fusms_list_get_size {(RTS_VOID_FCTPTR)fusms_list_get_size, "fusms_list_get_size", 0x2D8BA0E5, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_list_get_size
	#define EXT_fusms_list_get_size
	#define GET_fusms_list_get_size(fl)  CAL_CMGETAPI( "fusms_list_get_size" ) 
	#define CAL_fusms_list_get_size  fusms_list_get_size
	#define CHK_fusms_list_get_size  TRUE
	#define EXP_fusms_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_size", (RTS_UINTPTR)fusms_list_get_size, 1, 0x2D8BA0E5, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_list_get_size
	#define EXT_WagoSysModem_Internal_PFCfusms_list_get_size
	#define GET_WagoSysModem_Internal_PFCfusms_list_get_size  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_list_get_size  fusms_list_get_size
	#define CHK_WagoSysModem_Internal_PFCfusms_list_get_size  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_size", (RTS_UINTPTR)fusms_list_get_size, 1, 0x2D8BA0E5, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_list_get_size
	#define EXT_fusms_list_get_size
	#define GET_fusms_list_get_size(fl)  CAL_CMGETAPI( "fusms_list_get_size" ) 
	#define CAL_fusms_list_get_size  fusms_list_get_size
	#define CHK_fusms_list_get_size  TRUE
	#define EXP_fusms_list_get_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_size", (RTS_UINTPTR)fusms_list_get_size, 1, 0x2D8BA0E5, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_list_get_size  PFFUSMS_LIST_GET_SIZE_IEC pffusms_list_get_size;
	#define EXT_fusms_list_get_size  extern PFFUSMS_LIST_GET_SIZE_IEC pffusms_list_get_size;
	#define GET_fusms_list_get_size(fl)  s_pfCMGetAPI2( "fusms_list_get_size", (RTS_VOID_FCTPTR *)&pffusms_list_get_size, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x2D8BA0E5, 0x01010400)
	#define CAL_fusms_list_get_size  pffusms_list_get_size
	#define CHK_fusms_list_get_size  (pffusms_list_get_size != NULL)
	#define EXP_fusms_list_get_size   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_get_size", (RTS_UINTPTR)fusms_list_get_size, 1, 0x2D8BA0E5, 0x01010400) 
#endif


/**
 *Referesh the sms_list and get a new list from the modem
 */
typedef struct tagfusms_list_refresh_struct
{
	RTS_IEC_INT FuSms_list_refresh;		/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_list_refresh_struct;

void CDECL CDECL_EXT fusms_list_refresh(fusms_list_refresh_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_LIST_REFRESH_IEC) (fusms_list_refresh_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_LIST_REFRESH_NOTIMPLEMENTED)
	#define USE_fusms_list_refresh
	#define EXT_fusms_list_refresh
	#define GET_fusms_list_refresh(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_list_refresh(p0) 
	#define CHK_fusms_list_refresh  FALSE
	#define EXP_fusms_list_refresh  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_list_refresh
	#define EXT_fusms_list_refresh
	#define GET_fusms_list_refresh(fl)  CAL_CMGETAPI( "fusms_list_refresh" ) 
	#define CAL_fusms_list_refresh  fusms_list_refresh
	#define CHK_fusms_list_refresh  TRUE
	#define EXP_fusms_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_refresh", (RTS_UINTPTR)fusms_list_refresh, 1, 0x1AAD551D, 0x01010400) 
	#define EXTREF_ITF_fusms_list_refresh {(RTS_VOID_FCTPTR)fusms_list_refresh, "fusms_list_refresh", 0x1AAD551D, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_list_refresh
	#define EXT_fusms_list_refresh
	#define GET_fusms_list_refresh(fl)  CAL_CMGETAPI( "fusms_list_refresh" ) 
	#define CAL_fusms_list_refresh  fusms_list_refresh
	#define CHK_fusms_list_refresh  TRUE
	#define EXP_fusms_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_refresh", (RTS_UINTPTR)fusms_list_refresh, 1, 0x1AAD551D, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_list_refresh
	#define EXT_WagoSysModem_Internal_PFCfusms_list_refresh
	#define GET_WagoSysModem_Internal_PFCfusms_list_refresh  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_list_refresh  fusms_list_refresh
	#define CHK_WagoSysModem_Internal_PFCfusms_list_refresh  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_refresh", (RTS_UINTPTR)fusms_list_refresh, 1, 0x1AAD551D, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_list_refresh
	#define EXT_fusms_list_refresh
	#define GET_fusms_list_refresh(fl)  CAL_CMGETAPI( "fusms_list_refresh" ) 
	#define CAL_fusms_list_refresh  fusms_list_refresh
	#define CHK_fusms_list_refresh  TRUE
	#define EXP_fusms_list_refresh  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_refresh", (RTS_UINTPTR)fusms_list_refresh, 1, 0x1AAD551D, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_list_refresh  PFFUSMS_LIST_REFRESH_IEC pffusms_list_refresh;
	#define EXT_fusms_list_refresh  extern PFFUSMS_LIST_REFRESH_IEC pffusms_list_refresh;
	#define GET_fusms_list_refresh(fl)  s_pfCMGetAPI2( "fusms_list_refresh", (RTS_VOID_FCTPTR *)&pffusms_list_refresh, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1AAD551D, 0x01010400)
	#define CAL_fusms_list_refresh  pffusms_list_refresh
	#define CHK_fusms_list_refresh  (pffusms_list_refresh != NULL)
	#define EXP_fusms_list_refresh   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_list_refresh", (RTS_UINTPTR)fusms_list_refresh, 1, 0x1AAD551D, 0x01010400) 
#endif


/**
 * <description>fusms_read_pdu</description>
 */
typedef struct tagfusms_read_pdu_struct
{
	RTS_IEC_UINT uiIndex;				/* VAR_INPUT */	/* Index of the sms in the storage location */
	RTS_IEC_INT FuSms_read_pdu;			/* VAR_OUTPUT, Enum: ERESULT */
	typSmsMsgPDU PDU;					/* VAR_OUTPUT */	
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_read_pdu_struct;

void CDECL CDECL_EXT fusms_read_pdu(fusms_read_pdu_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_READ_PDU_IEC) (fusms_read_pdu_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_READ_PDU_NOTIMPLEMENTED)
	#define USE_fusms_read_pdu
	#define EXT_fusms_read_pdu
	#define GET_fusms_read_pdu(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_read_pdu(p0) 
	#define CHK_fusms_read_pdu  FALSE
	#define EXP_fusms_read_pdu  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_read_pdu
	#define EXT_fusms_read_pdu
	#define GET_fusms_read_pdu(fl)  CAL_CMGETAPI( "fusms_read_pdu" ) 
	#define CAL_fusms_read_pdu  fusms_read_pdu
	#define CHK_fusms_read_pdu  TRUE
	#define EXP_fusms_read_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_pdu", (RTS_UINTPTR)fusms_read_pdu, 1, 0x6581A654, 0x01010400) 
	#define EXTREF_ITF_fusms_read_pdu {(RTS_VOID_FCTPTR)fusms_read_pdu, "fusms_read_pdu", 0x6581A654, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_read_pdu
	#define EXT_fusms_read_pdu
	#define GET_fusms_read_pdu(fl)  CAL_CMGETAPI( "fusms_read_pdu" ) 
	#define CAL_fusms_read_pdu  fusms_read_pdu
	#define CHK_fusms_read_pdu  TRUE
	#define EXP_fusms_read_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_pdu", (RTS_UINTPTR)fusms_read_pdu, 1, 0x6581A654, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_read_pdu
	#define EXT_WagoSysModem_Internal_PFCfusms_read_pdu
	#define GET_WagoSysModem_Internal_PFCfusms_read_pdu  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_read_pdu  fusms_read_pdu
	#define CHK_WagoSysModem_Internal_PFCfusms_read_pdu  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_read_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_pdu", (RTS_UINTPTR)fusms_read_pdu, 1, 0x6581A654, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_read_pdu
	#define EXT_fusms_read_pdu
	#define GET_fusms_read_pdu(fl)  CAL_CMGETAPI( "fusms_read_pdu" ) 
	#define CAL_fusms_read_pdu  fusms_read_pdu
	#define CHK_fusms_read_pdu  TRUE
	#define EXP_fusms_read_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_pdu", (RTS_UINTPTR)fusms_read_pdu, 1, 0x6581A654, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_read_pdu  PFFUSMS_READ_PDU_IEC pffusms_read_pdu;
	#define EXT_fusms_read_pdu  extern PFFUSMS_READ_PDU_IEC pffusms_read_pdu;
	#define GET_fusms_read_pdu(fl)  s_pfCMGetAPI2( "fusms_read_pdu", (RTS_VOID_FCTPTR *)&pffusms_read_pdu, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6581A654, 0x01010400)
	#define CAL_fusms_read_pdu  pffusms_read_pdu
	#define CHK_fusms_read_pdu  (pffusms_read_pdu != NULL)
	#define EXP_fusms_read_pdu   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_pdu", (RTS_UINTPTR)fusms_read_pdu, 1, 0x6581A654, 0x01010400) 
#endif


/**
 * <description>fusms_read_text</description>
 */
typedef struct tagfusms_read_text_struct
{
	RTS_IEC_UINT uiIndex;				/* VAR_INPUT */	/* Index of the sms in the storage location */
	RTS_IEC_INT FuSms_read_text;		/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_STRING sText[325];			/* VAR_OUTPUT */	
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_read_text_struct;

void CDECL CDECL_EXT fusms_read_text(fusms_read_text_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_READ_TEXT_IEC) (fusms_read_text_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_READ_TEXT_NOTIMPLEMENTED)
	#define USE_fusms_read_text
	#define EXT_fusms_read_text
	#define GET_fusms_read_text(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_read_text(p0) 
	#define CHK_fusms_read_text  FALSE
	#define EXP_fusms_read_text  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_read_text
	#define EXT_fusms_read_text
	#define GET_fusms_read_text(fl)  CAL_CMGETAPI( "fusms_read_text" ) 
	#define CAL_fusms_read_text  fusms_read_text
	#define CHK_fusms_read_text  TRUE
	#define EXP_fusms_read_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_text", (RTS_UINTPTR)fusms_read_text, 1, 0x406D88D7, 0x01010400) 
	#define EXTREF_ITF_fusms_read_text {(RTS_VOID_FCTPTR)fusms_read_text, "fusms_read_text", 0x406D88D7, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_read_text
	#define EXT_fusms_read_text
	#define GET_fusms_read_text(fl)  CAL_CMGETAPI( "fusms_read_text" ) 
	#define CAL_fusms_read_text  fusms_read_text
	#define CHK_fusms_read_text  TRUE
	#define EXP_fusms_read_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_text", (RTS_UINTPTR)fusms_read_text, 1, 0x406D88D7, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_read_text
	#define EXT_WagoSysModem_Internal_PFCfusms_read_text
	#define GET_WagoSysModem_Internal_PFCfusms_read_text  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_read_text  fusms_read_text
	#define CHK_WagoSysModem_Internal_PFCfusms_read_text  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_read_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_text", (RTS_UINTPTR)fusms_read_text, 1, 0x406D88D7, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_read_text
	#define EXT_fusms_read_text
	#define GET_fusms_read_text(fl)  CAL_CMGETAPI( "fusms_read_text" ) 
	#define CAL_fusms_read_text  fusms_read_text
	#define CHK_fusms_read_text  TRUE
	#define EXP_fusms_read_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_text", (RTS_UINTPTR)fusms_read_text, 1, 0x406D88D7, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_read_text  PFFUSMS_READ_TEXT_IEC pffusms_read_text;
	#define EXT_fusms_read_text  extern PFFUSMS_READ_TEXT_IEC pffusms_read_text;
	#define GET_fusms_read_text(fl)  s_pfCMGetAPI2( "fusms_read_text", (RTS_VOID_FCTPTR *)&pffusms_read_text, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x406D88D7, 0x01010400)
	#define CAL_fusms_read_text  pffusms_read_text
	#define CHK_fusms_read_text  (pffusms_read_text != NULL)
	#define EXP_fusms_read_text   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_read_text", (RTS_UINTPTR)fusms_read_text, 1, 0x406D88D7, 0x01010400) 
#endif


/**
 * <description>fusms_send_pdu</description>
 */
typedef struct tagfusms_send_pdu_struct
{
	RTS_IEC_BYTE aData[257];			/* VAR_INPUT */	
	RTS_IEC_UINT uiDataLength;			/* VAR_INPUT */	
	RTS_IEC_INT FuSms_send_pdu;			/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_send_pdu_struct;

void CDECL CDECL_EXT fusms_send_pdu(fusms_send_pdu_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_SEND_PDU_IEC) (fusms_send_pdu_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_SEND_PDU_NOTIMPLEMENTED)
	#define USE_fusms_send_pdu
	#define EXT_fusms_send_pdu
	#define GET_fusms_send_pdu(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_send_pdu(p0) 
	#define CHK_fusms_send_pdu  FALSE
	#define EXP_fusms_send_pdu  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_send_pdu
	#define EXT_fusms_send_pdu
	#define GET_fusms_send_pdu(fl)  CAL_CMGETAPI( "fusms_send_pdu" ) 
	#define CAL_fusms_send_pdu  fusms_send_pdu
	#define CHK_fusms_send_pdu  TRUE
	#define EXP_fusms_send_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_pdu", (RTS_UINTPTR)fusms_send_pdu, 1, 0x1063400F, 0x01010400) 
	#define EXTREF_ITF_fusms_send_pdu {(RTS_VOID_FCTPTR)fusms_send_pdu, "fusms_send_pdu", 0x1063400F, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_send_pdu
	#define EXT_fusms_send_pdu
	#define GET_fusms_send_pdu(fl)  CAL_CMGETAPI( "fusms_send_pdu" ) 
	#define CAL_fusms_send_pdu  fusms_send_pdu
	#define CHK_fusms_send_pdu  TRUE
	#define EXP_fusms_send_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_pdu", (RTS_UINTPTR)fusms_send_pdu, 1, 0x1063400F, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_send_pdu
	#define EXT_WagoSysModem_Internal_PFCfusms_send_pdu
	#define GET_WagoSysModem_Internal_PFCfusms_send_pdu  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_send_pdu  fusms_send_pdu
	#define CHK_WagoSysModem_Internal_PFCfusms_send_pdu  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_send_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_pdu", (RTS_UINTPTR)fusms_send_pdu, 1, 0x1063400F, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_send_pdu
	#define EXT_fusms_send_pdu
	#define GET_fusms_send_pdu(fl)  CAL_CMGETAPI( "fusms_send_pdu" ) 
	#define CAL_fusms_send_pdu  fusms_send_pdu
	#define CHK_fusms_send_pdu  TRUE
	#define EXP_fusms_send_pdu  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_pdu", (RTS_UINTPTR)fusms_send_pdu, 1, 0x1063400F, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_send_pdu  PFFUSMS_SEND_PDU_IEC pffusms_send_pdu;
	#define EXT_fusms_send_pdu  extern PFFUSMS_SEND_PDU_IEC pffusms_send_pdu;
	#define GET_fusms_send_pdu(fl)  s_pfCMGetAPI2( "fusms_send_pdu", (RTS_VOID_FCTPTR *)&pffusms_send_pdu, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1063400F, 0x01010400)
	#define CAL_fusms_send_pdu  pffusms_send_pdu
	#define CHK_fusms_send_pdu  (pffusms_send_pdu != NULL)
	#define EXP_fusms_send_pdu   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_pdu", (RTS_UINTPTR)fusms_send_pdu, 1, 0x1063400F, 0x01010400) 
#endif


/**
 * <description>fusms_send_text</description>
 */
typedef struct tagfusms_send_text_struct
{
	RTS_IEC_STRING sReceiverNumber[25];	/* VAR_INPUT */	
	RTS_IEC_STRING sSMSCNumber[25];		/* VAR_INPUT */	
	RTS_IEC_STRING sText[161];			/* VAR_INPUT */	
	RTS_IEC_INT FuSms_send_text;		/* VAR_OUTPUT, Enum: ERESULT */
	RTS_IEC_STRING sResultText[81];		/* VAR_OUTPUT */	
} fusms_send_text_struct;

void CDECL CDECL_EXT fusms_send_text(fusms_send_text_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSMS_SEND_TEXT_IEC) (fusms_send_text_struct *p);
#if defined(WAGOSYSMODEM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSMS_SEND_TEXT_NOTIMPLEMENTED)
	#define USE_fusms_send_text
	#define EXT_fusms_send_text
	#define GET_fusms_send_text(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fusms_send_text(p0) 
	#define CHK_fusms_send_text  FALSE
	#define EXP_fusms_send_text  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fusms_send_text
	#define EXT_fusms_send_text
	#define GET_fusms_send_text(fl)  CAL_CMGETAPI( "fusms_send_text" ) 
	#define CAL_fusms_send_text  fusms_send_text
	#define CHK_fusms_send_text  TRUE
	#define EXP_fusms_send_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_text", (RTS_UINTPTR)fusms_send_text, 1, 0x34DCC8D7, 0x01010400) 
	#define EXTREF_ITF_fusms_send_text {(RTS_VOID_FCTPTR)fusms_send_text, "fusms_send_text", 0x34DCC8D7, 0x01010400}
#elif defined(MIXED_LINK) && !defined(WAGOSYSMODEM_INTERNAL_PFC_EXTERNAL)
	#define USE_fusms_send_text
	#define EXT_fusms_send_text
	#define GET_fusms_send_text(fl)  CAL_CMGETAPI( "fusms_send_text" ) 
	#define CAL_fusms_send_text  fusms_send_text
	#define CHK_fusms_send_text  TRUE
	#define EXP_fusms_send_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_text", (RTS_UINTPTR)fusms_send_text, 1, 0x34DCC8D7, 0x01010400) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysModem_Internal_PFCfusms_send_text
	#define EXT_WagoSysModem_Internal_PFCfusms_send_text
	#define GET_WagoSysModem_Internal_PFCfusms_send_text  ERR_OK
	#define CAL_WagoSysModem_Internal_PFCfusms_send_text  fusms_send_text
	#define CHK_WagoSysModem_Internal_PFCfusms_send_text  TRUE
	#define EXP_WagoSysModem_Internal_PFCfusms_send_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_text", (RTS_UINTPTR)fusms_send_text, 1, 0x34DCC8D7, 0x01010400) 
#elif defined(CPLUSPLUS)
	#define USE_fusms_send_text
	#define EXT_fusms_send_text
	#define GET_fusms_send_text(fl)  CAL_CMGETAPI( "fusms_send_text" ) 
	#define CAL_fusms_send_text  fusms_send_text
	#define CHK_fusms_send_text  TRUE
	#define EXP_fusms_send_text  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_text", (RTS_UINTPTR)fusms_send_text, 1, 0x34DCC8D7, 0x01010400) 
#else /* DYNAMIC_LINK */
	#define USE_fusms_send_text  PFFUSMS_SEND_TEXT_IEC pffusms_send_text;
	#define EXT_fusms_send_text  extern PFFUSMS_SEND_TEXT_IEC pffusms_send_text;
	#define GET_fusms_send_text(fl)  s_pfCMGetAPI2( "fusms_send_text", (RTS_VOID_FCTPTR *)&pffusms_send_text, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x34DCC8D7, 0x01010400)
	#define CAL_fusms_send_text  pffusms_send_text
	#define CHK_fusms_send_text  (pffusms_send_text != NULL)
	#define EXP_fusms_send_text   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fusms_send_text", (RTS_UINTPTR)fusms_send_text, 1, 0x34DCC8D7, 0x01010400) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysModem_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysModem_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysModem_Internal_PFC
		#define ITF_WagoSysModem_Internal_PFC static IWagoSysModem_Internal_PFC *pIWagoSysModem_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysModem_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysModem_Internal_PFC_C		IWagoSysModem_Internal_PFC;
	#ifndef ITF_WagoSysModem_Internal_PFC
		#define ITF_WagoSysModem_Internal_PFC
	#endif
	#define EXTITF_WagoSysModem_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSMODEM_INTERNAL_PFCITF_H_*/
