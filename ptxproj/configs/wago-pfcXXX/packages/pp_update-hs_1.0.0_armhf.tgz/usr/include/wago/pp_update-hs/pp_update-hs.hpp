//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file
///
///  \brief    Header to provide parameters for update of head station.
///
///  \author   LHe : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef INCLUDE_WAGO_PP_UPDATE_HS_PP_UPDATE_HS_HPP_
#define INCLUDE_WAGO_PP_UPDATE_HS_PP_UPDATE_HS_HPP_

#include <wago/wdx/base_parameter_provider.hpp>
#include <wago/wdx/parameter_service_backend_i.hpp>
#include <wago/wdx/file_transfer/base_file_provider.hpp>

#include <string>
#include <vector>
#include <memory>

namespace wago
{
namespace pp_update_hs
{

class fwupdate_proxy_i;

class update_hs:
    public wago::wdx::base_parameter_provider
{

  public:

    update_hs(update_hs const&) = delete;
    update_hs const& operator=(update_hs const&) = delete;

    explicit update_hs(wago::wdx::parameter_service_backend_i* backend_p);
    update_hs(wago::wdx::parameter_service_backend_i* backend_p, std::shared_ptr<fwupdate_proxy_i> fwupdate_);
    ~update_hs() override = default;

    std::string display_name() override;
    wago::wdx::parameter_selector_response get_provided_parameters() override;
    wago::future<wago::wdx::method_invocation_response> invoke_method(wago::wdx::parameter_instance_id method_id,
                                                     std::vector<std::shared_ptr<wago::wdx::parameter_value>> in_args) override;
    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

  private:
    wago::wdx::parameter_service_backend_i *backend;
    std::shared_ptr<fwupdate_proxy_i> fwupdate;

    wago::future<std::vector<std::shared_ptr<wago::wdx::parameter_value>>> create_file_providers(std::vector<wago::wdx::parameter_value> values, wago::wdx::parameter_instance_id id);
    std::shared_ptr<std::vector<std::shared_ptr<wago::wdx::base_file_provider>>> file_providers;

    void activate(std::vector<std::shared_ptr<wago::wdx::parameter_value>> const & in_args, wago::wdx::method_invocation_response & result);
    void start(wago::wdx::method_invocation_response & result);
    void finish(wago::wdx::method_invocation_response & result);
    void cancel(wago::wdx::method_invocation_response & result);
    void clear(wago::wdx::method_invocation_response & result);
    void get_last_log_entries(std::vector<std::shared_ptr<wago::wdx::parameter_value>> const & in_args, wago::wdx::method_invocation_response & result);
    void set_timeout(std::vector<std::shared_ptr<wago::wdx::parameter_value>> const & in_args, wago::wdx::method_invocation_response & result);
    void set_custom_value(std::vector<std::shared_ptr<wago::wdx::parameter_value>> const & in_args, wago::wdx::method_invocation_response & result);
    void get_custom_value(std::vector<std::shared_ptr<wago::wdx::parameter_value>> const &in_args, wago::wdx::method_invocation_response & result);
    void unregister_fileprovider(wago::wdx::method_invocation_response & result);
};

}
}

#endif /* INCLUDE_WAGO_PP_UPDATE_HS_PP_UPDATE_HS_HPP_ */

