//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libwserial_error.hpp
///
///  \brief    Library for controlling serial port
///
///  \author   TBi : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef INC_LIBWSERIAL_ERROR_H_
#define INC_LIBWSERIAL_ERROR_H_

#include <exception>
#include <string>

namespace wago {
namespace libwserial {

class libwserial_error : public std::exception {
public:
	explicit libwserial_error(std::string error_message) noexcept
		: m_error_message(std::move(error_message)) {}
	const char *what() const noexcept override {
		return m_error_message.c_str();
	}
private:
	std::string m_error_message;
};

} // namespace libwserial
} // namespace wago

#endif /* INC_LIBWSERIAL_ERROR_H_ */
