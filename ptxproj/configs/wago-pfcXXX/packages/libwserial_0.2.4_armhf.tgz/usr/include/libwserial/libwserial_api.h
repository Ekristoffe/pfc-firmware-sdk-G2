//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libwserial_api.h
///
///  \brief    Library for controlling serial port
///
///  \author   TBi : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_LIBWSERIAL_API_H_
#define INC_LIBWSERIAL_API_H_

#include "wc/api_export.h"

// Tell compiler and linker that the functions declared with this macro should
// not be removed from the .so API. LIBWSERIAL_API will be set to WC_API_EXPORT
// when the implementing project is compiled.
#ifndef LIBWSERIAL_API
  #define LIBWSERIAL_API
#endif

#endif /* INC_LIBWSERIAL_API_H_ */

