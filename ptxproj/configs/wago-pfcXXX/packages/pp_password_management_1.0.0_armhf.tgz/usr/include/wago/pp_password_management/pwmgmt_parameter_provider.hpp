//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     pwmgmt_parameter_provider.hpp
///
///  \brief    This parameter providers allows to manage p settings.
///
///  \author   BA : WAGO GmbH & Co. KG
///            WF : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_PP_PASSWORD_MANAGEMENT_PWMGMT_PARAMETER_PROVIDER_HPP
#define INCLUDE_WAGO_PP_PASSWORD_MANAGEMENT_PWMGMT_PARAMETER_PROVIDER_HPP

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>


namespace wago::pp_password_management
{

/// \class pwmgmt_parameter_provider
/// \brief This parameter providers allows to manage user settings.
class pwmgmt_parameter_provider final
    : public wago::wdx::base_parameter_provider
{
    pwmgmt_parameter_provider(pwmgmt_parameter_provider const &) = delete;
    pwmgmt_parameter_provider& operator=(pwmgmt_parameter_provider const &) = delete;
public:
    pwmgmt_parameter_provider();
    ~pwmgmt_parameter_provider() override;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
        std::vector<wago::wdx::value_request> value_requests) override;

    future<wdx::method_invocation_response> invoke_method(
        wdx::parameter_instance_id method_id, std::vector<std::shared_ptr<wdx::parameter_value>> in_args) override;

private:
    class detail;
    detail * d_ptr;
};

} // namespace wago::pp_password_management

#endif // INCLUDE_WAGO_PP_PASSWORD_MANAGEMENT_PWMGMT_PARAMETER_PROVIDER_HPP

//---- End of source file ------------------------------------------------------
