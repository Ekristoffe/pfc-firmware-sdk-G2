 //---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     http://svsv01003/svn/repo3/pfc/trunk/wago_intern/codesys3-Component/Include/TscInterfaces/WagoSysKbusTerminalControl_Internal_PFCItf.m4 (.h) 
///
/// \version  $Rev$
///
/// \brief    target specific component to support dynamic module configuration; iec- and fw-interface
///
/// \author   u015479 / WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------

	
	
#ifndef _WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFCITF_H_
#define _WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




#include "WagoSysKbusTerminalControl_Internal_CommonItf.h"

/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Function calculates module slot number
 *
 * Function calculates module slot number for asynchronous module 
 * access. Function uses given configured connector to calculate 
 * slot number. 
 *
 * Result codes:
 *   ERR_OK               Slot number calculated
 *   ERR_FAILED           Internal error
 *   ERR_PARAMETER        pConnector or pudiSlotNo was NULL
 *   ERR_INVALID_HANDLE   hIoDrv was invalid
 *   ERR_NOT_SUPPORTED    Driver does not support function
 *   ERR_TYPE_MISMATCH    Connector type not supported
 *   ERR_NOTINITIALIZED   No static configuration found
 *   ERR_DEVICE           No slot number for current module available
 */
typedef struct tagfuiodrvcalculateslotnumber_struct
{
  RTS_IEC_HANDLE hIoDrv;                      /* VAR_INPUT */   /* input:  registered instance handle of the IO-driver, that operates device respectively connector */
  IoConfigConnector *pConnector;              /* VAR_INPUT */   /* input:  pointer to static configured connector of traget KBUS modul */
  RTS_IEC_UDINT *udiSlotNo;                   /* VAR_IN_OUT */  /* output: slot number of traget KBUS modul */
  RTS_IEC_RESULT FuIoDrvCalculateSlotNumber;  /* VAR_OUTPUT */
} fuiodrvcalculateslotnumber_struct;

void CDECL CDECL_EXT fuiodrvcalculateslotnumber(fuiodrvcalculateslotnumber_struct *p);
typedef void (CDECL CDECL_EXT* PFFUIODRVCALCULATESLOTNUMBER_IEC) (fuiodrvcalculateslotnumber_struct *p);
#if defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUIODRVCALCULATESLOTNUMBER_NOTIMPLEMENTED)
	#define USE_fuiodrvcalculateslotnumber
	#define EXT_fuiodrvcalculateslotnumber
	#define GET_fuiodrvcalculateslotnumber(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuiodrvcalculateslotnumber(p0) 
	#define CHK_fuiodrvcalculateslotnumber  FALSE
	#define EXP_fuiodrvcalculateslotnumber  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuiodrvcalculateslotnumber
	#define EXT_fuiodrvcalculateslotnumber
	#define GET_fuiodrvcalculateslotnumber(fl)  CAL_CMGETAPI( "fuiodrvcalculateslotnumber" ) 
	#define CAL_fuiodrvcalculateslotnumber  fuiodrvcalculateslotnumber
	#define CHK_fuiodrvcalculateslotnumber  TRUE
	#define EXP_fuiodrvcalculateslotnumber  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvcalculateslotnumber", (RTS_UINTPTR)fuiodrvcalculateslotnumber, 1, RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000) 
	#define EXTREF_ITF_fuiodrvcalculateslotnumber {(RTS_VOID_FCTPTR)fuiodrvcalculateslotnumber, "fuiodrvcalculateslotnumber", RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_EXTERNAL)
	#define USE_fuiodrvcalculateslotnumber
	#define EXT_fuiodrvcalculateslotnumber
	#define GET_fuiodrvcalculateslotnumber(fl)  CAL_CMGETAPI( "fuiodrvcalculateslotnumber" ) 
	#define CAL_fuiodrvcalculateslotnumber  fuiodrvcalculateslotnumber
	#define CHK_fuiodrvcalculateslotnumber  TRUE
	#define EXP_fuiodrvcalculateslotnumber  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvcalculateslotnumber", (RTS_UINTPTR)fuiodrvcalculateslotnumber, 1, RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusTerminalControl_Internal_PFCfuiodrvcalculateslotnumber
	#define EXT_WagoSysKbusTerminalControl_Internal_PFCfuiodrvcalculateslotnumber
	#define GET_WagoSysKbusTerminalControl_Internal_PFCfuiodrvcalculateslotnumber  ERR_OK
	#define CAL_WagoSysKbusTerminalControl_Internal_PFCfuiodrvcalculateslotnumber  fuiodrvcalculateslotnumber
	#define CHK_WagoSysKbusTerminalControl_Internal_PFCfuiodrvcalculateslotnumber  TRUE
	#define EXP_WagoSysKbusTerminalControl_Internal_PFCfuiodrvcalculateslotnumber  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvcalculateslotnumber", (RTS_UINTPTR)fuiodrvcalculateslotnumber, 1, RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fuiodrvcalculateslotnumber
	#define EXT_fuiodrvcalculateslotnumber
	#define GET_fuiodrvcalculateslotnumber(fl)  CAL_CMGETAPI( "fuiodrvcalculateslotnumber" ) 
	#define CAL_fuiodrvcalculateslotnumber  fuiodrvcalculateslotnumber
	#define CHK_fuiodrvcalculateslotnumber  TRUE
	#define EXP_fuiodrvcalculateslotnumber  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvcalculateslotnumber", (RTS_UINTPTR)fuiodrvcalculateslotnumber, 1, RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fuiodrvcalculateslotnumber  PFFUIODRVCALCULATESLOTNUMBER_IEC pffuiodrvcalculateslotnumber;
	#define EXT_fuiodrvcalculateslotnumber  extern PFFUIODRVCALCULATESLOTNUMBER_IEC pffuiodrvcalculateslotnumber;
	#define GET_fuiodrvcalculateslotnumber(fl)  s_pfCMGetAPI2( "fuiodrvcalculateslotnumber", (RTS_VOID_FCTPTR *)&pffuiodrvcalculateslotnumber, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000)
	#define CAL_fuiodrvcalculateslotnumber  pffuiodrvcalculateslotnumber
	#define CHK_fuiodrvcalculateslotnumber  (pffuiodrvcalculateslotnumber != NULL)
	#define EXP_fuiodrvcalculateslotnumber   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvcalculateslotnumber", (RTS_UINTPTR)fuiodrvcalculateslotnumber, 1, RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000) 
#endif


/**
 * Function reads module configuration resp. module data mapping state
 *
 * Function reads module configuration state and module data mapping 
 * state. Function uses given configured connector to address module.
 *
 * Result codes:
 *   ERR_OK               Valid state information for current module
 *   ERR_FAILED           Internal error
 *   ERR_PARAMETER        pConnector, eCnfSts or eMapSts was NULL
 *   ERR_INVALID_HANDLE   hIoDrv was invalid
 *   ERR_NOT_SUPPORTED    Driver does not support function
 *   ERR_TYPE_MISMATCH    Connector type not supported
 *   ERR_NOTINITIALIZED   No static configuration found
 *   ERR_DEVICE           No state information for current module available 
 */
typedef struct tagfuiodrvgetconfmapstate_struct
{
  RTS_IEC_HANDLE hIoDrv;                  /* VAR_INPUT */   /* input:  registered instance handle of the IO-driver, that operates device respectively connector */
  IoConfigConnector *pConnector;          /* VAR_INPUT */   /* input:  pointer to static configured connector of traget KBUS modul */
  ECONFIG_STS *eCnfSts;                   /* VAR_IN_OUT */  /* output: modul configuration state */
  EMAPPING_STS *eMapSts;                  /* VAR_IN_OUT */  /* output: modul data mapping state */
  RTS_IEC_RESULT FuIoDrvGetConfMapState;  /* VAR_OUTPUT */
} fuiodrvgetconfmapstate_struct;

void CDECL CDECL_EXT fuiodrvgetconfmapstate(fuiodrvgetconfmapstate_struct *p);
typedef void (CDECL CDECL_EXT* PFFUIODRVGETCONFMAPSTATE_IEC) (fuiodrvgetconfmapstate_struct *p);
#if defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUIODRVGETCONFMAPSTATE_NOTIMPLEMENTED)
	#define USE_fuiodrvgetconfmapstate
	#define EXT_fuiodrvgetconfmapstate
	#define GET_fuiodrvgetconfmapstate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuiodrvgetconfmapstate(p0) 
	#define CHK_fuiodrvgetconfmapstate  FALSE
	#define EXP_fuiodrvgetconfmapstate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuiodrvgetconfmapstate
	#define EXT_fuiodrvgetconfmapstate
	#define GET_fuiodrvgetconfmapstate(fl)  CAL_CMGETAPI( "fuiodrvgetconfmapstate" ) 
	#define CAL_fuiodrvgetconfmapstate  fuiodrvgetconfmapstate
	#define CHK_fuiodrvgetconfmapstate  TRUE
	#define EXP_fuiodrvgetconfmapstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvgetconfmapstate", (RTS_UINTPTR)fuiodrvgetconfmapstate, 1, RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000) 
	#define EXTREF_ITF_fuiodrvgetconfmapstate {(RTS_VOID_FCTPTR)fuiodrvgetconfmapstate, "fuiodrvgetconfmapstate", RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_EXTERNAL)
	#define USE_fuiodrvgetconfmapstate
	#define EXT_fuiodrvgetconfmapstate
	#define GET_fuiodrvgetconfmapstate(fl)  CAL_CMGETAPI( "fuiodrvgetconfmapstate" ) 
	#define CAL_fuiodrvgetconfmapstate  fuiodrvgetconfmapstate
	#define CHK_fuiodrvgetconfmapstate  TRUE
	#define EXP_fuiodrvgetconfmapstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvgetconfmapstate", (RTS_UINTPTR)fuiodrvgetconfmapstate, 1, RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusTerminalControl_Internal_PFCfuiodrvgetconfmapstate
	#define EXT_WagoSysKbusTerminalControl_Internal_PFCfuiodrvgetconfmapstate
	#define GET_WagoSysKbusTerminalControl_Internal_PFCfuiodrvgetconfmapstate  ERR_OK
	#define CAL_WagoSysKbusTerminalControl_Internal_PFCfuiodrvgetconfmapstate  fuiodrvgetconfmapstate
	#define CHK_WagoSysKbusTerminalControl_Internal_PFCfuiodrvgetconfmapstate  TRUE
	#define EXP_WagoSysKbusTerminalControl_Internal_PFCfuiodrvgetconfmapstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvgetconfmapstate", (RTS_UINTPTR)fuiodrvgetconfmapstate, 1, RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fuiodrvgetconfmapstate
	#define EXT_fuiodrvgetconfmapstate
	#define GET_fuiodrvgetconfmapstate(fl)  CAL_CMGETAPI( "fuiodrvgetconfmapstate" ) 
	#define CAL_fuiodrvgetconfmapstate  fuiodrvgetconfmapstate
	#define CHK_fuiodrvgetconfmapstate  TRUE
	#define EXP_fuiodrvgetconfmapstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvgetconfmapstate", (RTS_UINTPTR)fuiodrvgetconfmapstate, 1, RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fuiodrvgetconfmapstate  PFFUIODRVGETCONFMAPSTATE_IEC pffuiodrvgetconfmapstate;
	#define EXT_fuiodrvgetconfmapstate  extern PFFUIODRVGETCONFMAPSTATE_IEC pffuiodrvgetconfmapstate;
	#define GET_fuiodrvgetconfmapstate(fl)  s_pfCMGetAPI2( "fuiodrvgetconfmapstate", (RTS_VOID_FCTPTR *)&pffuiodrvgetconfmapstate, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000)
	#define CAL_fuiodrvgetconfmapstate  pffuiodrvgetconfmapstate
	#define CHK_fuiodrvgetconfmapstate  (pffuiodrvgetconfmapstate != NULL)
	#define EXP_fuiodrvgetconfmapstate   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvgetconfmapstate", (RTS_UINTPTR)fuiodrvgetconfmapstate, 1, RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000) 
#endif


/**
 * Function provides dynamic module configuration
 *
 * Function extends existing static module configuration.  
 * Dynamic added configuration can be dynamic or static 
 * removed. Function uses given connector list including 
 * target module connector with parameter (4) slot number. 
 *
 * Result codes:
 *   ERR_OK               Dynamic configuration evaluated
 *   ERR_FAILED           Internal error
 *   ERR_PARAMETER        pConnectorList or nCount was NULL
 *   ERR_INVALID_HANDLE   hIoDrv was invalid
 *   ERR_NOT_SUPPORTED    Driver does not support function
 *   ERR_TYPE_MISMATCH    At least one connector with unsupported type in list
 *   ERR_NOTINITIALIZED   No static configuration found
 */
typedef struct tagfuiodrvupdateconfiguration_dynamic_struct
{
  RTS_IEC_HANDLE hIoDrv;                              /* VAR_INPUT */   /* input:  registered instance handle of the IO-driver, that operates device respectively connector list */
  IoConfigConnector *pConnectorList;                  /* VAR_INPUT */   /* input:  pointer to list of connectors */
  RTS_IEC_DINT nCount;                                /* VAR_INPUT */   /* input:  number of connectors in list */
  ECONFIG_CTRL eCtrl;                                 /* VAR_INPUT */   /* input:  control update configuration */
  RTS_IEC_RESULT FuIoDrvUpdateConfiguration_dynamic;  /* VAR_OUTPUT */
} fuiodrvupdateconfiguration_dynamic_struct;

void CDECL CDECL_EXT fuiodrvupdateconfiguration_dynamic(fuiodrvupdateconfiguration_dynamic_struct *p);
typedef void (CDECL CDECL_EXT* PFFUIODRVUPDATECONFIGURATION_DYNAMIC_IEC) (fuiodrvupdateconfiguration_dynamic_struct *p);
#if defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUIODRVUPDATECONFIGURATION_DYNAMIC_NOTIMPLEMENTED)
	#define USE_fuiodrvupdateconfiguration_dynamic
	#define EXT_fuiodrvupdateconfiguration_dynamic
	#define GET_fuiodrvupdateconfiguration_dynamic(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuiodrvupdateconfiguration_dynamic(p0) 
	#define CHK_fuiodrvupdateconfiguration_dynamic  FALSE
	#define EXP_fuiodrvupdateconfiguration_dynamic  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuiodrvupdateconfiguration_dynamic
	#define EXT_fuiodrvupdateconfiguration_dynamic
	#define GET_fuiodrvupdateconfiguration_dynamic(fl)  CAL_CMGETAPI( "fuiodrvupdateconfiguration_dynamic" ) 
	#define CAL_fuiodrvupdateconfiguration_dynamic  fuiodrvupdateconfiguration_dynamic
	#define CHK_fuiodrvupdateconfiguration_dynamic  TRUE
	#define EXP_fuiodrvupdateconfiguration_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdateconfiguration_dynamic", (RTS_UINTPTR)fuiodrvupdateconfiguration_dynamic, 1, RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000) 
	#define EXTREF_ITF_fuiodrvupdateconfiguration_dynamic {(RTS_VOID_FCTPTR)fuiodrvupdateconfiguration_dynamic, "fuiodrvupdateconfiguration_dynamic", RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_EXTERNAL)
	#define USE_fuiodrvupdateconfiguration_dynamic
	#define EXT_fuiodrvupdateconfiguration_dynamic
	#define GET_fuiodrvupdateconfiguration_dynamic(fl)  CAL_CMGETAPI( "fuiodrvupdateconfiguration_dynamic" ) 
	#define CAL_fuiodrvupdateconfiguration_dynamic  fuiodrvupdateconfiguration_dynamic
	#define CHK_fuiodrvupdateconfiguration_dynamic  TRUE
	#define EXP_fuiodrvupdateconfiguration_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdateconfiguration_dynamic", (RTS_UINTPTR)fuiodrvupdateconfiguration_dynamic, 1, RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdateconfiguration_dynamic
	#define EXT_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdateconfiguration_dynamic
	#define GET_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdateconfiguration_dynamic  ERR_OK
	#define CAL_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdateconfiguration_dynamic  fuiodrvupdateconfiguration_dynamic
	#define CHK_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdateconfiguration_dynamic  TRUE
	#define EXP_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdateconfiguration_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdateconfiguration_dynamic", (RTS_UINTPTR)fuiodrvupdateconfiguration_dynamic, 1, RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fuiodrvupdateconfiguration_dynamic
	#define EXT_fuiodrvupdateconfiguration_dynamic
	#define GET_fuiodrvupdateconfiguration_dynamic(fl)  CAL_CMGETAPI( "fuiodrvupdateconfiguration_dynamic" ) 
	#define CAL_fuiodrvupdateconfiguration_dynamic  fuiodrvupdateconfiguration_dynamic
	#define CHK_fuiodrvupdateconfiguration_dynamic  TRUE
	#define EXP_fuiodrvupdateconfiguration_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdateconfiguration_dynamic", (RTS_UINTPTR)fuiodrvupdateconfiguration_dynamic, 1, RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fuiodrvupdateconfiguration_dynamic  PFFUIODRVUPDATECONFIGURATION_DYNAMIC_IEC pffuiodrvupdateconfiguration_dynamic;
	#define EXT_fuiodrvupdateconfiguration_dynamic  extern PFFUIODRVUPDATECONFIGURATION_DYNAMIC_IEC pffuiodrvupdateconfiguration_dynamic;
	#define GET_fuiodrvupdateconfiguration_dynamic(fl)  s_pfCMGetAPI2( "fuiodrvupdateconfiguration_dynamic", (RTS_VOID_FCTPTR *)&pffuiodrvupdateconfiguration_dynamic, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000)
	#define CAL_fuiodrvupdateconfiguration_dynamic  pffuiodrvupdateconfiguration_dynamic
	#define CHK_fuiodrvupdateconfiguration_dynamic  (pffuiodrvupdateconfiguration_dynamic != NULL)
	#define EXP_fuiodrvupdateconfiguration_dynamic   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdateconfiguration_dynamic", (RTS_UINTPTR)fuiodrvupdateconfiguration_dynamic, 1, RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000) 
#endif


/**
 * Function provides dynamic module mapping
 *
 * Function updates unmapped modules. Function uses given 
 * task map list including task map for target module.
 *
 * Result codes:
 *   ERR_OK               Dynamic mapping evaluated
 *   ERR_FAILED           Internal error
 *   ERR_PARAMETER        pTaskMapList or nCount was NULL
 *   ERR_INVALID_HANDLE   hIoDrv was invalid
 *   ERR_NOT_SUPPORTED    Driver does not support function
 *   ERR_NOTINITIALIZED   No static mapping found
 */
typedef struct tagfuiodrvupdatemapping_dynamic_struct
{
  RTS_IEC_HANDLE hIoDrv;                        /* VAR_INPUT */   /* input:  registered instance handle of the IO-driver, that operates device respectively task map list */
  IoConfigTaskMap *pTaskMapList;                /* VAR_INPUT */   /* input:  pointer to list of task mappings */
  RTS_IEC_DINT nCount;                          /* VAR_INPUT */   /* input:  number of task mappings in list */
  EMAPPING_CTRL eCtrl;                          /* VAR_INPUT */   /* input:  control update mapping */
  RTS_IEC_RESULT FuIoDrvUpdateMapping_dynamic;  /* VAR_OUTPUT */  
} fuiodrvupdatemapping_dynamic_struct;

void CDECL CDECL_EXT fuiodrvupdatemapping_dynamic(fuiodrvupdatemapping_dynamic_struct *p);
typedef void (CDECL CDECL_EXT* PFFUIODRVUPDATEMAPPING_DYNAMIC_IEC) (fuiodrvupdatemapping_dynamic_struct *p);
#if defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUIODRVUPDATEMAPPING_DYNAMIC_NOTIMPLEMENTED)
	#define USE_fuiodrvupdatemapping_dynamic
	#define EXT_fuiodrvupdatemapping_dynamic
	#define GET_fuiodrvupdatemapping_dynamic(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuiodrvupdatemapping_dynamic(p0) 
	#define CHK_fuiodrvupdatemapping_dynamic  FALSE
	#define EXP_fuiodrvupdatemapping_dynamic  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuiodrvupdatemapping_dynamic
	#define EXT_fuiodrvupdatemapping_dynamic
	#define GET_fuiodrvupdatemapping_dynamic(fl)  CAL_CMGETAPI( "fuiodrvupdatemapping_dynamic" ) 
	#define CAL_fuiodrvupdatemapping_dynamic  fuiodrvupdatemapping_dynamic
	#define CHK_fuiodrvupdatemapping_dynamic  TRUE
	#define EXP_fuiodrvupdatemapping_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdatemapping_dynamic", (RTS_UINTPTR)fuiodrvupdatemapping_dynamic, 1, RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000) 
	#define EXTREF_ITF_fuiodrvupdatemapping_dynamic {(RTS_VOID_FCTPTR)fuiodrvupdatemapping_dynamic, "fuiodrvupdatemapping_dynamic", RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFC_EXTERNAL)
	#define USE_fuiodrvupdatemapping_dynamic
	#define EXT_fuiodrvupdatemapping_dynamic
	#define GET_fuiodrvupdatemapping_dynamic(fl)  CAL_CMGETAPI( "fuiodrvupdatemapping_dynamic" ) 
	#define CAL_fuiodrvupdatemapping_dynamic  fuiodrvupdatemapping_dynamic
	#define CHK_fuiodrvupdatemapping_dynamic  TRUE
	#define EXP_fuiodrvupdatemapping_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdatemapping_dynamic", (RTS_UINTPTR)fuiodrvupdatemapping_dynamic, 1, RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdatemapping_dynamic
	#define EXT_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdatemapping_dynamic
	#define GET_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdatemapping_dynamic  ERR_OK
	#define CAL_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdatemapping_dynamic  fuiodrvupdatemapping_dynamic
	#define CHK_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdatemapping_dynamic  TRUE
	#define EXP_WagoSysKbusTerminalControl_Internal_PFCfuiodrvupdatemapping_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdatemapping_dynamic", (RTS_UINTPTR)fuiodrvupdatemapping_dynamic, 1, RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fuiodrvupdatemapping_dynamic
	#define EXT_fuiodrvupdatemapping_dynamic
	#define GET_fuiodrvupdatemapping_dynamic(fl)  CAL_CMGETAPI( "fuiodrvupdatemapping_dynamic" ) 
	#define CAL_fuiodrvupdatemapping_dynamic  fuiodrvupdatemapping_dynamic
	#define CHK_fuiodrvupdatemapping_dynamic  TRUE
	#define EXP_fuiodrvupdatemapping_dynamic  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdatemapping_dynamic", (RTS_UINTPTR)fuiodrvupdatemapping_dynamic, 1, RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fuiodrvupdatemapping_dynamic  PFFUIODRVUPDATEMAPPING_DYNAMIC_IEC pffuiodrvupdatemapping_dynamic;
	#define EXT_fuiodrvupdatemapping_dynamic  extern PFFUIODRVUPDATEMAPPING_DYNAMIC_IEC pffuiodrvupdatemapping_dynamic;
	#define GET_fuiodrvupdatemapping_dynamic(fl)  s_pfCMGetAPI2( "fuiodrvupdatemapping_dynamic", (RTS_VOID_FCTPTR *)&pffuiodrvupdatemapping_dynamic, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000)
	#define CAL_fuiodrvupdatemapping_dynamic  pffuiodrvupdatemapping_dynamic
	#define CHK_fuiodrvupdatemapping_dynamic  (pffuiodrvupdatemapping_dynamic != NULL)
	#define EXP_fuiodrvupdatemapping_dynamic   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuiodrvupdatemapping_dynamic", (RTS_UINTPTR)fuiodrvupdatemapping_dynamic, 1, RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/



typedef struct
{
	IBase_C *pBase;
} IWagoSysKbusTerminalControl_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysKbusTerminalControl_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysKbusTerminalControl_Internal_PFC
		#define ITF_WagoSysKbusTerminalControl_Internal_PFC static IWagoSysKbusTerminalControl_Internal_PFC *pIWagoSysKbusTerminalControl_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysKbusTerminalControl_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysKbusTerminalControl_Internal_PFC_C		IWagoSysKbusTerminalControl_Internal_PFC;
	#ifndef ITF_WagoSysKbusTerminalControl_Internal_PFC
		#define ITF_WagoSysKbusTerminalControl_Internal_PFC
	#endif
	#define EXTITF_WagoSysKbusTerminalControl_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSKBUSTERMINALCONTROL_INTERNAL_PFCITF_H_*/
