/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

//---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All manufacturing,
// reproduction, use, and sales rights pertaining to this subject matter are governed by the license agreement. The
// recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     http://svsv01003/svn/repo3/pfc/trunk/wago_intern/codesys3-Component/TscIoDrvKbus/TscIoDrvKbusDep.m4 (.h) 
///
/// \version  $Rev$
///
/// \brief    target specific component to support communication to KBUS driver instance
///
/// \author   u015479 / WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------
#ifndef _TSCIODRVKBUSDEP_H_
#define _TSCIODRVKBUSDEP_H_

#define COMPONENT_NAME "TscIoDrvKbus" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscIoDrvKbus)
#define COMPONENT_NAME_UNQUOTED TscIoDrvKbus






#define CMP_VERSION         UINT32_C(0x00000100)
#define CMP_VERSION_STRING "0.0.1.0"
#define CMP_VERSION_RC      0,0,1,0

#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"

#include "CmpItf.h"
#include "CmpStd.h"
#include <WagoSysdefines.h>

#define CMPID_TscIoDrvKbus      TSCIODRVKBUS_CMPID
#define CLASSID_CTscIoDrvKbus   ADDVENDORID(CMP_VENDORID, TSCIODRVKBUS_CLASSID_C)
#define ITFID_ITscIoDrvKbus     ADDVENDORID(CMP_VENDORID, TSCIODRVKBUS_ITFID_I)






/**
 * \file WagoSysKbusTerminalControl_Internal_PFCItf.h
 */
#include "WagoSysKbusTerminalControl_Internal_PFCItf.h"







#include "CMItf.h"


/*Obsolete include: CmpLogItf.m4*/


#include "IoDrvKbusSItf.h"




        




     




     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pIIoDrvKbusS == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CIoDrvKbusS, &initResult); \
            if (pIBase != NULL) \
            { \
                pIIoDrvKbusS = (IIoDrvKbusS *)pIBase->QueryInterface(pIBase, ITFID_IIoDrvKbusS, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          /*Obsolete include CmpLog*/ \
		  if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pIIoDrvKbusS = NULL; \
          /*Obsolete include CmpLog*/ \
		  pICM = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pIIoDrvKbusS != NULL) \
        { \
            pIBase = (IBase *)pIIoDrvKbusS->QueryInterface(pIIoDrvKbusS, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pIIoDrvKbusS = NULL; \
            } \
        } \
          /*Obsolete include CmpLog*/ \
		  if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_FuIoDrvUpdateMapping_dynamic_s(0);\
          if (ERR_OK == importResult ) importResult = GET_FuIoDrvUpdateConfiguration_dynamic_s(0);\
          if (ERR_OK == importResult ) importResult = GET_FuIoDrvGetConfMapState_s(0);\
          if (ERR_OK == importResult ) importResult = GET_FuIoDrvCalculateSlotNumber_s(0);\
          if (ERR_OK == importResult ) importResult = GET_CMExit(0);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCIODRVKBUS_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)fuiodrvupdatemapping_dynamic, "fuiodrvupdatemapping_dynamic", RTSITF_GET_SIGNATURE(0x6474FB10, 0x6C947665), 0x01000000 },\
          { (RTS_VOID_FCTPTR)fuiodrvupdateconfiguration_dynamic, "fuiodrvupdateconfiguration_dynamic", RTSITF_GET_SIGNATURE(0x3B19F08A, 0xD8900FEC), 0x01000000 },\
          { (RTS_VOID_FCTPTR)fuiodrvgetconfmapstate, "fuiodrvgetconfmapstate", RTSITF_GET_SIGNATURE(0xDDBE0CAA, 0x3EA86160), 0x01000000 },\
          { (RTS_VOID_FCTPTR)fuiodrvcalculateslotnumber, "fuiodrvcalculateslotnumber", RTSITF_GET_SIGNATURE(0x537208AD, 0x958EB3C3), 0x01000000 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCIODRVKBUS_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCIODRVKBUS_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CM     \
	/*obsolete entry ITF_CmpLog*/      \
	ITF_IoDrvKbusS      \
    USE_CMExit      \
    USE_FuIoDrvCalculateSlotNumber_s      \
    USE_FuIoDrvGetConfMapState_s      \
    USE_FuIoDrvUpdateConfiguration_dynamic_s      \
    USE_FuIoDrvUpdateMapping_dynamic_s     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CM    \
	/*obsolete entry ITF_CmpLog*/     \
	ITF_IoDrvKbusS     \
    USE_CMExit      \
    USE_FuIoDrvCalculateSlotNumber_s      \
    USE_FuIoDrvGetConfMapState_s      \
    USE_FuIoDrvUpdateConfiguration_dynamic_s      \
    USE_FuIoDrvUpdateMapping_dynamic_s     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CM    \
	/*obsolete entry EXTITF_CmpLog*/     \
	EXTITF_IoDrvKbusS     \
    EXT_CMExit  \
    EXT_FuIoDrvCalculateSlotNumber_s  \
    EXT_FuIoDrvGetConfMapState_s  \
    EXT_FuIoDrvUpdateConfiguration_dynamic_s  \
    EXT_FuIoDrvUpdateMapping_dynamic_s 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscIoDrvKbus__Entry
#endif


#ifdef CPLUSPLUS

class CTscIoDrvKbus : public IWagoSysKbusTerminalControl_Internal_PFC 
{
    public:
        CTscIoDrvKbus() : hTscIoDrvKbus(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscIoDrvKbus()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoSysKbusTerminalControl_Internal_PFC *)this);            
            else if (iid == ITFID_IWagoSysKbusTerminalControl_Internal_PFC)
                pItf = dynamic_cast<IWagoSysKbusTerminalControl_Internal_PFC *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hTscIoDrvKbus;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
