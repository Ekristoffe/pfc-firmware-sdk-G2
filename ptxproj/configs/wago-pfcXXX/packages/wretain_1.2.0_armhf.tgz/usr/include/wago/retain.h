//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
///  \file
///
///  \brief    Retain Variables C API.
///            Please note that the module is single-threaded in nature and all
///            function calls should be executed once.
///
///  \author   WAGO GmbH & Co. KG
///-----------------------------------------------------------------------------


#ifndef WAGO_RETAIN_H_
#define WAGO_RETAIN_H_


#include <stddef.h>
#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif // __cplusplus


///
/// Initialize the retain variables memory.
/// Once the function is called the rest of the functions may be called.
/// @return returns 0 on success, <0 otherwise
///
extern int wrv_open(void);


///
/// Initialize the retain variables memory.
/// Works as wrv_open but it also extends the RV memory area by 'overflow_size' of bytes.
/// This additional memory area is not persisted and is lost after deinitialization.
/// Please note that this additional memory size is not used anywhere else and not included in
/// any returned values, specifically it is not included in the size of retain variables memory
/// returned by the wrv_get_size function.
/// @param overflow_size - the amount of bytes by which the RV memory area should be extended
/// @return returns 0 on success, <0 otherwise
///
extern int wrv_open_with_overflow(size_t overflow_size);


///
/// Deinitializes retain variables memory.
/// Once called the function closes all opened resources, including the memory area, which becomes
/// no longer valid. After that retain variables memory shall not be accessed anymore and the only
/// allowed action is to initialize the memory anew.
/// All data stored in retain variables memory prior to wrv_close call is synchronized with supporting hardware memory.
/// @return returns 0 on success, <0 otherwise
///
extern int wrv_close(void);


///
/// Returns pointer to retain variables memory area.
///
extern void* wrv_get_memory(void);


///
/// Returns size of retain variables memory area, in bytes.
///
extern size_t wrv_get_size(void);


///
/// Forces synchronization of retain variables memory with underlying hardware.
/// Implementation depends on the supporting hardware and may be NOP in some cases.
/// @return returns 0 on success, <0 otherwise
///
extern int wrv_synchronize(void);


///
/// Returns error message associated with the last error occurence.
/// The returned pointer points to statically allocated memory and as such shall not be freed.
///
extern const char* wrv_get_errmsg(void);


///
/// Zeroes the entire retain variable memory.
/// @return returns 0 on success, <0 otherwise
///
extern int wrv_erase(void);


#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus


#endif // WAGO_RETAIN_H_
