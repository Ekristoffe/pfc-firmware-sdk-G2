//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     activesystem_parameter_provider.hpp
///
///  \brief    <short description of the file contents>
///
///  \author   BA : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_PP_ACTIVESYSTEM_ACTIVESYSTEM_PARAMETER_PROVIDER_HPP_
#define INCLUDE_WAGO_PP_ACTIVESYSTEM_ACTIVESYSTEM_PARAMETER_PROVIDER_HPP_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>


namespace wago::pp_activesystem
{

/// \class activesystem_parameter_provider
/// \brief This parameter providers allows to access active system settings.
class activesystem_parameter_provider final
    : public wago::wdx::base_parameter_provider
{
    activesystem_parameter_provider(activesystem_parameter_provider const &) = delete;
    activesystem_parameter_provider& operator=(activesystem_parameter_provider const &) = delete;
public:
    activesystem_parameter_provider();
    ~activesystem_parameter_provider() override;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
        std::vector<wago::wdx::value_request> value_requests) override;

    future<wdx::method_invocation_response> invoke_method(
        wdx::parameter_instance_id method_id, std::vector<std::shared_ptr<wdx::parameter_value>> in_args) override;

private:
    struct detail;
    detail * d_ptr;
};

} // namespace wago::pp_activesystem

#endif /* INCLUDE_WAGO_PP_ACTIVESYSTEM_ACTIVESYSTEM_PARAMETER_PROVIDER_HPP_ */
//---- End of source file ------------------------------------------------------

