 /**
 * <interfacename>WagoSysProcess_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSPROCESS_INTERNAL_PFCITF_H_
#define _WAGOSYSPROCESS_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>fuexecutecommand</description>
 */
typedef struct tagfuexecutecommand_struct
{
	RTS_IEC_STRING sCommand[1025];		/* VAR_INPUT */	
	RTS_IEC_STRING *R_sStdOut;			/* VAR_INPUT */	
	RTS_IEC_UINT uiStdOutSize;			/* VAR_INPUT */	/* The maximal supported length is STRING(255) */
	RTS_IEC_STRING *R_sStdError;		/* VAR_INPUT */	
	RTS_IEC_UINT uiStdErrorSize;		/* VAR_INPUT */	/* The maximal supported length is STRING(255) */
	RTS_IEC_UDINT udiTimeoutMs;			/* VAR_INPUT */	/* Timeout for command execution */
	RTS_IEC_RESULT *pResult;			/* VAR_INPUT */	
	RTS_IEC_DINT FuExecuteCommand;		/* VAR_OUTPUT */	
} fuexecutecommand_struct;

void CDECL CDECL_EXT fuexecutecommand(fuexecutecommand_struct *p);
typedef void (CDECL CDECL_EXT* PFFUEXECUTECOMMAND_IEC) (fuexecutecommand_struct *p);
#if defined(WAGOSYSPROCESS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUEXECUTECOMMAND_NOTIMPLEMENTED)
	#define USE_fuexecutecommand
	#define EXT_fuexecutecommand
	#define GET_fuexecutecommand(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuexecutecommand(p0) 
	#define CHK_fuexecutecommand  FALSE
	#define EXP_fuexecutecommand  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuexecutecommand
	#define EXT_fuexecutecommand
	#define GET_fuexecutecommand(fl)  CAL_CMGETAPI( "fuexecutecommand" ) 
	#define CAL_fuexecutecommand  fuexecutecommand
	#define CHK_fuexecutecommand  TRUE
	#define EXP_fuexecutecommand  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuexecutecommand", (RTS_UINTPTR)fuexecutecommand, 1, 0xB9E4D169, 0x01000000) 
	#define EXTREF_ITF_fuexecutecommand {(RTS_VOID_FCTPTR)fuexecutecommand, "fuexecutecommand", 0xB9E4D169, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSPROCESS_INTERNAL_PFC_EXTERNAL)
	#define USE_fuexecutecommand
	#define EXT_fuexecutecommand
	#define GET_fuexecutecommand(fl)  CAL_CMGETAPI( "fuexecutecommand" ) 
	#define CAL_fuexecutecommand  fuexecutecommand
	#define CHK_fuexecutecommand  TRUE
	#define EXP_fuexecutecommand  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuexecutecommand", (RTS_UINTPTR)fuexecutecommand, 1, 0xB9E4D169, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysProcess_Internal_PFCfuexecutecommand
	#define EXT_WagoSysProcess_Internal_PFCfuexecutecommand
	#define GET_WagoSysProcess_Internal_PFCfuexecutecommand  ERR_OK
	#define CAL_WagoSysProcess_Internal_PFCfuexecutecommand  fuexecutecommand
	#define CHK_WagoSysProcess_Internal_PFCfuexecutecommand  TRUE
	#define EXP_WagoSysProcess_Internal_PFCfuexecutecommand  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuexecutecommand", (RTS_UINTPTR)fuexecutecommand, 1, 0xB9E4D169, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fuexecutecommand
	#define EXT_fuexecutecommand
	#define GET_fuexecutecommand(fl)  CAL_CMGETAPI( "fuexecutecommand" ) 
	#define CAL_fuexecutecommand  fuexecutecommand
	#define CHK_fuexecutecommand  TRUE
	#define EXP_fuexecutecommand  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuexecutecommand", (RTS_UINTPTR)fuexecutecommand, 1, 0xB9E4D169, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fuexecutecommand  PFFUEXECUTECOMMAND_IEC pffuexecutecommand;
	#define EXT_fuexecutecommand  extern PFFUEXECUTECOMMAND_IEC pffuexecutecommand;
	#define GET_fuexecutecommand(fl)  s_pfCMGetAPI2( "fuexecutecommand", (RTS_VOID_FCTPTR *)&pffuexecutecommand, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB9E4D169, 0x01000000)
	#define CAL_fuexecutecommand  pffuexecutecommand
	#define CHK_fuexecutecommand  (pffuexecutecommand != NULL)
	#define EXP_fuexecutecommand   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuexecutecommand", (RTS_UINTPTR)fuexecutecommand, 1, 0xB9E4D169, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysProcess_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysProcess_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysProcess_Internal_PFC
		#define ITF_WagoSysProcess_Internal_PFC static IWagoSysProcess_Internal_PFC *pIWagoSysProcess_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysProcess_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysProcess_Internal_PFC_C		IWagoSysProcess_Internal_PFC;
	#ifndef ITF_WagoSysProcess_Internal_PFC
		#define ITF_WagoSysProcess_Internal_PFC
	#endif
	#define EXTITF_WagoSysProcess_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSPROCESS_INTERNAL_PFCITF_H_*/
