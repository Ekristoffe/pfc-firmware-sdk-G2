/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 * <name>TscChCfgOnline</name>
 * <description> 
 *	<p>This component implements the user and goup management for the user manager.</p>
 * </description>
 *
 * <copyright>(c) 2003-2010 3S-Smart Software Solutions</copyright>
 */
#ifndef _TSCCHCFGONLINEDEP_H_
#define _TSCCHCFGONLINEDEP_H_

#define COMPONENT_NAME "TscChCfgOnline" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscChCfgOnline)
#define COMPONENT_NAME_UNQUOTED TscChCfgOnline





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscChCfgOnline 	ADDVENDORID(CMP_VENDORID, TSCCHCFGONLINE_CLASSID_C)
#define CMPID_TscChCfgOnline		  TSCCHCFGONLINE_CMPID
#define ITFID_TscChCfgOnline    ADDVENDORID(CMP_VENDORID, TSCCHCFGONLINE_CLASSID_C)


#define CMP_VERSION         UINT32_C(0x00000001)
#define CMP_VERSION_STRING "0.0.0.1"
#define CMP_VERSION_RC      0,0,0,1
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"







/**
 * \file TscChCfgOnlineItf.h
 */
#include "TscChCfgOnlineItf.h"







/*Obsolete include: CMUtilsItf.m4*/


#include "CmpMemPoolItf.h"


#include "SysMemItf.h"


#include "CmpSettingsItf.h"


#include "CMItf.h"


#include "CmpAppItf.h"


#include "CmpWebServerItf.h"


#include "CmpEventMgrItf.h"



        

      

      


        















     















     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICmpEventMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpEventMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpEventMgr = (ICmpEventMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpEventMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpWebServer == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpWebServer, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpWebServer = (ICmpWebServer *)pIBase->QueryInterface(pIBase, ITFID_ICmpWebServer, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpSettings == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSettings, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSettings = (ICmpSettings *)pIBase->QueryInterface(pIBase, ITFID_ICmpSettings, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysMem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysMem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysMem = (ISysMem *)pIBase->QueryInterface(pIBase, ITFID_ISysMem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpMemPool == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpMemPool, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpMemPool = (ICmpMemPool *)pIBase->QueryInterface(pIBase, ITFID_ICmpMemPool, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		   \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pICmpEventMgr = NULL; \
          pICmpWebServer = NULL; \
          pICmpApp = NULL; \
          pICM = NULL; \
          pICmpSettings = NULL; \
          pISysMem = NULL; \
          pICmpMemPool = NULL; \
          /*Obsolete include CMUtils*/ \
		   \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pICmpEventMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpEventMgr->QueryInterface(pICmpEventMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpEventMgr = NULL; \
            } \
        } \
          if (pICmpWebServer != NULL) \
        { \
            pIBase = (IBase *)pICmpWebServer->QueryInterface(pICmpWebServer, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpWebServer = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
          if (pICmpSettings != NULL) \
        { \
            pIBase = (IBase *)pICmpSettings->QueryInterface(pICmpSettings, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSettings = NULL; \
            } \
        } \
          if (pISysMem != NULL) \
        { \
            pIBase = (IBase *)pISysMem->QueryInterface(pISysMem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysMem = NULL; \
            } \
        } \
          if (pICmpMemPool != NULL) \
        { \
            pIBase = (IBase *)pICmpMemPool->QueryInterface(pICmpMemPool, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpMemPool = NULL; \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		   \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_CMGetComponent(0);\
          if (ERR_OK == importResult ) importResult = GET_CMGetCmpId(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_EventPost2(0);\
          if (ERR_OK == importResult ) importResult = GET_EventDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_EventCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlStrLen(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgRemoveKey(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgSetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlStrICmp(0);\
          /*Obsolete required include LogAdd*/ \
		  if (ERR_OK == importResult ) TempResult = GET_WebServerRequestRunning(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_WebServerReleaseRunning(CM_IMPORT_OPTIONAL_FUNCTION);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCCHCFGONLINE_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
                  
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCCHCFGONLINE_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                  
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCCHCFGONLINE_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
        { (RTS_VOID_FCTPTR)CcoGetRemove, "CcoGetRemove", 0, 0 },\
          { (RTS_VOID_FCTPTR)CcoGetValue, "CcoGetValue", 0, 0 },\
          { (RTS_VOID_FCTPTR)CcoGetKey, "CcoGetKey", 0, 0 },\
          { (RTS_VOID_FCTPTR)CcoGetSection, "CcoGetSection", 0, 0 },\
          { (RTS_VOID_FCTPTR)CcoSetRestartNecessity, "CcoSetRestartNecessity", 0, 0 },\
          \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	/*obsolete entry ITF_CMUtils*/      \
	ITF_CmpMemPool     \
	ITF_SysMem     \
	ITF_CmpSettings     \
	ITF_CM     \
	ITF_CmpApp     \
	ITF_CmpWebServer     \
	ITF_CmpEventMgr      \
    USE_WebServerReleaseRunning      \
    USE_WebServerRequestRunning      \
    /*obsolete USE_LogAdd*/      \
    USE_CMUtlStrICmp      \
    USE_SettgSetStringValue      \
    USE_SettgGetStringValue      \
    USE_SettgRemoveKey      \
    USE_CMUtlStrLen      \
    USE_CMUtlSafeStrCpy      \
    USE_EventCreate      \
    USE_EventDelete      \
    USE_EventPost2      \
    USE_EventOpen      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventClose      \
    USE_CMGetCmpId      \
    USE_CMGetComponent     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	/*obsolete entry ITF_CMUtils*/     \
	ITF_CmpMemPool    \
	ITF_SysMem    \
	ITF_CmpSettings    \
	ITF_CM    \
	ITF_CmpApp    \
	ITF_CmpWebServer    \
	ITF_CmpEventMgr     \
    USE_WebServerReleaseRunning      \
    USE_WebServerRequestRunning      \
    /*obsolete USE_LogAdd*/      \
    USE_CMUtlStrICmp      \
    USE_SettgSetStringValue      \
    USE_SettgGetStringValue      \
    USE_SettgRemoveKey      \
    USE_CMUtlStrLen      \
    USE_CMUtlSafeStrCpy      \
    USE_EventCreate      \
    USE_EventDelete      \
    USE_EventPost2      \
    USE_EventOpen      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventClose      \
    USE_CMGetCmpId      \
    USE_CMGetComponent     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	/*obsolete entry EXTITF_CMUtils*/     \
	EXTITF_CmpMemPool    \
	EXTITF_SysMem    \
	EXTITF_CmpSettings    \
	EXTITF_CM    \
	EXTITF_CmpApp    \
	EXTITF_CmpWebServer    \
	EXTITF_CmpEventMgr     \
    EXT_WebServerReleaseRunning  \
    EXT_WebServerRequestRunning  \
    /*obsolete EXT_LogAdd*/  \
    EXT_CMUtlStrICmp  \
    EXT_SettgSetStringValue  \
    EXT_SettgGetStringValue  \
    EXT_SettgRemoveKey  \
    EXT_CMUtlStrLen  \
    EXT_CMUtlSafeStrCpy  \
    EXT_EventCreate  \
    EXT_EventDelete  \
    EXT_EventPost2  \
    EXT_EventOpen  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_EventClose  \
    EXT_CMGetCmpId  \
    EXT_CMGetComponent 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscChCfgOnline__Entry
#endif


#ifdef CPLUSPLUS

class CTscChCfgOnline : public ITscChCfgOnline 
{
    public:
        CTscChCfgOnline() : hTscChCfgOnline(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscChCfgOnline()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ITscChCfgOnline *)this);            
            else if (iid == ITFID_ITscChCfgOnline)
                pItf = dynamic_cast<ITscChCfgOnline *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }
        virtual void CDECL ICcoSetRestartNecessity(struct tagCHCFGONLINE* pHandle, int iRestartNeeded);
        virtual RTS_RESULT CDECL ICcoGetSection(struct tagCHCFGONLINE* pHandle, char *pszValue, int *piLen);
        virtual RTS_RESULT CDECL ICcoGetKey(struct tagCHCFGONLINE* pHandle, char *pszValue, int *piLen);
        virtual RTS_RESULT CDECL ICcoGetValue(struct tagCHCFGONLINE* pHandle, char *pszValue, int *piLen);
        virtual RTS_INT CDECL ICcoGetRemove(struct tagCHCFGONLINE* pHandle);

    public:
        RTS_HANDLE hTscChCfgOnline;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
