 /**
 * <interfacename>WagoSysUserLED_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCCHCFGONLINEITF_H_
#define _TSCCHCFGONLINEITF_H_

#include "CmpStd.h"

 

 




/*#include "CmpAppItf.h"*/
/*#include "CmpWebServerItf.h"*/
#include "CmpEventMgrItf.h"

/** EXTERN LIB SECTION BEGIN **/

#define CCO_ERROR -1
#define CCO_NO_RESTART_NEEDED 0
#define CCO_RESTART_RECOMMENDED 1
#define CCO_RESTART_REQIRED 2

struct tagCHCFGONLINE;

/**
 * <category>Event parameter</category>
 * <element name="TscCco_ConfigChanged" type="IN">Pointer to Change description</element>
 */
typedef struct
{
	struct tagCHCFGONLINE* pCco;
} EVTPARAM_TscCco_ConfigChanged;
#define EVTPARAMID_TscCco_ConfigChanged	0x0001
#define EVTVERSION_TscCco_ConfigChanged	0x0001

/**
 * <category>Events</category>
 * <description>Event is sent after config has changed</description>
 * <param name="pEventParam" type="IN">EVTPARAM_TscCco_ConfigChanged</param>
 */
#define EVT_ConfigChangedOnline	MAKE_EVENTID(EVTCLASS_INFO, 1)

#ifdef __cplusplus
extern "C" {
#endif


/**
 * <description>Set the restart Necessity</description>
 * <param name="pHandle" type="IN">Pointer to name of the handle</param>
 * <param name="iRestartNeeded" type="IN">Set value of Restart need CCO_NO_RESTART_NEEDED, CCO_RESTART_RECOMMENDED, CCO_RESTART_REQIRED </param>
 */
void CDECL CcoSetRestartNecessity(struct tagCHCFGONLINE* pHandle, int iRestartNeeded);
typedef void (CDECL * PFCCOSETRESTARTNECESSITY) (struct tagCHCFGONLINE* pHandle, int iRestartNeeded);
#if defined(TSCCHCFGONLINE_NOTIMPLEMENTED) || defined(CCOSETRESTARTNECESSITY_NOTIMPLEMENTED)
	#define USE_CcoSetRestartNecessity
	#define EXT_CcoSetRestartNecessity
	#define GET_CcoSetRestartNecessity(fl)  ERR_NOTIMPLEMENTED
	#define CAL_CcoSetRestartNecessity(p0,p1)  
	#define CHK_CcoSetRestartNecessity  FALSE
	#define EXP_CcoSetRestartNecessity  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_CcoSetRestartNecessity
	#define EXT_CcoSetRestartNecessity
	#define GET_CcoSetRestartNecessity(fl)  CAL_CMGETAPI( "CcoSetRestartNecessity" ) 
	#define CAL_CcoSetRestartNecessity  CcoSetRestartNecessity
	#define CHK_CcoSetRestartNecessity  TRUE
	#define EXP_CcoSetRestartNecessity  CAL_CMEXPAPI( "CcoSetRestartNecessity" ) 
#elif defined(MIXED_LINK) && !defined(TSCCHCFGONLINE_EXTERNAL)
	#define USE_CcoSetRestartNecessity
	#define EXT_CcoSetRestartNecessity
	#define GET_CcoSetRestartNecessity(fl)  CAL_CMGETAPI( "CcoSetRestartNecessity" ) 
	#define CAL_CcoSetRestartNecessity  CcoSetRestartNecessity
	#define CHK_CcoSetRestartNecessity  TRUE
	#define EXP_CcoSetRestartNecessity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoSetRestartNecessity", (RTS_UINTPTR)CcoSetRestartNecessity, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscChCfgOnlineCcoSetRestartNecessity
	#define EXT_TscChCfgOnlineCcoSetRestartNecessity
	#define GET_TscChCfgOnlineCcoSetRestartNecessity  ERR_OK
	#define CAL_TscChCfgOnlineCcoSetRestartNecessity pITscChCfgOnline->ICcoSetRestartNecessity
	#define CHK_TscChCfgOnlineCcoSetRestartNecessity (pITscChCfgOnline != NULL)
	#define EXP_TscChCfgOnlineCcoSetRestartNecessity  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_CcoSetRestartNecessity
	#define EXT_CcoSetRestartNecessity
	#define GET_CcoSetRestartNecessity(fl)  CAL_CMGETAPI( "CcoSetRestartNecessity" ) 
	#define CAL_CcoSetRestartNecessity pITscChCfgOnline->ICcoSetRestartNecessity
	#define CHK_CcoSetRestartNecessity (pITscChCfgOnline != NULL)
	#define EXP_CcoSetRestartNecessity  CAL_CMEXPAPI( "CcoSetRestartNecessity" ) 
#else /* DYNAMIC_LINK */
	#define USE_CcoSetRestartNecessity  PFCCOSETRESTARTNECESSITY pfCcoSetRestartNecessity;
	#define EXT_CcoSetRestartNecessity  extern PFCCOSETRESTARTNECESSITY pfCcoSetRestartNecessity;
	#define GET_CcoSetRestartNecessity(fl)  s_pfCMGetAPI2( "CcoSetRestartNecessity", (RTS_VOID_FCTPTR *)&pfCcoSetRestartNecessity, (fl), 0, 0)
	#define CAL_CcoSetRestartNecessity  pfCcoSetRestartNecessity
	#define CHK_CcoSetRestartNecessity  (pfCcoSetRestartNecessity != NULL)
	#define EXP_CcoSetRestartNecessity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoSetRestartNecessity", (RTS_UINTPTR)CcoSetRestartNecessity, 0, 0) 
#endif




/**
 * <description>Get the Section of the Change</description>
 * <param name="pHandle" type="IN">Pointer to name of the handle</param>
 * <param name="pszValue" type="INOUT">Pointer to value for result</param>
 * <param name="piLen" type="INOUT">Max length of string value as IN and length of copied values excluding the NUL ending as OUT!</param>
 */
RTS_RESULT CDECL CcoGetSection(struct tagCHCFGONLINE* pHandle,char *pszValue, int *piLen);
typedef RTS_RESULT (CDECL * PFCCOGETSECTION) (struct tagCHCFGONLINE* pHandle,char *pszValue, int *piLen);
#if defined(TSCCHCFGONLINE_NOTIMPLEMENTED) || defined(CCOGETSECTION_NOTIMPLEMENTED)
	#define USE_CcoGetSection
	#define EXT_CcoGetSection
	#define GET_CcoGetSection(fl)  ERR_NOTIMPLEMENTED
	#define CAL_CcoGetSection(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_CcoGetSection  FALSE
	#define EXP_CcoGetSection  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_CcoGetSection
	#define EXT_CcoGetSection
	#define GET_CcoGetSection(fl)  CAL_CMGETAPI( "CcoGetSection" ) 
	#define CAL_CcoGetSection  CcoGetSection
	#define CHK_CcoGetSection  TRUE
	#define EXP_CcoGetSection  CAL_CMEXPAPI( "CcoGetSection" ) 
#elif defined(MIXED_LINK) && !defined(TSCCHCFGONLINE_EXTERNAL)
	#define USE_CcoGetSection
	#define EXT_CcoGetSection
	#define GET_CcoGetSection(fl)  CAL_CMGETAPI( "CcoGetSection" ) 
	#define CAL_CcoGetSection  CcoGetSection
	#define CHK_CcoGetSection  TRUE
	#define EXP_CcoGetSection  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetSection", (RTS_UINTPTR)CcoGetSection, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscChCfgOnlineCcoGetSection
	#define EXT_TscChCfgOnlineCcoGetSection
	#define GET_TscChCfgOnlineCcoGetSection  ERR_OK
	#define CAL_TscChCfgOnlineCcoGetSection pITscChCfgOnline->ICcoGetSection
	#define CHK_TscChCfgOnlineCcoGetSection (pITscChCfgOnline != NULL)
	#define EXP_TscChCfgOnlineCcoGetSection  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_CcoGetSection
	#define EXT_CcoGetSection
	#define GET_CcoGetSection(fl)  CAL_CMGETAPI( "CcoGetSection" ) 
	#define CAL_CcoGetSection pITscChCfgOnline->ICcoGetSection
	#define CHK_CcoGetSection (pITscChCfgOnline != NULL)
	#define EXP_CcoGetSection  CAL_CMEXPAPI( "CcoGetSection" ) 
#else /* DYNAMIC_LINK */
	#define USE_CcoGetSection  PFCCOGETSECTION pfCcoGetSection;
	#define EXT_CcoGetSection  extern PFCCOGETSECTION pfCcoGetSection;
	#define GET_CcoGetSection(fl)  s_pfCMGetAPI2( "CcoGetSection", (RTS_VOID_FCTPTR *)&pfCcoGetSection, (fl), 0, 0)
	#define CAL_CcoGetSection  pfCcoGetSection
	#define CHK_CcoGetSection  (pfCcoGetSection != NULL)
	#define EXP_CcoGetSection  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetSection", (RTS_UINTPTR)CcoGetSection, 0, 0) 
#endif




/**
 * <description>Get the Key of the Change</description>
 * <param name="pHandle" type="IN">Pointer to name of the handle</param>
 * <param name="pszValue" type="INOUT">Pointer to value for result</param>
 * <param name="piLen" type="INOUT">Max length of string value as IN and length of copied values excluding the NUL ending as OUT!</param>
 */
RTS_RESULT CDECL CcoGetKey(struct tagCHCFGONLINE* pHandle,char *pszValue, int *piLen);
typedef RTS_RESULT (CDECL * PFCCOGETKEY) (struct tagCHCFGONLINE* pHandle,char *pszValue, int *piLen);
#if defined(TSCCHCFGONLINE_NOTIMPLEMENTED) || defined(CCOGETKEY_NOTIMPLEMENTED)
	#define USE_CcoGetKey
	#define EXT_CcoGetKey
	#define GET_CcoGetKey(fl)  ERR_NOTIMPLEMENTED
	#define CAL_CcoGetKey(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_CcoGetKey  FALSE
	#define EXP_CcoGetKey  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_CcoGetKey
	#define EXT_CcoGetKey
	#define GET_CcoGetKey(fl)  CAL_CMGETAPI( "CcoGetKey" ) 
	#define CAL_CcoGetKey  CcoGetKey
	#define CHK_CcoGetKey  TRUE
	#define EXP_CcoGetKey  CAL_CMEXPAPI( "CcoGetKey" ) 
#elif defined(MIXED_LINK) && !defined(TSCCHCFGONLINE_EXTERNAL)
	#define USE_CcoGetKey
	#define EXT_CcoGetKey
	#define GET_CcoGetKey(fl)  CAL_CMGETAPI( "CcoGetKey" ) 
	#define CAL_CcoGetKey  CcoGetKey
	#define CHK_CcoGetKey  TRUE
	#define EXP_CcoGetKey  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetKey", (RTS_UINTPTR)CcoGetKey, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscChCfgOnlineCcoGetKey
	#define EXT_TscChCfgOnlineCcoGetKey
	#define GET_TscChCfgOnlineCcoGetKey  ERR_OK
	#define CAL_TscChCfgOnlineCcoGetKey pITscChCfgOnline->ICcoGetKey
	#define CHK_TscChCfgOnlineCcoGetKey (pITscChCfgOnline != NULL)
	#define EXP_TscChCfgOnlineCcoGetKey  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_CcoGetKey
	#define EXT_CcoGetKey
	#define GET_CcoGetKey(fl)  CAL_CMGETAPI( "CcoGetKey" ) 
	#define CAL_CcoGetKey pITscChCfgOnline->ICcoGetKey
	#define CHK_CcoGetKey (pITscChCfgOnline != NULL)
	#define EXP_CcoGetKey  CAL_CMEXPAPI( "CcoGetKey" ) 
#else /* DYNAMIC_LINK */
	#define USE_CcoGetKey  PFCCOGETKEY pfCcoGetKey;
	#define EXT_CcoGetKey  extern PFCCOGETKEY pfCcoGetKey;
	#define GET_CcoGetKey(fl)  s_pfCMGetAPI2( "CcoGetKey", (RTS_VOID_FCTPTR *)&pfCcoGetKey, (fl), 0, 0)
	#define CAL_CcoGetKey  pfCcoGetKey
	#define CHK_CcoGetKey  (pfCcoGetKey != NULL)
	#define EXP_CcoGetKey  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetKey", (RTS_UINTPTR)CcoGetKey, 0, 0) 
#endif




/**
 * <description>Get the Value of the Change</description>
 * <param name="pHandle" type="IN">Pointer to name of the handle</param>
 * <param name="pszValue" type="INOUT">Pointer to value for result</param>
 * <param name="piLen" type="INOUT">Max length of string value as IN and length of copied values excluding the NUL ending as OUT!</param>
 */
RTS_RESULT CDECL CcoGetValue(struct tagCHCFGONLINE* pHandle,char *pszValue, int *piLen);
typedef RTS_RESULT (CDECL * PFCCOGETVALUE) (struct tagCHCFGONLINE* pHandle,char *pszValue, int *piLen);
#if defined(TSCCHCFGONLINE_NOTIMPLEMENTED) || defined(CCOGETVALUE_NOTIMPLEMENTED)
	#define USE_CcoGetValue
	#define EXT_CcoGetValue
	#define GET_CcoGetValue(fl)  ERR_NOTIMPLEMENTED
	#define CAL_CcoGetValue(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_CcoGetValue  FALSE
	#define EXP_CcoGetValue  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_CcoGetValue
	#define EXT_CcoGetValue
	#define GET_CcoGetValue(fl)  CAL_CMGETAPI( "CcoGetValue" ) 
	#define CAL_CcoGetValue  CcoGetValue
	#define CHK_CcoGetValue  TRUE
	#define EXP_CcoGetValue  CAL_CMEXPAPI( "CcoGetValue" ) 
#elif defined(MIXED_LINK) && !defined(TSCCHCFGONLINE_EXTERNAL)
	#define USE_CcoGetValue
	#define EXT_CcoGetValue
	#define GET_CcoGetValue(fl)  CAL_CMGETAPI( "CcoGetValue" ) 
	#define CAL_CcoGetValue  CcoGetValue
	#define CHK_CcoGetValue  TRUE
	#define EXP_CcoGetValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetValue", (RTS_UINTPTR)CcoGetValue, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscChCfgOnlineCcoGetValue
	#define EXT_TscChCfgOnlineCcoGetValue
	#define GET_TscChCfgOnlineCcoGetValue  ERR_OK
	#define CAL_TscChCfgOnlineCcoGetValue pITscChCfgOnline->ICcoGetValue
	#define CHK_TscChCfgOnlineCcoGetValue (pITscChCfgOnline != NULL)
	#define EXP_TscChCfgOnlineCcoGetValue  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_CcoGetValue
	#define EXT_CcoGetValue
	#define GET_CcoGetValue(fl)  CAL_CMGETAPI( "CcoGetValue" ) 
	#define CAL_CcoGetValue pITscChCfgOnline->ICcoGetValue
	#define CHK_CcoGetValue (pITscChCfgOnline != NULL)
	#define EXP_CcoGetValue  CAL_CMEXPAPI( "CcoGetValue" ) 
#else /* DYNAMIC_LINK */
	#define USE_CcoGetValue  PFCCOGETVALUE pfCcoGetValue;
	#define EXT_CcoGetValue  extern PFCCOGETVALUE pfCcoGetValue;
	#define GET_CcoGetValue(fl)  s_pfCMGetAPI2( "CcoGetValue", (RTS_VOID_FCTPTR *)&pfCcoGetValue, (fl), 0, 0)
	#define CAL_CcoGetValue  pfCcoGetValue
	#define CHK_CcoGetValue  (pfCcoGetValue != NULL)
	#define EXP_CcoGetValue  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetValue", (RTS_UINTPTR)CcoGetValue, 0, 0) 
#endif




/**
 * <description>Get the info if the specifyed key was removed</description>
 * <param name="pHandle" type="IN">Pointer to name of the handle</param>
 */
RTS_INT CDECL CcoGetRemove(struct tagCHCFGONLINE* pHandle);
typedef RTS_INT (CDECL * PFCCOGETREMOVE) (struct tagCHCFGONLINE* pHandle);
#if defined(TSCCHCFGONLINE_NOTIMPLEMENTED) || defined(CCOGETREMOVE_NOTIMPLEMENTED)
	#define USE_CcoGetRemove
	#define EXT_CcoGetRemove
	#define GET_CcoGetRemove(fl)  ERR_NOTIMPLEMENTED
	#define CAL_CcoGetRemove(p0)  (RTS_INT)ERR_NOTIMPLEMENTED
	#define CHK_CcoGetRemove  FALSE
	#define EXP_CcoGetRemove  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_CcoGetRemove
	#define EXT_CcoGetRemove
	#define GET_CcoGetRemove(fl)  CAL_CMGETAPI( "CcoGetRemove" ) 
	#define CAL_CcoGetRemove  CcoGetRemove
	#define CHK_CcoGetRemove  TRUE
	#define EXP_CcoGetRemove  CAL_CMEXPAPI( "CcoGetRemove" ) 
#elif defined(MIXED_LINK) && !defined(TSCCHCFGONLINE_EXTERNAL)
	#define USE_CcoGetRemove
	#define EXT_CcoGetRemove
	#define GET_CcoGetRemove(fl)  CAL_CMGETAPI( "CcoGetRemove" ) 
	#define CAL_CcoGetRemove  CcoGetRemove
	#define CHK_CcoGetRemove  TRUE
	#define EXP_CcoGetRemove  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetRemove", (RTS_UINTPTR)CcoGetRemove, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscChCfgOnlineCcoGetRemove
	#define EXT_TscChCfgOnlineCcoGetRemove
	#define GET_TscChCfgOnlineCcoGetRemove  ERR_OK
	#define CAL_TscChCfgOnlineCcoGetRemove pITscChCfgOnline->ICcoGetRemove
	#define CHK_TscChCfgOnlineCcoGetRemove (pITscChCfgOnline != NULL)
	#define EXP_TscChCfgOnlineCcoGetRemove  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_CcoGetRemove
	#define EXT_CcoGetRemove
	#define GET_CcoGetRemove(fl)  CAL_CMGETAPI( "CcoGetRemove" ) 
	#define CAL_CcoGetRemove pITscChCfgOnline->ICcoGetRemove
	#define CHK_CcoGetRemove (pITscChCfgOnline != NULL)
	#define EXP_CcoGetRemove  CAL_CMEXPAPI( "CcoGetRemove" ) 
#else /* DYNAMIC_LINK */
	#define USE_CcoGetRemove  PFCCOGETREMOVE pfCcoGetRemove;
	#define EXT_CcoGetRemove  extern PFCCOGETREMOVE pfCcoGetRemove;
	#define GET_CcoGetRemove(fl)  s_pfCMGetAPI2( "CcoGetRemove", (RTS_VOID_FCTPTR *)&pfCcoGetRemove, (fl), 0, 0)
	#define CAL_CcoGetRemove  pfCcoGetRemove
	#define CHK_CcoGetRemove  (pfCcoGetRemove != NULL)
	#define EXP_CcoGetRemove  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"CcoGetRemove", (RTS_UINTPTR)CcoGetRemove, 0, 0) 
#endif




#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFCCOSETRESTARTNECESSITY ICcoSetRestartNecessity;
 	PFCCOGETSECTION ICcoGetSection;
 	PFCCOGETKEY ICcoGetKey;
 	PFCCOGETVALUE ICcoGetValue;
 	PFCCOGETREMOVE ICcoGetRemove;
 } ITscChCfgOnline_C;

#ifdef CPLUSPLUS
class ITscChCfgOnline : public IBase
{
	public:
		virtual void CDECL ICcoSetRestartNecessity(struct tagCHCFGONLINE* pHandle, int iRestartNeeded) =0;
		virtual RTS_RESULT CDECL ICcoGetSection(struct tagCHCFGONLINE* pHandle, char *pszValue, int *piLen) =0;
		virtual RTS_RESULT CDECL ICcoGetKey(struct tagCHCFGONLINE* pHandle, char *pszValue, int *piLen) =0;
		virtual RTS_RESULT CDECL ICcoGetValue(struct tagCHCFGONLINE* pHandle, char *pszValue, int *piLen) =0;
		virtual RTS_INT CDECL ICcoGetRemove(struct tagCHCFGONLINE* pHandle) =0;
};
	#ifndef ITF_TscChCfgOnline
		#define ITF_TscChCfgOnline static ITscChCfgOnline *pITscChCfgOnline = NULL;
	#endif
	#define EXTITF_TscChCfgOnline
#else	/*CPLUSPLUS*/
	typedef ITscChCfgOnline_C		ITscChCfgOnline;
	#ifndef ITF_TscChCfgOnline
		#define ITF_TscChCfgOnline
	#endif
	#define EXTITF_TscChCfgOnline
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCCHCFGONLINEITF_H_*/
