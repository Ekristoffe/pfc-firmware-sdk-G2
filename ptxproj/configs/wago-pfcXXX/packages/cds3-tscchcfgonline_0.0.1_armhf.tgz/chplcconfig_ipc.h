//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     chplcconfig_ipc.h
///
///  \version  $Id$
///
///  \brief    <short description of the file contents>
///
///  \author   <author> : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef CHPLCCONFIG_IPC_H_
#define CHPLCCONFIG_IPC_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
#define PLC_CONFIG_NAME "plc.config"
#define PLC_CONFIG_PATH "/plc/config"
#define PLC_CONFIG_SET  "set"
#define PLC_CONFIG_GET  "get"
#define PLC_CONFIG_REMOVE  "rm"

typedef enum ePlcConfigResult{
  PLC_CONFIG_ERROR              = -1,
  PLC_CONFIG_NO_RESTART_NEEDED  = 0,
  PLC_CONFIG_RESTART_RECOMMENDED,
  PLC_CONFIG_RESTART_REQIRED,
}tPlcConfigResult;

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function implementation
//------------------------------------------------------------------------------


#endif /* CHPLCCONFIG_IPC_H_ */
//---- End of source file ------------------------------------------------------
