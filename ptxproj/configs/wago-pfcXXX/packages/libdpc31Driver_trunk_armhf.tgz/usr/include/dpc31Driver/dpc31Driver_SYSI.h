//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dpc31Driver_SYSI.h
///
///  \defgroup page_dpc31Driver_sysi System Interface (SYSI)
///  \ingroup  page_dpc31Driver_component
///
///  \version  $Id:
///
///  \brief    This module is the common interface of this component. It is possible to create and destroy objects of
///             the DPC31 Driver. Before using of the created object is possible the activation after the initialization
///             is necessary.
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPC31DRIVER_SYSI_H
#define DPC31DRIVER_SYSI_H

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Driver_sysi_definitions Definitions
///  \ingroup page_dpc31Driver_sysi
///
///  These are the definitions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup dpc31DriverStatus Status codes
///  \ingroup page_dpc31Driver_sysi_definitions
///
/// The function return value defines are 32 bit values and have the following format:
///
/// @code
///
///   3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0
///   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
///  +---+---------------------------+--------------------------------+
///  |Sev|      extended Code        |               Code             |
///  +---+---------------------------+--------------------------------+
///
/// @endcode
///
///  - Sev is the severity code
///   - 00 - Success
///   - 01 - Informational
///   - 10 - Warning
///   - 11 - Error
///
/// \{
//----------------------------------------------------------------------------------------------------------------------
/** the processing of the function has been successfully finished */
#define DPC31DRIVER_SUCCESS                                        0x00000000U
/** an undefined error has occurred during the processing of the function */
#define DPC31DRIVER_ERROR_UNDEFINED                                0xC0000000U
/** the pointer of a function parameter is invalid */
#define DPC31DRIVER_ERROR_NULL_POINTER                             0xC0000001U
/** the object state is not valid */
#define DPC31DRIVER_ERROR_INVALID_OBJ_STATE                        0xC0000002U
/** the function was called in the wrong sequence */
#define DPC31DRIVER_ERROR_INVALID_SEQUENCE                         0xC0000003U
/** the requested resource is not available */
#define DPC31DRIVER_ERROR_RESSOURCE_FAULT                          0xC0000004U
///  \}

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup dpc31DriverSysiDefines Common defines
///  \ingroup page_dpc31Driver_sysi_definitions
///
///  The following defines are used in this module.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** maximum string length definition */
#define DPC31DRIVER_MAX_STRING_LEN 20
///  \}

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Driver_sysi_data_types Data Types
///  \ingroup page_dpc31Driver_sysi
///
///  These are the data types of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
/// @ingroup page_dpc31Driver_sysi_data_types
///
/// The @ref dpc31DriverSettings_t structure describes the DPC31 driver component settings.
///
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** file name of the main DPC31 device */
    char strMainDeviceName[DPC31DRIVER_MAX_STRING_LEN];
    /** real time thread priority of the main device interrupt */
    uint8_t ucMainDevThreadPrio;
#ifdef EXTRA_PINS
    /** file name of the data exchange interrupt */
    char strDataExchangeInterruptName[DPC31DRIVER_MAX_STRING_LEN];
    /** real time thread priority of the data exchange interrupt */
    uint8_t ucExchThreadPrio;
    /** file name of the synchronisation signal interrupt */
    char strSyncInterruptName[DPC31DRIVER_MAX_STRING_LEN];
    /** real time thread priority of the synchronisation signal interrupt */
    uint8_t ucSyncIrqThreadPrio;
#endif
    /** version string of the UIO driver */
    char strDeviceVersion[DPC31DRIVER_MAX_STRING_LEN];
}dpc31DriverSettings_t;

//----------------------------------------------------------------------------------------------------------------------
// Global Variables
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Driver_sysi_functions Functions
///  \ingroup page_dpc31Driver_sysi
///
///   These are the functions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//-- Function: dpc31Driver_Initialise --------------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_sysi_functions
///
///  This function creates a new object of the DPC31 stack. The memory is allocated here. Additionally all necessary
///   internal initialisation are processed in this function. If something went wrong the handle is NULL and no memory
///   has been allocated.
///
///  \param   pstDpc31DriverSettings    settings of the component context
///
///  \return  object handle
///
//----------------------------------------------------------------------------------------------------------------------
handle_t dpc31Driver_Initialise (dpc31DriverSettings_t const *  pstDpc31DriverSettings);

//-- Function: dpc31Driver_Activate ------------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_sysi_functions
///
///  This function activates the object of the DPC31 stack.
///
///  \param   pObjHandle                     handle of the DPC31 stack object
///
///  \return  @ref DPC31DRIVER_SUCCESS                 no error has occurred
///  \return  @ref DPC31DRIVER_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  @ref DPC31DRIVER_ERROR_NULL_POINTER      the object handle is invalid
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_Activate (handle_t pObjHandle);

//-- Function: dpc31Driver_Deactivate ----------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_sysi_functions
///
///  This function deactivates the object of the DPC31 stack.
///
///  \param   pObjHandle                     handle of the DPC31 stack object
///
///  \return  @ref DPC31DRIVER_SUCCESS                 no error has occurred
///  \return  @ref DPC31DRIVER_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  @ref DPC31DRIVER_ERROR_NULL_POINTER      the object handle is invalid
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_Deactivate (handle_t pObjHandle);

//-- Function: dpc31Driver_Release -------------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_sysi_functions
///
///  This function destroys the object of the DPC31 stack. The memory is released as well.
///
///  \param   pObjHandle object handle for this software component created by the component initialisation
///
///  \return  @ref DPC31DRIVER_SUCCESS                 no error has occurred
///  \return  @ref DPC31DRIVER_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  @ref DPC31DRIVER_ERROR_NULL_POINTER      the object handle is invalid
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_Release (handle_t pObjHandle);

#endif
//---- End of header ---------------------------------------------------------------------------------------------------
