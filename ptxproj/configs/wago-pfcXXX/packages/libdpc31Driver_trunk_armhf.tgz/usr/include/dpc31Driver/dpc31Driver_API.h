//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dpc31Driver_API.h
///
///  \defgroup page_dpc31Driver_api Application Programming Interface (API)
///  \ingroup  page_dpc31Driver_component
///
///  \version  $Id:
///
///  \brief    This module is the application interface for the DPC31 driver software component. All available
///             functions can only be accessed by using this interface.
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPC31DRIVER_API_H
#define DPC31DRIVER_API_H

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>

#include "dpc31Driver_SYSI.h"

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Driver_api_data_types Data Types
///  \ingroup page_dpc31Driver_api
///
///  These are the data types of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
/// @ingroup page_dpc31Driver_api_data_types
///
/// The @ref dpc31IsrCbFnc_t function type describes the callback functions of the DPC31 interrupts.
///
//----------------------------------------------------------------------------------------------------------------------
typedef void (*dpc31IsrCbFnc_t) (handle_t pObjHandle);

//----------------------------------------------------------------------------------------------------------------------
///
/// @ingroup page_dpc31Driver_api_data_types
///
/// The @ref dpc31DriverCbFnc_t structure specifies the callback functions of the DPC31 interrupts.
///
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** call back function of the main DPC31 interrupt */
    dpc31IsrCbFnc_t pfDpc31InterruptMain;
    /** call back function of the data exchange interrupt */
    dpc31IsrCbFnc_t pfDpc31InterruptDataExchange;
    /** call back function of the synchronisation signal interrupt */
    dpc31IsrCbFnc_t pfDpc31InterruptSync;
    /** user handle which will be returned with the main DPC31 interrupt */
    handle_t pDpc31InterruptMainHdl;
    /** user handle which will be returned with the data exchange interrupt */
    handle_t pDpc31InterruptDataExchangeHdl;
    /** user handle which will be returned with the synchronisation signal interrupt */
    handle_t pDpc31InterruptSyncHdl;
}dpc31DriverCbFnc_t;

//----------------------------------------------------------------------------------------------------------------------
// Global Variables
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup page_dpc31Driver_api_functions Functions
///  \ingroup page_dpc31Driver_api
///
///   These are the functions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//-- Function: dpc31Driver_OpenDevice ----------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function opens the communication channel between the DPC31 hardware and the user space. This includes
///   the communication memory as well as the worker threats for the three DPC31 interrupts. This is realized by using
///   the userspace IO driver (UIO).
///
///  \param   pObjHandle        object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_OpenDevice (handle_t pObjHandle);


//-- Function: dpc31Driver_CloseDevice ---------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function closes the communication channel between the DPC31 hardware and the user space. All created threads
///   will be destroyed and the mapped memory will be unmapped.
///
///  \param   pObjHandle        object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_CloseDevice (handle_t pObjHandle);

//-- Function: dpc31Driver_ResetDevice ---------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function performs a hardware reset of the DPC31 hardware.
///
///  \param   pObjHandle        object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_ResetDevice (handle_t pObjHandle);

//-- Function: dpc31Driver_GetMemoryPtr --------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function returns the pointer to the DPC31 communication memory.
///
///  \param   ppMemoryPtr       pointer to the return value where the DPC31 memory pointer should be stored.
///  \param   pObjHandle        object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_GetMemoryPtr (void** ppMemoryPtr,
                                   handle_t pObjHandle);

//-- Function: dpc31Driver_Register ------------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function can be used to register the callback functions for the interrupt events of the DPC31 hardware.
///
///  \param   pstDpc31DriverCbFnc   pointer to the structure in witch the callback functions are specified
///  \param   pObjHandle            object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.

///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Driver_RegisterCbFnc (dpc31DriverCbFnc_t* pstDpc31DriverCbFnc,
                                    handle_t pObjHandle);

//-- Function: dpc31Driver_CtrlTimePin1 --------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function is for debug issues. It can be used to set and reset a hardware pin for timing measurements.
///   Please consider the processing delay of the operating system.
///
///  \param   bSet              control the hardware pin (true = set the pin; false = reset the pin)
///  \param   pObjHandle        object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
void dpc31Driver_CtrlTimePin1 (bool bSet,
                               handle_t pObjHandle);

//-- Function: dpc31Driver_CtrlTimePin2 --------------------------------------------------------------------------------
///
///  @ingroup page_dpc31Driver_api_functions
///
///  This function is for debug issues. It can be used to set and reset a hardware pin for timing measurements.
///   Please consider the processing delay of the operating system.
///
///  \param   bSet              control the hardware pin (true = set the pin; false = reset the pin)
///  \param   pObjHandle        object handle for this software component created by the component initialisation
///
///  \return  The routine returns @ref DPC31DRIVER_SUCCESS on success. Another value such like
///            @ref DPC31DRIVER_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
void dpc31Driver_CtrlTimePin2 (bool bSet,
                               handle_t pObjHandle);

#endif
//---- End of header ---------------------------------------------------------------------------------------------------
