//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
#ifndef WGO_FBEXECUTE_H_
#define WGO_FBEXECUTE_H_

#include <stdint.h>

#include "CmpStd.h"
#include "CmpErrors.h"
#include "CmpItf.h"

#define CHK_FUNCTION(x,y,z) if(!(CHK_ ## x)){y;return z;}
#define SET_FB_BUSY(x) {*(x->xBusy)=TRUE;*(x->xDone)=FALSE;*(x->xError)=FALSE;}
#define SET_FB_DONE(x) {*(x->xBusy)=FALSE;*(x->xDone)=TRUE;*(x->xError)=FALSE;}
#define SET_FB_ERROR(x) {*(x->xBusy)=FALSE;*(x->xDone)=FALSE;*(x->xError)=TRUE;}
#define SET_FB_IDLE(x) {*(x->xBusy)=FALSE;*(x->xDone)=FALSE;*(x->xError)=FALSE;}

typedef void*(*tGetDataHandler)(void*);
typedef void(*tFreeDataHandler)(void*);
typedef void(*tResumeDataHandler)(void*,void*,RTS_IEC_DINT);
typedef int32_t(*tExecHandler)(void*);

/*
  This struct is used to execute a function block in a separate thread.
  The fields hold pointers to the actual codesys function block variables.
  We use separate pointers to the variables of the function block instead of a pointer to the function block itself
  because there are different instances of the function block in the application.
*/
typedef struct {
    RTS_IEC_BOOL      * xExecute;        /* VAR_INPUT */ /* Enable SNMP-request */
    RTS_IEC_BOOL      * xBusy;         /* VAR_OUTPUT */  /* Function block is already Busy */
    RTS_IEC_BOOL      * xDone;         /* VAR_OUTPUT */  /* Function block has done its work an outgoing data can be used */
    RTS_IEC_BOOL      * xError;        /* VAR_OUTPUT */  /* Function block is in error state */
    RTS_IEC_DINT      * diStatus;        /* VAR_OUTPUT */  /* Return-Code */
    RTS_IEC_BOOL      * xOldEnable;      /* Local variable */
    intptr_t          * diData;           /* Local variable */
    intptr_t          * diSyncHandle;      /* Local variable */
    void              * data;
    tGetDataHandler     getAsncExecData;
    tResumeDataHandler  resumeAsyncExecData;
    tFreeDataHandler    freeAsyncExecData;
    tExecHandler        execHandler;
}tFbExecute;

typedef struct {
    /* VAR_OUTPUT */  /* Function block is in error state */
    RTS_IEC_DINT      diStatus;
    RTS_IEC_DINT      diAsyncState;
    void            * data;
    tFreeDataHandler  freeAsyncExecData;
    tExecHandler      execHandler;
}tFbExecObject;

#define FB_EXECUTE_HEAD_INIT(x,y) { \
  .xExecute=&(x->xExecute),\
  .xBusy=&(x->xBusy),\
  .xDone=&(x->xDone),\
  .xError=&(x->xError),\
  .diStatus=&(x->diStatus),\
  .xOldEnable=&(x->xOldEnable),\
  .diData= (intptr_t*)&(x->diData),\
  .diSyncHandle= (intptr_t*)&(x->diSyncHandle),\
  .data=(void*)&y,}

void CDECL wagofb_FbExecuteInit(tFbExecute * fb);
void CDECL wagofb_FbExecuteMain(tFbExecute *fb);
void CDECL wagofb_FbExecuteExit(tFbExecute *fb);

#endif /* WGO_FBEXECUTE_H_ */
//---- End of source file ------------------------------------------------------
