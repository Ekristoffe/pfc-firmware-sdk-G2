/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component Template</name>
 *  <description> 
 *  An example on how to implement a component.
 *  This component does no usefull work and it exports no functions
 *  which are intended to be used for anything. Use at your own risk.
 *  </description>
 *  <copyright>
 *  (c) 2003-2010 3S-Smart Software Solutions
 *  </copyright>
 */
#ifndef _TSCSNMPDEP_H_
#define _TSCSNMPDEP_H_

#define COMPONENT_NAME "TscSnmp" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscSnmp)
#define COMPONENT_NAME_UNQUOTED TscSnmp





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscSnmp 	ADDVENDORID(CMP_VENDORID, TSCSNMP_CLASSID_C)
#define CMPID_TscSnmp		  TSCSNMP_CMPID
#define ITFID_TscSnmp    ADDVENDORID(CMP_VENDORID, TSCSNMP_CLASSID_C)

#define CMP_VERSION         UINT32_C(0x00000001)
#define CMP_VERSION_STRING "0.0.0.1"
#define CMP_VERSION_RC      0,0,0,1
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"				

#include "SysOutItf.h"


#include "TscSharedPointerItf.h"


#include "SysMemItf.h"



/*needed by AsyncMgr*/
#include "SysTaskItf.h"


#include "TscAsyncMgrItf.h"



/*for debugging*/
#include "SysCpuHandlingItf.h"



#include "WagoTypesCommonItf.h"









/**
 * \file WagoSysSNMP_Internal_PFCItf.h
 */
#include "WagoSysSNMP_Internal_PFCItf.h"







        










     










     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pIWagoTypesCommon == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CWagoTypesCommon, &initResult); \
            if (pIBase != NULL) \
            { \
                pIWagoTypesCommon = (IWagoTypesCommon *)pIBase->QueryInterface(pIBase, ITFID_IWagoTypesCommon, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysCpuHandling == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysCpuHandling, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysCpuHandling = (ISysCpuHandling *)pIBase->QueryInterface(pIBase, ITFID_ISysCpuHandling, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pITscAsyncMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscAsyncMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscAsyncMgr = (ITscAsyncMgr *)pIBase->QueryInterface(pIBase, ITFID_ITscAsyncMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysMem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysMem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysMem = (ISysMem *)pIBase->QueryInterface(pIBase, ITFID_ISysMem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pITscSharedPointer == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscSharedPointer, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscSharedPointer = (ITscSharedPointer *)pIBase->QueryInterface(pIBase, ITFID_ITscSharedPointer, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysOut == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysOut, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysOut = (ISysOut *)pIBase->QueryInterface(pIBase, ITFID_ISysOut, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pIWagoTypesCommon = NULL; \
          pISysCpuHandling = NULL; \
          pITscAsyncMgr = NULL; \
          pISysTask = NULL; \
          pISysMem = NULL; \
          pITscSharedPointer = NULL; \
          pISysOut = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pIWagoTypesCommon != NULL) \
        { \
            pIBase = (IBase *)pIWagoTypesCommon->QueryInterface(pIWagoTypesCommon, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pIWagoTypesCommon = NULL; \
            } \
        } \
          if (pISysCpuHandling != NULL) \
        { \
            pIBase = (IBase *)pISysCpuHandling->QueryInterface(pISysCpuHandling, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysCpuHandling = NULL; \
            } \
        } \
          if (pITscAsyncMgr != NULL) \
        { \
            pIBase = (IBase *)pITscAsyncMgr->QueryInterface(pITscAsyncMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscAsyncMgr = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
          if (pISysMem != NULL) \
        { \
            pIBase = (IBase *)pISysMem->QueryInterface(pISysMem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysMem = NULL; \
            } \
        } \
          if (pITscSharedPointer != NULL) \
        { \
            pIBase = (IBase *)pITscSharedPointer->QueryInterface(pITscSharedPointer, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscSharedPointer = NULL; \
            } \
        } \
          if (pISysOut != NULL) \
        { \
            pIBase = (IBase *)pISysOut->QueryInterface(pISysOut, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysOut = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_SysCpuAtomicAdd(0);\
          if (ERR_OK == importResult ) importResult = GET_TscAsyncAdd(0);\
          if (ERR_OK == importResult ) importResult = GET_TscAsyncRemove(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemFreeData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemAllocData(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerNew(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerCopy(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerGetInstance(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerGetRefCount(0);\
          if (ERR_OK == importResult ) importResult = GET_TscSharedPointerDeref(0);\
          /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCSNMP_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)snmp_udint_to_tlv, "snmp_udint_to_tlv", RTSITF_GET_SIGNATURE(0x0731226E,0xF2D03512), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_tlv_to_udint, "snmp_tlv_to_udint", RTSITF_GET_SIGNATURE(0x647ADDBC,0x7BADEF0B), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_tlv_to_string, "snmp_tlv_to_string", RTSITF_GET_SIGNATURE(0xAB5A0F11,0x77E9E29B), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_tlv_to_dint, "snmp_tlv_to_dint", RTSITF_GET_SIGNATURE(0x89E1C31A,0xEAB2B532), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_tlv_get_type, "snmp_tlv_get_type", RTSITF_GET_SIGNATURE(0x7B47ED73,0x6490DFC4), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_string_to_tlv, "snmp_string_to_tlv", RTSITF_GET_SIGNATURE(0x765E0752,0x3FBCC041), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set_v3__fb_exit, "snmp_set_v3__fb_exit", RTSITF_GET_SIGNATURE(0x52559045,0x1A664360), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set_v3__fb_init, "snmp_set_v3__fb_init", RTSITF_GET_SIGNATURE(0x24254E15,0xA1269902), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set_v3__main, "snmp_set_v3__main", RTSITF_GET_SIGNATURE(0x50988FE0,0xDCEBADCA), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set_custom_oid_value, "snmp_set_custom_oid_value", RTSITF_GET_SIGNATURE(0x63D942BB,0x963855C7), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set__fb_exit, "snmp_set__fb_exit", RTSITF_GET_SIGNATURE(0x47DB007A,0xC4ACE622), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set__fb_init, "snmp_set__fb_init", RTSITF_GET_SIGNATURE(0xAF3B3FDD,0xCF8A6E16), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_set__main, "snmp_set__main", RTSITF_GET_SIGNATURE(0x1A9D3DF6,0xF2C31A3B), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_trap_to_adr_v3, "snmp_send_trap_to_adr_v3", RTSITF_GET_SIGNATURE(0xFC0B175A,0x9B314270), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_trap_to_adr_v2c, "snmp_send_trap_to_adr_v2c", RTSITF_GET_SIGNATURE(0x44D6A146,0x7EEE01BD), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_trap_to_adr_v1, "snmp_send_trap_to_adr_v1", RTSITF_GET_SIGNATURE(0xED0670D5,0x57C1049F), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_trap, "snmp_send_trap", RTSITF_GET_SIGNATURE(0x37F52882,0x5E60DF34), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_inform_to_adr_v3__fb_exit, "snmp_send_inform_to_adr_v3__fb_exit", RTSITF_GET_SIGNATURE(0x0442CABB,0xD2B6CDDB), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_inform_to_adr_v3__fb_init, "snmp_send_inform_to_adr_v3__fb_init", RTSITF_GET_SIGNATURE(0xEDC5068A,0xAD332DF8), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_inform_to_adr_v3__main, "snmp_send_inform_to_adr_v3__main", RTSITF_GET_SIGNATURE(0x01CDC097,0x194F5571), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_inform_to_adr__fb_exit, "snmp_send_inform_to_adr__fb_exit", RTSITF_GET_SIGNATURE(0x14225BE5,0xD37FFC9D), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_inform_to_adr__fb_init, "snmp_send_inform_to_adr__fb_init", RTSITF_GET_SIGNATURE(0x433CE928,0x1F4F48D0), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_inform_to_adr__main, "snmp_send_inform_to_adr__main", RTSITF_GET_SIGNATURE(0xBA0562F4,0xA54CA470), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_send_ent_trap, "snmp_send_ent_trap", 0xDAFE8EA0, 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_register_custom_oid, "snmp_register_custom_oid", RTSITF_GET_SIGNATURE(0x0EF871E4,0xDA27AE59), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_null_to_tlv, "snmp_null_to_tlv", RTSITF_GET_SIGNATURE(0x46F68A53,0x9A4567D9), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get_v3__fb_exit, "snmp_get_v3__fb_exit", RTSITF_GET_SIGNATURE(0xFBBA1716,0x8E610128), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get_v3__fb_init, "snmp_get_v3__fb_init", RTSITF_GET_SIGNATURE(0xCF8DB525,0x576E07E1), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get_v3__main, "snmp_get_v3__main", RTSITF_GET_SIGNATURE(0x2411E4C8,0x6A44A8E2), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get_error_string, "snmp_get_error_string", 0x5B86A025, 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get_custom_oid_value, "snmp_get_custom_oid_value", RTSITF_GET_SIGNATURE(0xB62A05FA,0x032E1514), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get__fb_exit, "snmp_get__fb_exit", RTSITF_GET_SIGNATURE(0x9DC6E4B6,0xF6108117), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get__fb_init, "snmp_get__fb_init", RTSITF_GET_SIGNATURE(0xDD9DCE46,0x87A2B7F7), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_get__main, "snmp_get__main", RTSITF_GET_SIGNATURE(0x1000D8BC,0x26EE97CE), 0x01020200 },\
          { (RTS_VOID_FCTPTR)snmp_dint_to_tlv, "snmp_dint_to_tlv", RTSITF_GET_SIGNATURE(0x8A6AABF1,0x050F6C48), 0x01020200 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCSNMP_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                                                              
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCSNMP_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                                                              \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut     \
	ITF_TscSharedPointer     \
	ITF_SysMem     \
	ITF_SysTask     \
	ITF_TscAsyncMgr     \
	ITF_SysCpuHandling     \
	ITF_WagoTypesCommon      \
    /*obsolete USE_LogAdd*/      \
    USE_TscSharedPointerDeref      \
    USE_TscSharedPointerGetRefCount      \
    USE_TscSharedPointerGetInstance      \
    USE_TscSharedPointerCopy      \
    USE_TscSharedPointerNew      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_TscAsyncRemove      \
    USE_TscAsyncAdd      \
    USE_SysCpuAtomicAdd     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut    \
	ITF_TscSharedPointer    \
	ITF_SysMem    \
	ITF_SysTask    \
	ITF_TscAsyncMgr    \
	ITF_SysCpuHandling    \
	ITF_WagoTypesCommon     \
    /*obsolete USE_LogAdd*/      \
    USE_TscSharedPointerDeref      \
    USE_TscSharedPointerGetRefCount      \
    USE_TscSharedPointerGetInstance      \
    USE_TscSharedPointerCopy      \
    USE_TscSharedPointerNew      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_TscAsyncRemove      \
    USE_TscAsyncAdd      \
    USE_SysCpuAtomicAdd     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysOut    \
	EXTITF_TscSharedPointer    \
	EXTITF_SysMem    \
	EXTITF_SysTask    \
	EXTITF_TscAsyncMgr    \
	EXTITF_SysCpuHandling    \
	EXTITF_WagoTypesCommon     \
    /*obsolete EXT_LogAdd*/  \
    EXT_TscSharedPointerDeref  \
    EXT_TscSharedPointerGetRefCount  \
    EXT_TscSharedPointerGetInstance  \
    EXT_TscSharedPointerCopy  \
    EXT_TscSharedPointerNew  \
    EXT_SysMemAllocData  \
    EXT_SysMemFreeData  \
    EXT_TscAsyncRemove  \
    EXT_TscAsyncAdd  \
    EXT_SysCpuAtomicAdd 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscSnmp__Entry
#endif


#ifdef CPLUSPLUS

class CTscSnmp : public IWagoSysSNMP_Internal_PFC 
{
    public:
        CTscSnmp() : hTscSnmp(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscSnmp()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoSysSNMP_Internal_PFC *)this);            
            else if (iid == ITFID_IWagoSysSNMP_Internal_PFC)
                pItf = dynamic_cast<IWagoSysSNMP_Internal_PFC *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hTscSnmp;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
