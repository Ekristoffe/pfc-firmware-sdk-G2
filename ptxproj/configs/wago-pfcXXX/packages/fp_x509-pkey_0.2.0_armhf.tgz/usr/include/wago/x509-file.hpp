//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     x509-file.hpp
///
///  \brief    The x509_file class is a config file provider that only accepts
///            x.509 compliant certificates.
///
///  \author   WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef INCLUDE_X509_FILE_HPP__
#define INCLUDE_X509_FILE_HPP__

#include <wago/wdx/linuxos/file/config_file.hpp>

namespace wago {

    class x509_file : public wdx::linuxos::file::config_file
    {
        x509_file (x509_file const&) = delete;
        x509_file const& operator = (x509_file const&) = delete;

      public:
        using wdx::linuxos::file::config_file::config_file;

        void store(const std::vector<uint8_t> &data) override;
        bool validate(const std::vector<uint8_t> &data);
    };

}
#endif
// vim: ts=4 sw=4 expandtab
