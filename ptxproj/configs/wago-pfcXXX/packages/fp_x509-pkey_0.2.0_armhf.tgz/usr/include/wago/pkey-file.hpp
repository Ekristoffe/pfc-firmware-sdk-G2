//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     pkey-file.hpp
///
///  \brief    The pkey_file class is a config file provider that only accepts
///            PEM formatted private keys in PKCS#1 or PKCS#8 format
///
///  \author   WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef INCLUDE_PKEY_FILE_HPP__
#define INCLUDE_PKEY_FILE_HPP__

#include <wago/wdx/linuxos/file/config_file.hpp>

namespace wago {

    class pkey_file : public wdx::linuxos::file::config_file
    {
        pkey_file (pkey_file const&) = delete;
        pkey_file const& operator = (pkey_file const&) = delete;

      public:
        using wdx::linuxos::file::config_file::config_file;

        void store(const std::vector<uint8_t> &data) override;
        bool validate(const std::vector<uint8_t> &data);
    };

}
#endif
// vim: ts=4 sw=4 expandtab
