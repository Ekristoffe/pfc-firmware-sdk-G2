//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
/// manufacturing, reproduction, use, and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// \file WagoLed_API.h
///
/// \version $Revision$
///
/// \brief Global Interface to the LED Components of a Coupler
///
/// \author Hans Florian Scholz: Wago
//------------------------------------------------------------------------------

#ifndef WAGOLEDCTL_H_
#define WAGOLEDCTL_H_

#include <errno.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and typedefinitions
//------------------------------------------------------------------------------

//Enumaration of all possible leds. do not change the order only add new LEDs at the end of the enum
typedef enum {
  LedU1= 1,
  LedU2,
  LedU3,
  LedU4,
  LedU5,
  LedU6,
  LedU7,
  LedSys ,
  LedRun,
  LedIO,
  LedMs,
  LedNs,
  LedCAN,
  LedBF,
  LedDia,
  //add new LEDs here


  LedMax
}tLed;

typedef enum {
  LedColorOff=0,
  LedColorGreen,
  LedColorRed,
  LedColorYellow,
  LedColorBlue,
  LedColorCyan,
  LedColorMagenta,
  LedColorWhite,

  LedColorMax
}tLedColor;

//Led timevalue in milliseconds
typedef unsigned int tLedTime;

typedef enum {
  LedStateUnknown = 0,
  LedStateOff     = 1,
  LedStateStatic  = 2,
  LedStateBlink   = 3,
  LedStateFlash   = 4,
}tLedStatus_;

typedef struct {
    tLed       number;
    tLedStatus_ state;
    tLedColor  color1;
    tLedColor  color2;
    tLedTime   time1;
    tLedTime   time2;
}tLedState;

typedef enum {
  LedReturnOk=0,                    /* Kein Fehler aufgetreten*/
  LedReturnAlreadySet = EALREADY,   /* (114) LED befindet sich aktuell in diesem Zustand*/
  LedReturnOutOfRange = ENODEV,     /* (19)Invalide LED-Nummer */
  LedReturnColorError = EINVAL,     /* (22)Fehler mit der/den gewählten LED-Farbe/n */
  LedReturnTimingError= ETIME       /* (62)Fehler bei Eingestellten Blink und Flashzeiten */
}tLedReturn;

void LEDCTL_Init(void);

//-- Function: LEDCTL_SetStatic ---------------------------------------------------
///
///  Set LED into Static Mode
///
///  Thread-safety: This is thread-safe and reentrant
///
///  \param Led    enum-value of the LED
///  \param Color  enum-Value of the LED Color
///
///  \return LedReturnOk            on success
///          LedReturnColorError    if color is invalid
///          LedReturnOutOfRange    if selected led is out of range
///          LedReturnAlreadySet    if led state is the same as the selected
//---------------------------------------------------------------------------------
tLedReturn LEDCTL_SetStatic(tLed,
                            tLedColor);

//-- Function: LEDCTL_SetBlink ---------------------------------------------------
///
///  Set LED into Blinking Mode
///
///  Thread-safety: This is thread-safe and reentrant
///
///  \param Led     enum-value of the LED
///  \param Color1  enum-Value of the LED Color
///  \param Color2  enum-Value of the LED Color
///  \param Time1   Blink time 1 in ms
///  \param Time2   Blink time 2 in ms
///
///  \return LedReturnOk            on success
///          LedReturnColorError    if color is invalid
///          LedReturnOutOfRange    if selected led is out of range
///          LedReturnAlreadySet    if led state is the same as the selected
///          LedReturnTimingError   if timing is invalid
//--------------------------------------------------------------------------------
tLedReturn LEDCTL_SetBlink(tLed,
                           tLedColor,
                           tLedColor,
                           tLedTime,
                           tLedTime);

//-- Function: LEDCTL_SetFlash ---------------------------------------------------
///
///  Set LED into Flashing Mode
///
///  Thread-safety: This is thread-safe and reentrant
///
///  \param Led     enum-value of the LED
///  \param Color1  enum-Value of the LED Color
///  \param Color2  enum-Value of the LED Color
///  \param Time    Flashing time in ms
///
///  \return LedReturnOk            on success
///          LedReturnColorError    if color is invalid
///          LedReturnOutOfRange    if selected led is out of range
///          LedReturnAlreadySet    if led state is the same as the selected
//--------------------------------------------------------------------------------
tLedReturn LEDCTL_SetFlash(tLed,
                           tLedColor,
                           tLedColor,
                           tLedTime);

//-- Function: LEDCTL_GetAllStates ---------------------------------------------------
///
///  Get States of all LEDs
///  uses a Array of tLedStates for writing the informaion
///  array elements contains the real real number of written LEDs
///
///  Thread-safety: This is thread-safe and reentrant
///
///  \param LedStates Pointer to Array of LED states
///  \param arrayElements Pointer to an Integer containing the number of array elements
///
///  \return LedReturnOk            on success
//------------------------------------------------------------------------------------
tLedReturn LEDCTL_GetAllStates(tLedState *,
                               unsigned int *);

//-- Function: LEDCTL_GetState ---------------------------------------------------
///
///  Get States of one
///  uses a Array of tLedStates for writing the informaion
///  array elements contains the real real number of written LEDs
///
///  Thread-safety: This is thread-safe and reentrant
///
///  \param Led enum of asked LED
///  \param LetSate Pointer to instance of tLedState
///
///  \return LedReturnOk            on success
//--------------------------------------------------------------------------------
tLedReturn LEDCTL_GetState( tLed,
                            tLedState *);

#endif /* WAGOLEDCTL_H_ */
