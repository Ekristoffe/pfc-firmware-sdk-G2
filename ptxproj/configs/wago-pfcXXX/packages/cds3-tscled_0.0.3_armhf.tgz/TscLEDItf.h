 /**
 * <interfacename>TscLED</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCLEDITF_H_
#define _TSCLEDITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eLedColor_Tsc</description>
 */
#define ELEDCOLOR_TSC_OFF    0	
#define ELEDCOLOR_TSC_GREEN    1	
#define ELEDCOLOR_TSC_RED    2	
#define ELEDCOLOR_TSC_YELLOW    3	
#define ELEDCOLOR_TSC_BLUE    4	
#define ELEDCOLOR_TSC_CYAN    5	
#define ELEDCOLOR_TSC_MAGENTA    6	
#define ELEDCOLOR_TSC_WHITE    7	
/* Typed enum definition */
#define ELEDCOLOR_TSC    RTS_IEC_INT

/**
 * identifies one of the LEDs which can be operated with FbUserLED 
 */
#define ELEDID_TSC_NONE    0	
#define ELEDID_TSC_USERLED_1    1	
#define ELEDID_TSC_USERLED_2    2	
#define ELEDID_TSC_USERLED_3    3	
#define ELEDID_TSC_USERLED_4    4	
#define ELEDID_TSC_USERLED_5    5	
#define ELEDID_TSC_USERLED_6    6	
#define ELEDID_TSC_USERLED_7    7	
#define ELEDID_TSC_SYS		    8
#define ELEDID_TSC_RUN		    9
#define ELEDID_TSC_IO		   10
#define ELEDID_TSC_MS		   11
#define ELEDID_TSC_NS		   12
#define ELEDID_TSC_CAN		   13
#define ELEDID_TSC_BF 		   14
#define ELEDID_TSC_DIA 		   15
/* Typed enum definition */
#define ELEDID_TSC    RTS_IEC_INT

/**
 * <description>Enum: eLedState</description>
 */
#define ELEDSTATE_FAIL    0	
#define ELEDSTATE_OFF    1	
#define ELEDSTATE_STATIC    2	
#define ELEDSTATE_BLINK    3	
#define ELEDSTATE_FLASH    4	
/* Typed enum definition */
#define ELEDSTATE    RTS_IEC_INT

/**
 * <description>LED_STATE</description>
 */
typedef struct tagLED_STATE
{
	RTS_IEC_INT eLedID;		
	RTS_IEC_INT eState;		
	RTS_IEC_TIME timTime1;		
	RTS_IEC_TIME timTime2;		
	RTS_IEC_INT eColor1;		
	RTS_IEC_INT eColor2;		
} LED_STATE;

/**
 * <description>led_get_states__main</description>
 */
typedef struct tagled_get_states_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	RTS_IEC_BOOL bEN;					/* VAR_INPUT */	
	RTS_IEC_BOOL bDone;					/* VAR_OUTPUT */	
	RTS_IEC_BOOL bBusy;					/* VAR_OUTPUT */	
	RTS_IEC_DWORD *dwNoOfLEDs;			/* VAR_IN_OUT */	
	LED_STATE **States;					/* VAR_IN_OUT */	
	RTS_IEC_BOOL oldEnable;				/* Local variable */	
} led_get_states_struct;

/**
 * <description>led_get_states_fb_init</description>
 */
typedef struct tagled_get_states_fb_init_struct
{
	led_get_states_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	/* bei TRUE werden die Retain-Variablen initialisiert (Warmstart / Kaltstart) */
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* bei TRUE wird die Instanz anschließend in den Copy-Code kopiert (Online Change) */
	RTS_IEC_BOOL fb_init;				/* VAR_OUTPUT */	
} led_get_states_fb_init_struct;

void CDECL CDECL_EXT led_get_states__fb_init(led_get_states_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFLED_GET_STATES__FB_INIT_IEC) (led_get_states_fb_init_struct *p);
#if defined(TSCLED_NOTIMPLEMENTED) || defined(LED_GET_STATES__FB_INIT_NOTIMPLEMENTED)
	#define USE_led_get_states__fb_init
	#define EXT_led_get_states__fb_init
	#define GET_led_get_states__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_led_get_states__fb_init(p0) 
	#define CHK_led_get_states__fb_init  FALSE
	#define EXP_led_get_states__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_led_get_states__fb_init
	#define EXT_led_get_states__fb_init
	#define GET_led_get_states__fb_init(fl)  CAL_CMGETAPI( "led_get_states__fb_init" ) 
	#define CAL_led_get_states__fb_init  led_get_states__fb_init
	#define CHK_led_get_states__fb_init  TRUE
	#define EXP_led_get_states__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_init", (RTS_UINTPTR)led_get_states__fb_init, 1, 0x0, 0x01000002) 
	#define EXTREF_ITF_led_get_states__fb_init {(RTS_VOID_FCTPTR)led_get_states__fb_init, "led_get_states__fb_init", 0x0, 0x01000002}
#elif defined(MIXED_LINK) && !defined(TSCLED_EXTERNAL)
	#define USE_led_get_states__fb_init
	#define EXT_led_get_states__fb_init
	#define GET_led_get_states__fb_init(fl)  CAL_CMGETAPI( "led_get_states__fb_init" ) 
	#define CAL_led_get_states__fb_init  led_get_states__fb_init
	#define CHK_led_get_states__fb_init  TRUE
	#define EXP_led_get_states__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_init", (RTS_UINTPTR)led_get_states__fb_init, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscLEDled_get_states__fb_init
	#define EXT_TscLEDled_get_states__fb_init
	#define GET_TscLEDled_get_states__fb_init  ERR_OK
	#define CAL_TscLEDled_get_states__fb_init  led_get_states__fb_init
	#define CHK_TscLEDled_get_states__fb_init  TRUE
	#define EXP_TscLEDled_get_states__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_init", (RTS_UINTPTR)led_get_states__fb_init, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS)
	#define USE_led_get_states__fb_init
	#define EXT_led_get_states__fb_init
	#define GET_led_get_states__fb_init(fl)  CAL_CMGETAPI( "led_get_states__fb_init" ) 
	#define CAL_led_get_states__fb_init  led_get_states__fb_init
	#define CHK_led_get_states__fb_init  TRUE
	#define EXP_led_get_states__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_init", (RTS_UINTPTR)led_get_states__fb_init, 1, 0x0, 0x01000002) 
#else /* DYNAMIC_LINK */
	#define USE_led_get_states__fb_init  PFLED_GET_STATES__FB_INIT_IEC pfled_get_states__fb_init;
	#define EXT_led_get_states__fb_init  extern PFLED_GET_STATES__FB_INIT_IEC pfled_get_states__fb_init;
	#define GET_led_get_states__fb_init(fl)  s_pfCMGetAPI2( "led_get_states__fb_init", (RTS_VOID_FCTPTR *)&pfled_get_states__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0, 0x01000002)
	#define CAL_led_get_states__fb_init  pfled_get_states__fb_init
	#define CHK_led_get_states__fb_init  (pfled_get_states__fb_init != NULL)
	#define EXP_led_get_states__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_init", (RTS_UINTPTR)led_get_states__fb_init, 1, 0x0, 0x01000002) 
#endif


/**
 * <description>led_get_states_main</description>
 */
typedef struct tagled_get_states_main_struct
{
	led_get_states_struct *pInstance;	/* VAR_INPUT */	
} led_get_states_main_struct;

void CDECL CDECL_EXT led_get_states__main(led_get_states_main_struct *p);
typedef void (CDECL CDECL_EXT* PFLED_GET_STATES__MAIN_IEC) (led_get_states_main_struct *p);
#if defined(TSCLED_NOTIMPLEMENTED) || defined(LED_GET_STATES__MAIN_NOTIMPLEMENTED)
	#define USE_led_get_states__main
	#define EXT_led_get_states__main
	#define GET_led_get_states__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_led_get_states__main(p0) 
	#define CHK_led_get_states__main  FALSE
	#define EXP_led_get_states__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_led_get_states__main
	#define EXT_led_get_states__main
	#define GET_led_get_states__main(fl)  CAL_CMGETAPI( "led_get_states__main" ) 
	#define CAL_led_get_states__main  led_get_states__main
	#define CHK_led_get_states__main  TRUE
	#define EXP_led_get_states__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__main", (RTS_UINTPTR)led_get_states__main, 1, 0x0, 0x01000002) 
	#define EXTREF_ITF_led_get_states__main {(RTS_VOID_FCTPTR)led_get_states__main, "led_get_states__main", 0x0, 0x01000002}
#elif defined(MIXED_LINK) && !defined(TSCLED_EXTERNAL)
	#define USE_led_get_states__main
	#define EXT_led_get_states__main
	#define GET_led_get_states__main(fl)  CAL_CMGETAPI( "led_get_states__main" ) 
	#define CAL_led_get_states__main  led_get_states__main
	#define CHK_led_get_states__main  TRUE
	#define EXP_led_get_states__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__main", (RTS_UINTPTR)led_get_states__main, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscLEDled_get_states__main
	#define EXT_TscLEDled_get_states__main
	#define GET_TscLEDled_get_states__main  ERR_OK
	#define CAL_TscLEDled_get_states__main  led_get_states__main
	#define CHK_TscLEDled_get_states__main  TRUE
	#define EXP_TscLEDled_get_states__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__main", (RTS_UINTPTR)led_get_states__main, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS)
	#define USE_led_get_states__main
	#define EXT_led_get_states__main
	#define GET_led_get_states__main(fl)  CAL_CMGETAPI( "led_get_states__main" ) 
	#define CAL_led_get_states__main  led_get_states__main
	#define CHK_led_get_states__main  TRUE
	#define EXP_led_get_states__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__main", (RTS_UINTPTR)led_get_states__main, 1, 0x0, 0x01000002) 
#else /* DYNAMIC_LINK */
	#define USE_led_get_states__main  PFLED_GET_STATES__MAIN_IEC pfled_get_states__main;
	#define EXT_led_get_states__main  extern PFLED_GET_STATES__MAIN_IEC pfled_get_states__main;
	#define GET_led_get_states__main(fl)  s_pfCMGetAPI2( "led_get_states__main", (RTS_VOID_FCTPTR *)&pfled_get_states__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0, 0x01000002)
	#define CAL_led_get_states__main  pfled_get_states__main
	#define CHK_led_get_states__main  (pfled_get_states__main != NULL)
	#define EXP_led_get_states__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__main", (RTS_UINTPTR)led_get_states__main, 1, 0x0, 0x01000002) 
#endif


/**
 * <description>led_get_states_fb_exit</description>
 */
typedef struct tagled_get_states_fb_exit_struct
{
	led_get_states_struct *pInstance;	/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	
	RTS_IEC_BOOL fb_exit;				/* VAR_OUTPUT */	
} led_get_states_fb_exit_struct;

void CDECL CDECL_EXT led_get_states__fb_exit(led_get_states_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFLED_GET_STATES__FB_EXIT_IEC) (led_get_states_fb_exit_struct *p);
#if defined(TSCLED_NOTIMPLEMENTED) || defined(LED_GET_STATES__FB_EXIT_NOTIMPLEMENTED)
	#define USE_led_get_states__fb_exit
	#define EXT_led_get_states__fb_exit
	#define GET_led_get_states__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_led_get_states__fb_exit(p0) 
	#define CHK_led_get_states__fb_exit  FALSE
	#define EXP_led_get_states__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_led_get_states__fb_exit
	#define EXT_led_get_states__fb_exit
	#define GET_led_get_states__fb_exit(fl)  CAL_CMGETAPI( "led_get_states__fb_exit" ) 
	#define CAL_led_get_states__fb_exit  led_get_states__fb_exit
	#define CHK_led_get_states__fb_exit  TRUE
	#define EXP_led_get_states__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_exit", (RTS_UINTPTR)led_get_states__fb_exit, 1, 0x0, 0x01000002) 
	#define EXTREF_ITF_led_get_states__fb_exit {(RTS_VOID_FCTPTR)led_get_states__fb_exit, "led_get_states__fb_exit", 0x0, 0x01000002}
#elif defined(MIXED_LINK) && !defined(TSCLED_EXTERNAL)
	#define USE_led_get_states__fb_exit
	#define EXT_led_get_states__fb_exit
	#define GET_led_get_states__fb_exit(fl)  CAL_CMGETAPI( "led_get_states__fb_exit" ) 
	#define CAL_led_get_states__fb_exit  led_get_states__fb_exit
	#define CHK_led_get_states__fb_exit  TRUE
	#define EXP_led_get_states__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_exit", (RTS_UINTPTR)led_get_states__fb_exit, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscLEDled_get_states__fb_exit
	#define EXT_TscLEDled_get_states__fb_exit
	#define GET_TscLEDled_get_states__fb_exit  ERR_OK
	#define CAL_TscLEDled_get_states__fb_exit  led_get_states__fb_exit
	#define CHK_TscLEDled_get_states__fb_exit  TRUE
	#define EXP_TscLEDled_get_states__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_exit", (RTS_UINTPTR)led_get_states__fb_exit, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS)
	#define USE_led_get_states__fb_exit
	#define EXT_led_get_states__fb_exit
	#define GET_led_get_states__fb_exit(fl)  CAL_CMGETAPI( "led_get_states__fb_exit" ) 
	#define CAL_led_get_states__fb_exit  led_get_states__fb_exit
	#define CHK_led_get_states__fb_exit  TRUE
	#define EXP_led_get_states__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_exit", (RTS_UINTPTR)led_get_states__fb_exit, 1, 0x0, 0x01000002) 
#else /* DYNAMIC_LINK */
	#define USE_led_get_states__fb_exit  PFLED_GET_STATES__FB_EXIT_IEC pfled_get_states__fb_exit;
	#define EXT_led_get_states__fb_exit  extern PFLED_GET_STATES__FB_EXIT_IEC pfled_get_states__fb_exit;
	#define GET_led_get_states__fb_exit(fl)  s_pfCMGetAPI2( "led_get_states__fb_exit", (RTS_VOID_FCTPTR *)&pfled_get_states__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0, 0x01000002)
	#define CAL_led_get_states__fb_exit  pfled_get_states__fb_exit
	#define CHK_led_get_states__fb_exit  (pfled_get_states__fb_exit != NULL)
	#define EXP_led_get_states__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_get_states__fb_exit", (RTS_UINTPTR)led_get_states__fb_exit, 1, 0x0, 0x01000002) 
#endif


/**
 * make the LED blink, i.e. switch between two color states cyclically
 *
 *
 *=============  ====================================================================================== 
 ***result codes**
 *----------------------------------------------------------------------------------------------------- 
 *0              success
 *EALREADY       LED is already in this state
 *EINVAL         Illegal color code
 *ENODEV         Unsupported LED ID
 *ETIME          Illegal timing set
 *=============  ====================================================================================== 
 *
 *On error, no change of the LED state takes place.
 *
 */
typedef struct tagled_set_blink_struct
{
	RTS_IEC_INT LedId;					/* VAR_INPUT, Enum: ELEDID_TSC */
	RTS_IEC_TIME timTime1;				/* VAR_INPUT */	
	RTS_IEC_TIME timTime2;				/* VAR_INPUT */	
	RTS_IEC_INT color1;					/* VAR_INPUT, Enum: ELEDCOLOR_TSC */
	RTS_IEC_INT color2;					/* VAR_INPUT, Enum: ELEDCOLOR_TSC */
	RTS_IEC_DWORD LED_Set_Blink;		/* VAR_OUTPUT */	
} led_set_blink_struct;

void CDECL CDECL_EXT led_set_blink(led_set_blink_struct *p);
typedef void (CDECL CDECL_EXT* PFLED_SET_BLINK_IEC) (led_set_blink_struct *p);
#if defined(TSCLED_NOTIMPLEMENTED) || defined(LED_SET_BLINK_NOTIMPLEMENTED)
	#define USE_led_set_blink
	#define EXT_led_set_blink
	#define GET_led_set_blink(fl)  ERR_NOTIMPLEMENTED
	#define CAL_led_set_blink(p0) 
	#define CHK_led_set_blink  FALSE
	#define EXP_led_set_blink  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_led_set_blink
	#define EXT_led_set_blink
	#define GET_led_set_blink(fl)  CAL_CMGETAPI( "led_set_blink" ) 
	#define CAL_led_set_blink  led_set_blink
	#define CHK_led_set_blink  TRUE
	#define EXP_led_set_blink  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_blink", (RTS_UINTPTR)led_set_blink, 1, 0x0, 0x01000002) 
	#define EXTREF_ITF_led_set_blink {(RTS_VOID_FCTPTR)led_set_blink, "led_set_blink", 0x0, 0x01000002}
#elif defined(MIXED_LINK) && !defined(TSCLED_EXTERNAL)
	#define USE_led_set_blink
	#define EXT_led_set_blink
	#define GET_led_set_blink(fl)  CAL_CMGETAPI( "led_set_blink" ) 
	#define CAL_led_set_blink  led_set_blink
	#define CHK_led_set_blink  TRUE
	#define EXP_led_set_blink  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_blink", (RTS_UINTPTR)led_set_blink, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscLEDled_set_blink
	#define EXT_TscLEDled_set_blink
	#define GET_TscLEDled_set_blink  ERR_OK
	#define CAL_TscLEDled_set_blink  led_set_blink
	#define CHK_TscLEDled_set_blink  TRUE
	#define EXP_TscLEDled_set_blink  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_blink", (RTS_UINTPTR)led_set_blink, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS)
	#define USE_led_set_blink
	#define EXT_led_set_blink
	#define GET_led_set_blink(fl)  CAL_CMGETAPI( "led_set_blink" ) 
	#define CAL_led_set_blink  led_set_blink
	#define CHK_led_set_blink  TRUE
	#define EXP_led_set_blink  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_blink", (RTS_UINTPTR)led_set_blink, 1, 0x0, 0x01000002) 
#else /* DYNAMIC_LINK */
	#define USE_led_set_blink  PFLED_SET_BLINK_IEC pfled_set_blink;
	#define EXT_led_set_blink  extern PFLED_SET_BLINK_IEC pfled_set_blink;
	#define GET_led_set_blink(fl)  s_pfCMGetAPI2( "led_set_blink", (RTS_VOID_FCTPTR *)&pfled_set_blink, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0, 0x01000002)
	#define CAL_led_set_blink  pfled_set_blink
	#define CHK_led_set_blink  (pfled_set_blink != NULL)
	#define EXP_led_set_blink   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_blink", (RTS_UINTPTR)led_set_blink, 1, 0x0, 0x01000002) 
#endif


/**
 * Make the LED display a color for a given time ('flash') 
 *and then display continuously a second color (which also could be 'off')
 * 
 *While the first phase of the flashis in progress, the xBusy-Output of the FB is TRUE.
 *
 *When applying this function while the LED is still 'flash'ing, the flash time 
 *will be retriggered.   
 *
 *When the flash time is expired, the LED transits to the 'static' mode.
 *
 *=============  ====================================================================================== 
 ***result codes**
 *----------------------------------------------------------------------------------------------------- 
 *0              success
 *EINVAL         Illegal color code
 *ENODEV         Unsupported LED ID
 *EINVAL         Illegal color code
 *=============  ====================================================================================== 
 *
 *On error, no change of the LED state takes place.
 *
 */
typedef struct tagled_set_flash_struct
{
	RTS_IEC_INT LedId;					/* VAR_INPUT, Enum: ELEDID_TSC */
	RTS_IEC_TIME timFlash_time;			/* VAR_INPUT */	
	RTS_IEC_INT eFlash_color;			/* VAR_INPUT, Enum: ELEDCOLOR_TSC */
	RTS_IEC_INT eStatic_color;			/* VAR_INPUT, Enum: ELEDCOLOR_TSC */
	RTS_IEC_DWORD LED_Set_Flash;		/* VAR_OUTPUT */	
} led_set_flash_struct;

void CDECL CDECL_EXT led_set_flash(led_set_flash_struct *p);
typedef void (CDECL CDECL_EXT* PFLED_SET_FLASH_IEC) (led_set_flash_struct *p);
#if defined(TSCLED_NOTIMPLEMENTED) || defined(LED_SET_FLASH_NOTIMPLEMENTED)
	#define USE_led_set_flash
	#define EXT_led_set_flash
	#define GET_led_set_flash(fl)  ERR_NOTIMPLEMENTED
	#define CAL_led_set_flash(p0) 
	#define CHK_led_set_flash  FALSE
	#define EXP_led_set_flash  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_led_set_flash
	#define EXT_led_set_flash
	#define GET_led_set_flash(fl)  CAL_CMGETAPI( "led_set_flash" ) 
	#define CAL_led_set_flash  led_set_flash
	#define CHK_led_set_flash  TRUE
	#define EXP_led_set_flash  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_flash", (RTS_UINTPTR)led_set_flash, 1, 0x0, 0x01000002) 
	#define EXTREF_ITF_led_set_flash {(RTS_VOID_FCTPTR)led_set_flash, "led_set_flash", 0x0, 0x01000002}
#elif defined(MIXED_LINK) && !defined(TSCLED_EXTERNAL)
	#define USE_led_set_flash
	#define EXT_led_set_flash
	#define GET_led_set_flash(fl)  CAL_CMGETAPI( "led_set_flash" ) 
	#define CAL_led_set_flash  led_set_flash
	#define CHK_led_set_flash  TRUE
	#define EXP_led_set_flash  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_flash", (RTS_UINTPTR)led_set_flash, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscLEDled_set_flash
	#define EXT_TscLEDled_set_flash
	#define GET_TscLEDled_set_flash  ERR_OK
	#define CAL_TscLEDled_set_flash  led_set_flash
	#define CHK_TscLEDled_set_flash  TRUE
	#define EXP_TscLEDled_set_flash  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_flash", (RTS_UINTPTR)led_set_flash, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS)
	#define USE_led_set_flash
	#define EXT_led_set_flash
	#define GET_led_set_flash(fl)  CAL_CMGETAPI( "led_set_flash" ) 
	#define CAL_led_set_flash  led_set_flash
	#define CHK_led_set_flash  TRUE
	#define EXP_led_set_flash  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_flash", (RTS_UINTPTR)led_set_flash, 1, 0x0, 0x01000002) 
#else /* DYNAMIC_LINK */
	#define USE_led_set_flash  PFLED_SET_FLASH_IEC pfled_set_flash;
	#define EXT_led_set_flash  extern PFLED_SET_FLASH_IEC pfled_set_flash;
	#define GET_led_set_flash(fl)  s_pfCMGetAPI2( "led_set_flash", (RTS_VOID_FCTPTR *)&pfled_set_flash, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0, 0x01000002)
	#define CAL_led_set_flash  pfled_set_flash
	#define CHK_led_set_flash  (pfled_set_flash != NULL)
	#define EXP_led_set_flash   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_flash", (RTS_UINTPTR)led_set_flash, 1, 0x0, 0x01000002) 
#endif


/**
 * sets the LED to a static operating state 
 *
 *The parameter "eColor" denotes the new illumination color of the LED (which might also be "off").
 * 	
 *=============  ====================================================================================== 
 ***result codes**
 *----------------------------------------------------------------------------------------------------- 
 *0              success
 *EALREADY       LED is already in this state
 *EINVAL         Illegal color code
 *ENODEV         Unsupported LED ID
 *=============  ====================================================================================== 
 *
 *If the requested color is not supported by the hardware, this method fails with EINVAL ("Invalid Argument");
 *
 *On error, no change of the LED state takes place.
 */
typedef struct tagled_set_static_struct
{
	RTS_IEC_INT LedId;					/* VAR_INPUT, Enum: ELEDID_TSC */
	RTS_IEC_INT color;					/* VAR_INPUT, Enum: ELEDCOLOR_TSC */
	RTS_IEC_DWORD LED_Set_Static;		/* VAR_OUTPUT */	
} led_set_static_struct;

void CDECL CDECL_EXT led_set_static(led_set_static_struct *p);
typedef void (CDECL CDECL_EXT* PFLED_SET_STATIC_IEC) (led_set_static_struct *p);
#if defined(TSCLED_NOTIMPLEMENTED) || defined(LED_SET_STATIC_NOTIMPLEMENTED)
	#define USE_led_set_static
	#define EXT_led_set_static
	#define GET_led_set_static(fl)  ERR_NOTIMPLEMENTED
	#define CAL_led_set_static(p0) 
	#define CHK_led_set_static  FALSE
	#define EXP_led_set_static  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_led_set_static
	#define EXT_led_set_static
	#define GET_led_set_static(fl)  CAL_CMGETAPI( "led_set_static" ) 
	#define CAL_led_set_static  led_set_static
	#define CHK_led_set_static  TRUE
	#define EXP_led_set_static  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_static", (RTS_UINTPTR)led_set_static, 1, 0x0, 0x01000002) 
	#define EXTREF_ITF_led_set_static {(RTS_VOID_FCTPTR)led_set_static, "led_set_static", 0x0, 0x01000002}
#elif defined(MIXED_LINK) && !defined(TSCLED_EXTERNAL)
	#define USE_led_set_static
	#define EXT_led_set_static
	#define GET_led_set_static(fl)  CAL_CMGETAPI( "led_set_static" ) 
	#define CAL_led_set_static  led_set_static
	#define CHK_led_set_static  TRUE
	#define EXP_led_set_static  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_static", (RTS_UINTPTR)led_set_static, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscLEDled_set_static
	#define EXT_TscLEDled_set_static
	#define GET_TscLEDled_set_static  ERR_OK
	#define CAL_TscLEDled_set_static  led_set_static
	#define CHK_TscLEDled_set_static  TRUE
	#define EXP_TscLEDled_set_static  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_static", (RTS_UINTPTR)led_set_static, 1, 0x0, 0x01000002) 
#elif defined(CPLUSPLUS)
	#define USE_led_set_static
	#define EXT_led_set_static
	#define GET_led_set_static(fl)  CAL_CMGETAPI( "led_set_static" ) 
	#define CAL_led_set_static  led_set_static
	#define CHK_led_set_static  TRUE
	#define EXP_led_set_static  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_static", (RTS_UINTPTR)led_set_static, 1, 0x0, 0x01000002) 
#else /* DYNAMIC_LINK */
	#define USE_led_set_static  PFLED_SET_STATIC_IEC pfled_set_static;
	#define EXT_led_set_static  extern PFLED_SET_STATIC_IEC pfled_set_static;
	#define GET_led_set_static(fl)  s_pfCMGetAPI2( "led_set_static", (RTS_VOID_FCTPTR *)&pfled_set_static, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0, 0x01000002)
	#define CAL_led_set_static  pfled_set_static
	#define CHK_led_set_static  (pfled_set_static != NULL)
	#define EXP_led_set_static   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"led_set_static", (RTS_UINTPTR)led_set_static, 1, 0x0, 0x01000002) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ITscLED_C;

#ifdef CPLUSPLUS
class ITscLED : public IBase
{
	public:
};
	#ifndef ITF_TscLED
		#define ITF_TscLED static ITscLED *pITscLED = NULL;
	#endif
	#define EXTITF_TscLED
#else	/*CPLUSPLUS*/
	typedef ITscLED_C		ITscLED;
	#ifndef ITF_TscLED
		#define ITF_TscLED
	#endif
	#define EXTITF_TscLED
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCLEDITF_H_*/
