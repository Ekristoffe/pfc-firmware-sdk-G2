 /**
 * <interfacename>SysUtil</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _SYSUTILITF_H_
#define _SYSUTILITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/* routines for OS specific modules */
RTS_RESULT SysUtil_init3(void);
RTS_RESULT SysUtil_run(void);
RTS_RESULT SysUtil_exit3(void);

RTS_IEC_RESULT CDECL SysUtilConvWStringToUTF8(RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVWSTRINGTOUTF8) (RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVWSTRINGTOUTF8_NOTIMPLEMENTED)
	#define USE_SysUtilConvWStringToUTF8
	#define EXT_SysUtilConvWStringToUTF8
	#define GET_SysUtilConvWStringToUTF8(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvWStringToUTF8(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvWStringToUTF8  FALSE
	#define EXP_SysUtilConvWStringToUTF8  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvWStringToUTF8
	#define EXT_SysUtilConvWStringToUTF8
	#define GET_SysUtilConvWStringToUTF8(fl)  CAL_CMGETAPI( "SysUtilConvWStringToUTF8" ) 
	#define CAL_SysUtilConvWStringToUTF8  SysUtilConvWStringToUTF8
	#define CHK_SysUtilConvWStringToUTF8  TRUE
	#define EXP_SysUtilConvWStringToUTF8  CAL_CMEXPAPI( "SysUtilConvWStringToUTF8" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvWStringToUTF8
	#define EXT_SysUtilConvWStringToUTF8
	#define GET_SysUtilConvWStringToUTF8(fl)  CAL_CMGETAPI( "SysUtilConvWStringToUTF8" ) 
	#define CAL_SysUtilConvWStringToUTF8  SysUtilConvWStringToUTF8
	#define CHK_SysUtilConvWStringToUTF8  TRUE
	#define EXP_SysUtilConvWStringToUTF8  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvWStringToUTF8", (RTS_UINTPTR)SysUtilConvWStringToUTF8, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvWStringToUTF8
	#define EXT_SysUtilSysUtilConvWStringToUTF8
	#define GET_SysUtilSysUtilConvWStringToUTF8  ERR_OK
	#define CAL_SysUtilSysUtilConvWStringToUTF8  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvWStringToUTF8
	#define CHK_SysUtilSysUtilConvWStringToUTF8	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvWStringToUTF8  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvWStringToUTF8
	#define EXT_SysUtilConvWStringToUTF8
	#define GET_SysUtilConvWStringToUTF8(fl)  CAL_CMGETAPI( "SysUtilConvWStringToUTF8" ) 
	#define CAL_SysUtilConvWStringToUTF8  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvWStringToUTF8
	#define CHK_SysUtilConvWStringToUTF8	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvWStringToUTF8  CAL_CMEXPAPI( "SysUtilConvWStringToUTF8" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvWStringToUTF8  PFSYSUTILCONVWSTRINGTOUTF8 pfSysUtilConvWStringToUTF8;
	#define EXT_SysUtilConvWStringToUTF8  extern PFSYSUTILCONVWSTRINGTOUTF8 pfSysUtilConvWStringToUTF8;
	#define GET_SysUtilConvWStringToUTF8(fl)  s_pfCMGetAPI2( "SysUtilConvWStringToUTF8", (RTS_VOID_FCTPTR *)&pfSysUtilConvWStringToUTF8, (fl), 0, 0)
	#define CAL_SysUtilConvWStringToUTF8  pfSysUtilConvWStringToUTF8
	#define CHK_SysUtilConvWStringToUTF8  (pfSysUtilConvWStringToUTF8 != NULL)
	#define EXP_SysUtilConvWStringToUTF8  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvWStringToUTF8", (RTS_UINTPTR)SysUtilConvWStringToUTF8, 0, 0) 
#endif



RTS_IEC_RESULT CDECL SysUtilConvUTF8ToWString(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVUTF8TOWSTRING) (RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVUTF8TOWSTRING_NOTIMPLEMENTED)
	#define USE_SysUtilConvUTF8ToWString
	#define EXT_SysUtilConvUTF8ToWString
	#define GET_SysUtilConvUTF8ToWString(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvUTF8ToWString(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvUTF8ToWString  FALSE
	#define EXP_SysUtilConvUTF8ToWString  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvUTF8ToWString
	#define EXT_SysUtilConvUTF8ToWString
	#define GET_SysUtilConvUTF8ToWString(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToWString" ) 
	#define CAL_SysUtilConvUTF8ToWString  SysUtilConvUTF8ToWString
	#define CHK_SysUtilConvUTF8ToWString  TRUE
	#define EXP_SysUtilConvUTF8ToWString  CAL_CMEXPAPI( "SysUtilConvUTF8ToWString" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvUTF8ToWString
	#define EXT_SysUtilConvUTF8ToWString
	#define GET_SysUtilConvUTF8ToWString(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToWString" ) 
	#define CAL_SysUtilConvUTF8ToWString  SysUtilConvUTF8ToWString
	#define CHK_SysUtilConvUTF8ToWString  TRUE
	#define EXP_SysUtilConvUTF8ToWString  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToWString", (RTS_UINTPTR)SysUtilConvUTF8ToWString, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvUTF8ToWString
	#define EXT_SysUtilSysUtilConvUTF8ToWString
	#define GET_SysUtilSysUtilConvUTF8ToWString  ERR_OK
	#define CAL_SysUtilSysUtilConvUTF8ToWString  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToWString
	#define CHK_SysUtilSysUtilConvUTF8ToWString	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvUTF8ToWString  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvUTF8ToWString
	#define EXT_SysUtilConvUTF8ToWString
	#define GET_SysUtilConvUTF8ToWString(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToWString" ) 
	#define CAL_SysUtilConvUTF8ToWString  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToWString
	#define CHK_SysUtilConvUTF8ToWString	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvUTF8ToWString  CAL_CMEXPAPI( "SysUtilConvUTF8ToWString" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvUTF8ToWString  PFSYSUTILCONVUTF8TOWSTRING pfSysUtilConvUTF8ToWString;
	#define EXT_SysUtilConvUTF8ToWString  extern PFSYSUTILCONVUTF8TOWSTRING pfSysUtilConvUTF8ToWString;
	#define GET_SysUtilConvUTF8ToWString(fl)  s_pfCMGetAPI2( "SysUtilConvUTF8ToWString", (RTS_VOID_FCTPTR *)&pfSysUtilConvUTF8ToWString, (fl), 0, 0)
	#define CAL_SysUtilConvUTF8ToWString  pfSysUtilConvUTF8ToWString
	#define CHK_SysUtilConvUTF8ToWString  (pfSysUtilConvUTF8ToWString != NULL)
	#define EXP_SysUtilConvUTF8ToWString  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToWString", (RTS_UINTPTR)SysUtilConvUTF8ToWString, 0, 0) 
#endif



RTS_IEC_RESULT CDECL SysUtilConvUTF8ToString(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVUTF8TOSTRING) (RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVUTF8TOSTRING_NOTIMPLEMENTED)
	#define USE_SysUtilConvUTF8ToString
	#define EXT_SysUtilConvUTF8ToString
	#define GET_SysUtilConvUTF8ToString(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvUTF8ToString(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvUTF8ToString  FALSE
	#define EXP_SysUtilConvUTF8ToString  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvUTF8ToString
	#define EXT_SysUtilConvUTF8ToString
	#define GET_SysUtilConvUTF8ToString(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString" ) 
	#define CAL_SysUtilConvUTF8ToString  SysUtilConvUTF8ToString
	#define CHK_SysUtilConvUTF8ToString  TRUE
	#define EXP_SysUtilConvUTF8ToString  CAL_CMEXPAPI( "SysUtilConvUTF8ToString" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvUTF8ToString
	#define EXT_SysUtilConvUTF8ToString
	#define GET_SysUtilConvUTF8ToString(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString" ) 
	#define CAL_SysUtilConvUTF8ToString  SysUtilConvUTF8ToString
	#define CHK_SysUtilConvUTF8ToString  TRUE
	#define EXP_SysUtilConvUTF8ToString  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString", (RTS_UINTPTR)SysUtilConvUTF8ToString, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvUTF8ToString
	#define EXT_SysUtilSysUtilConvUTF8ToString
	#define GET_SysUtilSysUtilConvUTF8ToString  ERR_OK
	#define CAL_SysUtilSysUtilConvUTF8ToString  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString
	#define CHK_SysUtilSysUtilConvUTF8ToString	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvUTF8ToString  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvUTF8ToString
	#define EXT_SysUtilConvUTF8ToString
	#define GET_SysUtilConvUTF8ToString(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString" ) 
	#define CAL_SysUtilConvUTF8ToString  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString
	#define CHK_SysUtilConvUTF8ToString	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvUTF8ToString  CAL_CMEXPAPI( "SysUtilConvUTF8ToString" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvUTF8ToString  PFSYSUTILCONVUTF8TOSTRING pfSysUtilConvUTF8ToString;
	#define EXT_SysUtilConvUTF8ToString  extern PFSYSUTILCONVUTF8TOSTRING pfSysUtilConvUTF8ToString;
	#define GET_SysUtilConvUTF8ToString(fl)  s_pfCMGetAPI2( "SysUtilConvUTF8ToString", (RTS_VOID_FCTPTR *)&pfSysUtilConvUTF8ToString, (fl), 0, 0)
	#define CAL_SysUtilConvUTF8ToString  pfSysUtilConvUTF8ToString
	#define CHK_SysUtilConvUTF8ToString  (pfSysUtilConvUTF8ToString != NULL)
	#define EXP_SysUtilConvUTF8ToString  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString", (RTS_UINTPTR)SysUtilConvUTF8ToString, 0, 0) 
#endif



RTS_IEC_RESULT CDECL SysUtilConvUTF8ToString2(RTS_IEC_STRING* lpMultiByteStr);
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVUTF8TOSTRING2) (RTS_IEC_STRING* lpMultiByteStr);
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVUTF8TOSTRING2_NOTIMPLEMENTED)
	#define USE_SysUtilConvUTF8ToString2
	#define EXT_SysUtilConvUTF8ToString2
	#define GET_SysUtilConvUTF8ToString2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvUTF8ToString2(p0)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvUTF8ToString2  FALSE
	#define EXP_SysUtilConvUTF8ToString2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvUTF8ToString2
	#define EXT_SysUtilConvUTF8ToString2
	#define GET_SysUtilConvUTF8ToString2(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString2" ) 
	#define CAL_SysUtilConvUTF8ToString2  SysUtilConvUTF8ToString2
	#define CHK_SysUtilConvUTF8ToString2  TRUE
	#define EXP_SysUtilConvUTF8ToString2  CAL_CMEXPAPI( "SysUtilConvUTF8ToString2" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvUTF8ToString2
	#define EXT_SysUtilConvUTF8ToString2
	#define GET_SysUtilConvUTF8ToString2(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString2" ) 
	#define CAL_SysUtilConvUTF8ToString2  SysUtilConvUTF8ToString2
	#define CHK_SysUtilConvUTF8ToString2  TRUE
	#define EXP_SysUtilConvUTF8ToString2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString2", (RTS_UINTPTR)SysUtilConvUTF8ToString2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvUTF8ToString2
	#define EXT_SysUtilSysUtilConvUTF8ToString2
	#define GET_SysUtilSysUtilConvUTF8ToString2  ERR_OK
	#define CAL_SysUtilSysUtilConvUTF8ToString2  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString2
	#define CHK_SysUtilSysUtilConvUTF8ToString2	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvUTF8ToString2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvUTF8ToString2
	#define EXT_SysUtilConvUTF8ToString2
	#define GET_SysUtilConvUTF8ToString2(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString2" ) 
	#define CAL_SysUtilConvUTF8ToString2  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString2
	#define CHK_SysUtilConvUTF8ToString2	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvUTF8ToString2  CAL_CMEXPAPI( "SysUtilConvUTF8ToString2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvUTF8ToString2  PFSYSUTILCONVUTF8TOSTRING2 pfSysUtilConvUTF8ToString2;
	#define EXT_SysUtilConvUTF8ToString2  extern PFSYSUTILCONVUTF8TOSTRING2 pfSysUtilConvUTF8ToString2;
	#define GET_SysUtilConvUTF8ToString2(fl)  s_pfCMGetAPI2( "SysUtilConvUTF8ToString2", (RTS_VOID_FCTPTR *)&pfSysUtilConvUTF8ToString2, (fl), 0, 0)
	#define CAL_SysUtilConvUTF8ToString2  pfSysUtilConvUTF8ToString2
	#define CHK_SysUtilConvUTF8ToString2  (pfSysUtilConvUTF8ToString2 != NULL)
	#define EXP_SysUtilConvUTF8ToString2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString2", (RTS_UINTPTR)SysUtilConvUTF8ToString2, 0, 0) 
#endif



// convert a IEC-STRING(ISO8859+special characters) to UTF8
// Input parameters:
// # lpCharStr - STRING to convert
// # cchChar   - size in Bytes of the string indicated by lpCharStr;
//				 Alternatively, this parameter can be set to -1 if the string is null-terminated.
// # lpMultiByteStr - Pointer to a buffer that receives the converted string.
// # cbMultiByte - Size, in characters, of the buffer indicated by lpMultiByteStr.
//				 - If this value is 0, the function returns the required buffer size, in characters, including any terminating null character,
//				   and makes no use of the lpMultiByteStr buffer.
// # pBytesWritten - the number of characters written to the buffer indicated by lpMultiByteStr
// Return Value:
// # ERR_OK - success
// # ERR_PARAMETER - if lpMultiByteStr and lpCharStr are overlapping (to avoid memory overwritting)
// # ERR_BUFFERSIZE - if the size of the buffer lpMultiByteStr is too small;
//					- in this case pBytesWritten is the number of bytes, including NULL terminator, written to the lpMultiByteStr
RTS_IEC_RESULT CDECL SysUtilConvStringToUTF8(const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVSTRINGTOUTF8) (const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVSTRINGTOUTF8_NOTIMPLEMENTED)
	#define USE_SysUtilConvStringToUTF8
	#define EXT_SysUtilConvStringToUTF8
	#define GET_SysUtilConvStringToUTF8(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvStringToUTF8(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvStringToUTF8  FALSE
	#define EXP_SysUtilConvStringToUTF8  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvStringToUTF8
	#define EXT_SysUtilConvStringToUTF8
	#define GET_SysUtilConvStringToUTF8(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF8" ) 
	#define CAL_SysUtilConvStringToUTF8  SysUtilConvStringToUTF8
	#define CHK_SysUtilConvStringToUTF8  TRUE
	#define EXP_SysUtilConvStringToUTF8  CAL_CMEXPAPI( "SysUtilConvStringToUTF8" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvStringToUTF8
	#define EXT_SysUtilConvStringToUTF8
	#define GET_SysUtilConvStringToUTF8(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF8" ) 
	#define CAL_SysUtilConvStringToUTF8  SysUtilConvStringToUTF8
	#define CHK_SysUtilConvStringToUTF8  TRUE
	#define EXP_SysUtilConvStringToUTF8  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvStringToUTF8", (RTS_UINTPTR)SysUtilConvStringToUTF8, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvStringToUTF8
	#define EXT_SysUtilSysUtilConvStringToUTF8
	#define GET_SysUtilSysUtilConvStringToUTF8  ERR_OK
	#define CAL_SysUtilSysUtilConvStringToUTF8  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvStringToUTF8
	#define CHK_SysUtilSysUtilConvStringToUTF8	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvStringToUTF8  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvStringToUTF8
	#define EXT_SysUtilConvStringToUTF8
	#define GET_SysUtilConvStringToUTF8(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF8" ) 
	#define CAL_SysUtilConvStringToUTF8  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvStringToUTF8
	#define CHK_SysUtilConvStringToUTF8	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvStringToUTF8  CAL_CMEXPAPI( "SysUtilConvStringToUTF8" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvStringToUTF8  PFSYSUTILCONVSTRINGTOUTF8 pfSysUtilConvStringToUTF8;
	#define EXT_SysUtilConvStringToUTF8  extern PFSYSUTILCONVSTRINGTOUTF8 pfSysUtilConvStringToUTF8;
	#define GET_SysUtilConvStringToUTF8(fl)  s_pfCMGetAPI2( "SysUtilConvStringToUTF8", (RTS_VOID_FCTPTR *)&pfSysUtilConvStringToUTF8, (fl), 0, 0)
	#define CAL_SysUtilConvStringToUTF8  pfSysUtilConvStringToUTF8
	#define CHK_SysUtilConvStringToUTF8  (pfSysUtilConvStringToUTF8 != NULL)
	#define EXP_SysUtilConvStringToUTF8  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvStringToUTF8", (RTS_UINTPTR)SysUtilConvStringToUTF8, 0, 0) 
#endif



RTS_IEC_RESULT CDECL SysUtilConvStringToUTF82(RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVSTRINGTOUTF82) (RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVSTRINGTOUTF82_NOTIMPLEMENTED)
	#define USE_SysUtilConvStringToUTF82
	#define EXT_SysUtilConvStringToUTF82
	#define GET_SysUtilConvStringToUTF82(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvStringToUTF82(p0,p1,p2)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvStringToUTF82  FALSE
	#define EXP_SysUtilConvStringToUTF82  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvStringToUTF82
	#define EXT_SysUtilConvStringToUTF82
	#define GET_SysUtilConvStringToUTF82(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF82" ) 
	#define CAL_SysUtilConvStringToUTF82  SysUtilConvStringToUTF82
	#define CHK_SysUtilConvStringToUTF82  TRUE
	#define EXP_SysUtilConvStringToUTF82  CAL_CMEXPAPI( "SysUtilConvStringToUTF82" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvStringToUTF82
	#define EXT_SysUtilConvStringToUTF82
	#define GET_SysUtilConvStringToUTF82(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF82" ) 
	#define CAL_SysUtilConvStringToUTF82  SysUtilConvStringToUTF82
	#define CHK_SysUtilConvStringToUTF82  TRUE
	#define EXP_SysUtilConvStringToUTF82  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvStringToUTF82", (RTS_UINTPTR)SysUtilConvStringToUTF82, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvStringToUTF82
	#define EXT_SysUtilSysUtilConvStringToUTF82
	#define GET_SysUtilSysUtilConvStringToUTF82  ERR_OK
	#define CAL_SysUtilSysUtilConvStringToUTF82  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvStringToUTF82
	#define CHK_SysUtilSysUtilConvStringToUTF82	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvStringToUTF82  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvStringToUTF82
	#define EXT_SysUtilConvStringToUTF82
	#define GET_SysUtilConvStringToUTF82(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF82" ) 
	#define CAL_SysUtilConvStringToUTF82  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvStringToUTF82
	#define CHK_SysUtilConvStringToUTF82	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvStringToUTF82  CAL_CMEXPAPI( "SysUtilConvStringToUTF82" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvStringToUTF82  PFSYSUTILCONVSTRINGTOUTF82 pfSysUtilConvStringToUTF82;
	#define EXT_SysUtilConvStringToUTF82  extern PFSYSUTILCONVSTRINGTOUTF82 pfSysUtilConvStringToUTF82;
	#define GET_SysUtilConvStringToUTF82(fl)  s_pfCMGetAPI2( "SysUtilConvStringToUTF82", (RTS_VOID_FCTPTR *)&pfSysUtilConvStringToUTF82, (fl), 0, 0)
	#define CAL_SysUtilConvStringToUTF82  pfSysUtilConvStringToUTF82
	#define CHK_SysUtilConvStringToUTF82  (pfSysUtilConvStringToUTF82 != NULL)
	#define EXP_SysUtilConvStringToUTF82  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvStringToUTF82", (RTS_UINTPTR)SysUtilConvStringToUTF82, 0, 0) 
#endif



// like SysUtilConvStringToUTF8 + Escape (' and \ will be replaced with \' and \\)
RTS_IEC_RESULT CDECL SysUtilConvStringToUTF83(const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVSTRINGTOUTF83) (const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVSTRINGTOUTF83_NOTIMPLEMENTED)
	#define USE_SysUtilConvStringToUTF83
	#define EXT_SysUtilConvStringToUTF83
	#define GET_SysUtilConvStringToUTF83(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvStringToUTF83(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvStringToUTF83  FALSE
	#define EXP_SysUtilConvStringToUTF83  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvStringToUTF83
	#define EXT_SysUtilConvStringToUTF83
	#define GET_SysUtilConvStringToUTF83(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF83" ) 
	#define CAL_SysUtilConvStringToUTF83  SysUtilConvStringToUTF83
	#define CHK_SysUtilConvStringToUTF83  TRUE
	#define EXP_SysUtilConvStringToUTF83  CAL_CMEXPAPI( "SysUtilConvStringToUTF83" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvStringToUTF83
	#define EXT_SysUtilConvStringToUTF83
	#define GET_SysUtilConvStringToUTF83(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF83" ) 
	#define CAL_SysUtilConvStringToUTF83  SysUtilConvStringToUTF83
	#define CHK_SysUtilConvStringToUTF83  TRUE
	#define EXP_SysUtilConvStringToUTF83  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvStringToUTF83", (RTS_UINTPTR)SysUtilConvStringToUTF83, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvStringToUTF83
	#define EXT_SysUtilSysUtilConvStringToUTF83
	#define GET_SysUtilSysUtilConvStringToUTF83  ERR_OK
	#define CAL_SysUtilSysUtilConvStringToUTF83  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvStringToUTF83
	#define CHK_SysUtilSysUtilConvStringToUTF83	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvStringToUTF83  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvStringToUTF83
	#define EXT_SysUtilConvStringToUTF83
	#define GET_SysUtilConvStringToUTF83(fl)  CAL_CMGETAPI( "SysUtilConvStringToUTF83" ) 
	#define CAL_SysUtilConvStringToUTF83  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvStringToUTF83
	#define CHK_SysUtilConvStringToUTF83	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvStringToUTF83  CAL_CMEXPAPI( "SysUtilConvStringToUTF83" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvStringToUTF83  PFSYSUTILCONVSTRINGTOUTF83 pfSysUtilConvStringToUTF83;
	#define EXT_SysUtilConvStringToUTF83  extern PFSYSUTILCONVSTRINGTOUTF83 pfSysUtilConvStringToUTF83;
	#define GET_SysUtilConvStringToUTF83(fl)  s_pfCMGetAPI2( "SysUtilConvStringToUTF83", (RTS_VOID_FCTPTR *)&pfSysUtilConvStringToUTF83, (fl), 0, 0)
	#define CAL_SysUtilConvStringToUTF83  pfSysUtilConvStringToUTF83
	#define CHK_SysUtilConvStringToUTF83  (pfSysUtilConvStringToUTF83 != NULL)
	#define EXP_SysUtilConvStringToUTF83  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvStringToUTF83", (RTS_UINTPTR)SysUtilConvStringToUTF83, 0, 0) 
#endif



RTS_IEC_RESULT CDECL SysUtilCreateUUID(RTS_IEC_STRING* sUUID, RTS_IEC_DWORD* pSize);
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCREATEUUID) (RTS_IEC_STRING* sUUID, RTS_IEC_DWORD* pSize);
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCREATEUUID_NOTIMPLEMENTED)
	#define USE_SysUtilCreateUUID
	#define EXT_SysUtilCreateUUID
	#define GET_SysUtilCreateUUID(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilCreateUUID(p0,p1)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilCreateUUID  FALSE
	#define EXP_SysUtilCreateUUID  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilCreateUUID
	#define EXT_SysUtilCreateUUID
	#define GET_SysUtilCreateUUID(fl)  CAL_CMGETAPI( "SysUtilCreateUUID" ) 
	#define CAL_SysUtilCreateUUID  SysUtilCreateUUID
	#define CHK_SysUtilCreateUUID  TRUE
	#define EXP_SysUtilCreateUUID  CAL_CMEXPAPI( "SysUtilCreateUUID" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilCreateUUID
	#define EXT_SysUtilCreateUUID
	#define GET_SysUtilCreateUUID(fl)  CAL_CMGETAPI( "SysUtilCreateUUID" ) 
	#define CAL_SysUtilCreateUUID  SysUtilCreateUUID
	#define CHK_SysUtilCreateUUID  TRUE
	#define EXP_SysUtilCreateUUID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilCreateUUID", (RTS_UINTPTR)SysUtilCreateUUID, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilCreateUUID
	#define EXT_SysUtilSysUtilCreateUUID
	#define GET_SysUtilSysUtilCreateUUID  ERR_OK
	#define CAL_SysUtilSysUtilCreateUUID  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilCreateUUID
	#define CHK_SysUtilSysUtilCreateUUID	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilCreateUUID  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilCreateUUID
	#define EXT_SysUtilCreateUUID
	#define GET_SysUtilCreateUUID(fl)  CAL_CMGETAPI( "SysUtilCreateUUID" ) 
	#define CAL_SysUtilCreateUUID  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilCreateUUID
	#define CHK_SysUtilCreateUUID	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilCreateUUID  CAL_CMEXPAPI( "SysUtilCreateUUID" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilCreateUUID  PFSYSUTILCREATEUUID pfSysUtilCreateUUID;
	#define EXT_SysUtilCreateUUID  extern PFSYSUTILCREATEUUID pfSysUtilCreateUUID;
	#define GET_SysUtilCreateUUID(fl)  s_pfCMGetAPI2( "SysUtilCreateUUID", (RTS_VOID_FCTPTR *)&pfSysUtilCreateUUID, (fl), 0, 0)
	#define CAL_SysUtilCreateUUID  pfSysUtilCreateUUID
	#define CHK_SysUtilCreateUUID  (pfSysUtilCreateUUID != NULL)
	#define EXP_SysUtilCreateUUID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilCreateUUID", (RTS_UINTPTR)SysUtilCreateUUID, 0, 0) 
#endif



// like SysUtilConvUTF8ToString2 + Escape
RTS_IEC_RESULT CDECL SysUtilConvUTF8ToString3(RTS_IEC_STRING* lpMultiByteStr);
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVUTF8TOSTRING3) (RTS_IEC_STRING* lpMultiByteStr);
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVUTF8TOSTRING3_NOTIMPLEMENTED)
	#define USE_SysUtilConvUTF8ToString3
	#define EXT_SysUtilConvUTF8ToString3
	#define GET_SysUtilConvUTF8ToString3(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvUTF8ToString3(p0)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvUTF8ToString3  FALSE
	#define EXP_SysUtilConvUTF8ToString3  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvUTF8ToString3
	#define EXT_SysUtilConvUTF8ToString3
	#define GET_SysUtilConvUTF8ToString3(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString3" ) 
	#define CAL_SysUtilConvUTF8ToString3  SysUtilConvUTF8ToString3
	#define CHK_SysUtilConvUTF8ToString3  TRUE
	#define EXP_SysUtilConvUTF8ToString3  CAL_CMEXPAPI( "SysUtilConvUTF8ToString3" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvUTF8ToString3
	#define EXT_SysUtilConvUTF8ToString3
	#define GET_SysUtilConvUTF8ToString3(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString3" ) 
	#define CAL_SysUtilConvUTF8ToString3  SysUtilConvUTF8ToString3
	#define CHK_SysUtilConvUTF8ToString3  TRUE
	#define EXP_SysUtilConvUTF8ToString3  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString3", (RTS_UINTPTR)SysUtilConvUTF8ToString3, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvUTF8ToString3
	#define EXT_SysUtilSysUtilConvUTF8ToString3
	#define GET_SysUtilSysUtilConvUTF8ToString3  ERR_OK
	#define CAL_SysUtilSysUtilConvUTF8ToString3  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString3
	#define CHK_SysUtilSysUtilConvUTF8ToString3	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvUTF8ToString3  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvUTF8ToString3
	#define EXT_SysUtilConvUTF8ToString3
	#define GET_SysUtilConvUTF8ToString3(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString3" ) 
	#define CAL_SysUtilConvUTF8ToString3  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString3
	#define CHK_SysUtilConvUTF8ToString3	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvUTF8ToString3  CAL_CMEXPAPI( "SysUtilConvUTF8ToString3" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvUTF8ToString3  PFSYSUTILCONVUTF8TOSTRING3 pfSysUtilConvUTF8ToString3;
	#define EXT_SysUtilConvUTF8ToString3  extern PFSYSUTILCONVUTF8TOSTRING3 pfSysUtilConvUTF8ToString3;
	#define GET_SysUtilConvUTF8ToString3(fl)  s_pfCMGetAPI2( "SysUtilConvUTF8ToString3", (RTS_VOID_FCTPTR *)&pfSysUtilConvUTF8ToString3, (fl), 0, 0)
	#define CAL_SysUtilConvUTF8ToString3  pfSysUtilConvUTF8ToString3
	#define CHK_SysUtilConvUTF8ToString3  (pfSysUtilConvUTF8ToString3 != NULL)
	#define EXP_SysUtilConvUTF8ToString3  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString3", (RTS_UINTPTR)SysUtilConvUTF8ToString3, 0, 0) 
#endif



// like SysUtilConvUTF8ToString + Escape
RTS_IEC_RESULT CDECL SysUtilConvUTF8ToString4(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
typedef RTS_IEC_RESULT (CDECL * PFSYSUTILCONVUTF8TOSTRING4) (RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten );
#if defined(SYSUTIL_NOTIMPLEMENTED) || defined(SYSUTILCONVUTF8TOSTRING4_NOTIMPLEMENTED)
	#define USE_SysUtilConvUTF8ToString4
	#define EXT_SysUtilConvUTF8ToString4
	#define GET_SysUtilConvUTF8ToString4(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysUtilConvUTF8ToString4(p0,p1,p2,p3,p4)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysUtilConvUTF8ToString4  FALSE
	#define EXP_SysUtilConvUTF8ToString4  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysUtilConvUTF8ToString4
	#define EXT_SysUtilConvUTF8ToString4
	#define GET_SysUtilConvUTF8ToString4(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString4" ) 
	#define CAL_SysUtilConvUTF8ToString4  SysUtilConvUTF8ToString4
	#define CHK_SysUtilConvUTF8ToString4  TRUE
	#define EXP_SysUtilConvUTF8ToString4  CAL_CMEXPAPI( "SysUtilConvUTF8ToString4" ) 
#elif defined(MIXED_LINK) && !defined(SYSUTIL_EXTERNAL)
	#define USE_SysUtilConvUTF8ToString4
	#define EXT_SysUtilConvUTF8ToString4
	#define GET_SysUtilConvUTF8ToString4(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString4" ) 
	#define CAL_SysUtilConvUTF8ToString4  SysUtilConvUTF8ToString4
	#define CHK_SysUtilConvUTF8ToString4  TRUE
	#define EXP_SysUtilConvUTF8ToString4  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString4", (RTS_UINTPTR)SysUtilConvUTF8ToString4, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysUtilSysUtilConvUTF8ToString4
	#define EXT_SysUtilSysUtilConvUTF8ToString4
	#define GET_SysUtilSysUtilConvUTF8ToString4  ERR_OK
	#define CAL_SysUtilSysUtilConvUTF8ToString4  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString4
	#define CHK_SysUtilSysUtilConvUTF8ToString4	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilSysUtilConvUTF8ToString4  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysUtilConvUTF8ToString4
	#define EXT_SysUtilConvUTF8ToString4
	#define GET_SysUtilConvUTF8ToString4(fl)  CAL_CMGETAPI( "SysUtilConvUTF8ToString4" ) 
	#define CAL_SysUtilConvUTF8ToString4  ((ISysUtil*)s_pfCMCreateInstance(CLASSID_CSysUtil, NULL))->ISysUtilConvUTF8ToString4
	#define CHK_SysUtilConvUTF8ToString4	(s_pfCMCreateInstance != NULL && pISysUtil != NULL)
	#define EXP_SysUtilConvUTF8ToString4  CAL_CMEXPAPI( "SysUtilConvUTF8ToString4" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysUtilConvUTF8ToString4  PFSYSUTILCONVUTF8TOSTRING4 pfSysUtilConvUTF8ToString4;
	#define EXT_SysUtilConvUTF8ToString4  extern PFSYSUTILCONVUTF8TOSTRING4 pfSysUtilConvUTF8ToString4;
	#define GET_SysUtilConvUTF8ToString4(fl)  s_pfCMGetAPI2( "SysUtilConvUTF8ToString4", (RTS_VOID_FCTPTR *)&pfSysUtilConvUTF8ToString4, (fl), 0, 0)
	#define CAL_SysUtilConvUTF8ToString4  pfSysUtilConvUTF8ToString4
	#define CHK_SysUtilConvUTF8ToString4  (pfSysUtilConvUTF8ToString4 != NULL)
	#define EXP_SysUtilConvUTF8ToString4  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysUtilConvUTF8ToString4", (RTS_UINTPTR)SysUtilConvUTF8ToString4, 0, 0) 
#endif




#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFSYSUTILCONVWSTRINGTOUTF8 ISysUtilConvWStringToUTF8;
 	PFSYSUTILCONVUTF8TOWSTRING ISysUtilConvUTF8ToWString;
 	PFSYSUTILCONVUTF8TOSTRING ISysUtilConvUTF8ToString;
 	PFSYSUTILCONVUTF8TOSTRING2 ISysUtilConvUTF8ToString2;
 	PFSYSUTILCONVSTRINGTOUTF8 ISysUtilConvStringToUTF8;
 	PFSYSUTILCONVSTRINGTOUTF82 ISysUtilConvStringToUTF82;
 	PFSYSUTILCONVSTRINGTOUTF83 ISysUtilConvStringToUTF83;
 	PFSYSUTILCREATEUUID ISysUtilCreateUUID;
 	PFSYSUTILCONVUTF8TOSTRING3 ISysUtilConvUTF8ToString3;
 	PFSYSUTILCONVUTF8TOSTRING4 ISysUtilConvUTF8ToString4;
 } ISysUtil_C;

#ifdef CPLUSPLUS
class ISysUtil : public IBase
{
	public:
		virtual RTS_IEC_RESULT CDECL ISysUtilConvWStringToUTF8(RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten ) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToWString(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_WSTRING* lpWideCharStr, RTS_IEC_INT cchWideChar, RTS_IEC_INT* pBytesWritten ) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten ) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString2(RTS_IEC_STRING* lpMultiByteStr) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvStringToUTF8(const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten ) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvStringToUTF82(RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten ) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvStringToUTF83(const RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_INT* pBytesWritten ) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilCreateUUID(RTS_IEC_STRING* sUUID, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString3(RTS_IEC_STRING* lpMultiByteStr) =0;
		virtual RTS_IEC_RESULT CDECL ISysUtilConvUTF8ToString4(RTS_IEC_STRING* lpMultiByteStr, RTS_IEC_INT cbMultiByte, RTS_IEC_STRING* lpCharStr, RTS_IEC_INT cchChar, RTS_IEC_INT* pBytesWritten ) =0;
};
	#ifndef ITF_SysUtil
		#define ITF_SysUtil static ISysUtil *pISysUtil = NULL;
	#endif
	#define EXTITF_SysUtil
#else	/*CPLUSPLUS*/
	typedef ISysUtil_C		ISysUtil;
	#ifndef ITF_SysUtil
		#define ITF_SysUtil
	#endif
	#define EXTITF_SysUtil
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_SYSUTILITF_H_*/
