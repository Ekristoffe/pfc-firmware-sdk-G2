//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
///-----------------------------------------------------------------------------
///  \file
///
///  \brief    Parameter Provider for Device Reboot.
///
///  \author   WF : WAGO GmbH & Co. KG
///-----------------------------------------------------------------------------
#ifndef WAGO_PP_REBOOT_REBOOT_PARAMETER_PROVIDER_HPP_
#define WAGO_PP_REBOOT_REBOOT_PARAMETER_PROVIDER_HPP_

#include <wago/wdx/base_parameter_provider.hpp>

namespace wago::pp_reboot
{

/// \class reboot_parameter_provider
/// \brief This parameter provider allows to reboot the device.
///
/// It also allow to query the current boot status.
class reboot_parameter_provider final
  : public wago::wdx::base_parameter_provider
{
    reboot_parameter_provider(reboot_parameter_provider const &) = delete;
    reboot_parameter_provider& operator=(reboot_parameter_provider const&) = delete;
public:
    reboot_parameter_provider();

    ~reboot_parameter_provider() override = default;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    wago::future<wago::wdx::method_invocation_response> invoke_method(
        wago::wdx::parameter_instance_id method_id,
        std::vector<std::shared_ptr<wago::wdx::parameter_value>> in_args) override;

private:
     class detail;
     detail * d_ptr{nullptr};
};

}

#endif /* WAGO_PP_REBOOT_REBOOT_PARAMETER_PROVIDER_HPP_ */
//---- End of source file ------------------------------------------------------

