#ifndef eWS_H
#define eWS_H

#include "CmpStd.h"
#include "CmpWSServerDep.h"
#include "WSServer.h"

#define eWS_VERSION  13

#ifndef SO_HASHTABLE_MODULUS
   #define SO_HASHTABLE_MODULUS 32
#endif

#ifndef AWAITING_TIMEOUT
   #define AWAITING_TIMEOUT 20
#endif

#define CONTEXT_VISU    0
#define CONTEXT_WBM     1
#define CONTEXT_OPCUA   2

#define MAX_GETDPS   1000

//#define ELRESTWS_VALUE_MAX 200000
//#define ELRESTWS_BUFFER_MAX 204800 // 200k
//#define ELRESTWS_SENDBUF_MAX(nSize) eWS_SEND_BUFFER_PRE_PADDING + nSize + eWS_SEND_BUFFER_POST_PADDING 

#define MAX_WEBSOCKET_KEY_LEN 128
#define MAX_MUX_RECURSION 2
#define eWS_MAX_SOCKET_IO_BUF 64*1024
#define eWS_SEND_BUFFER_PRE_PADDING (4 + 10 + (2 * MAX_MUX_RECURSION))
#define eWS_SEND_BUFFER_POST_PADDING 4

// suppress listening on any port, that's what you want if this server is configured
// to use  the same port as 3S-WebServer; in this case 3S-WebServer are listening and
// forward to the server the upgrade requests
#define CONTEXT_PORT_NO_LISTEN -1

enum eWS_SERVER_STATES
{
   // connection established, the server completed a handshake with a client
   // protocol specific dat can be initialised
   eWS_STATE_ESTABLISHED,
   // websocket session ends
	eWS_STATE_CLOSED,
   // server recieves data from the client
	eWS_STATE_RECEIVE,
   // server recieves PONG (answer to ping)
	eWS_STATE_RECEIVE_PONG,
   // the websocket connection is able to accept a new packet without blocking
   eWS_STATE_SERVER_WRITEABLE,
   // the server can accept a connection to a client;
   // depending on user data the connection can still be rejected
   eWS_STATE_FILTER_NETWORK_CONNECTION,
   // for the eWSOPCUA protocol, trying to connect to the OPCUA server
   // part of handschake
   eWS_STATE_OPCUA_CONNECTING
};

enum eWS_return_status {
	eWS_RETURN_ERROR = RTS_SSIZE_MAX,
	eWS_RETURN_MORE_SERVICE = RTS_SSIZE_MAX-1,
};

struct eWS_poll {
	RTS_HANDLE hSocket;
	RTS_IEC_INT events;
	RTS_IEC_INT revents;
};

enum eWS_write_protocol {
	eWS_WRITE_TEXT,
	eWS_WRITE_BINARY,
	eWS_WRITE_CONTINUATION,

	// special 04+ opcodes
	eWS_WRITE_CLOSE,
	eWS_WRITE_PING,
	eWS_WRITE_PONG,

	eWS_WRITE_HTTP_HEADERS,

	// flags
	eWS_WRITE_NO_FIN = 0x40
};


enum eWS_WS_TOKENS {
	WS_TOKEN_GET_URI,            // "get "
	WS_TOKEN_HOST,               // "host:"
	WS_TOKEN_CONNECTION,         // "connection:"
	WS_TOKEN_UPGRADE,            // "upgrade:"
	WS_TOKEN_ORIGIN,             // "origin:"

	WS_TOKEN_PROTOCOL,           // "sec-websocket-protocol:"	
	WS_TOKEN_KEY,                // "sec-websocket-key:"
	WS_TOKEN_VERSION              // "sec-websocket-version:"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// From RFC 6455 https://tools.ietf.org/html/rfc6455?page=45#page-45
//
// Endpoints(Clients) MAY use the following pre-defined close codes when sending a Close frame:
//
//   1000 - Normal Closure
//       The purpose for which the connection was established has been fulfilled.
//   1001 - Going Away
//       An endpoint is "going away", such as a server going down or a browser having navigated away from a page.
//   1002 - Protocol error 
//       An endpoint is terminating the connection due to a protocol error.
//   1003 - Unsupported Data
//       An endpoint is terminating the connection because it has received a type of data it cannot accept (e.g., an
//       endpoint that understands only text data MAY send this if it receives a binary message).
//   1004 - ---Reserved----
//       The specific meaning might be defined in the future.
//   1005 - No Status Rcvd
//       1005 is a reserved value and MUST NOT be set as a status code in a Close control frame by an endpoint.
//       It is designated for use in applications expecting a status code to indicate that no status code was actually present.
//   1006 - Abnormal Closure
//       1006 is a reserved value and MUST NOT be set as a status code in a  Close control frame by an endpoint.
//       It is designated for use in applications expecting a status code to indicate that the connection was closed abnormally,
//       e.g., without sending or receiving a Close control frame.
//   1007 - Invalid frame payload data
//       An endpoint is terminating the connection because it has received data within a message that was not consistent with
//       the type of the message (e.g., non-UTF-8 [RFC3629] data within a text message).
//   1008 - Policy Violation
//       An endpoint is terminating the connection because it has received a message that violates its policy.
//       This is a generic status code that can be returned when there is no other more suitable status code (e.g., 1003 or 1009) or
//       if there is a need to hide specific details about the policy.
//   1009 - Message Too Big
//       An endpoint is terminating the connection because it has received a message that is too big for it to process.
//   1010 - Mandatory Ext.
//       An endpoint (client) is terminating the connection because it has expected the server to negotiate one or more extension,
//       but the server didn't return them in the response message of the WebSocket handshake.  The list of extensions that
//       are needed SHOULD appear in the /reason/ part of the Close frame.
//       Note that this status code is not used by the server, because it can fail the WebSocket handshake instead.
//   1011 - Internal Server Error
//       A server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.
//   1015 - TLS handshake
//       1015 is a reserved value and MUST NOT be set as a status code in a Close control frame by an endpoint.
//       It is designated for use in applications expecting a status code to indicate that the connection was closed due to a failure to perform a TLS handshake
//       (e.g., the server certificate can't be verified).
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum RFC6455_CLOSE_CODE {
	RFC6455_CLOSE_CODE_NOSTATUS = 0,
	RFC6455_CLOSE_CODE_NORMAL = 1000,
	RFC6455_CLOSE_CODE_GOINGAWAY = 1001,
	RFC6455_CLOSE_CODE_PROTOCOL_ERR = 1002,
	RFC6455_CLOSE_CODE_UNACCEPTABLE_OPCODE = 1003,
	RFC6455_CLOSE_CODE_RESERVED = 1004,
	RFC6455_CLOSE_CODE_NO_STATUS = 1005,
	RFC6455_CLOSE_CODE_ABNORMAL_CLOSE = 1006,
	RFC6455_CLOSE_CODE_INVALID_PAYLOAD = 1007,
	RFC6455_CLOSE_CODE_POLICY_VIOLATION = 1008,
	RFC6455_CLOSE_CODE_MESSAGE_TOO_LARGE = 1009,
	RFC6455_CLOSE_CODE_EXTENSION_REQUIRED = 1010,
	RFC6455_CLOSE_CODE_UNEXPECTED_CONDITION = 1011,
	RFC6455_CLOSE_CODE_TLS_FAILURE = 1015,

	eWS_CLOSE_CODE_NOSTATUS_CONTEXT_DESTROY = 9999,
   eWS_CLOSE_CODEOPCUA_CLIENT_CLOSED
};

typedef struct tag_eWS_OPCUA_ATTR {
   char        sName[256];
   RTS_HANDLE  hHandle; // handle to the value
   RTS_UI16    nType;   // type
   RTS_UI8     nUserAccessLevel; // user rights
   void*       pValue;  // pointer to the value

} eWS_OPCUA_ATTR;

struct eWS_OPCUA {
   char        sServerURL[256];
   char        sUser[100];
   char        sPassword[100];

   RTS_HANDLE  hClient;

   eWS_OPCUA_ATTR arrGets[MAX_GETDPS];

   RTS_BOOL    bDataChanged;
};

/*typedef struct tag_eWS_Request_Browse
{
   char sUUID[40];

   eWS_REQUEST_BROWSE_FORMAT nFormat;
   eWS_REQUEST_BROWSE_FILTER nFilter;

} eWS_Request_Browse;*/

typedef struct tag_eWS_Thread {

   RTS_HANDLE  handle;

   void*       pParam;  //abhängig vom ThreadTyp

   RTS_UI32    nErrorCode;
   RTS_UI32    nErrorCodeExt;
   RTS_UI32    nStartTime;
   RTS_UI32    nTimeout;
   RTS_UI8     nPercent;
   //eWS_THREAD_BROWSE_STATE nState;
} eWS_Thread;

// eWS Server settings
struct eWS_Server_Settings
{
   // Port
	RTS_I32  i3SWebServerPort;
   RTS_I32  iPort;

   // SecurePort
   //RTS_I32   n3SWebServerSecurePort;
   //RTS_I32   nSecurePort;

   // ConnectionType
   RTS_I32   i3SWebServerConnectionType;
   RTS_I32   iConnectionType;

   // MaxClient
   RTS_I32  iMaxClients;

   //RefreshTime
   RTS_I32  iRefreshTime;

   //PING/PONG-Settings
   RTS_I32  iPingTime;
   RTS_I32  iPingInterval;
   RTS_I32  iPingRetry;

   // KeepAlive
	RTS_I32  iKATime;
	RTS_I32  iKARetries;
	RTS_I32  iKAInterval;

   // LocalClient(s)
   RTS_UI32 arrLocalClients[WS_MAX_LOCALCLIENTS];

   //Task Settings
   RTS_UI32 uiTaskPriority; // default: RTS_UI32_MAX: (RTS_UI32)(~((RTS_UI32)0)) - idle Zeit
   RTS_UI32 uiTaskInterval; // default: 0 microseconds
   RTS_UI32 uiTaskStackSize; // default: 0, abhängig vom Betriebssystem

   // Buffer size
   RTS_UI32 uiBufferSize; // in kb; default: 200 kb

	struct eWS_protocols *protocols;
   RTS_UI32 uiCountOfProtocols;
};

// eWSSocket

//eWS_CONNECTION_MODE
enum eWS_CONNECTION_MODE {
	eWS_CONNECTION_MODE_HTTP_SERVING,
	eWS_CONNECTION_MODE_HTTP_SERVING_ACCEPTED, // actual HTTP service going on
	eWS_CONNECTION_MODE_PRE_WS_SERVING_ACCEPT,

	eWS_CONNECTION_MODE_WS_SERVING,

	// special internal types
	eWS_CONNECTION_MODE_SERVER_LISTENER
};

// eWS_CONNECTION_STATES
enum eWS_CONNECTION_STATES {
	eWS_CONNECTION_STATE_HTTP,
	eWS_CONNECTION_STATE_HTTP_HEADERS,
	eWS_CONNECTION_STATE_DEAD_SOCKET,
	eWS_CONNECTION_STATE_ESTABLISHED,
	eWS_CONNECTION_STATE_CLIENT_UNCONNECTED,
	eWS_CONNECTION_STATE_RETURNED_CLOSE_ALREADY,
	eWS_CONNECTION_STATE_AWAITING_CLOSE_ACK,
	eWS_CONNECTION_STATE_FLUSHING_STORED_SEND_BEFORE_CLOSE
};
//
//      1                   2                   3                   4
//      0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
//     +-+-+-+-+-------+-+-------------+-------------------------------+
//     |F|R|R|R| opcode|M| Payload len |    Extended payload length    |
//     |I|S|S|S|  (4)  |A|     (7)     |             (16/64)           |
//     |N|V|V|V|       |S|             |   (if payload len==126/127)   |
//     | |1|2|3|       |K|             |                               |
//     +-+-+-+-+-------+-+-------------+ - - - - - - - - - - - - - - - +
//     |     Extended payload length continued, if payload len == 127  |
//     + - - - - - - - - - - - - - - - +-------------------------------+
//     |                               |Masking-key, if MASK set to 1  |
//     +-------------------------------+-------------------------------+
//     | Masking-key (continued)       |          Payload Data         |
//     +-------------------------------- - - - - - - - - - - - - - - - +
//     :                     Payload Data continued ...                :
//     + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
//     |                     Payload Data continued ...                |
//     +---------------------------------------------------------------+
//
enum eWS_BUF_PARSE_STATES {
	eWS_BUF_PARSE_STATE_NEW,

	eWS_BUF_PARSE_STATE_FRAME_BYTE_1,
	eWS_BUF_PARSE_STATE_FRAME_BYTE_2,
	eWS_BUF_PARSE_STATE_FRAME_EXTENDED_PAYLOAD_LENGTH_BYTE1,
   eWS_BUF_PARSE_STATE_FRAME_EXTENDED_PAYLOAD_LENGTH_BYTE2,
   eWS_BUF_PARSE_STATE_FRAME_EXTENDED_PAYLOAD_LENGTH_BYTE_TOOBIG,
   eWS_BUF_PARSE_STATE_FRAME_EXTENDED_PAYLOAD_LENGTH_BYTE_TOOBIG_IGNORE1,
   eWS_BUF_PARSE_STATE_FRAME_EXTENDED_PAYLOAD_LENGTH_BYTE_TOOBIG_IGNORE2,
	eWS_BUF_PARSE_STATE_FRAME_EXTENDED_PAYLOAD_LENGTH_BYTE_TOOBIG_IGNORE3,
	
	eWS_BUF_PARSE_STATE_FRAME_PAYLOAD_LENGTH_4,
	eWS_BUF_PARSE_STATE_FRAME_PAYLOAD_LENGTH_3,
	eWS_BUF_PARSE_STATE_FRAME_PAYLOAD_LENGTH_2,
	eWS_BUF_PARSE_STATE_FRAME_PAYLOAD_LENGTH_1,

	eWS_BUF_PARSE_STATE_MASK_KEY_1,
	eWS_BUF_PARSE_STATE_MASK_KEY_2,
	eWS_BUF_PARSE_STATE_MASK_KEY_3,
	eWS_BUF_PARSE_STATE_MASK_KEY_4,

	eWS_BUF_PARSE_STATE_PAYLOAD_COMPLETE
};

enum eWS_PENDING_TIMEOUT {
	eWS_NO_PENDING_TIMEOUT = 0,
	eWS_PENDING_TIMEOUT_ESTABLISH_WITH_SERVER,
	eWS_PENDING_TIMEOUT_CLOSE_ACK
};

struct eWS_WS_HANDSHAKE
{
   char host[128];
   char connection[32];
   char upgrade[32];
   char origin[128];
   char sec_websocket_key[128];
   char sec_websocket_protocol[32];
   // Websocket Protocol Version
   // momentan ist nur die Version 13 unterstützt
	RTS_UI8 sec_websocket_version;
};

// https://tools.ietf.org/html/rfc6455#section-5.2
enum websocket_opcodes {
	WS_OPCODE_CONTINUATION = 0,         // continuation frame
	WS_OPCODE_TEXT_FRAME = 1,           // text frame
	WS_OPCODE_BINARY_FRAME = 2,         // binary frame
	WS_OPCODE_NOSPEC__MUX = 7,          // x3-7 are reserved for further non-control frames
   WS_OPCODE_CLOSE = 8,                // connection close
	WS_OPCODE_PING = 9,                 // ping
	WS_OPCODE_PONG = 0xa                // pong

   //%xB-F are reserved for further control frames
};

struct eWS_WS_DATA
{
	char                          user_buffer[eWS_MAX_SOCKET_IO_BUF+ eWS_SEND_BUFFER_PRE_PADDING + eWS_SEND_BUFFER_POST_PADDING];
	int                           user_buffer_length;
	unsigned char                 masking_key[4];
	unsigned char                 frame_mask_index;
	RTS_SIZE                      payload_length;
	
   enum websocket_opcodes        opcode;  // 4 bits, Defines the interpretation of the "Payload data".  If an unknown
                                          // opcode is received, the receiving endpoint MUST _Fail theWebSocket Connection_.
	unsigned int                  fin:1; // FIN:  1 bit; Indicates that this is the final fragment in a message.  
                                          // The first fragment MAY also be the final fragment.
	unsigned char                 rsv;     // 3 bits, RSV1, RSV2, RSV3:  1 bit each; not supportted for the moment
                                          // MUST be 0 unless an extension is negotiated that defines meanings for non-zero values.
                                          // If a nonzero value is received and none of the negotiated extensions defines the meaning of such a nonzero
                                          // value, the receiving endpoint MUST _Fail the WebSocket Connection_.
	unsigned int                  frame_is_binary:1; // not supportted at the moment
   unsigned int                  frame_is_masked:1; // Mask:  1 bit;  Defines whether the "Payload data" is masked.
                                                    // If set to 1, a masking key is present in masking-key, and this is used to unmask
                                                    // the "Payload data".  All frames sent from client to server have this bit set to 1.
	unsigned int                  all_zero:1;
	enum RFC6455_CLOSE_CODE       close_reason; 

	
	unsigned int                  inside_frame:1; // next write will be more of frame

	unsigned char                 *ping_payload_buf; // non-NULL if malloc'd
	unsigned int                  ping_payload_len;
	unsigned char                 ping_pending_flag;
};

struct eWS_SOCKET
{
	const struct eWS_protocols *pProtocol;

   enum eWS_CONNECTION_MODE   connMode;
	enum eWS_CONNECTION_STATES connState;
	enum eWS_BUF_PARSE_STATES  parseState;

	RTS_UI32 handshakeParsingCompleted:1;
	RTS_UI32 socket_is_permanently_unusable:1;

	enum eWS_PENDING_TIMEOUT pendingTimeout;
	RTS_UI32 pendingTimeoutLimit;

	RTS_HANDLE hSocket;
	RTS_I32 position_in_sockets_table;
	
	// truncated send handling
	char *truncated_send_malloc; // non-NULL means buffering in progress
	unsigned int truncated_send_allocation; // size of malloc
	unsigned int truncated_send_offset; // where we are in terms of spilling
	unsigned int truncated_send_len; // how much is buffered

	struct session_info sessionInfo;

   struct eWS_WS_HANDSHAKE  handshake;
	struct eWS_WS_DATA       data;

	RTS_IEC_BOOL sock_send_blocking;

   char sUserName[2*(WS_USERNAME_MAX+1)];
   char  sAuthToken[128];

   char szIpAddress[16];
   RTS_BOOL bLocal;
   RTS_IEC_BYTE nContext; // 1 - WBM, 2 - OPCUA, sonst VISU

   RTS_UI32 lastReceived;
   RTS_UI32 lastPing;
   RTS_UI32 nPingCurrentRetry;
   RTS_IEC_BOOL bPing;
   RTS_IEC_BOOL b3SWebServer;  
   
   struct eWS_OPCUA opcuaClient;

};

// sockets hash table:
//    - key:   socket handle
//    - value: the index in the socket array (eWS_SOCKET)
#define eWS_SOCKET_HASH(hSocket) ((hSocket ^ (hSocket >> 8) ^ (hSocket >> 16)) % SO_HASHTABLE_MODULUS)
struct eWS_SOCKET_hashtable {
	struct eWS_SOCKET **arr_eWS;
	RTS_I32           iLength;
};


#define eWS_LISTEN_SERVICE_MODULO 10
struct eWS_SERVER_CONTEXT{

   struct eWS_poll *sockets;
   RTS_I32 iCountOfSockets; // number of sockets/connections
	struct eWS_SOCKET_hashtable sockets_hashtable[SO_HASHTABLE_MODULUS];
	RTS_UI32 uiMaxOfSockets;
   
   RTS_I32 listen_port;

   // millisecond tick
	RTS_UI32 uiLastTimeoutCheck;

	// communication buffer used for anything (read/write)
	char service_buffer[eWS_MAX_SOCKET_IO_BUF];

	RTS_UI32    listen_service_modulo;
	RTS_UI32    listen_service_count;
	RTS_HANDLE  listen_service_handle;
	RTS_UI32    listen_service_extraseen;

   struct eWS_Server_Settings settings;

   char*       buf;
};

int callback(struct eWS_SERVER_CONTEXT *context,
			            struct eWS_SOCKET *ews,
			            enum eWS_SERVER_STATES state,
			            void *user,
						   void *in, RTS_SIZE len);

typedef int (callback_function)(struct eWS_SERVER_CONTEXT *context,
			                    struct eWS_SOCKET **ewss,
			                    enum eWS_SERVER_STATES state,
			                    void *user,
			                    void *in, RTS_SIZE len);
struct eWS_protocols {
	const char *name;
	callback_function *callback;

   unsigned int id;
   unsigned int id_ext;

	//
	 // below are filled in on server init and can be left uninitialized,
	 // no need for user to use them directly either
	//
   unsigned int id_ext_client;

	struct eWS_SERVER_CONTEXT *owning_server;
	int protocol_index;
};

struct eWS_SOCKET * eWS_create(struct eWS_SERVER_CONTEXT *context);
struct eWS_SOCKET * eWS_fromHandle(struct eWS_SERVER_CONTEXT* context, RTS_HANDLE hSocket);

int   ews_add_socket(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET *ews);
int   ews_remove_socket(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET* ews);

void  eWS_close_and_free_session(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET **ews, enum RFC6455_CLOSE_CODE eWS_close_status);

int   eWS_set_socket_options(struct eWS_SERVER_CONTEXT *context, RTS_HANDLE hSocket);

struct eWS_SERVER_CONTEXT * eWS_context_create (struct eWS_Server_Settings *pSettings);
void                        eWS_context_destroy(struct eWS_SERVER_CONTEXT *context);

int         eWS_read (struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET **ews, char *buf, RTS_SSIZE len);
RTS_SSIZE   eWS_write(struct eWS_SOCKET *ews, char *buf, RTS_SSIZE len, enum eWS_write_protocol protocol);

int   eWS_service(struct eWS_SERVER_CONTEXT *context, int timeout_ms);

void  eWS_set_timeout(struct eWS_SOCKET *ews, enum eWS_PENDING_TIMEOUT reason, int secs);

int   eWS_callback_on_writable(struct eWS_SERVER_CONTEXT *context, struct eWS_SOCKET *ews);
int   eWS_callback_on_writable_all_protocol(const struct eWS_protocols *protocol);


#endif
