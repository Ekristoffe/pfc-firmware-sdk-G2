#ifndef __B64_H__
#define __B64_H__

#include "CmpStd.h"

RTS_UI32 b64_encode_string1(const char *in, RTS_UI32 inlen, char * out, RTS_UI32 outlen);
int      b64_encode_string2(const char *in, int in_len, char *out, int out_size);

#endif