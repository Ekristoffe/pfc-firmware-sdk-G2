 /**
 * <interfacename>SysParameterSettings</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _SYSPARAMETERSETTINGSITF_H_
#define _SYSPARAMETERSETTINGSITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

//group allowed to login into WBM
#define WBM_GROUP_NAME        "wbmusers"
//group allowed to access to /home/plc_v3
#define CODESYS_GROUP         "codesysdir"

#define ADMIN_GROUP           "Administrators"
#define SERVICE_GROUP         "Services"
#define DEVELOPER_GROUP       "Developers"
#define SUPERVISOR_GROUP      "Supervisors"
#define USER_GROUP            "Users"
#define GUEST_GROUP           "Guests"
#define SSH_GROUP             "sshusers"
#define FTP_GROUP             "ftpusers"
#define SDCARD_GROUP          "sdcard"

#define ADMIN_USER            "Administrator"
#define SERVICE_USER          "Service"
#define DEVELOPER_USER        "Developer"
#define SUPERVISOR_USER       "Supervisor"
#define USER_USER             "User"
#define GUEST_USER            "Guest"


//bit code to allow to write the parameter
#define WRITE_NONE                0x0000
#define WRITE_ADMIN_GROUP         0x0001
#define WRITE_SERVICE_GROUP       0x0002
#define WRITE_SUPERVISOR_GROUP    0x0004
#define WRITE_DEVELOPER_GROUP     0x0008
#define WRITE_USER_GROUP          0x0010
#define WRITE_GUEST_GROUP         0x0020
#define WRITE_EEPROM_GROUP        0x0040

#define WRITE_ALL_EXCEPT_SUPERV_USERS_GUESTS  (WRITE_ADMIN_GROUP | WRITE_SERVICE_GROUP | WRITE_DEVELOPER_GROUP)
#define WRITE_ALL_EXCEPT_USERS_GUESTS         (WRITE_ADMIN_GROUP | WRITE_SERVICE_GROUP | WRITE_DEVELOPER_GROUP | WRITE_SUPERVISOR_GROUP)
#define WRITE_ALL_EXCEPT_GUESTS               (WRITE_ADMIN_GROUP | WRITE_SERVICE_GROUP | WRITE_DEVELOPER_GROUP | WRITE_SUPERVISOR_GROUP | WRITE_USER_GROUP )
#define WRITE_ALL                             (WRITE_ADMIN_GROUP | WRITE_SERVICE_GROUP | WRITE_DEVELOPER_GROUP | WRITE_SUPERVISOR_GROUP | WRITE_USER_GROUP | WRITE_GUEST_GROUP)


#define SYSPARAMETERSETTINGS_NUM_OF_STATIC_FONTS	20
#define SYSPARAMETERSETTINGS_FONT_NAME_LENGTH		81
#define SYSPARAMETERSETTINGS_FONT_SUBST_LENGTH		81
#define SYSPARAMETERSETTINGS_FONT_FAMILY_LENGTH		81
#define SYSPARAMETERSETTINGS_BROWSER_URL_LENGTH		(MAX_PATH_LEN+1)
#define SYSPARAMETERSETTINGS_BROWSER_URLS_MAX		10
#define	SYSPARAMETERSETTINGS_NET_ROUTE_LENGTH		100
#define	SYSPARAMETERSETTINGS_NET_ROUTES_MAX			10
#define SYSPARAMETERSETTINGS_NET_SSID_LENGTH		32

/********** Structures **********/

typedef struct
{
  RTS_IEC_BOOL bSubmitted;
  RTS_IEC_BOOL bDhcp;
  char szNetmask[16];
  char szIpAddr[16];
  char szGateway[16];
  char szNameserver1[16];
  char szNameserver2[16];
  char szDomainName[128];
}AdapterNetworkV4Settings;

typedef struct
{
  RTS_IEC_BOOL bSubmitted;  
  RTS_UI32 nRefreshInterval;
  char szNtpServer[128];
  char szTimeZone[128];
}NtpSettings;

typedef struct
{
	void* pValue;
	struct dynamic_list* pNext;
} dynamic_list;

/* routines for OS specific modules */
RTS_RESULT SysParameterSettings_init3(void);
RTS_RESULT SysParameterSettings_run(void);
RTS_RESULT SysParameterSettings_exit3(void);

/* RMC5xx */
RTS_RESULT CDECL SysParameterSettings_GetDomainName1(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDOMAINNAME1) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDOMAINNAME1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDomainName1
	#define EXT_SysParameterSettings_GetDomainName1
	#define GET_SysParameterSettings_GetDomainName1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDomainName1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDomainName1  FALSE
	#define EXP_SysParameterSettings_GetDomainName1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDomainName1
	#define EXT_SysParameterSettings_GetDomainName1
	#define GET_SysParameterSettings_GetDomainName1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDomainName1" ) 
	#define CAL_SysParameterSettings_GetDomainName1  SysParameterSettings_GetDomainName1
	#define CHK_SysParameterSettings_GetDomainName1  TRUE
	#define EXP_SysParameterSettings_GetDomainName1  CAL_CMEXPAPI( "SysParameterSettings_GetDomainName1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDomainName1
	#define EXT_SysParameterSettings_GetDomainName1
	#define GET_SysParameterSettings_GetDomainName1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDomainName1" ) 
	#define CAL_SysParameterSettings_GetDomainName1  SysParameterSettings_GetDomainName1
	#define CHK_SysParameterSettings_GetDomainName1  TRUE
	#define EXP_SysParameterSettings_GetDomainName1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDomainName1", (RTS_UINTPTR)SysParameterSettings_GetDomainName1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDomainName1
	#define EXT_SysParameterSettingsSysParameterSettings_GetDomainName1
	#define GET_SysParameterSettingsSysParameterSettings_GetDomainName1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDomainName1 pISysParameterSettings->ISysParameterSettings_GetDomainName1
	#define CHK_SysParameterSettingsSysParameterSettings_GetDomainName1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDomainName1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDomainName1
	#define EXT_SysParameterSettings_GetDomainName1
	#define GET_SysParameterSettings_GetDomainName1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDomainName1" ) 
	#define CAL_SysParameterSettings_GetDomainName1 pISysParameterSettings->ISysParameterSettings_GetDomainName1
	#define CHK_SysParameterSettings_GetDomainName1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDomainName1  CAL_CMEXPAPI( "SysParameterSettings_GetDomainName1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDomainName1  PFSYSPARAMETERSETTINGS_GETDOMAINNAME1 pfSysParameterSettings_GetDomainName1;
	#define EXT_SysParameterSettings_GetDomainName1  extern PFSYSPARAMETERSETTINGS_GETDOMAINNAME1 pfSysParameterSettings_GetDomainName1;
	#define GET_SysParameterSettings_GetDomainName1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDomainName1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDomainName1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDomainName1  pfSysParameterSettings_GetDomainName1
	#define CHK_SysParameterSettings_GetDomainName1  (pfSysParameterSettings_GetDomainName1 != NULL)
	#define EXP_SysParameterSettings_GetDomainName1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDomainName1", (RTS_UINTPTR)SysParameterSettings_GetDomainName1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDomainName2(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDOMAINNAME2) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDOMAINNAME2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDomainName2
	#define EXT_SysParameterSettings_GetDomainName2
	#define GET_SysParameterSettings_GetDomainName2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDomainName2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDomainName2  FALSE
	#define EXP_SysParameterSettings_GetDomainName2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDomainName2
	#define EXT_SysParameterSettings_GetDomainName2
	#define GET_SysParameterSettings_GetDomainName2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDomainName2" ) 
	#define CAL_SysParameterSettings_GetDomainName2  SysParameterSettings_GetDomainName2
	#define CHK_SysParameterSettings_GetDomainName2  TRUE
	#define EXP_SysParameterSettings_GetDomainName2  CAL_CMEXPAPI( "SysParameterSettings_GetDomainName2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDomainName2
	#define EXT_SysParameterSettings_GetDomainName2
	#define GET_SysParameterSettings_GetDomainName2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDomainName2" ) 
	#define CAL_SysParameterSettings_GetDomainName2  SysParameterSettings_GetDomainName2
	#define CHK_SysParameterSettings_GetDomainName2  TRUE
	#define EXP_SysParameterSettings_GetDomainName2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDomainName2", (RTS_UINTPTR)SysParameterSettings_GetDomainName2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDomainName2
	#define EXT_SysParameterSettingsSysParameterSettings_GetDomainName2
	#define GET_SysParameterSettingsSysParameterSettings_GetDomainName2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDomainName2 pISysParameterSettings->ISysParameterSettings_GetDomainName2
	#define CHK_SysParameterSettingsSysParameterSettings_GetDomainName2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDomainName2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDomainName2
	#define EXT_SysParameterSettings_GetDomainName2
	#define GET_SysParameterSettings_GetDomainName2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDomainName2" ) 
	#define CAL_SysParameterSettings_GetDomainName2 pISysParameterSettings->ISysParameterSettings_GetDomainName2
	#define CHK_SysParameterSettings_GetDomainName2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDomainName2  CAL_CMEXPAPI( "SysParameterSettings_GetDomainName2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDomainName2  PFSYSPARAMETERSETTINGS_GETDOMAINNAME2 pfSysParameterSettings_GetDomainName2;
	#define EXT_SysParameterSettings_GetDomainName2  extern PFSYSPARAMETERSETTINGS_GETDOMAINNAME2 pfSysParameterSettings_GetDomainName2;
	#define GET_SysParameterSettings_GetDomainName2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDomainName2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDomainName2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDomainName2  pfSysParameterSettings_GetDomainName2
	#define CHK_SysParameterSettings_GetDomainName2  (pfSysParameterSettings_GetDomainName2 != NULL)
	#define EXP_SysParameterSettings_GetDomainName2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDomainName2", (RTS_UINTPTR)SysParameterSettings_GetDomainName2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetNameservers1(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETNAMESERVERS1) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETNAMESERVERS1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetNameservers1
	#define EXT_SysParameterSettings_GetNameservers1
	#define GET_SysParameterSettings_GetNameservers1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetNameservers1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetNameservers1  FALSE
	#define EXP_SysParameterSettings_GetNameservers1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetNameservers1
	#define EXT_SysParameterSettings_GetNameservers1
	#define GET_SysParameterSettings_GetNameservers1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNameservers1" ) 
	#define CAL_SysParameterSettings_GetNameservers1  SysParameterSettings_GetNameservers1
	#define CHK_SysParameterSettings_GetNameservers1  TRUE
	#define EXP_SysParameterSettings_GetNameservers1  CAL_CMEXPAPI( "SysParameterSettings_GetNameservers1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetNameservers1
	#define EXT_SysParameterSettings_GetNameservers1
	#define GET_SysParameterSettings_GetNameservers1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNameservers1" ) 
	#define CAL_SysParameterSettings_GetNameservers1  SysParameterSettings_GetNameservers1
	#define CHK_SysParameterSettings_GetNameservers1  TRUE
	#define EXP_SysParameterSettings_GetNameservers1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNameservers1", (RTS_UINTPTR)SysParameterSettings_GetNameservers1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetNameservers1
	#define EXT_SysParameterSettingsSysParameterSettings_GetNameservers1
	#define GET_SysParameterSettingsSysParameterSettings_GetNameservers1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetNameservers1 pISysParameterSettings->ISysParameterSettings_GetNameservers1
	#define CHK_SysParameterSettingsSysParameterSettings_GetNameservers1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetNameservers1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetNameservers1
	#define EXT_SysParameterSettings_GetNameservers1
	#define GET_SysParameterSettings_GetNameservers1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNameservers1" ) 
	#define CAL_SysParameterSettings_GetNameservers1 pISysParameterSettings->ISysParameterSettings_GetNameservers1
	#define CHK_SysParameterSettings_GetNameservers1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetNameservers1  CAL_CMEXPAPI( "SysParameterSettings_GetNameservers1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetNameservers1  PFSYSPARAMETERSETTINGS_GETNAMESERVERS1 pfSysParameterSettings_GetNameservers1;
	#define EXT_SysParameterSettings_GetNameservers1  extern PFSYSPARAMETERSETTINGS_GETNAMESERVERS1 pfSysParameterSettings_GetNameservers1;
	#define GET_SysParameterSettings_GetNameservers1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetNameservers1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetNameservers1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetNameservers1  pfSysParameterSettings_GetNameservers1
	#define CHK_SysParameterSettings_GetNameservers1  (pfSysParameterSettings_GetNameservers1 != NULL)
	#define EXP_SysParameterSettings_GetNameservers1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNameservers1", (RTS_UINTPTR)SysParameterSettings_GetNameservers1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetNameservers2(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETNAMESERVERS2) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETNAMESERVERS2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetNameservers2
	#define EXT_SysParameterSettings_GetNameservers2
	#define GET_SysParameterSettings_GetNameservers2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetNameservers2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetNameservers2  FALSE
	#define EXP_SysParameterSettings_GetNameservers2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetNameservers2
	#define EXT_SysParameterSettings_GetNameservers2
	#define GET_SysParameterSettings_GetNameservers2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNameservers2" ) 
	#define CAL_SysParameterSettings_GetNameservers2  SysParameterSettings_GetNameservers2
	#define CHK_SysParameterSettings_GetNameservers2  TRUE
	#define EXP_SysParameterSettings_GetNameservers2  CAL_CMEXPAPI( "SysParameterSettings_GetNameservers2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetNameservers2
	#define EXT_SysParameterSettings_GetNameservers2
	#define GET_SysParameterSettings_GetNameservers2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNameservers2" ) 
	#define CAL_SysParameterSettings_GetNameservers2  SysParameterSettings_GetNameservers2
	#define CHK_SysParameterSettings_GetNameservers2  TRUE
	#define EXP_SysParameterSettings_GetNameservers2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNameservers2", (RTS_UINTPTR)SysParameterSettings_GetNameservers2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetNameservers2
	#define EXT_SysParameterSettingsSysParameterSettings_GetNameservers2
	#define GET_SysParameterSettingsSysParameterSettings_GetNameservers2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetNameservers2 pISysParameterSettings->ISysParameterSettings_GetNameservers2
	#define CHK_SysParameterSettingsSysParameterSettings_GetNameservers2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetNameservers2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetNameservers2
	#define EXT_SysParameterSettings_GetNameservers2
	#define GET_SysParameterSettings_GetNameservers2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNameservers2" ) 
	#define CAL_SysParameterSettings_GetNameservers2 pISysParameterSettings->ISysParameterSettings_GetNameservers2
	#define CHK_SysParameterSettings_GetNameservers2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetNameservers2  CAL_CMEXPAPI( "SysParameterSettings_GetNameservers2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetNameservers2  PFSYSPARAMETERSETTINGS_GETNAMESERVERS2 pfSysParameterSettings_GetNameservers2;
	#define EXT_SysParameterSettings_GetNameservers2  extern PFSYSPARAMETERSETTINGS_GETNAMESERVERS2 pfSysParameterSettings_GetNameservers2;
	#define GET_SysParameterSettings_GetNameservers2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetNameservers2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetNameservers2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetNameservers2  pfSysParameterSettings_GetNameservers2
	#define CHK_SysParameterSettings_GetNameservers2  (pfSysParameterSettings_GetNameservers2 != NULL)
	#define EXP_SysParameterSettings_GetNameservers2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNameservers2", (RTS_UINTPTR)SysParameterSettings_GetNameservers2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetAdapterInfo1(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETADAPTERINFO1) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETADAPTERINFO1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetAdapterInfo1
	#define EXT_SysParameterSettings_SetAdapterInfo1
	#define GET_SysParameterSettings_SetAdapterInfo1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetAdapterInfo1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetAdapterInfo1  FALSE
	#define EXP_SysParameterSettings_SetAdapterInfo1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetAdapterInfo1
	#define EXT_SysParameterSettings_SetAdapterInfo1
	#define GET_SysParameterSettings_SetAdapterInfo1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAdapterInfo1" ) 
	#define CAL_SysParameterSettings_SetAdapterInfo1  SysParameterSettings_SetAdapterInfo1
	#define CHK_SysParameterSettings_SetAdapterInfo1  TRUE
	#define EXP_SysParameterSettings_SetAdapterInfo1  CAL_CMEXPAPI( "SysParameterSettings_SetAdapterInfo1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetAdapterInfo1
	#define EXT_SysParameterSettings_SetAdapterInfo1
	#define GET_SysParameterSettings_SetAdapterInfo1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAdapterInfo1" ) 
	#define CAL_SysParameterSettings_SetAdapterInfo1  SysParameterSettings_SetAdapterInfo1
	#define CHK_SysParameterSettings_SetAdapterInfo1  TRUE
	#define EXP_SysParameterSettings_SetAdapterInfo1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAdapterInfo1", (RTS_UINTPTR)SysParameterSettings_SetAdapterInfo1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetAdapterInfo1
	#define EXT_SysParameterSettingsSysParameterSettings_SetAdapterInfo1
	#define GET_SysParameterSettingsSysParameterSettings_SetAdapterInfo1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetAdapterInfo1 pISysParameterSettings->ISysParameterSettings_SetAdapterInfo1
	#define CHK_SysParameterSettingsSysParameterSettings_SetAdapterInfo1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetAdapterInfo1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetAdapterInfo1
	#define EXT_SysParameterSettings_SetAdapterInfo1
	#define GET_SysParameterSettings_SetAdapterInfo1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAdapterInfo1" ) 
	#define CAL_SysParameterSettings_SetAdapterInfo1 pISysParameterSettings->ISysParameterSettings_SetAdapterInfo1
	#define CHK_SysParameterSettings_SetAdapterInfo1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetAdapterInfo1  CAL_CMEXPAPI( "SysParameterSettings_SetAdapterInfo1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetAdapterInfo1  PFSYSPARAMETERSETTINGS_SETADAPTERINFO1 pfSysParameterSettings_SetAdapterInfo1;
	#define EXT_SysParameterSettings_SetAdapterInfo1  extern PFSYSPARAMETERSETTINGS_SETADAPTERINFO1 pfSysParameterSettings_SetAdapterInfo1;
	#define GET_SysParameterSettings_SetAdapterInfo1(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetAdapterInfo1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetAdapterInfo1, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetAdapterInfo1  pfSysParameterSettings_SetAdapterInfo1
	#define CHK_SysParameterSettings_SetAdapterInfo1  (pfSysParameterSettings_SetAdapterInfo1 != NULL)
	#define EXP_SysParameterSettings_SetAdapterInfo1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAdapterInfo1", (RTS_UINTPTR)SysParameterSettings_SetAdapterInfo1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetAdapterInfo2(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETADAPTERINFO2) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETADAPTERINFO2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetAdapterInfo2
	#define EXT_SysParameterSettings_SetAdapterInfo2
	#define GET_SysParameterSettings_SetAdapterInfo2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetAdapterInfo2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetAdapterInfo2  FALSE
	#define EXP_SysParameterSettings_SetAdapterInfo2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetAdapterInfo2
	#define EXT_SysParameterSettings_SetAdapterInfo2
	#define GET_SysParameterSettings_SetAdapterInfo2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAdapterInfo2" ) 
	#define CAL_SysParameterSettings_SetAdapterInfo2  SysParameterSettings_SetAdapterInfo2
	#define CHK_SysParameterSettings_SetAdapterInfo2  TRUE
	#define EXP_SysParameterSettings_SetAdapterInfo2  CAL_CMEXPAPI( "SysParameterSettings_SetAdapterInfo2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetAdapterInfo2
	#define EXT_SysParameterSettings_SetAdapterInfo2
	#define GET_SysParameterSettings_SetAdapterInfo2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAdapterInfo2" ) 
	#define CAL_SysParameterSettings_SetAdapterInfo2  SysParameterSettings_SetAdapterInfo2
	#define CHK_SysParameterSettings_SetAdapterInfo2  TRUE
	#define EXP_SysParameterSettings_SetAdapterInfo2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAdapterInfo2", (RTS_UINTPTR)SysParameterSettings_SetAdapterInfo2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetAdapterInfo2
	#define EXT_SysParameterSettingsSysParameterSettings_SetAdapterInfo2
	#define GET_SysParameterSettingsSysParameterSettings_SetAdapterInfo2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetAdapterInfo2 pISysParameterSettings->ISysParameterSettings_SetAdapterInfo2
	#define CHK_SysParameterSettingsSysParameterSettings_SetAdapterInfo2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetAdapterInfo2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetAdapterInfo2
	#define EXT_SysParameterSettings_SetAdapterInfo2
	#define GET_SysParameterSettings_SetAdapterInfo2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAdapterInfo2" ) 
	#define CAL_SysParameterSettings_SetAdapterInfo2 pISysParameterSettings->ISysParameterSettings_SetAdapterInfo2
	#define CHK_SysParameterSettings_SetAdapterInfo2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetAdapterInfo2  CAL_CMEXPAPI( "SysParameterSettings_SetAdapterInfo2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetAdapterInfo2  PFSYSPARAMETERSETTINGS_SETADAPTERINFO2 pfSysParameterSettings_SetAdapterInfo2;
	#define EXT_SysParameterSettings_SetAdapterInfo2  extern PFSYSPARAMETERSETTINGS_SETADAPTERINFO2 pfSysParameterSettings_SetAdapterInfo2;
	#define GET_SysParameterSettings_SetAdapterInfo2(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetAdapterInfo2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetAdapterInfo2, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetAdapterInfo2  pfSysParameterSettings_SetAdapterInfo2
	#define CHK_SysParameterSettings_SetAdapterInfo2  (pfSysParameterSettings_SetAdapterInfo2 != NULL)
	#define EXP_SysParameterSettings_SetAdapterInfo2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAdapterInfo2", (RTS_UINTPTR)SysParameterSettings_SetAdapterInfo2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetStaticGateway1(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY1) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSTATICGATEWAY1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetStaticGateway1
	#define EXT_SysParameterSettings_GetStaticGateway1
	#define GET_SysParameterSettings_GetStaticGateway1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetStaticGateway1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetStaticGateway1  FALSE
	#define EXP_SysParameterSettings_GetStaticGateway1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetStaticGateway1
	#define EXT_SysParameterSettings_GetStaticGateway1
	#define GET_SysParameterSettings_GetStaticGateway1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStaticGateway1" ) 
	#define CAL_SysParameterSettings_GetStaticGateway1  SysParameterSettings_GetStaticGateway1
	#define CHK_SysParameterSettings_GetStaticGateway1  TRUE
	#define EXP_SysParameterSettings_GetStaticGateway1  CAL_CMEXPAPI( "SysParameterSettings_GetStaticGateway1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetStaticGateway1
	#define EXT_SysParameterSettings_GetStaticGateway1
	#define GET_SysParameterSettings_GetStaticGateway1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStaticGateway1" ) 
	#define CAL_SysParameterSettings_GetStaticGateway1  SysParameterSettings_GetStaticGateway1
	#define CHK_SysParameterSettings_GetStaticGateway1  TRUE
	#define EXP_SysParameterSettings_GetStaticGateway1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetStaticGateway1", (RTS_UINTPTR)SysParameterSettings_GetStaticGateway1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetStaticGateway1
	#define EXT_SysParameterSettingsSysParameterSettings_GetStaticGateway1
	#define GET_SysParameterSettingsSysParameterSettings_GetStaticGateway1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetStaticGateway1 pISysParameterSettings->ISysParameterSettings_GetStaticGateway1
	#define CHK_SysParameterSettingsSysParameterSettings_GetStaticGateway1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetStaticGateway1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetStaticGateway1
	#define EXT_SysParameterSettings_GetStaticGateway1
	#define GET_SysParameterSettings_GetStaticGateway1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStaticGateway1" ) 
	#define CAL_SysParameterSettings_GetStaticGateway1 pISysParameterSettings->ISysParameterSettings_GetStaticGateway1
	#define CHK_SysParameterSettings_GetStaticGateway1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetStaticGateway1  CAL_CMEXPAPI( "SysParameterSettings_GetStaticGateway1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetStaticGateway1  PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY1 pfSysParameterSettings_GetStaticGateway1;
	#define EXT_SysParameterSettings_GetStaticGateway1  extern PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY1 pfSysParameterSettings_GetStaticGateway1;
	#define GET_SysParameterSettings_GetStaticGateway1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetStaticGateway1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetStaticGateway1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetStaticGateway1  pfSysParameterSettings_GetStaticGateway1
	#define CHK_SysParameterSettings_GetStaticGateway1  (pfSysParameterSettings_GetStaticGateway1 != NULL)
	#define EXP_SysParameterSettings_GetStaticGateway1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetStaticGateway1", (RTS_UINTPTR)SysParameterSettings_GetStaticGateway1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetStaticGateway2(AdapterNetworkV4Settings * pAdapter);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY2) (AdapterNetworkV4Settings * pAdapter);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSTATICGATEWAY2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetStaticGateway2
	#define EXT_SysParameterSettings_GetStaticGateway2
	#define GET_SysParameterSettings_GetStaticGateway2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetStaticGateway2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetStaticGateway2  FALSE
	#define EXP_SysParameterSettings_GetStaticGateway2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetStaticGateway2
	#define EXT_SysParameterSettings_GetStaticGateway2
	#define GET_SysParameterSettings_GetStaticGateway2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStaticGateway2" ) 
	#define CAL_SysParameterSettings_GetStaticGateway2  SysParameterSettings_GetStaticGateway2
	#define CHK_SysParameterSettings_GetStaticGateway2  TRUE
	#define EXP_SysParameterSettings_GetStaticGateway2  CAL_CMEXPAPI( "SysParameterSettings_GetStaticGateway2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetStaticGateway2
	#define EXT_SysParameterSettings_GetStaticGateway2
	#define GET_SysParameterSettings_GetStaticGateway2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStaticGateway2" ) 
	#define CAL_SysParameterSettings_GetStaticGateway2  SysParameterSettings_GetStaticGateway2
	#define CHK_SysParameterSettings_GetStaticGateway2  TRUE
	#define EXP_SysParameterSettings_GetStaticGateway2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetStaticGateway2", (RTS_UINTPTR)SysParameterSettings_GetStaticGateway2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetStaticGateway2
	#define EXT_SysParameterSettingsSysParameterSettings_GetStaticGateway2
	#define GET_SysParameterSettingsSysParameterSettings_GetStaticGateway2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetStaticGateway2 pISysParameterSettings->ISysParameterSettings_GetStaticGateway2
	#define CHK_SysParameterSettingsSysParameterSettings_GetStaticGateway2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetStaticGateway2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetStaticGateway2
	#define EXT_SysParameterSettings_GetStaticGateway2
	#define GET_SysParameterSettings_GetStaticGateway2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStaticGateway2" ) 
	#define CAL_SysParameterSettings_GetStaticGateway2 pISysParameterSettings->ISysParameterSettings_GetStaticGateway2
	#define CHK_SysParameterSettings_GetStaticGateway2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetStaticGateway2  CAL_CMEXPAPI( "SysParameterSettings_GetStaticGateway2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetStaticGateway2  PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY2 pfSysParameterSettings_GetStaticGateway2;
	#define EXT_SysParameterSettings_GetStaticGateway2  extern PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY2 pfSysParameterSettings_GetStaticGateway2;
	#define GET_SysParameterSettings_GetStaticGateway2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetStaticGateway2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetStaticGateway2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetStaticGateway2  pfSysParameterSettings_GetStaticGateway2
	#define CHK_SysParameterSettings_GetStaticGateway2  (pfSysParameterSettings_GetStaticGateway2 != NULL)
	#define EXP_SysParameterSettings_GetStaticGateway2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetStaticGateway2", (RTS_UINTPTR)SysParameterSettings_GetStaticGateway2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetFtpStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETFTPSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETFTPSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetFtpStatus
	#define EXT_SysParameterSettings_GetFtpStatus
	#define GET_SysParameterSettings_GetFtpStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetFtpStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetFtpStatus  FALSE
	#define EXP_SysParameterSettings_GetFtpStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetFtpStatus
	#define EXT_SysParameterSettings_GetFtpStatus
	#define GET_SysParameterSettings_GetFtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFtpStatus" ) 
	#define CAL_SysParameterSettings_GetFtpStatus  SysParameterSettings_GetFtpStatus
	#define CHK_SysParameterSettings_GetFtpStatus  TRUE
	#define EXP_SysParameterSettings_GetFtpStatus  CAL_CMEXPAPI( "SysParameterSettings_GetFtpStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetFtpStatus
	#define EXT_SysParameterSettings_GetFtpStatus
	#define GET_SysParameterSettings_GetFtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFtpStatus" ) 
	#define CAL_SysParameterSettings_GetFtpStatus  SysParameterSettings_GetFtpStatus
	#define CHK_SysParameterSettings_GetFtpStatus  TRUE
	#define EXP_SysParameterSettings_GetFtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFtpStatus", (RTS_UINTPTR)SysParameterSettings_GetFtpStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetFtpStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetFtpStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetFtpStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetFtpStatus pISysParameterSettings->ISysParameterSettings_GetFtpStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetFtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetFtpStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetFtpStatus
	#define EXT_SysParameterSettings_GetFtpStatus
	#define GET_SysParameterSettings_GetFtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFtpStatus" ) 
	#define CAL_SysParameterSettings_GetFtpStatus pISysParameterSettings->ISysParameterSettings_GetFtpStatus
	#define CHK_SysParameterSettings_GetFtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetFtpStatus  CAL_CMEXPAPI( "SysParameterSettings_GetFtpStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetFtpStatus  PFSYSPARAMETERSETTINGS_GETFTPSTATUS pfSysParameterSettings_GetFtpStatus;
	#define EXT_SysParameterSettings_GetFtpStatus  extern PFSYSPARAMETERSETTINGS_GETFTPSTATUS pfSysParameterSettings_GetFtpStatus;
	#define GET_SysParameterSettings_GetFtpStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetFtpStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetFtpStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetFtpStatus  pfSysParameterSettings_GetFtpStatus
	#define CHK_SysParameterSettings_GetFtpStatus  (pfSysParameterSettings_GetFtpStatus != NULL)
	#define EXP_SysParameterSettings_GetFtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFtpStatus", (RTS_UINTPTR)SysParameterSettings_GetFtpStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetFtpStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETFTPSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETFTPSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetFtpStatus
	#define EXT_SysParameterSettings_SetFtpStatus
	#define GET_SysParameterSettings_SetFtpStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetFtpStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetFtpStatus  FALSE
	#define EXP_SysParameterSettings_SetFtpStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetFtpStatus
	#define EXT_SysParameterSettings_SetFtpStatus
	#define GET_SysParameterSettings_SetFtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetFtpStatus" ) 
	#define CAL_SysParameterSettings_SetFtpStatus  SysParameterSettings_SetFtpStatus
	#define CHK_SysParameterSettings_SetFtpStatus  TRUE
	#define EXP_SysParameterSettings_SetFtpStatus  CAL_CMEXPAPI( "SysParameterSettings_SetFtpStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetFtpStatus
	#define EXT_SysParameterSettings_SetFtpStatus
	#define GET_SysParameterSettings_SetFtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetFtpStatus" ) 
	#define CAL_SysParameterSettings_SetFtpStatus  SysParameterSettings_SetFtpStatus
	#define CHK_SysParameterSettings_SetFtpStatus  TRUE
	#define EXP_SysParameterSettings_SetFtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetFtpStatus", (RTS_UINTPTR)SysParameterSettings_SetFtpStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetFtpStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetFtpStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetFtpStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetFtpStatus pISysParameterSettings->ISysParameterSettings_SetFtpStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetFtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetFtpStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetFtpStatus
	#define EXT_SysParameterSettings_SetFtpStatus
	#define GET_SysParameterSettings_SetFtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetFtpStatus" ) 
	#define CAL_SysParameterSettings_SetFtpStatus pISysParameterSettings->ISysParameterSettings_SetFtpStatus
	#define CHK_SysParameterSettings_SetFtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetFtpStatus  CAL_CMEXPAPI( "SysParameterSettings_SetFtpStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetFtpStatus  PFSYSPARAMETERSETTINGS_SETFTPSTATUS pfSysParameterSettings_SetFtpStatus;
	#define EXT_SysParameterSettings_SetFtpStatus  extern PFSYSPARAMETERSETTINGS_SETFTPSTATUS pfSysParameterSettings_SetFtpStatus;
	#define GET_SysParameterSettings_SetFtpStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetFtpStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetFtpStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetFtpStatus  pfSysParameterSettings_SetFtpStatus
	#define CHK_SysParameterSettings_SetFtpStatus  (pfSysParameterSettings_SetFtpStatus != NULL)
	#define EXP_SysParameterSettings_SetFtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetFtpStatus", (RTS_UINTPTR)SysParameterSettings_SetFtpStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetNtpStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETNTPSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETNTPSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetNtpStatus
	#define EXT_SysParameterSettings_GetNtpStatus
	#define GET_SysParameterSettings_GetNtpStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetNtpStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetNtpStatus  FALSE
	#define EXP_SysParameterSettings_GetNtpStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetNtpStatus
	#define EXT_SysParameterSettings_GetNtpStatus
	#define GET_SysParameterSettings_GetNtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNtpStatus" ) 
	#define CAL_SysParameterSettings_GetNtpStatus  SysParameterSettings_GetNtpStatus
	#define CHK_SysParameterSettings_GetNtpStatus  TRUE
	#define EXP_SysParameterSettings_GetNtpStatus  CAL_CMEXPAPI( "SysParameterSettings_GetNtpStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetNtpStatus
	#define EXT_SysParameterSettings_GetNtpStatus
	#define GET_SysParameterSettings_GetNtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNtpStatus" ) 
	#define CAL_SysParameterSettings_GetNtpStatus  SysParameterSettings_GetNtpStatus
	#define CHK_SysParameterSettings_GetNtpStatus  TRUE
	#define EXP_SysParameterSettings_GetNtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNtpStatus", (RTS_UINTPTR)SysParameterSettings_GetNtpStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetNtpStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetNtpStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetNtpStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetNtpStatus pISysParameterSettings->ISysParameterSettings_GetNtpStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetNtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetNtpStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetNtpStatus
	#define EXT_SysParameterSettings_GetNtpStatus
	#define GET_SysParameterSettings_GetNtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNtpStatus" ) 
	#define CAL_SysParameterSettings_GetNtpStatus pISysParameterSettings->ISysParameterSettings_GetNtpStatus
	#define CHK_SysParameterSettings_GetNtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetNtpStatus  CAL_CMEXPAPI( "SysParameterSettings_GetNtpStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetNtpStatus  PFSYSPARAMETERSETTINGS_GETNTPSTATUS pfSysParameterSettings_GetNtpStatus;
	#define EXT_SysParameterSettings_GetNtpStatus  extern PFSYSPARAMETERSETTINGS_GETNTPSTATUS pfSysParameterSettings_GetNtpStatus;
	#define GET_SysParameterSettings_GetNtpStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetNtpStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetNtpStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetNtpStatus  pfSysParameterSettings_GetNtpStatus
	#define CHK_SysParameterSettings_GetNtpStatus  (pfSysParameterSettings_GetNtpStatus != NULL)
	#define EXP_SysParameterSettings_GetNtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNtpStatus", (RTS_UINTPTR)SysParameterSettings_GetNtpStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetNtpStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETNTPSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETNTPSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetNtpStatus
	#define EXT_SysParameterSettings_SetNtpStatus
	#define GET_SysParameterSettings_SetNtpStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetNtpStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetNtpStatus  FALSE
	#define EXP_SysParameterSettings_SetNtpStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetNtpStatus
	#define EXT_SysParameterSettings_SetNtpStatus
	#define GET_SysParameterSettings_SetNtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNtpStatus" ) 
	#define CAL_SysParameterSettings_SetNtpStatus  SysParameterSettings_SetNtpStatus
	#define CHK_SysParameterSettings_SetNtpStatus  TRUE
	#define EXP_SysParameterSettings_SetNtpStatus  CAL_CMEXPAPI( "SysParameterSettings_SetNtpStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetNtpStatus
	#define EXT_SysParameterSettings_SetNtpStatus
	#define GET_SysParameterSettings_SetNtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNtpStatus" ) 
	#define CAL_SysParameterSettings_SetNtpStatus  SysParameterSettings_SetNtpStatus
	#define CHK_SysParameterSettings_SetNtpStatus  TRUE
	#define EXP_SysParameterSettings_SetNtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetNtpStatus", (RTS_UINTPTR)SysParameterSettings_SetNtpStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetNtpStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetNtpStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetNtpStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetNtpStatus pISysParameterSettings->ISysParameterSettings_SetNtpStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetNtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetNtpStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetNtpStatus
	#define EXT_SysParameterSettings_SetNtpStatus
	#define GET_SysParameterSettings_SetNtpStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNtpStatus" ) 
	#define CAL_SysParameterSettings_SetNtpStatus pISysParameterSettings->ISysParameterSettings_SetNtpStatus
	#define CHK_SysParameterSettings_SetNtpStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetNtpStatus  CAL_CMEXPAPI( "SysParameterSettings_SetNtpStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetNtpStatus  PFSYSPARAMETERSETTINGS_SETNTPSTATUS pfSysParameterSettings_SetNtpStatus;
	#define EXT_SysParameterSettings_SetNtpStatus  extern PFSYSPARAMETERSETTINGS_SETNTPSTATUS pfSysParameterSettings_SetNtpStatus;
	#define GET_SysParameterSettings_SetNtpStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetNtpStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetNtpStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetNtpStatus  pfSysParameterSettings_SetNtpStatus
	#define CHK_SysParameterSettings_SetNtpStatus  (pfSysParameterSettings_SetNtpStatus != NULL)
	#define EXP_SysParameterSettings_SetNtpStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetNtpStatus", (RTS_UINTPTR)SysParameterSettings_SetNtpStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetNtpServer(char * pszNtpServer, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETNTPSERVER) (char * pszNtpServer, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETNTPSERVER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetNtpServer
	#define EXT_SysParameterSettings_GetNtpServer
	#define GET_SysParameterSettings_GetNtpServer(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetNtpServer(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetNtpServer  FALSE
	#define EXP_SysParameterSettings_GetNtpServer  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetNtpServer
	#define EXT_SysParameterSettings_GetNtpServer
	#define GET_SysParameterSettings_GetNtpServer(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNtpServer" ) 
	#define CAL_SysParameterSettings_GetNtpServer  SysParameterSettings_GetNtpServer
	#define CHK_SysParameterSettings_GetNtpServer  TRUE
	#define EXP_SysParameterSettings_GetNtpServer  CAL_CMEXPAPI( "SysParameterSettings_GetNtpServer" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetNtpServer
	#define EXT_SysParameterSettings_GetNtpServer
	#define GET_SysParameterSettings_GetNtpServer(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNtpServer" ) 
	#define CAL_SysParameterSettings_GetNtpServer  SysParameterSettings_GetNtpServer
	#define CHK_SysParameterSettings_GetNtpServer  TRUE
	#define EXP_SysParameterSettings_GetNtpServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNtpServer", (RTS_UINTPTR)SysParameterSettings_GetNtpServer, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetNtpServer
	#define EXT_SysParameterSettingsSysParameterSettings_GetNtpServer
	#define GET_SysParameterSettingsSysParameterSettings_GetNtpServer  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetNtpServer pISysParameterSettings->ISysParameterSettings_GetNtpServer
	#define CHK_SysParameterSettingsSysParameterSettings_GetNtpServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetNtpServer  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetNtpServer
	#define EXT_SysParameterSettings_GetNtpServer
	#define GET_SysParameterSettings_GetNtpServer(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNtpServer" ) 
	#define CAL_SysParameterSettings_GetNtpServer pISysParameterSettings->ISysParameterSettings_GetNtpServer
	#define CHK_SysParameterSettings_GetNtpServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetNtpServer  CAL_CMEXPAPI( "SysParameterSettings_GetNtpServer" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetNtpServer  PFSYSPARAMETERSETTINGS_GETNTPSERVER pfSysParameterSettings_GetNtpServer;
	#define EXT_SysParameterSettings_GetNtpServer  extern PFSYSPARAMETERSETTINGS_GETNTPSERVER pfSysParameterSettings_GetNtpServer;
	#define GET_SysParameterSettings_GetNtpServer(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetNtpServer", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetNtpServer, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetNtpServer  pfSysParameterSettings_GetNtpServer
	#define CHK_SysParameterSettings_GetNtpServer  (pfSysParameterSettings_GetNtpServer != NULL)
	#define EXP_SysParameterSettings_GetNtpServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNtpServer", (RTS_UINTPTR)SysParameterSettings_GetNtpServer, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetNtpServer(char * pszNtpServer);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETNTPSERVER) (char * pszNtpServer);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETNTPSERVER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetNtpServer
	#define EXT_SysParameterSettings_SetNtpServer
	#define GET_SysParameterSettings_SetNtpServer(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetNtpServer(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetNtpServer  FALSE
	#define EXP_SysParameterSettings_SetNtpServer  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetNtpServer
	#define EXT_SysParameterSettings_SetNtpServer
	#define GET_SysParameterSettings_SetNtpServer(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNtpServer" ) 
	#define CAL_SysParameterSettings_SetNtpServer  SysParameterSettings_SetNtpServer
	#define CHK_SysParameterSettings_SetNtpServer  TRUE
	#define EXP_SysParameterSettings_SetNtpServer  CAL_CMEXPAPI( "SysParameterSettings_SetNtpServer" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetNtpServer
	#define EXT_SysParameterSettings_SetNtpServer
	#define GET_SysParameterSettings_SetNtpServer(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNtpServer" ) 
	#define CAL_SysParameterSettings_SetNtpServer  SysParameterSettings_SetNtpServer
	#define CHK_SysParameterSettings_SetNtpServer  TRUE
	#define EXP_SysParameterSettings_SetNtpServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetNtpServer", (RTS_UINTPTR)SysParameterSettings_SetNtpServer, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetNtpServer
	#define EXT_SysParameterSettingsSysParameterSettings_SetNtpServer
	#define GET_SysParameterSettingsSysParameterSettings_SetNtpServer  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetNtpServer pISysParameterSettings->ISysParameterSettings_SetNtpServer
	#define CHK_SysParameterSettingsSysParameterSettings_SetNtpServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetNtpServer  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetNtpServer
	#define EXT_SysParameterSettings_SetNtpServer
	#define GET_SysParameterSettings_SetNtpServer(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNtpServer" ) 
	#define CAL_SysParameterSettings_SetNtpServer pISysParameterSettings->ISysParameterSettings_SetNtpServer
	#define CHK_SysParameterSettings_SetNtpServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetNtpServer  CAL_CMEXPAPI( "SysParameterSettings_SetNtpServer" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetNtpServer  PFSYSPARAMETERSETTINGS_SETNTPSERVER pfSysParameterSettings_SetNtpServer;
	#define EXT_SysParameterSettings_SetNtpServer  extern PFSYSPARAMETERSETTINGS_SETNTPSERVER pfSysParameterSettings_SetNtpServer;
	#define GET_SysParameterSettings_SetNtpServer(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetNtpServer", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetNtpServer, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetNtpServer  pfSysParameterSettings_SetNtpServer
	#define CHK_SysParameterSettings_SetNtpServer  (pfSysParameterSettings_SetNtpServer != NULL)
	#define EXP_SysParameterSettings_SetNtpServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetNtpServer", (RTS_UINTPTR)SysParameterSettings_SetNtpServer, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetTimezone(char * pszTimezone, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETTIMEZONE) (char * pszTimezone, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETTIMEZONE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetTimezone
	#define EXT_SysParameterSettings_GetTimezone
	#define GET_SysParameterSettings_GetTimezone(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetTimezone(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetTimezone  FALSE
	#define EXP_SysParameterSettings_GetTimezone  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetTimezone
	#define EXT_SysParameterSettings_GetTimezone
	#define GET_SysParameterSettings_GetTimezone(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTimezone" ) 
	#define CAL_SysParameterSettings_GetTimezone  SysParameterSettings_GetTimezone
	#define CHK_SysParameterSettings_GetTimezone  TRUE
	#define EXP_SysParameterSettings_GetTimezone  CAL_CMEXPAPI( "SysParameterSettings_GetTimezone" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetTimezone
	#define EXT_SysParameterSettings_GetTimezone
	#define GET_SysParameterSettings_GetTimezone(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTimezone" ) 
	#define CAL_SysParameterSettings_GetTimezone  SysParameterSettings_GetTimezone
	#define CHK_SysParameterSettings_GetTimezone  TRUE
	#define EXP_SysParameterSettings_GetTimezone  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetTimezone", (RTS_UINTPTR)SysParameterSettings_GetTimezone, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetTimezone
	#define EXT_SysParameterSettingsSysParameterSettings_GetTimezone
	#define GET_SysParameterSettingsSysParameterSettings_GetTimezone  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetTimezone pISysParameterSettings->ISysParameterSettings_GetTimezone
	#define CHK_SysParameterSettingsSysParameterSettings_GetTimezone (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetTimezone  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetTimezone
	#define EXT_SysParameterSettings_GetTimezone
	#define GET_SysParameterSettings_GetTimezone(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTimezone" ) 
	#define CAL_SysParameterSettings_GetTimezone pISysParameterSettings->ISysParameterSettings_GetTimezone
	#define CHK_SysParameterSettings_GetTimezone (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetTimezone  CAL_CMEXPAPI( "SysParameterSettings_GetTimezone" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetTimezone  PFSYSPARAMETERSETTINGS_GETTIMEZONE pfSysParameterSettings_GetTimezone;
	#define EXT_SysParameterSettings_GetTimezone  extern PFSYSPARAMETERSETTINGS_GETTIMEZONE pfSysParameterSettings_GetTimezone;
	#define GET_SysParameterSettings_GetTimezone(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetTimezone", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetTimezone, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetTimezone  pfSysParameterSettings_GetTimezone
	#define CHK_SysParameterSettings_GetTimezone  (pfSysParameterSettings_GetTimezone != NULL)
	#define EXP_SysParameterSettings_GetTimezone  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetTimezone", (RTS_UINTPTR)SysParameterSettings_GetTimezone, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetTimezone(char * pszTimezone);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETTIMEZONE) (char * pszTimezone);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETTIMEZONE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetTimezone
	#define EXT_SysParameterSettings_SetTimezone
	#define GET_SysParameterSettings_SetTimezone(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetTimezone(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetTimezone  FALSE
	#define EXP_SysParameterSettings_SetTimezone  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetTimezone
	#define EXT_SysParameterSettings_SetTimezone
	#define GET_SysParameterSettings_SetTimezone(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTimezone" ) 
	#define CAL_SysParameterSettings_SetTimezone  SysParameterSettings_SetTimezone
	#define CHK_SysParameterSettings_SetTimezone  TRUE
	#define EXP_SysParameterSettings_SetTimezone  CAL_CMEXPAPI( "SysParameterSettings_SetTimezone" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetTimezone
	#define EXT_SysParameterSettings_SetTimezone
	#define GET_SysParameterSettings_SetTimezone(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTimezone" ) 
	#define CAL_SysParameterSettings_SetTimezone  SysParameterSettings_SetTimezone
	#define CHK_SysParameterSettings_SetTimezone  TRUE
	#define EXP_SysParameterSettings_SetTimezone  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetTimezone", (RTS_UINTPTR)SysParameterSettings_SetTimezone, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetTimezone
	#define EXT_SysParameterSettingsSysParameterSettings_SetTimezone
	#define GET_SysParameterSettingsSysParameterSettings_SetTimezone  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetTimezone pISysParameterSettings->ISysParameterSettings_SetTimezone
	#define CHK_SysParameterSettingsSysParameterSettings_SetTimezone (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetTimezone  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetTimezone
	#define EXT_SysParameterSettings_SetTimezone
	#define GET_SysParameterSettings_SetTimezone(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTimezone" ) 
	#define CAL_SysParameterSettings_SetTimezone pISysParameterSettings->ISysParameterSettings_SetTimezone
	#define CHK_SysParameterSettings_SetTimezone (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetTimezone  CAL_CMEXPAPI( "SysParameterSettings_SetTimezone" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetTimezone  PFSYSPARAMETERSETTINGS_SETTIMEZONE pfSysParameterSettings_SetTimezone;
	#define EXT_SysParameterSettings_SetTimezone  extern PFSYSPARAMETERSETTINGS_SETTIMEZONE pfSysParameterSettings_SetTimezone;
	#define GET_SysParameterSettings_SetTimezone(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetTimezone", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetTimezone, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetTimezone  pfSysParameterSettings_SetTimezone
	#define CHK_SysParameterSettings_SetTimezone  (pfSysParameterSettings_SetTimezone != NULL)
	#define EXP_SysParameterSettings_SetTimezone  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetTimezone", (RTS_UINTPTR)SysParameterSettings_SetTimezone, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDate(char * pszDate, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDATE) (char * pszDate, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDATE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDate
	#define EXT_SysParameterSettings_GetDate
	#define GET_SysParameterSettings_GetDate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDate(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDate  FALSE
	#define EXP_SysParameterSettings_GetDate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDate
	#define EXT_SysParameterSettings_GetDate
	#define GET_SysParameterSettings_GetDate(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDate" ) 
	#define CAL_SysParameterSettings_GetDate  SysParameterSettings_GetDate
	#define CHK_SysParameterSettings_GetDate  TRUE
	#define EXP_SysParameterSettings_GetDate  CAL_CMEXPAPI( "SysParameterSettings_GetDate" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDate
	#define EXT_SysParameterSettings_GetDate
	#define GET_SysParameterSettings_GetDate(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDate" ) 
	#define CAL_SysParameterSettings_GetDate  SysParameterSettings_GetDate
	#define CHK_SysParameterSettings_GetDate  TRUE
	#define EXP_SysParameterSettings_GetDate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDate", (RTS_UINTPTR)SysParameterSettings_GetDate, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDate
	#define EXT_SysParameterSettingsSysParameterSettings_GetDate
	#define GET_SysParameterSettingsSysParameterSettings_GetDate  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDate pISysParameterSettings->ISysParameterSettings_GetDate
	#define CHK_SysParameterSettingsSysParameterSettings_GetDate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDate  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDate
	#define EXT_SysParameterSettings_GetDate
	#define GET_SysParameterSettings_GetDate(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDate" ) 
	#define CAL_SysParameterSettings_GetDate pISysParameterSettings->ISysParameterSettings_GetDate
	#define CHK_SysParameterSettings_GetDate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDate  CAL_CMEXPAPI( "SysParameterSettings_GetDate" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDate  PFSYSPARAMETERSETTINGS_GETDATE pfSysParameterSettings_GetDate;
	#define EXT_SysParameterSettings_GetDate  extern PFSYSPARAMETERSETTINGS_GETDATE pfSysParameterSettings_GetDate;
	#define GET_SysParameterSettings_GetDate(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDate", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDate, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDate  pfSysParameterSettings_GetDate
	#define CHK_SysParameterSettings_GetDate  (pfSysParameterSettings_GetDate != NULL)
	#define EXP_SysParameterSettings_GetDate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDate", (RTS_UINTPTR)SysParameterSettings_GetDate, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDate(char * pszDate);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDATE) (char * pszDate);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDATE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDate
	#define EXT_SysParameterSettings_SetDate
	#define GET_SysParameterSettings_SetDate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDate(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDate  FALSE
	#define EXP_SysParameterSettings_SetDate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDate
	#define EXT_SysParameterSettings_SetDate
	#define GET_SysParameterSettings_SetDate(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDate" ) 
	#define CAL_SysParameterSettings_SetDate  SysParameterSettings_SetDate
	#define CHK_SysParameterSettings_SetDate  TRUE
	#define EXP_SysParameterSettings_SetDate  CAL_CMEXPAPI( "SysParameterSettings_SetDate" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDate
	#define EXT_SysParameterSettings_SetDate
	#define GET_SysParameterSettings_SetDate(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDate" ) 
	#define CAL_SysParameterSettings_SetDate  SysParameterSettings_SetDate
	#define CHK_SysParameterSettings_SetDate  TRUE
	#define EXP_SysParameterSettings_SetDate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDate", (RTS_UINTPTR)SysParameterSettings_SetDate, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDate
	#define EXT_SysParameterSettingsSysParameterSettings_SetDate
	#define GET_SysParameterSettingsSysParameterSettings_SetDate  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDate pISysParameterSettings->ISysParameterSettings_SetDate
	#define CHK_SysParameterSettingsSysParameterSettings_SetDate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDate  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDate
	#define EXT_SysParameterSettings_SetDate
	#define GET_SysParameterSettings_SetDate(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDate" ) 
	#define CAL_SysParameterSettings_SetDate pISysParameterSettings->ISysParameterSettings_SetDate
	#define CHK_SysParameterSettings_SetDate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDate  CAL_CMEXPAPI( "SysParameterSettings_SetDate" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDate  PFSYSPARAMETERSETTINGS_SETDATE pfSysParameterSettings_SetDate;
	#define EXT_SysParameterSettings_SetDate  extern PFSYSPARAMETERSETTINGS_SETDATE pfSysParameterSettings_SetDate;
	#define GET_SysParameterSettings_SetDate(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDate", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDate, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDate  pfSysParameterSettings_SetDate
	#define CHK_SysParameterSettings_SetDate  (pfSysParameterSettings_SetDate != NULL)
	#define EXP_SysParameterSettings_SetDate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDate", (RTS_UINTPTR)SysParameterSettings_SetDate, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetTime(char * pszTime, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETTIME) (char * pszTime, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetTime
	#define EXT_SysParameterSettings_GetTime
	#define GET_SysParameterSettings_GetTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetTime(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetTime  FALSE
	#define EXP_SysParameterSettings_GetTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetTime
	#define EXT_SysParameterSettings_GetTime
	#define GET_SysParameterSettings_GetTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTime" ) 
	#define CAL_SysParameterSettings_GetTime  SysParameterSettings_GetTime
	#define CHK_SysParameterSettings_GetTime  TRUE
	#define EXP_SysParameterSettings_GetTime  CAL_CMEXPAPI( "SysParameterSettings_GetTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetTime
	#define EXT_SysParameterSettings_GetTime
	#define GET_SysParameterSettings_GetTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTime" ) 
	#define CAL_SysParameterSettings_GetTime  SysParameterSettings_GetTime
	#define CHK_SysParameterSettings_GetTime  TRUE
	#define EXP_SysParameterSettings_GetTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetTime", (RTS_UINTPTR)SysParameterSettings_GetTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetTime
	#define EXT_SysParameterSettingsSysParameterSettings_GetTime
	#define GET_SysParameterSettingsSysParameterSettings_GetTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetTime pISysParameterSettings->ISysParameterSettings_GetTime
	#define CHK_SysParameterSettingsSysParameterSettings_GetTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetTime
	#define EXT_SysParameterSettings_GetTime
	#define GET_SysParameterSettings_GetTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTime" ) 
	#define CAL_SysParameterSettings_GetTime pISysParameterSettings->ISysParameterSettings_GetTime
	#define CHK_SysParameterSettings_GetTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetTime  CAL_CMEXPAPI( "SysParameterSettings_GetTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetTime  PFSYSPARAMETERSETTINGS_GETTIME pfSysParameterSettings_GetTime;
	#define EXT_SysParameterSettings_GetTime  extern PFSYSPARAMETERSETTINGS_GETTIME pfSysParameterSettings_GetTime;
	#define GET_SysParameterSettings_GetTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetTime  pfSysParameterSettings_GetTime
	#define CHK_SysParameterSettings_GetTime  (pfSysParameterSettings_GetTime != NULL)
	#define EXP_SysParameterSettings_GetTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetTime", (RTS_UINTPTR)SysParameterSettings_GetTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetTime(char * pszTime);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETTIME) (char * pszTime);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetTime
	#define EXT_SysParameterSettings_SetTime
	#define GET_SysParameterSettings_SetTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetTime  FALSE
	#define EXP_SysParameterSettings_SetTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetTime
	#define EXT_SysParameterSettings_SetTime
	#define GET_SysParameterSettings_SetTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTime" ) 
	#define CAL_SysParameterSettings_SetTime  SysParameterSettings_SetTime
	#define CHK_SysParameterSettings_SetTime  TRUE
	#define EXP_SysParameterSettings_SetTime  CAL_CMEXPAPI( "SysParameterSettings_SetTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetTime
	#define EXT_SysParameterSettings_SetTime
	#define GET_SysParameterSettings_SetTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTime" ) 
	#define CAL_SysParameterSettings_SetTime  SysParameterSettings_SetTime
	#define CHK_SysParameterSettings_SetTime  TRUE
	#define EXP_SysParameterSettings_SetTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetTime", (RTS_UINTPTR)SysParameterSettings_SetTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetTime
	#define EXT_SysParameterSettingsSysParameterSettings_SetTime
	#define GET_SysParameterSettingsSysParameterSettings_SetTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetTime pISysParameterSettings->ISysParameterSettings_SetTime
	#define CHK_SysParameterSettingsSysParameterSettings_SetTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetTime
	#define EXT_SysParameterSettings_SetTime
	#define GET_SysParameterSettings_SetTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTime" ) 
	#define CAL_SysParameterSettings_SetTime pISysParameterSettings->ISysParameterSettings_SetTime
	#define CHK_SysParameterSettings_SetTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetTime  CAL_CMEXPAPI( "SysParameterSettings_SetTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetTime  PFSYSPARAMETERSETTINGS_SETTIME pfSysParameterSettings_SetTime;
	#define EXT_SysParameterSettings_SetTime  extern PFSYSPARAMETERSETTINGS_SETTIME pfSysParameterSettings_SetTime;
	#define GET_SysParameterSettings_SetTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetTime  pfSysParameterSettings_SetTime
	#define CHK_SysParameterSettings_SetTime  (pfSysParameterSettings_SetTime != NULL)
	#define EXP_SysParameterSettings_SetTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetTime", (RTS_UINTPTR)SysParameterSettings_SetTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDhcpStatus1(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDHCPSTATUS1) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDHCPSTATUS1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDhcpStatus1
	#define EXT_SysParameterSettings_GetDhcpStatus1
	#define GET_SysParameterSettings_GetDhcpStatus1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDhcpStatus1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDhcpStatus1  FALSE
	#define EXP_SysParameterSettings_GetDhcpStatus1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDhcpStatus1
	#define EXT_SysParameterSettings_GetDhcpStatus1
	#define GET_SysParameterSettings_GetDhcpStatus1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDhcpStatus1" ) 
	#define CAL_SysParameterSettings_GetDhcpStatus1  SysParameterSettings_GetDhcpStatus1
	#define CHK_SysParameterSettings_GetDhcpStatus1  TRUE
	#define EXP_SysParameterSettings_GetDhcpStatus1  CAL_CMEXPAPI( "SysParameterSettings_GetDhcpStatus1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDhcpStatus1
	#define EXT_SysParameterSettings_GetDhcpStatus1
	#define GET_SysParameterSettings_GetDhcpStatus1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDhcpStatus1" ) 
	#define CAL_SysParameterSettings_GetDhcpStatus1  SysParameterSettings_GetDhcpStatus1
	#define CHK_SysParameterSettings_GetDhcpStatus1  TRUE
	#define EXP_SysParameterSettings_GetDhcpStatus1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDhcpStatus1", (RTS_UINTPTR)SysParameterSettings_GetDhcpStatus1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDhcpStatus1
	#define EXT_SysParameterSettingsSysParameterSettings_GetDhcpStatus1
	#define GET_SysParameterSettingsSysParameterSettings_GetDhcpStatus1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDhcpStatus1 pISysParameterSettings->ISysParameterSettings_GetDhcpStatus1
	#define CHK_SysParameterSettingsSysParameterSettings_GetDhcpStatus1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDhcpStatus1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDhcpStatus1
	#define EXT_SysParameterSettings_GetDhcpStatus1
	#define GET_SysParameterSettings_GetDhcpStatus1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDhcpStatus1" ) 
	#define CAL_SysParameterSettings_GetDhcpStatus1 pISysParameterSettings->ISysParameterSettings_GetDhcpStatus1
	#define CHK_SysParameterSettings_GetDhcpStatus1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDhcpStatus1  CAL_CMEXPAPI( "SysParameterSettings_GetDhcpStatus1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDhcpStatus1  PFSYSPARAMETERSETTINGS_GETDHCPSTATUS1 pfSysParameterSettings_GetDhcpStatus1;
	#define EXT_SysParameterSettings_GetDhcpStatus1  extern PFSYSPARAMETERSETTINGS_GETDHCPSTATUS1 pfSysParameterSettings_GetDhcpStatus1;
	#define GET_SysParameterSettings_GetDhcpStatus1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDhcpStatus1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDhcpStatus1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDhcpStatus1  pfSysParameterSettings_GetDhcpStatus1
	#define CHK_SysParameterSettings_GetDhcpStatus1  (pfSysParameterSettings_GetDhcpStatus1 != NULL)
	#define EXP_SysParameterSettings_GetDhcpStatus1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDhcpStatus1", (RTS_UINTPTR)SysParameterSettings_GetDhcpStatus1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDhcpStatus2(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDHCPSTATUS2) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDHCPSTATUS2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDhcpStatus2
	#define EXT_SysParameterSettings_GetDhcpStatus2
	#define GET_SysParameterSettings_GetDhcpStatus2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDhcpStatus2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDhcpStatus2  FALSE
	#define EXP_SysParameterSettings_GetDhcpStatus2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDhcpStatus2
	#define EXT_SysParameterSettings_GetDhcpStatus2
	#define GET_SysParameterSettings_GetDhcpStatus2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDhcpStatus2" ) 
	#define CAL_SysParameterSettings_GetDhcpStatus2  SysParameterSettings_GetDhcpStatus2
	#define CHK_SysParameterSettings_GetDhcpStatus2  TRUE
	#define EXP_SysParameterSettings_GetDhcpStatus2  CAL_CMEXPAPI( "SysParameterSettings_GetDhcpStatus2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDhcpStatus2
	#define EXT_SysParameterSettings_GetDhcpStatus2
	#define GET_SysParameterSettings_GetDhcpStatus2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDhcpStatus2" ) 
	#define CAL_SysParameterSettings_GetDhcpStatus2  SysParameterSettings_GetDhcpStatus2
	#define CHK_SysParameterSettings_GetDhcpStatus2  TRUE
	#define EXP_SysParameterSettings_GetDhcpStatus2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDhcpStatus2", (RTS_UINTPTR)SysParameterSettings_GetDhcpStatus2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDhcpStatus2
	#define EXT_SysParameterSettingsSysParameterSettings_GetDhcpStatus2
	#define GET_SysParameterSettingsSysParameterSettings_GetDhcpStatus2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDhcpStatus2 pISysParameterSettings->ISysParameterSettings_GetDhcpStatus2
	#define CHK_SysParameterSettingsSysParameterSettings_GetDhcpStatus2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDhcpStatus2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDhcpStatus2
	#define EXT_SysParameterSettings_GetDhcpStatus2
	#define GET_SysParameterSettings_GetDhcpStatus2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDhcpStatus2" ) 
	#define CAL_SysParameterSettings_GetDhcpStatus2 pISysParameterSettings->ISysParameterSettings_GetDhcpStatus2
	#define CHK_SysParameterSettings_GetDhcpStatus2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDhcpStatus2  CAL_CMEXPAPI( "SysParameterSettings_GetDhcpStatus2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDhcpStatus2  PFSYSPARAMETERSETTINGS_GETDHCPSTATUS2 pfSysParameterSettings_GetDhcpStatus2;
	#define EXT_SysParameterSettings_GetDhcpStatus2  extern PFSYSPARAMETERSETTINGS_GETDHCPSTATUS2 pfSysParameterSettings_GetDhcpStatus2;
	#define GET_SysParameterSettings_GetDhcpStatus2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDhcpStatus2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDhcpStatus2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDhcpStatus2  pfSysParameterSettings_GetDhcpStatus2
	#define CHK_SysParameterSettings_GetDhcpStatus2  (pfSysParameterSettings_GetDhcpStatus2 != NULL)
	#define EXP_SysParameterSettings_GetDhcpStatus2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDhcpStatus2", (RTS_UINTPTR)SysParameterSettings_GetDhcpStatus2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_Reboot(void);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_REBOOT) (void);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_REBOOT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_Reboot
	#define EXT_SysParameterSettings_Reboot
	#define GET_SysParameterSettings_Reboot(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_Reboot()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_Reboot  FALSE
	#define EXP_SysParameterSettings_Reboot  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_Reboot
	#define EXT_SysParameterSettings_Reboot
	#define GET_SysParameterSettings_Reboot(fl)  CAL_CMGETAPI( "SysParameterSettings_Reboot" ) 
	#define CAL_SysParameterSettings_Reboot  SysParameterSettings_Reboot
	#define CHK_SysParameterSettings_Reboot  TRUE
	#define EXP_SysParameterSettings_Reboot  CAL_CMEXPAPI( "SysParameterSettings_Reboot" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_Reboot
	#define EXT_SysParameterSettings_Reboot
	#define GET_SysParameterSettings_Reboot(fl)  CAL_CMGETAPI( "SysParameterSettings_Reboot" ) 
	#define CAL_SysParameterSettings_Reboot  SysParameterSettings_Reboot
	#define CHK_SysParameterSettings_Reboot  TRUE
	#define EXP_SysParameterSettings_Reboot  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_Reboot", (RTS_UINTPTR)SysParameterSettings_Reboot, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_Reboot
	#define EXT_SysParameterSettingsSysParameterSettings_Reboot
	#define GET_SysParameterSettingsSysParameterSettings_Reboot  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_Reboot pISysParameterSettings->ISysParameterSettings_Reboot
	#define CHK_SysParameterSettingsSysParameterSettings_Reboot (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_Reboot  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_Reboot
	#define EXT_SysParameterSettings_Reboot
	#define GET_SysParameterSettings_Reboot(fl)  CAL_CMGETAPI( "SysParameterSettings_Reboot" ) 
	#define CAL_SysParameterSettings_Reboot pISysParameterSettings->ISysParameterSettings_Reboot
	#define CHK_SysParameterSettings_Reboot (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_Reboot  CAL_CMEXPAPI( "SysParameterSettings_Reboot" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_Reboot  PFSYSPARAMETERSETTINGS_REBOOT pfSysParameterSettings_Reboot;
	#define EXT_SysParameterSettings_Reboot  extern PFSYSPARAMETERSETTINGS_REBOOT pfSysParameterSettings_Reboot;
	#define GET_SysParameterSettings_Reboot(fl)  s_pfCMGetAPI2( "SysParameterSettings_Reboot", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_Reboot, (fl), 0, 0)
	#define CAL_SysParameterSettings_Reboot  pfSysParameterSettings_Reboot
	#define CHK_SysParameterSettings_Reboot  (pfSysParameterSettings_Reboot != NULL)
	#define EXP_SysParameterSettings_Reboot  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_Reboot", (RTS_UINTPTR)SysParameterSettings_Reboot, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMemTotal(RTS_UI32 * pMemory);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMEMTOTAL) (RTS_UI32 * pMemory);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMEMTOTAL_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMemTotal
	#define EXT_SysParameterSettings_GetMemTotal
	#define GET_SysParameterSettings_GetMemTotal(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMemTotal(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMemTotal  FALSE
	#define EXP_SysParameterSettings_GetMemTotal  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMemTotal
	#define EXT_SysParameterSettings_GetMemTotal
	#define GET_SysParameterSettings_GetMemTotal(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemTotal" ) 
	#define CAL_SysParameterSettings_GetMemTotal  SysParameterSettings_GetMemTotal
	#define CHK_SysParameterSettings_GetMemTotal  TRUE
	#define EXP_SysParameterSettings_GetMemTotal  CAL_CMEXPAPI( "SysParameterSettings_GetMemTotal" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMemTotal
	#define EXT_SysParameterSettings_GetMemTotal
	#define GET_SysParameterSettings_GetMemTotal(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemTotal" ) 
	#define CAL_SysParameterSettings_GetMemTotal  SysParameterSettings_GetMemTotal
	#define CHK_SysParameterSettings_GetMemTotal  TRUE
	#define EXP_SysParameterSettings_GetMemTotal  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemTotal", (RTS_UINTPTR)SysParameterSettings_GetMemTotal, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMemTotal
	#define EXT_SysParameterSettingsSysParameterSettings_GetMemTotal
	#define GET_SysParameterSettingsSysParameterSettings_GetMemTotal  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMemTotal pISysParameterSettings->ISysParameterSettings_GetMemTotal
	#define CHK_SysParameterSettingsSysParameterSettings_GetMemTotal (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMemTotal  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMemTotal
	#define EXT_SysParameterSettings_GetMemTotal
	#define GET_SysParameterSettings_GetMemTotal(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemTotal" ) 
	#define CAL_SysParameterSettings_GetMemTotal pISysParameterSettings->ISysParameterSettings_GetMemTotal
	#define CHK_SysParameterSettings_GetMemTotal (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMemTotal  CAL_CMEXPAPI( "SysParameterSettings_GetMemTotal" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMemTotal  PFSYSPARAMETERSETTINGS_GETMEMTOTAL pfSysParameterSettings_GetMemTotal;
	#define EXT_SysParameterSettings_GetMemTotal  extern PFSYSPARAMETERSETTINGS_GETMEMTOTAL pfSysParameterSettings_GetMemTotal;
	#define GET_SysParameterSettings_GetMemTotal(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMemTotal", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMemTotal, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMemTotal  pfSysParameterSettings_GetMemTotal
	#define CHK_SysParameterSettings_GetMemTotal  (pfSysParameterSettings_GetMemTotal != NULL)
	#define EXP_SysParameterSettings_GetMemTotal  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemTotal", (RTS_UINTPTR)SysParameterSettings_GetMemTotal, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMemAvailable(RTS_UI32 * pMemory);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMEMAVAILABLE) (RTS_UI32 * pMemory);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMEMAVAILABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMemAvailable
	#define EXT_SysParameterSettings_GetMemAvailable
	#define GET_SysParameterSettings_GetMemAvailable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMemAvailable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMemAvailable  FALSE
	#define EXP_SysParameterSettings_GetMemAvailable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMemAvailable
	#define EXT_SysParameterSettings_GetMemAvailable
	#define GET_SysParameterSettings_GetMemAvailable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemAvailable" ) 
	#define CAL_SysParameterSettings_GetMemAvailable  SysParameterSettings_GetMemAvailable
	#define CHK_SysParameterSettings_GetMemAvailable  TRUE
	#define EXP_SysParameterSettings_GetMemAvailable  CAL_CMEXPAPI( "SysParameterSettings_GetMemAvailable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMemAvailable
	#define EXT_SysParameterSettings_GetMemAvailable
	#define GET_SysParameterSettings_GetMemAvailable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemAvailable" ) 
	#define CAL_SysParameterSettings_GetMemAvailable  SysParameterSettings_GetMemAvailable
	#define CHK_SysParameterSettings_GetMemAvailable  TRUE
	#define EXP_SysParameterSettings_GetMemAvailable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemAvailable", (RTS_UINTPTR)SysParameterSettings_GetMemAvailable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMemAvailable
	#define EXT_SysParameterSettingsSysParameterSettings_GetMemAvailable
	#define GET_SysParameterSettingsSysParameterSettings_GetMemAvailable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMemAvailable pISysParameterSettings->ISysParameterSettings_GetMemAvailable
	#define CHK_SysParameterSettingsSysParameterSettings_GetMemAvailable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMemAvailable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMemAvailable
	#define EXT_SysParameterSettings_GetMemAvailable
	#define GET_SysParameterSettings_GetMemAvailable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemAvailable" ) 
	#define CAL_SysParameterSettings_GetMemAvailable pISysParameterSettings->ISysParameterSettings_GetMemAvailable
	#define CHK_SysParameterSettings_GetMemAvailable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMemAvailable  CAL_CMEXPAPI( "SysParameterSettings_GetMemAvailable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMemAvailable  PFSYSPARAMETERSETTINGS_GETMEMAVAILABLE pfSysParameterSettings_GetMemAvailable;
	#define EXT_SysParameterSettings_GetMemAvailable  extern PFSYSPARAMETERSETTINGS_GETMEMAVAILABLE pfSysParameterSettings_GetMemAvailable;
	#define GET_SysParameterSettings_GetMemAvailable(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMemAvailable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMemAvailable, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMemAvailable  pfSysParameterSettings_GetMemAvailable
	#define CHK_SysParameterSettings_GetMemAvailable  (pfSysParameterSettings_GetMemAvailable != NULL)
	#define EXP_SysParameterSettings_GetMemAvailable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemAvailable", (RTS_UINTPTR)SysParameterSettings_GetMemAvailable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMemFlashTotal(RTS_UI32 * pMemory);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMEMFLASHTOTAL) (RTS_UI32 * pMemory);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMEMFLASHTOTAL_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMemFlashTotal
	#define EXT_SysParameterSettings_GetMemFlashTotal
	#define GET_SysParameterSettings_GetMemFlashTotal(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMemFlashTotal(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMemFlashTotal  FALSE
	#define EXP_SysParameterSettings_GetMemFlashTotal  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMemFlashTotal
	#define EXT_SysParameterSettings_GetMemFlashTotal
	#define GET_SysParameterSettings_GetMemFlashTotal(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemFlashTotal" ) 
	#define CAL_SysParameterSettings_GetMemFlashTotal  SysParameterSettings_GetMemFlashTotal
	#define CHK_SysParameterSettings_GetMemFlashTotal  TRUE
	#define EXP_SysParameterSettings_GetMemFlashTotal  CAL_CMEXPAPI( "SysParameterSettings_GetMemFlashTotal" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMemFlashTotal
	#define EXT_SysParameterSettings_GetMemFlashTotal
	#define GET_SysParameterSettings_GetMemFlashTotal(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemFlashTotal" ) 
	#define CAL_SysParameterSettings_GetMemFlashTotal  SysParameterSettings_GetMemFlashTotal
	#define CHK_SysParameterSettings_GetMemFlashTotal  TRUE
	#define EXP_SysParameterSettings_GetMemFlashTotal  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemFlashTotal", (RTS_UINTPTR)SysParameterSettings_GetMemFlashTotal, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMemFlashTotal
	#define EXT_SysParameterSettingsSysParameterSettings_GetMemFlashTotal
	#define GET_SysParameterSettingsSysParameterSettings_GetMemFlashTotal  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMemFlashTotal pISysParameterSettings->ISysParameterSettings_GetMemFlashTotal
	#define CHK_SysParameterSettingsSysParameterSettings_GetMemFlashTotal (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMemFlashTotal  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMemFlashTotal
	#define EXT_SysParameterSettings_GetMemFlashTotal
	#define GET_SysParameterSettings_GetMemFlashTotal(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemFlashTotal" ) 
	#define CAL_SysParameterSettings_GetMemFlashTotal pISysParameterSettings->ISysParameterSettings_GetMemFlashTotal
	#define CHK_SysParameterSettings_GetMemFlashTotal (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMemFlashTotal  CAL_CMEXPAPI( "SysParameterSettings_GetMemFlashTotal" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMemFlashTotal  PFSYSPARAMETERSETTINGS_GETMEMFLASHTOTAL pfSysParameterSettings_GetMemFlashTotal;
	#define EXT_SysParameterSettings_GetMemFlashTotal  extern PFSYSPARAMETERSETTINGS_GETMEMFLASHTOTAL pfSysParameterSettings_GetMemFlashTotal;
	#define GET_SysParameterSettings_GetMemFlashTotal(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMemFlashTotal", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMemFlashTotal, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMemFlashTotal  pfSysParameterSettings_GetMemFlashTotal
	#define CHK_SysParameterSettings_GetMemFlashTotal  (pfSysParameterSettings_GetMemFlashTotal != NULL)
	#define EXP_SysParameterSettings_GetMemFlashTotal  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemFlashTotal", (RTS_UINTPTR)SysParameterSettings_GetMemFlashTotal, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMemFlashAvailable(RTS_UI32 * pMemory);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMEMFLASHAVAILABLE) (RTS_UI32 * pMemory);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMEMFLASHAVAILABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMemFlashAvailable
	#define EXT_SysParameterSettings_GetMemFlashAvailable
	#define GET_SysParameterSettings_GetMemFlashAvailable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMemFlashAvailable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMemFlashAvailable  FALSE
	#define EXP_SysParameterSettings_GetMemFlashAvailable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMemFlashAvailable
	#define EXT_SysParameterSettings_GetMemFlashAvailable
	#define GET_SysParameterSettings_GetMemFlashAvailable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemFlashAvailable" ) 
	#define CAL_SysParameterSettings_GetMemFlashAvailable  SysParameterSettings_GetMemFlashAvailable
	#define CHK_SysParameterSettings_GetMemFlashAvailable  TRUE
	#define EXP_SysParameterSettings_GetMemFlashAvailable  CAL_CMEXPAPI( "SysParameterSettings_GetMemFlashAvailable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMemFlashAvailable
	#define EXT_SysParameterSettings_GetMemFlashAvailable
	#define GET_SysParameterSettings_GetMemFlashAvailable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemFlashAvailable" ) 
	#define CAL_SysParameterSettings_GetMemFlashAvailable  SysParameterSettings_GetMemFlashAvailable
	#define CHK_SysParameterSettings_GetMemFlashAvailable  TRUE
	#define EXP_SysParameterSettings_GetMemFlashAvailable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemFlashAvailable", (RTS_UINTPTR)SysParameterSettings_GetMemFlashAvailable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMemFlashAvailable
	#define EXT_SysParameterSettingsSysParameterSettings_GetMemFlashAvailable
	#define GET_SysParameterSettingsSysParameterSettings_GetMemFlashAvailable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMemFlashAvailable pISysParameterSettings->ISysParameterSettings_GetMemFlashAvailable
	#define CHK_SysParameterSettingsSysParameterSettings_GetMemFlashAvailable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMemFlashAvailable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMemFlashAvailable
	#define EXT_SysParameterSettings_GetMemFlashAvailable
	#define GET_SysParameterSettings_GetMemFlashAvailable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMemFlashAvailable" ) 
	#define CAL_SysParameterSettings_GetMemFlashAvailable pISysParameterSettings->ISysParameterSettings_GetMemFlashAvailable
	#define CHK_SysParameterSettings_GetMemFlashAvailable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMemFlashAvailable  CAL_CMEXPAPI( "SysParameterSettings_GetMemFlashAvailable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMemFlashAvailable  PFSYSPARAMETERSETTINGS_GETMEMFLASHAVAILABLE pfSysParameterSettings_GetMemFlashAvailable;
	#define EXT_SysParameterSettings_GetMemFlashAvailable  extern PFSYSPARAMETERSETTINGS_GETMEMFLASHAVAILABLE pfSysParameterSettings_GetMemFlashAvailable;
	#define GET_SysParameterSettings_GetMemFlashAvailable(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMemFlashAvailable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMemFlashAvailable, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMemFlashAvailable  pfSysParameterSettings_GetMemFlashAvailable
	#define CHK_SysParameterSettings_GetMemFlashAvailable  (pfSysParameterSettings_GetMemFlashAvailable != NULL)
	#define EXP_SysParameterSettings_GetMemFlashAvailable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMemFlashAvailable", (RTS_UINTPTR)SysParameterSettings_GetMemFlashAvailable, 0, 0) 
#endif



/**
 * <description> This function create default Users (Linux/Windows CE), when don't exist. Called in CmpParameterUSR.CmpParameterUSR_init3.</description>
  */
RTS_RESULT CDECL SysParameterSettings_CreateDefaultUsers(void);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_CREATEDEFAULTUSERS) (void);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_CREATEDEFAULTUSERS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_CreateDefaultUsers
	#define EXT_SysParameterSettings_CreateDefaultUsers
	#define GET_SysParameterSettings_CreateDefaultUsers(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_CreateDefaultUsers()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_CreateDefaultUsers  FALSE
	#define EXP_SysParameterSettings_CreateDefaultUsers  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_CreateDefaultUsers
	#define EXT_SysParameterSettings_CreateDefaultUsers
	#define GET_SysParameterSettings_CreateDefaultUsers(fl)  CAL_CMGETAPI( "SysParameterSettings_CreateDefaultUsers" ) 
	#define CAL_SysParameterSettings_CreateDefaultUsers  SysParameterSettings_CreateDefaultUsers
	#define CHK_SysParameterSettings_CreateDefaultUsers  TRUE
	#define EXP_SysParameterSettings_CreateDefaultUsers  CAL_CMEXPAPI( "SysParameterSettings_CreateDefaultUsers" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_CreateDefaultUsers
	#define EXT_SysParameterSettings_CreateDefaultUsers
	#define GET_SysParameterSettings_CreateDefaultUsers(fl)  CAL_CMGETAPI( "SysParameterSettings_CreateDefaultUsers" ) 
	#define CAL_SysParameterSettings_CreateDefaultUsers  SysParameterSettings_CreateDefaultUsers
	#define CHK_SysParameterSettings_CreateDefaultUsers  TRUE
	#define EXP_SysParameterSettings_CreateDefaultUsers  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_CreateDefaultUsers", (RTS_UINTPTR)SysParameterSettings_CreateDefaultUsers, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_CreateDefaultUsers
	#define EXT_SysParameterSettingsSysParameterSettings_CreateDefaultUsers
	#define GET_SysParameterSettingsSysParameterSettings_CreateDefaultUsers  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_CreateDefaultUsers pISysParameterSettings->ISysParameterSettings_CreateDefaultUsers
	#define CHK_SysParameterSettingsSysParameterSettings_CreateDefaultUsers (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_CreateDefaultUsers  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_CreateDefaultUsers
	#define EXT_SysParameterSettings_CreateDefaultUsers
	#define GET_SysParameterSettings_CreateDefaultUsers(fl)  CAL_CMGETAPI( "SysParameterSettings_CreateDefaultUsers" ) 
	#define CAL_SysParameterSettings_CreateDefaultUsers pISysParameterSettings->ISysParameterSettings_CreateDefaultUsers
	#define CHK_SysParameterSettings_CreateDefaultUsers (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_CreateDefaultUsers  CAL_CMEXPAPI( "SysParameterSettings_CreateDefaultUsers" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_CreateDefaultUsers  PFSYSPARAMETERSETTINGS_CREATEDEFAULTUSERS pfSysParameterSettings_CreateDefaultUsers;
	#define EXT_SysParameterSettings_CreateDefaultUsers  extern PFSYSPARAMETERSETTINGS_CREATEDEFAULTUSERS pfSysParameterSettings_CreateDefaultUsers;
	#define GET_SysParameterSettings_CreateDefaultUsers(fl)  s_pfCMGetAPI2( "SysParameterSettings_CreateDefaultUsers", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_CreateDefaultUsers, (fl), 0, 0)
	#define CAL_SysParameterSettings_CreateDefaultUsers  pfSysParameterSettings_CreateDefaultUsers
	#define CHK_SysParameterSettings_CreateDefaultUsers  (pfSysParameterSettings_CreateDefaultUsers != NULL)
	#define EXP_SysParameterSettings_CreateDefaultUsers  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_CreateDefaultUsers", (RTS_UINTPTR)SysParameterSettings_CreateDefaultUsers, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_CreateUser(char * szUsername, char * szPasswd, char * szGroupname);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_CREATEUSER) (char * szUsername, char * szPasswd, char * szGroupname);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_CREATEUSER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_CreateUser
	#define EXT_SysParameterSettings_CreateUser
	#define GET_SysParameterSettings_CreateUser(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_CreateUser(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_CreateUser  FALSE
	#define EXP_SysParameterSettings_CreateUser  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_CreateUser
	#define EXT_SysParameterSettings_CreateUser
	#define GET_SysParameterSettings_CreateUser(fl)  CAL_CMGETAPI( "SysParameterSettings_CreateUser" ) 
	#define CAL_SysParameterSettings_CreateUser  SysParameterSettings_CreateUser
	#define CHK_SysParameterSettings_CreateUser  TRUE
	#define EXP_SysParameterSettings_CreateUser  CAL_CMEXPAPI( "SysParameterSettings_CreateUser" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_CreateUser
	#define EXT_SysParameterSettings_CreateUser
	#define GET_SysParameterSettings_CreateUser(fl)  CAL_CMGETAPI( "SysParameterSettings_CreateUser" ) 
	#define CAL_SysParameterSettings_CreateUser  SysParameterSettings_CreateUser
	#define CHK_SysParameterSettings_CreateUser  TRUE
	#define EXP_SysParameterSettings_CreateUser  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_CreateUser", (RTS_UINTPTR)SysParameterSettings_CreateUser, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_CreateUser
	#define EXT_SysParameterSettingsSysParameterSettings_CreateUser
	#define GET_SysParameterSettingsSysParameterSettings_CreateUser  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_CreateUser pISysParameterSettings->ISysParameterSettings_CreateUser
	#define CHK_SysParameterSettingsSysParameterSettings_CreateUser (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_CreateUser  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_CreateUser
	#define EXT_SysParameterSettings_CreateUser
	#define GET_SysParameterSettings_CreateUser(fl)  CAL_CMGETAPI( "SysParameterSettings_CreateUser" ) 
	#define CAL_SysParameterSettings_CreateUser pISysParameterSettings->ISysParameterSettings_CreateUser
	#define CHK_SysParameterSettings_CreateUser (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_CreateUser  CAL_CMEXPAPI( "SysParameterSettings_CreateUser" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_CreateUser  PFSYSPARAMETERSETTINGS_CREATEUSER pfSysParameterSettings_CreateUser;
	#define EXT_SysParameterSettings_CreateUser  extern PFSYSPARAMETERSETTINGS_CREATEUSER pfSysParameterSettings_CreateUser;
	#define GET_SysParameterSettings_CreateUser(fl)  s_pfCMGetAPI2( "SysParameterSettings_CreateUser", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_CreateUser, (fl), 0, 0)
	#define CAL_SysParameterSettings_CreateUser  pfSysParameterSettings_CreateUser
	#define CHK_SysParameterSettings_CreateUser  (pfSysParameterSettings_CreateUser != NULL)
	#define EXP_SysParameterSettings_CreateUser  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_CreateUser", (RTS_UINTPTR)SysParameterSettings_CreateUser, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_ChangePasswd(char * szUsername, char * szPasswd);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_CHANGEPASSWD) (char * szUsername, char * szPasswd);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_CHANGEPASSWD_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_ChangePasswd
	#define EXT_SysParameterSettings_ChangePasswd
	#define GET_SysParameterSettings_ChangePasswd(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_ChangePasswd(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_ChangePasswd  FALSE
	#define EXP_SysParameterSettings_ChangePasswd  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_ChangePasswd
	#define EXT_SysParameterSettings_ChangePasswd
	#define GET_SysParameterSettings_ChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_ChangePasswd" ) 
	#define CAL_SysParameterSettings_ChangePasswd  SysParameterSettings_ChangePasswd
	#define CHK_SysParameterSettings_ChangePasswd  TRUE
	#define EXP_SysParameterSettings_ChangePasswd  CAL_CMEXPAPI( "SysParameterSettings_ChangePasswd" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_ChangePasswd
	#define EXT_SysParameterSettings_ChangePasswd
	#define GET_SysParameterSettings_ChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_ChangePasswd" ) 
	#define CAL_SysParameterSettings_ChangePasswd  SysParameterSettings_ChangePasswd
	#define CHK_SysParameterSettings_ChangePasswd  TRUE
	#define EXP_SysParameterSettings_ChangePasswd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_ChangePasswd", (RTS_UINTPTR)SysParameterSettings_ChangePasswd, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_ChangePasswd
	#define EXT_SysParameterSettingsSysParameterSettings_ChangePasswd
	#define GET_SysParameterSettingsSysParameterSettings_ChangePasswd  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_ChangePasswd pISysParameterSettings->ISysParameterSettings_ChangePasswd
	#define CHK_SysParameterSettingsSysParameterSettings_ChangePasswd (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_ChangePasswd  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_ChangePasswd
	#define EXT_SysParameterSettings_ChangePasswd
	#define GET_SysParameterSettings_ChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_ChangePasswd" ) 
	#define CAL_SysParameterSettings_ChangePasswd pISysParameterSettings->ISysParameterSettings_ChangePasswd
	#define CHK_SysParameterSettings_ChangePasswd (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_ChangePasswd  CAL_CMEXPAPI( "SysParameterSettings_ChangePasswd" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_ChangePasswd  PFSYSPARAMETERSETTINGS_CHANGEPASSWD pfSysParameterSettings_ChangePasswd;
	#define EXT_SysParameterSettings_ChangePasswd  extern PFSYSPARAMETERSETTINGS_CHANGEPASSWD pfSysParameterSettings_ChangePasswd;
	#define GET_SysParameterSettings_ChangePasswd(fl)  s_pfCMGetAPI2( "SysParameterSettings_ChangePasswd", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_ChangePasswd, (fl), 0, 0)
	#define CAL_SysParameterSettings_ChangePasswd  pfSysParameterSettings_ChangePasswd
	#define CHK_SysParameterSettings_ChangePasswd  (pfSysParameterSettings_ChangePasswd != NULL)
	#define EXP_SysParameterSettings_ChangePasswd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_ChangePasswd", (RTS_UINTPTR)SysParameterSettings_ChangePasswd, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetUsersGroupList(char * szUsername, char * szOutGroupList, int maxlen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETUSERSGROUPLIST) (char * szUsername, char * szOutGroupList, int maxlen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETUSERSGROUPLIST_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetUsersGroupList
	#define EXT_SysParameterSettings_GetUsersGroupList
	#define GET_SysParameterSettings_GetUsersGroupList(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetUsersGroupList(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetUsersGroupList  FALSE
	#define EXP_SysParameterSettings_GetUsersGroupList  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetUsersGroupList
	#define EXT_SysParameterSettings_GetUsersGroupList
	#define GET_SysParameterSettings_GetUsersGroupList(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUsersGroupList" ) 
	#define CAL_SysParameterSettings_GetUsersGroupList  SysParameterSettings_GetUsersGroupList
	#define CHK_SysParameterSettings_GetUsersGroupList  TRUE
	#define EXP_SysParameterSettings_GetUsersGroupList  CAL_CMEXPAPI( "SysParameterSettings_GetUsersGroupList" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetUsersGroupList
	#define EXT_SysParameterSettings_GetUsersGroupList
	#define GET_SysParameterSettings_GetUsersGroupList(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUsersGroupList" ) 
	#define CAL_SysParameterSettings_GetUsersGroupList  SysParameterSettings_GetUsersGroupList
	#define CHK_SysParameterSettings_GetUsersGroupList  TRUE
	#define EXP_SysParameterSettings_GetUsersGroupList  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUsersGroupList", (RTS_UINTPTR)SysParameterSettings_GetUsersGroupList, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetUsersGroupList
	#define EXT_SysParameterSettingsSysParameterSettings_GetUsersGroupList
	#define GET_SysParameterSettingsSysParameterSettings_GetUsersGroupList  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetUsersGroupList pISysParameterSettings->ISysParameterSettings_GetUsersGroupList
	#define CHK_SysParameterSettingsSysParameterSettings_GetUsersGroupList (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetUsersGroupList  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetUsersGroupList
	#define EXT_SysParameterSettings_GetUsersGroupList
	#define GET_SysParameterSettings_GetUsersGroupList(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUsersGroupList" ) 
	#define CAL_SysParameterSettings_GetUsersGroupList pISysParameterSettings->ISysParameterSettings_GetUsersGroupList
	#define CHK_SysParameterSettings_GetUsersGroupList (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetUsersGroupList  CAL_CMEXPAPI( "SysParameterSettings_GetUsersGroupList" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetUsersGroupList  PFSYSPARAMETERSETTINGS_GETUSERSGROUPLIST pfSysParameterSettings_GetUsersGroupList;
	#define EXT_SysParameterSettings_GetUsersGroupList  extern PFSYSPARAMETERSETTINGS_GETUSERSGROUPLIST pfSysParameterSettings_GetUsersGroupList;
	#define GET_SysParameterSettings_GetUsersGroupList(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetUsersGroupList", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetUsersGroupList, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetUsersGroupList  pfSysParameterSettings_GetUsersGroupList
	#define CHK_SysParameterSettings_GetUsersGroupList  (pfSysParameterSettings_GetUsersGroupList != NULL)
	#define EXP_SysParameterSettings_GetUsersGroupList  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUsersGroupList", (RTS_UINTPTR)SysParameterSettings_GetUsersGroupList, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_AddUserToGroup(char * szUsername, char * szGroupname);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_ADDUSERTOGROUP) (char * szUsername, char * szGroupname);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ADDUSERTOGROUP_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_AddUserToGroup
	#define EXT_SysParameterSettings_AddUserToGroup
	#define GET_SysParameterSettings_AddUserToGroup(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_AddUserToGroup(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_AddUserToGroup  FALSE
	#define EXP_SysParameterSettings_AddUserToGroup  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_AddUserToGroup
	#define EXT_SysParameterSettings_AddUserToGroup
	#define GET_SysParameterSettings_AddUserToGroup(fl)  CAL_CMGETAPI( "SysParameterSettings_AddUserToGroup" ) 
	#define CAL_SysParameterSettings_AddUserToGroup  SysParameterSettings_AddUserToGroup
	#define CHK_SysParameterSettings_AddUserToGroup  TRUE
	#define EXP_SysParameterSettings_AddUserToGroup  CAL_CMEXPAPI( "SysParameterSettings_AddUserToGroup" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_AddUserToGroup
	#define EXT_SysParameterSettings_AddUserToGroup
	#define GET_SysParameterSettings_AddUserToGroup(fl)  CAL_CMGETAPI( "SysParameterSettings_AddUserToGroup" ) 
	#define CAL_SysParameterSettings_AddUserToGroup  SysParameterSettings_AddUserToGroup
	#define CHK_SysParameterSettings_AddUserToGroup  TRUE
	#define EXP_SysParameterSettings_AddUserToGroup  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_AddUserToGroup", (RTS_UINTPTR)SysParameterSettings_AddUserToGroup, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_AddUserToGroup
	#define EXT_SysParameterSettingsSysParameterSettings_AddUserToGroup
	#define GET_SysParameterSettingsSysParameterSettings_AddUserToGroup  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_AddUserToGroup pISysParameterSettings->ISysParameterSettings_AddUserToGroup
	#define CHK_SysParameterSettingsSysParameterSettings_AddUserToGroup (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_AddUserToGroup  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_AddUserToGroup
	#define EXT_SysParameterSettings_AddUserToGroup
	#define GET_SysParameterSettings_AddUserToGroup(fl)  CAL_CMGETAPI( "SysParameterSettings_AddUserToGroup" ) 
	#define CAL_SysParameterSettings_AddUserToGroup pISysParameterSettings->ISysParameterSettings_AddUserToGroup
	#define CHK_SysParameterSettings_AddUserToGroup (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_AddUserToGroup  CAL_CMEXPAPI( "SysParameterSettings_AddUserToGroup" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_AddUserToGroup  PFSYSPARAMETERSETTINGS_ADDUSERTOGROUP pfSysParameterSettings_AddUserToGroup;
	#define EXT_SysParameterSettings_AddUserToGroup  extern PFSYSPARAMETERSETTINGS_ADDUSERTOGROUP pfSysParameterSettings_AddUserToGroup;
	#define GET_SysParameterSettings_AddUserToGroup(fl)  s_pfCMGetAPI2( "SysParameterSettings_AddUserToGroup", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_AddUserToGroup, (fl), 0, 0)
	#define CAL_SysParameterSettings_AddUserToGroup  pfSysParameterSettings_AddUserToGroup
	#define CHK_SysParameterSettings_AddUserToGroup  (pfSysParameterSettings_AddUserToGroup != NULL)
	#define EXP_SysParameterSettings_AddUserToGroup  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_AddUserToGroup", (RTS_UINTPTR)SysParameterSettings_AddUserToGroup, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_RemoveUserFromGroup(char * szUsername, char * szGroupname);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_REMOVEUSERFROMGROUP) (char * szUsername, char * szGroupname);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_REMOVEUSERFROMGROUP_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_RemoveUserFromGroup
	#define EXT_SysParameterSettings_RemoveUserFromGroup
	#define GET_SysParameterSettings_RemoveUserFromGroup(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_RemoveUserFromGroup(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_RemoveUserFromGroup  FALSE
	#define EXP_SysParameterSettings_RemoveUserFromGroup  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_RemoveUserFromGroup
	#define EXT_SysParameterSettings_RemoveUserFromGroup
	#define GET_SysParameterSettings_RemoveUserFromGroup(fl)  CAL_CMGETAPI( "SysParameterSettings_RemoveUserFromGroup" ) 
	#define CAL_SysParameterSettings_RemoveUserFromGroup  SysParameterSettings_RemoveUserFromGroup
	#define CHK_SysParameterSettings_RemoveUserFromGroup  TRUE
	#define EXP_SysParameterSettings_RemoveUserFromGroup  CAL_CMEXPAPI( "SysParameterSettings_RemoveUserFromGroup" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_RemoveUserFromGroup
	#define EXT_SysParameterSettings_RemoveUserFromGroup
	#define GET_SysParameterSettings_RemoveUserFromGroup(fl)  CAL_CMGETAPI( "SysParameterSettings_RemoveUserFromGroup" ) 
	#define CAL_SysParameterSettings_RemoveUserFromGroup  SysParameterSettings_RemoveUserFromGroup
	#define CHK_SysParameterSettings_RemoveUserFromGroup  TRUE
	#define EXP_SysParameterSettings_RemoveUserFromGroup  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_RemoveUserFromGroup", (RTS_UINTPTR)SysParameterSettings_RemoveUserFromGroup, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_RemoveUserFromGroup
	#define EXT_SysParameterSettingsSysParameterSettings_RemoveUserFromGroup
	#define GET_SysParameterSettingsSysParameterSettings_RemoveUserFromGroup  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_RemoveUserFromGroup pISysParameterSettings->ISysParameterSettings_RemoveUserFromGroup
	#define CHK_SysParameterSettingsSysParameterSettings_RemoveUserFromGroup (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_RemoveUserFromGroup  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_RemoveUserFromGroup
	#define EXT_SysParameterSettings_RemoveUserFromGroup
	#define GET_SysParameterSettings_RemoveUserFromGroup(fl)  CAL_CMGETAPI( "SysParameterSettings_RemoveUserFromGroup" ) 
	#define CAL_SysParameterSettings_RemoveUserFromGroup pISysParameterSettings->ISysParameterSettings_RemoveUserFromGroup
	#define CHK_SysParameterSettings_RemoveUserFromGroup (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_RemoveUserFromGroup  CAL_CMEXPAPI( "SysParameterSettings_RemoveUserFromGroup" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_RemoveUserFromGroup  PFSYSPARAMETERSETTINGS_REMOVEUSERFROMGROUP pfSysParameterSettings_RemoveUserFromGroup;
	#define EXT_SysParameterSettings_RemoveUserFromGroup  extern PFSYSPARAMETERSETTINGS_REMOVEUSERFROMGROUP pfSysParameterSettings_RemoveUserFromGroup;
	#define GET_SysParameterSettings_RemoveUserFromGroup(fl)  s_pfCMGetAPI2( "SysParameterSettings_RemoveUserFromGroup", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_RemoveUserFromGroup, (fl), 0, 0)
	#define CAL_SysParameterSettings_RemoveUserFromGroup  pfSysParameterSettings_RemoveUserFromGroup
	#define CHK_SysParameterSettings_RemoveUserFromGroup  (pfSysParameterSettings_RemoveUserFromGroup != NULL)
	#define EXP_SysParameterSettings_RemoveUserFromGroup  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_RemoveUserFromGroup", (RTS_UINTPTR)SysParameterSettings_RemoveUserFromGroup, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_VerifyPassword(char * szUsername, char * szPasswd);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_VERIFYPASSWORD) (char * szUsername, char * szPasswd);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_VERIFYPASSWORD_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_VerifyPassword
	#define EXT_SysParameterSettings_VerifyPassword
	#define GET_SysParameterSettings_VerifyPassword(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_VerifyPassword(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_VerifyPassword  FALSE
	#define EXP_SysParameterSettings_VerifyPassword  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_VerifyPassword
	#define EXT_SysParameterSettings_VerifyPassword
	#define GET_SysParameterSettings_VerifyPassword(fl)  CAL_CMGETAPI( "SysParameterSettings_VerifyPassword" ) 
	#define CAL_SysParameterSettings_VerifyPassword  SysParameterSettings_VerifyPassword
	#define CHK_SysParameterSettings_VerifyPassword  TRUE
	#define EXP_SysParameterSettings_VerifyPassword  CAL_CMEXPAPI( "SysParameterSettings_VerifyPassword" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_VerifyPassword
	#define EXT_SysParameterSettings_VerifyPassword
	#define GET_SysParameterSettings_VerifyPassword(fl)  CAL_CMGETAPI( "SysParameterSettings_VerifyPassword" ) 
	#define CAL_SysParameterSettings_VerifyPassword  SysParameterSettings_VerifyPassword
	#define CHK_SysParameterSettings_VerifyPassword  TRUE
	#define EXP_SysParameterSettings_VerifyPassword  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_VerifyPassword", (RTS_UINTPTR)SysParameterSettings_VerifyPassword, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_VerifyPassword
	#define EXT_SysParameterSettingsSysParameterSettings_VerifyPassword
	#define GET_SysParameterSettingsSysParameterSettings_VerifyPassword  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_VerifyPassword pISysParameterSettings->ISysParameterSettings_VerifyPassword
	#define CHK_SysParameterSettingsSysParameterSettings_VerifyPassword (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_VerifyPassword  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_VerifyPassword
	#define EXT_SysParameterSettings_VerifyPassword
	#define GET_SysParameterSettings_VerifyPassword(fl)  CAL_CMGETAPI( "SysParameterSettings_VerifyPassword" ) 
	#define CAL_SysParameterSettings_VerifyPassword pISysParameterSettings->ISysParameterSettings_VerifyPassword
	#define CHK_SysParameterSettings_VerifyPassword (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_VerifyPassword  CAL_CMEXPAPI( "SysParameterSettings_VerifyPassword" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_VerifyPassword  PFSYSPARAMETERSETTINGS_VERIFYPASSWORD pfSysParameterSettings_VerifyPassword;
	#define EXT_SysParameterSettings_VerifyPassword  extern PFSYSPARAMETERSETTINGS_VERIFYPASSWORD pfSysParameterSettings_VerifyPassword;
	#define GET_SysParameterSettings_VerifyPassword(fl)  s_pfCMGetAPI2( "SysParameterSettings_VerifyPassword", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_VerifyPassword, (fl), 0, 0)
	#define CAL_SysParameterSettings_VerifyPassword  pfSysParameterSettings_VerifyPassword
	#define CHK_SysParameterSettings_VerifyPassword  (pfSysParameterSettings_VerifyPassword != NULL)
	#define EXP_SysParameterSettings_VerifyPassword  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_VerifyPassword", (RTS_UINTPTR)SysParameterSettings_VerifyPassword, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetGroupMembers(char * szGroupname, char * szOutput, int maxlen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETGROUPMEMBERS) (char * szGroupname, char * szOutput, int maxlen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETGROUPMEMBERS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetGroupMembers
	#define EXT_SysParameterSettings_GetGroupMembers
	#define GET_SysParameterSettings_GetGroupMembers(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetGroupMembers(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetGroupMembers  FALSE
	#define EXP_SysParameterSettings_GetGroupMembers  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetGroupMembers
	#define EXT_SysParameterSettings_GetGroupMembers
	#define GET_SysParameterSettings_GetGroupMembers(fl)  CAL_CMGETAPI( "SysParameterSettings_GetGroupMembers" ) 
	#define CAL_SysParameterSettings_GetGroupMembers  SysParameterSettings_GetGroupMembers
	#define CHK_SysParameterSettings_GetGroupMembers  TRUE
	#define EXP_SysParameterSettings_GetGroupMembers  CAL_CMEXPAPI( "SysParameterSettings_GetGroupMembers" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetGroupMembers
	#define EXT_SysParameterSettings_GetGroupMembers
	#define GET_SysParameterSettings_GetGroupMembers(fl)  CAL_CMGETAPI( "SysParameterSettings_GetGroupMembers" ) 
	#define CAL_SysParameterSettings_GetGroupMembers  SysParameterSettings_GetGroupMembers
	#define CHK_SysParameterSettings_GetGroupMembers  TRUE
	#define EXP_SysParameterSettings_GetGroupMembers  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetGroupMembers", (RTS_UINTPTR)SysParameterSettings_GetGroupMembers, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetGroupMembers
	#define EXT_SysParameterSettingsSysParameterSettings_GetGroupMembers
	#define GET_SysParameterSettingsSysParameterSettings_GetGroupMembers  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetGroupMembers pISysParameterSettings->ISysParameterSettings_GetGroupMembers
	#define CHK_SysParameterSettingsSysParameterSettings_GetGroupMembers (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetGroupMembers  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetGroupMembers
	#define EXT_SysParameterSettings_GetGroupMembers
	#define GET_SysParameterSettings_GetGroupMembers(fl)  CAL_CMGETAPI( "SysParameterSettings_GetGroupMembers" ) 
	#define CAL_SysParameterSettings_GetGroupMembers pISysParameterSettings->ISysParameterSettings_GetGroupMembers
	#define CHK_SysParameterSettings_GetGroupMembers (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetGroupMembers  CAL_CMEXPAPI( "SysParameterSettings_GetGroupMembers" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetGroupMembers  PFSYSPARAMETERSETTINGS_GETGROUPMEMBERS pfSysParameterSettings_GetGroupMembers;
	#define EXT_SysParameterSettings_GetGroupMembers  extern PFSYSPARAMETERSETTINGS_GETGROUPMEMBERS pfSysParameterSettings_GetGroupMembers;
	#define GET_SysParameterSettings_GetGroupMembers(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetGroupMembers", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetGroupMembers, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetGroupMembers  pfSysParameterSettings_GetGroupMembers
	#define CHK_SysParameterSettings_GetGroupMembers  (pfSysParameterSettings_GetGroupMembers != NULL)
	#define EXP_SysParameterSettings_GetGroupMembers  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetGroupMembers", (RTS_UINTPTR)SysParameterSettings_GetGroupMembers, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetVersions(char * szOutput, int buflen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETVERSIONS) (char * szOutput, int buflen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETVERSIONS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetVersions
	#define EXT_SysParameterSettings_GetVersions
	#define GET_SysParameterSettings_GetVersions(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetVersions(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetVersions  FALSE
	#define EXP_SysParameterSettings_GetVersions  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetVersions
	#define EXT_SysParameterSettings_GetVersions
	#define GET_SysParameterSettings_GetVersions(fl)  CAL_CMGETAPI( "SysParameterSettings_GetVersions" ) 
	#define CAL_SysParameterSettings_GetVersions  SysParameterSettings_GetVersions
	#define CHK_SysParameterSettings_GetVersions  TRUE
	#define EXP_SysParameterSettings_GetVersions  CAL_CMEXPAPI( "SysParameterSettings_GetVersions" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetVersions
	#define EXT_SysParameterSettings_GetVersions
	#define GET_SysParameterSettings_GetVersions(fl)  CAL_CMGETAPI( "SysParameterSettings_GetVersions" ) 
	#define CAL_SysParameterSettings_GetVersions  SysParameterSettings_GetVersions
	#define CHK_SysParameterSettings_GetVersions  TRUE
	#define EXP_SysParameterSettings_GetVersions  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetVersions", (RTS_UINTPTR)SysParameterSettings_GetVersions, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetVersions
	#define EXT_SysParameterSettingsSysParameterSettings_GetVersions
	#define GET_SysParameterSettingsSysParameterSettings_GetVersions  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetVersions pISysParameterSettings->ISysParameterSettings_GetVersions
	#define CHK_SysParameterSettingsSysParameterSettings_GetVersions (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetVersions  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetVersions
	#define EXT_SysParameterSettings_GetVersions
	#define GET_SysParameterSettings_GetVersions(fl)  CAL_CMGETAPI( "SysParameterSettings_GetVersions" ) 
	#define CAL_SysParameterSettings_GetVersions pISysParameterSettings->ISysParameterSettings_GetVersions
	#define CHK_SysParameterSettings_GetVersions (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetVersions  CAL_CMEXPAPI( "SysParameterSettings_GetVersions" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetVersions  PFSYSPARAMETERSETTINGS_GETVERSIONS pfSysParameterSettings_GetVersions;
	#define EXT_SysParameterSettings_GetVersions  extern PFSYSPARAMETERSETTINGS_GETVERSIONS pfSysParameterSettings_GetVersions;
	#define GET_SysParameterSettings_GetVersions(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetVersions", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetVersions, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetVersions  pfSysParameterSettings_GetVersions
	#define CHK_SysParameterSettings_GetVersions  (pfSysParameterSettings_GetVersions != NULL)
	#define EXP_SysParameterSettings_GetVersions  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetVersions", (RTS_UINTPTR)SysParameterSettings_GetVersions, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMysqlStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMYSQLSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMYSQLSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMysqlStatus
	#define EXT_SysParameterSettings_GetMysqlStatus
	#define GET_SysParameterSettings_GetMysqlStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMysqlStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMysqlStatus  FALSE
	#define EXP_SysParameterSettings_GetMysqlStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMysqlStatus
	#define EXT_SysParameterSettings_GetMysqlStatus
	#define GET_SysParameterSettings_GetMysqlStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlStatus" ) 
	#define CAL_SysParameterSettings_GetMysqlStatus  SysParameterSettings_GetMysqlStatus
	#define CHK_SysParameterSettings_GetMysqlStatus  TRUE
	#define EXP_SysParameterSettings_GetMysqlStatus  CAL_CMEXPAPI( "SysParameterSettings_GetMysqlStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMysqlStatus
	#define EXT_SysParameterSettings_GetMysqlStatus
	#define GET_SysParameterSettings_GetMysqlStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlStatus" ) 
	#define CAL_SysParameterSettings_GetMysqlStatus  SysParameterSettings_GetMysqlStatus
	#define CHK_SysParameterSettings_GetMysqlStatus  TRUE
	#define EXP_SysParameterSettings_GetMysqlStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMysqlStatus", (RTS_UINTPTR)SysParameterSettings_GetMysqlStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMysqlStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetMysqlStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetMysqlStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMysqlStatus pISysParameterSettings->ISysParameterSettings_GetMysqlStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetMysqlStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMysqlStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMysqlStatus
	#define EXT_SysParameterSettings_GetMysqlStatus
	#define GET_SysParameterSettings_GetMysqlStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlStatus" ) 
	#define CAL_SysParameterSettings_GetMysqlStatus pISysParameterSettings->ISysParameterSettings_GetMysqlStatus
	#define CHK_SysParameterSettings_GetMysqlStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMysqlStatus  CAL_CMEXPAPI( "SysParameterSettings_GetMysqlStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMysqlStatus  PFSYSPARAMETERSETTINGS_GETMYSQLSTATUS pfSysParameterSettings_GetMysqlStatus;
	#define EXT_SysParameterSettings_GetMysqlStatus  extern PFSYSPARAMETERSETTINGS_GETMYSQLSTATUS pfSysParameterSettings_GetMysqlStatus;
	#define GET_SysParameterSettings_GetMysqlStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMysqlStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMysqlStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMysqlStatus  pfSysParameterSettings_GetMysqlStatus
	#define CHK_SysParameterSettings_GetMysqlStatus  (pfSysParameterSettings_GetMysqlStatus != NULL)
	#define EXP_SysParameterSettings_GetMysqlStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMysqlStatus", (RTS_UINTPTR)SysParameterSettings_GetMysqlStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetMysqlStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETMYSQLSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETMYSQLSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetMysqlStatus
	#define EXT_SysParameterSettings_SetMysqlStatus
	#define GET_SysParameterSettings_SetMysqlStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetMysqlStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetMysqlStatus  FALSE
	#define EXP_SysParameterSettings_SetMysqlStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetMysqlStatus
	#define EXT_SysParameterSettings_SetMysqlStatus
	#define GET_SysParameterSettings_SetMysqlStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlStatus" ) 
	#define CAL_SysParameterSettings_SetMysqlStatus  SysParameterSettings_SetMysqlStatus
	#define CHK_SysParameterSettings_SetMysqlStatus  TRUE
	#define EXP_SysParameterSettings_SetMysqlStatus  CAL_CMEXPAPI( "SysParameterSettings_SetMysqlStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetMysqlStatus
	#define EXT_SysParameterSettings_SetMysqlStatus
	#define GET_SysParameterSettings_SetMysqlStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlStatus" ) 
	#define CAL_SysParameterSettings_SetMysqlStatus  SysParameterSettings_SetMysqlStatus
	#define CHK_SysParameterSettings_SetMysqlStatus  TRUE
	#define EXP_SysParameterSettings_SetMysqlStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMysqlStatus", (RTS_UINTPTR)SysParameterSettings_SetMysqlStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetMysqlStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetMysqlStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetMysqlStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetMysqlStatus pISysParameterSettings->ISysParameterSettings_SetMysqlStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetMysqlStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetMysqlStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetMysqlStatus
	#define EXT_SysParameterSettings_SetMysqlStatus
	#define GET_SysParameterSettings_SetMysqlStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlStatus" ) 
	#define CAL_SysParameterSettings_SetMysqlStatus pISysParameterSettings->ISysParameterSettings_SetMysqlStatus
	#define CHK_SysParameterSettings_SetMysqlStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetMysqlStatus  CAL_CMEXPAPI( "SysParameterSettings_SetMysqlStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetMysqlStatus  PFSYSPARAMETERSETTINGS_SETMYSQLSTATUS pfSysParameterSettings_SetMysqlStatus;
	#define EXT_SysParameterSettings_SetMysqlStatus  extern PFSYSPARAMETERSETTINGS_SETMYSQLSTATUS pfSysParameterSettings_SetMysqlStatus;
	#define GET_SysParameterSettings_SetMysqlStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetMysqlStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetMysqlStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetMysqlStatus  pfSysParameterSettings_SetMysqlStatus
	#define CHK_SysParameterSettings_SetMysqlStatus  (pfSysParameterSettings_SetMysqlStatus != NULL)
	#define EXP_SysParameterSettings_SetMysqlStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMysqlStatus", (RTS_UINTPTR)SysParameterSettings_SetMysqlStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetLighttpdStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETLIGHTTPDSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETLIGHTTPDSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetLighttpdStatus
	#define EXT_SysParameterSettings_GetLighttpdStatus
	#define GET_SysParameterSettings_GetLighttpdStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetLighttpdStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetLighttpdStatus  FALSE
	#define EXP_SysParameterSettings_GetLighttpdStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetLighttpdStatus
	#define EXT_SysParameterSettings_GetLighttpdStatus
	#define GET_SysParameterSettings_GetLighttpdStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLighttpdStatus" ) 
	#define CAL_SysParameterSettings_GetLighttpdStatus  SysParameterSettings_GetLighttpdStatus
	#define CHK_SysParameterSettings_GetLighttpdStatus  TRUE
	#define EXP_SysParameterSettings_GetLighttpdStatus  CAL_CMEXPAPI( "SysParameterSettings_GetLighttpdStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetLighttpdStatus
	#define EXT_SysParameterSettings_GetLighttpdStatus
	#define GET_SysParameterSettings_GetLighttpdStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLighttpdStatus" ) 
	#define CAL_SysParameterSettings_GetLighttpdStatus  SysParameterSettings_GetLighttpdStatus
	#define CHK_SysParameterSettings_GetLighttpdStatus  TRUE
	#define EXP_SysParameterSettings_GetLighttpdStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetLighttpdStatus", (RTS_UINTPTR)SysParameterSettings_GetLighttpdStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetLighttpdStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetLighttpdStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetLighttpdStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetLighttpdStatus pISysParameterSettings->ISysParameterSettings_GetLighttpdStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetLighttpdStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetLighttpdStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetLighttpdStatus
	#define EXT_SysParameterSettings_GetLighttpdStatus
	#define GET_SysParameterSettings_GetLighttpdStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLighttpdStatus" ) 
	#define CAL_SysParameterSettings_GetLighttpdStatus pISysParameterSettings->ISysParameterSettings_GetLighttpdStatus
	#define CHK_SysParameterSettings_GetLighttpdStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetLighttpdStatus  CAL_CMEXPAPI( "SysParameterSettings_GetLighttpdStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetLighttpdStatus  PFSYSPARAMETERSETTINGS_GETLIGHTTPDSTATUS pfSysParameterSettings_GetLighttpdStatus;
	#define EXT_SysParameterSettings_GetLighttpdStatus  extern PFSYSPARAMETERSETTINGS_GETLIGHTTPDSTATUS pfSysParameterSettings_GetLighttpdStatus;
	#define GET_SysParameterSettings_GetLighttpdStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetLighttpdStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetLighttpdStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetLighttpdStatus  pfSysParameterSettings_GetLighttpdStatus
	#define CHK_SysParameterSettings_GetLighttpdStatus  (pfSysParameterSettings_GetLighttpdStatus != NULL)
	#define EXP_SysParameterSettings_GetLighttpdStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetLighttpdStatus", (RTS_UINTPTR)SysParameterSettings_GetLighttpdStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetLighttpdStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETLIGHTTPDSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETLIGHTTPDSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetLighttpdStatus
	#define EXT_SysParameterSettings_SetLighttpdStatus
	#define GET_SysParameterSettings_SetLighttpdStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetLighttpdStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetLighttpdStatus  FALSE
	#define EXP_SysParameterSettings_SetLighttpdStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetLighttpdStatus
	#define EXT_SysParameterSettings_SetLighttpdStatus
	#define GET_SysParameterSettings_SetLighttpdStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLighttpdStatus" ) 
	#define CAL_SysParameterSettings_SetLighttpdStatus  SysParameterSettings_SetLighttpdStatus
	#define CHK_SysParameterSettings_SetLighttpdStatus  TRUE
	#define EXP_SysParameterSettings_SetLighttpdStatus  CAL_CMEXPAPI( "SysParameterSettings_SetLighttpdStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetLighttpdStatus
	#define EXT_SysParameterSettings_SetLighttpdStatus
	#define GET_SysParameterSettings_SetLighttpdStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLighttpdStatus" ) 
	#define CAL_SysParameterSettings_SetLighttpdStatus  SysParameterSettings_SetLighttpdStatus
	#define CHK_SysParameterSettings_SetLighttpdStatus  TRUE
	#define EXP_SysParameterSettings_SetLighttpdStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetLighttpdStatus", (RTS_UINTPTR)SysParameterSettings_SetLighttpdStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetLighttpdStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetLighttpdStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetLighttpdStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetLighttpdStatus pISysParameterSettings->ISysParameterSettings_SetLighttpdStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetLighttpdStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetLighttpdStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetLighttpdStatus
	#define EXT_SysParameterSettings_SetLighttpdStatus
	#define GET_SysParameterSettings_SetLighttpdStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLighttpdStatus" ) 
	#define CAL_SysParameterSettings_SetLighttpdStatus pISysParameterSettings->ISysParameterSettings_SetLighttpdStatus
	#define CHK_SysParameterSettings_SetLighttpdStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetLighttpdStatus  CAL_CMEXPAPI( "SysParameterSettings_SetLighttpdStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetLighttpdStatus  PFSYSPARAMETERSETTINGS_SETLIGHTTPDSTATUS pfSysParameterSettings_SetLighttpdStatus;
	#define EXT_SysParameterSettings_SetLighttpdStatus  extern PFSYSPARAMETERSETTINGS_SETLIGHTTPDSTATUS pfSysParameterSettings_SetLighttpdStatus;
	#define GET_SysParameterSettings_SetLighttpdStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetLighttpdStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetLighttpdStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetLighttpdStatus  pfSysParameterSettings_SetLighttpdStatus
	#define CHK_SysParameterSettings_SetLighttpdStatus  (pfSysParameterSettings_SetLighttpdStatus != NULL)
	#define EXP_SysParameterSettings_SetLighttpdStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetLighttpdStatus", (RTS_UINTPTR)SysParameterSettings_SetLighttpdStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetLighttpdPort(RTS_UI32 *pport);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETLIGHTTPDPORT) (RTS_UI32 *pport);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETLIGHTTPDPORT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetLighttpdPort
	#define EXT_SysParameterSettings_GetLighttpdPort
	#define GET_SysParameterSettings_GetLighttpdPort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetLighttpdPort(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetLighttpdPort  FALSE
	#define EXP_SysParameterSettings_GetLighttpdPort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetLighttpdPort
	#define EXT_SysParameterSettings_GetLighttpdPort
	#define GET_SysParameterSettings_GetLighttpdPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLighttpdPort" ) 
	#define CAL_SysParameterSettings_GetLighttpdPort  SysParameterSettings_GetLighttpdPort
	#define CHK_SysParameterSettings_GetLighttpdPort  TRUE
	#define EXP_SysParameterSettings_GetLighttpdPort  CAL_CMEXPAPI( "SysParameterSettings_GetLighttpdPort" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetLighttpdPort
	#define EXT_SysParameterSettings_GetLighttpdPort
	#define GET_SysParameterSettings_GetLighttpdPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLighttpdPort" ) 
	#define CAL_SysParameterSettings_GetLighttpdPort  SysParameterSettings_GetLighttpdPort
	#define CHK_SysParameterSettings_GetLighttpdPort  TRUE
	#define EXP_SysParameterSettings_GetLighttpdPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetLighttpdPort", (RTS_UINTPTR)SysParameterSettings_GetLighttpdPort, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetLighttpdPort
	#define EXT_SysParameterSettingsSysParameterSettings_GetLighttpdPort
	#define GET_SysParameterSettingsSysParameterSettings_GetLighttpdPort  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetLighttpdPort pISysParameterSettings->ISysParameterSettings_GetLighttpdPort
	#define CHK_SysParameterSettingsSysParameterSettings_GetLighttpdPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetLighttpdPort  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetLighttpdPort
	#define EXT_SysParameterSettings_GetLighttpdPort
	#define GET_SysParameterSettings_GetLighttpdPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLighttpdPort" ) 
	#define CAL_SysParameterSettings_GetLighttpdPort pISysParameterSettings->ISysParameterSettings_GetLighttpdPort
	#define CHK_SysParameterSettings_GetLighttpdPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetLighttpdPort  CAL_CMEXPAPI( "SysParameterSettings_GetLighttpdPort" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetLighttpdPort  PFSYSPARAMETERSETTINGS_GETLIGHTTPDPORT pfSysParameterSettings_GetLighttpdPort;
	#define EXT_SysParameterSettings_GetLighttpdPort  extern PFSYSPARAMETERSETTINGS_GETLIGHTTPDPORT pfSysParameterSettings_GetLighttpdPort;
	#define GET_SysParameterSettings_GetLighttpdPort(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetLighttpdPort", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetLighttpdPort, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetLighttpdPort  pfSysParameterSettings_GetLighttpdPort
	#define CHK_SysParameterSettings_GetLighttpdPort  (pfSysParameterSettings_GetLighttpdPort != NULL)
	#define EXP_SysParameterSettings_GetLighttpdPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetLighttpdPort", (RTS_UINTPTR)SysParameterSettings_GetLighttpdPort, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetLighttpdPort(RTS_UI32 port);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETLIGHTTPDPORT) (RTS_UI32 port);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETLIGHTTPDPORT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetLighttpdPort
	#define EXT_SysParameterSettings_SetLighttpdPort
	#define GET_SysParameterSettings_SetLighttpdPort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetLighttpdPort(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetLighttpdPort  FALSE
	#define EXP_SysParameterSettings_SetLighttpdPort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetLighttpdPort
	#define EXT_SysParameterSettings_SetLighttpdPort
	#define GET_SysParameterSettings_SetLighttpdPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLighttpdPort" ) 
	#define CAL_SysParameterSettings_SetLighttpdPort  SysParameterSettings_SetLighttpdPort
	#define CHK_SysParameterSettings_SetLighttpdPort  TRUE
	#define EXP_SysParameterSettings_SetLighttpdPort  CAL_CMEXPAPI( "SysParameterSettings_SetLighttpdPort" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetLighttpdPort
	#define EXT_SysParameterSettings_SetLighttpdPort
	#define GET_SysParameterSettings_SetLighttpdPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLighttpdPort" ) 
	#define CAL_SysParameterSettings_SetLighttpdPort  SysParameterSettings_SetLighttpdPort
	#define CHK_SysParameterSettings_SetLighttpdPort  TRUE
	#define EXP_SysParameterSettings_SetLighttpdPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetLighttpdPort", (RTS_UINTPTR)SysParameterSettings_SetLighttpdPort, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetLighttpdPort
	#define EXT_SysParameterSettingsSysParameterSettings_SetLighttpdPort
	#define GET_SysParameterSettingsSysParameterSettings_SetLighttpdPort  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetLighttpdPort pISysParameterSettings->ISysParameterSettings_SetLighttpdPort
	#define CHK_SysParameterSettingsSysParameterSettings_SetLighttpdPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetLighttpdPort  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetLighttpdPort
	#define EXT_SysParameterSettings_SetLighttpdPort
	#define GET_SysParameterSettings_SetLighttpdPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLighttpdPort" ) 
	#define CAL_SysParameterSettings_SetLighttpdPort pISysParameterSettings->ISysParameterSettings_SetLighttpdPort
	#define CHK_SysParameterSettings_SetLighttpdPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetLighttpdPort  CAL_CMEXPAPI( "SysParameterSettings_SetLighttpdPort" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetLighttpdPort  PFSYSPARAMETERSETTINGS_SETLIGHTTPDPORT pfSysParameterSettings_SetLighttpdPort;
	#define EXT_SysParameterSettings_SetLighttpdPort  extern PFSYSPARAMETERSETTINGS_SETLIGHTTPDPORT pfSysParameterSettings_SetLighttpdPort;
	#define GET_SysParameterSettings_SetLighttpdPort(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetLighttpdPort", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetLighttpdPort, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetLighttpdPort  pfSysParameterSettings_SetLighttpdPort
	#define CHK_SysParameterSettings_SetLighttpdPort  (pfSysParameterSettings_SetLighttpdPort != NULL)
	#define EXP_SysParameterSettings_SetLighttpdPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetLighttpdPort", (RTS_UINTPTR)SysParameterSettings_SetLighttpdPort, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMysqlDbDir(char * pszDir, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMYSQLDBDIR) (char * pszDir, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMYSQLDBDIR_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMysqlDbDir
	#define EXT_SysParameterSettings_GetMysqlDbDir
	#define GET_SysParameterSettings_GetMysqlDbDir(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMysqlDbDir(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMysqlDbDir  FALSE
	#define EXP_SysParameterSettings_GetMysqlDbDir  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMysqlDbDir
	#define EXT_SysParameterSettings_GetMysqlDbDir
	#define GET_SysParameterSettings_GetMysqlDbDir(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlDbDir" ) 
	#define CAL_SysParameterSettings_GetMysqlDbDir  SysParameterSettings_GetMysqlDbDir
	#define CHK_SysParameterSettings_GetMysqlDbDir  TRUE
	#define EXP_SysParameterSettings_GetMysqlDbDir  CAL_CMEXPAPI( "SysParameterSettings_GetMysqlDbDir" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMysqlDbDir
	#define EXT_SysParameterSettings_GetMysqlDbDir
	#define GET_SysParameterSettings_GetMysqlDbDir(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlDbDir" ) 
	#define CAL_SysParameterSettings_GetMysqlDbDir  SysParameterSettings_GetMysqlDbDir
	#define CHK_SysParameterSettings_GetMysqlDbDir  TRUE
	#define EXP_SysParameterSettings_GetMysqlDbDir  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMysqlDbDir", (RTS_UINTPTR)SysParameterSettings_GetMysqlDbDir, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMysqlDbDir
	#define EXT_SysParameterSettingsSysParameterSettings_GetMysqlDbDir
	#define GET_SysParameterSettingsSysParameterSettings_GetMysqlDbDir  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMysqlDbDir pISysParameterSettings->ISysParameterSettings_GetMysqlDbDir
	#define CHK_SysParameterSettingsSysParameterSettings_GetMysqlDbDir (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMysqlDbDir  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMysqlDbDir
	#define EXT_SysParameterSettings_GetMysqlDbDir
	#define GET_SysParameterSettings_GetMysqlDbDir(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlDbDir" ) 
	#define CAL_SysParameterSettings_GetMysqlDbDir pISysParameterSettings->ISysParameterSettings_GetMysqlDbDir
	#define CHK_SysParameterSettings_GetMysqlDbDir (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMysqlDbDir  CAL_CMEXPAPI( "SysParameterSettings_GetMysqlDbDir" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMysqlDbDir  PFSYSPARAMETERSETTINGS_GETMYSQLDBDIR pfSysParameterSettings_GetMysqlDbDir;
	#define EXT_SysParameterSettings_GetMysqlDbDir  extern PFSYSPARAMETERSETTINGS_GETMYSQLDBDIR pfSysParameterSettings_GetMysqlDbDir;
	#define GET_SysParameterSettings_GetMysqlDbDir(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMysqlDbDir", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMysqlDbDir, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMysqlDbDir  pfSysParameterSettings_GetMysqlDbDir
	#define CHK_SysParameterSettings_GetMysqlDbDir  (pfSysParameterSettings_GetMysqlDbDir != NULL)
	#define EXP_SysParameterSettings_GetMysqlDbDir  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMysqlDbDir", (RTS_UINTPTR)SysParameterSettings_GetMysqlDbDir, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetMysqlDbDir(char * pszDir);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETMYSQLDBDIR) (char * pszDir);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETMYSQLDBDIR_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetMysqlDbDir
	#define EXT_SysParameterSettings_SetMysqlDbDir
	#define GET_SysParameterSettings_SetMysqlDbDir(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetMysqlDbDir(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetMysqlDbDir  FALSE
	#define EXP_SysParameterSettings_SetMysqlDbDir  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetMysqlDbDir
	#define EXT_SysParameterSettings_SetMysqlDbDir
	#define GET_SysParameterSettings_SetMysqlDbDir(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlDbDir" ) 
	#define CAL_SysParameterSettings_SetMysqlDbDir  SysParameterSettings_SetMysqlDbDir
	#define CHK_SysParameterSettings_SetMysqlDbDir  TRUE
	#define EXP_SysParameterSettings_SetMysqlDbDir  CAL_CMEXPAPI( "SysParameterSettings_SetMysqlDbDir" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetMysqlDbDir
	#define EXT_SysParameterSettings_SetMysqlDbDir
	#define GET_SysParameterSettings_SetMysqlDbDir(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlDbDir" ) 
	#define CAL_SysParameterSettings_SetMysqlDbDir  SysParameterSettings_SetMysqlDbDir
	#define CHK_SysParameterSettings_SetMysqlDbDir  TRUE
	#define EXP_SysParameterSettings_SetMysqlDbDir  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMysqlDbDir", (RTS_UINTPTR)SysParameterSettings_SetMysqlDbDir, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetMysqlDbDir
	#define EXT_SysParameterSettingsSysParameterSettings_SetMysqlDbDir
	#define GET_SysParameterSettingsSysParameterSettings_SetMysqlDbDir  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetMysqlDbDir pISysParameterSettings->ISysParameterSettings_SetMysqlDbDir
	#define CHK_SysParameterSettingsSysParameterSettings_SetMysqlDbDir (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetMysqlDbDir  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetMysqlDbDir
	#define EXT_SysParameterSettings_SetMysqlDbDir
	#define GET_SysParameterSettings_SetMysqlDbDir(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlDbDir" ) 
	#define CAL_SysParameterSettings_SetMysqlDbDir pISysParameterSettings->ISysParameterSettings_SetMysqlDbDir
	#define CHK_SysParameterSettings_SetMysqlDbDir (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetMysqlDbDir  CAL_CMEXPAPI( "SysParameterSettings_SetMysqlDbDir" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetMysqlDbDir  PFSYSPARAMETERSETTINGS_SETMYSQLDBDIR pfSysParameterSettings_SetMysqlDbDir;
	#define EXT_SysParameterSettings_SetMysqlDbDir  extern PFSYSPARAMETERSETTINGS_SETMYSQLDBDIR pfSysParameterSettings_SetMysqlDbDir;
	#define GET_SysParameterSettings_SetMysqlDbDir(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetMysqlDbDir", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetMysqlDbDir, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetMysqlDbDir  pfSysParameterSettings_SetMysqlDbDir
	#define CHK_SysParameterSettings_SetMysqlDbDir  (pfSysParameterSettings_SetMysqlDbDir != NULL)
	#define EXP_SysParameterSettings_SetMysqlDbDir  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMysqlDbDir", (RTS_UINTPTR)SysParameterSettings_SetMysqlDbDir, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetTelnetStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETTELNETSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETTELNETSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetTelnetStatus
	#define EXT_SysParameterSettings_GetTelnetStatus
	#define GET_SysParameterSettings_GetTelnetStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetTelnetStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetTelnetStatus  FALSE
	#define EXP_SysParameterSettings_GetTelnetStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetTelnetStatus
	#define EXT_SysParameterSettings_GetTelnetStatus
	#define GET_SysParameterSettings_GetTelnetStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTelnetStatus" ) 
	#define CAL_SysParameterSettings_GetTelnetStatus  SysParameterSettings_GetTelnetStatus
	#define CHK_SysParameterSettings_GetTelnetStatus  TRUE
	#define EXP_SysParameterSettings_GetTelnetStatus  CAL_CMEXPAPI( "SysParameterSettings_GetTelnetStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetTelnetStatus
	#define EXT_SysParameterSettings_GetTelnetStatus
	#define GET_SysParameterSettings_GetTelnetStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTelnetStatus" ) 
	#define CAL_SysParameterSettings_GetTelnetStatus  SysParameterSettings_GetTelnetStatus
	#define CHK_SysParameterSettings_GetTelnetStatus  TRUE
	#define EXP_SysParameterSettings_GetTelnetStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetTelnetStatus", (RTS_UINTPTR)SysParameterSettings_GetTelnetStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetTelnetStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetTelnetStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetTelnetStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetTelnetStatus pISysParameterSettings->ISysParameterSettings_GetTelnetStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetTelnetStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetTelnetStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetTelnetStatus
	#define EXT_SysParameterSettings_GetTelnetStatus
	#define GET_SysParameterSettings_GetTelnetStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetTelnetStatus" ) 
	#define CAL_SysParameterSettings_GetTelnetStatus pISysParameterSettings->ISysParameterSettings_GetTelnetStatus
	#define CHK_SysParameterSettings_GetTelnetStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetTelnetStatus  CAL_CMEXPAPI( "SysParameterSettings_GetTelnetStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetTelnetStatus  PFSYSPARAMETERSETTINGS_GETTELNETSTATUS pfSysParameterSettings_GetTelnetStatus;
	#define EXT_SysParameterSettings_GetTelnetStatus  extern PFSYSPARAMETERSETTINGS_GETTELNETSTATUS pfSysParameterSettings_GetTelnetStatus;
	#define GET_SysParameterSettings_GetTelnetStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetTelnetStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetTelnetStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetTelnetStatus  pfSysParameterSettings_GetTelnetStatus
	#define CHK_SysParameterSettings_GetTelnetStatus  (pfSysParameterSettings_GetTelnetStatus != NULL)
	#define EXP_SysParameterSettings_GetTelnetStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetTelnetStatus", (RTS_UINTPTR)SysParameterSettings_GetTelnetStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetTelnetStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETTELNETSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETTELNETSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetTelnetStatus
	#define EXT_SysParameterSettings_SetTelnetStatus
	#define GET_SysParameterSettings_SetTelnetStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetTelnetStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetTelnetStatus  FALSE
	#define EXP_SysParameterSettings_SetTelnetStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetTelnetStatus
	#define EXT_SysParameterSettings_SetTelnetStatus
	#define GET_SysParameterSettings_SetTelnetStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTelnetStatus" ) 
	#define CAL_SysParameterSettings_SetTelnetStatus  SysParameterSettings_SetTelnetStatus
	#define CHK_SysParameterSettings_SetTelnetStatus  TRUE
	#define EXP_SysParameterSettings_SetTelnetStatus  CAL_CMEXPAPI( "SysParameterSettings_SetTelnetStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetTelnetStatus
	#define EXT_SysParameterSettings_SetTelnetStatus
	#define GET_SysParameterSettings_SetTelnetStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTelnetStatus" ) 
	#define CAL_SysParameterSettings_SetTelnetStatus  SysParameterSettings_SetTelnetStatus
	#define CHK_SysParameterSettings_SetTelnetStatus  TRUE
	#define EXP_SysParameterSettings_SetTelnetStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetTelnetStatus", (RTS_UINTPTR)SysParameterSettings_SetTelnetStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetTelnetStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetTelnetStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetTelnetStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetTelnetStatus pISysParameterSettings->ISysParameterSettings_SetTelnetStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetTelnetStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetTelnetStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetTelnetStatus
	#define EXT_SysParameterSettings_SetTelnetStatus
	#define GET_SysParameterSettings_SetTelnetStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetTelnetStatus" ) 
	#define CAL_SysParameterSettings_SetTelnetStatus pISysParameterSettings->ISysParameterSettings_SetTelnetStatus
	#define CHK_SysParameterSettings_SetTelnetStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetTelnetStatus  CAL_CMEXPAPI( "SysParameterSettings_SetTelnetStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetTelnetStatus  PFSYSPARAMETERSETTINGS_SETTELNETSTATUS pfSysParameterSettings_SetTelnetStatus;
	#define EXT_SysParameterSettings_SetTelnetStatus  extern PFSYSPARAMETERSETTINGS_SETTELNETSTATUS pfSysParameterSettings_SetTelnetStatus;
	#define GET_SysParameterSettings_SetTelnetStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetTelnetStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetTelnetStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetTelnetStatus  pfSysParameterSettings_SetTelnetStatus
	#define CHK_SysParameterSettings_SetTelnetStatus  (pfSysParameterSettings_SetTelnetStatus != NULL)
	#define EXP_SysParameterSettings_SetTelnetStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetTelnetStatus", (RTS_UINTPTR)SysParameterSettings_SetTelnetStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetSSHStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSSHSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSSHSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetSSHStatus
	#define EXT_SysParameterSettings_GetSSHStatus
	#define GET_SysParameterSettings_GetSSHStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetSSHStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetSSHStatus  FALSE
	#define EXP_SysParameterSettings_GetSSHStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetSSHStatus
	#define EXT_SysParameterSettings_GetSSHStatus
	#define GET_SysParameterSettings_GetSSHStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSSHStatus" ) 
	#define CAL_SysParameterSettings_GetSSHStatus  SysParameterSettings_GetSSHStatus
	#define CHK_SysParameterSettings_GetSSHStatus  TRUE
	#define EXP_SysParameterSettings_GetSSHStatus  CAL_CMEXPAPI( "SysParameterSettings_GetSSHStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetSSHStatus
	#define EXT_SysParameterSettings_GetSSHStatus
	#define GET_SysParameterSettings_GetSSHStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSSHStatus" ) 
	#define CAL_SysParameterSettings_GetSSHStatus  SysParameterSettings_GetSSHStatus
	#define CHK_SysParameterSettings_GetSSHStatus  TRUE
	#define EXP_SysParameterSettings_GetSSHStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSSHStatus", (RTS_UINTPTR)SysParameterSettings_GetSSHStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetSSHStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetSSHStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetSSHStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetSSHStatus pISysParameterSettings->ISysParameterSettings_GetSSHStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetSSHStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetSSHStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetSSHStatus
	#define EXT_SysParameterSettings_GetSSHStatus
	#define GET_SysParameterSettings_GetSSHStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSSHStatus" ) 
	#define CAL_SysParameterSettings_GetSSHStatus pISysParameterSettings->ISysParameterSettings_GetSSHStatus
	#define CHK_SysParameterSettings_GetSSHStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetSSHStatus  CAL_CMEXPAPI( "SysParameterSettings_GetSSHStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetSSHStatus  PFSYSPARAMETERSETTINGS_GETSSHSTATUS pfSysParameterSettings_GetSSHStatus;
	#define EXT_SysParameterSettings_GetSSHStatus  extern PFSYSPARAMETERSETTINGS_GETSSHSTATUS pfSysParameterSettings_GetSSHStatus;
	#define GET_SysParameterSettings_GetSSHStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetSSHStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetSSHStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetSSHStatus  pfSysParameterSettings_GetSSHStatus
	#define CHK_SysParameterSettings_GetSSHStatus  (pfSysParameterSettings_GetSSHStatus != NULL)
	#define EXP_SysParameterSettings_GetSSHStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSSHStatus", (RTS_UINTPTR)SysParameterSettings_GetSSHStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetSSHStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETSSHSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETSSHSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetSSHStatus
	#define EXT_SysParameterSettings_SetSSHStatus
	#define GET_SysParameterSettings_SetSSHStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetSSHStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetSSHStatus  FALSE
	#define EXP_SysParameterSettings_SetSSHStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetSSHStatus
	#define EXT_SysParameterSettings_SetSSHStatus
	#define GET_SysParameterSettings_SetSSHStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSSHStatus" ) 
	#define CAL_SysParameterSettings_SetSSHStatus  SysParameterSettings_SetSSHStatus
	#define CHK_SysParameterSettings_SetSSHStatus  TRUE
	#define EXP_SysParameterSettings_SetSSHStatus  CAL_CMEXPAPI( "SysParameterSettings_SetSSHStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetSSHStatus
	#define EXT_SysParameterSettings_SetSSHStatus
	#define GET_SysParameterSettings_SetSSHStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSSHStatus" ) 
	#define CAL_SysParameterSettings_SetSSHStatus  SysParameterSettings_SetSSHStatus
	#define CHK_SysParameterSettings_SetSSHStatus  TRUE
	#define EXP_SysParameterSettings_SetSSHStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetSSHStatus", (RTS_UINTPTR)SysParameterSettings_SetSSHStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetSSHStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetSSHStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetSSHStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetSSHStatus pISysParameterSettings->ISysParameterSettings_SetSSHStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetSSHStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetSSHStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetSSHStatus
	#define EXT_SysParameterSettings_SetSSHStatus
	#define GET_SysParameterSettings_SetSSHStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSSHStatus" ) 
	#define CAL_SysParameterSettings_SetSSHStatus pISysParameterSettings->ISysParameterSettings_SetSSHStatus
	#define CHK_SysParameterSettings_SetSSHStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetSSHStatus  CAL_CMEXPAPI( "SysParameterSettings_SetSSHStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetSSHStatus  PFSYSPARAMETERSETTINGS_SETSSHSTATUS pfSysParameterSettings_SetSSHStatus;
	#define EXT_SysParameterSettings_SetSSHStatus  extern PFSYSPARAMETERSETTINGS_SETSSHSTATUS pfSysParameterSettings_SetSSHStatus;
	#define GET_SysParameterSettings_SetSSHStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetSSHStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetSSHStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetSSHStatus  pfSysParameterSettings_SetSSHStatus
	#define CHK_SysParameterSettings_SetSSHStatus  (pfSysParameterSettings_SetSSHStatus != NULL)
	#define EXP_SysParameterSettings_SetSSHStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetSSHStatus", (RTS_UINTPTR)SysParameterSettings_SetSSHStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWatchdogStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWATCHDOGSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWATCHDOGSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWatchdogStatus
	#define EXT_SysParameterSettings_GetWatchdogStatus
	#define GET_SysParameterSettings_GetWatchdogStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWatchdogStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWatchdogStatus  FALSE
	#define EXP_SysParameterSettings_GetWatchdogStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWatchdogStatus
	#define EXT_SysParameterSettings_GetWatchdogStatus
	#define GET_SysParameterSettings_GetWatchdogStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogStatus" ) 
	#define CAL_SysParameterSettings_GetWatchdogStatus  SysParameterSettings_GetWatchdogStatus
	#define CHK_SysParameterSettings_GetWatchdogStatus  TRUE
	#define EXP_SysParameterSettings_GetWatchdogStatus  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWatchdogStatus
	#define EXT_SysParameterSettings_GetWatchdogStatus
	#define GET_SysParameterSettings_GetWatchdogStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogStatus" ) 
	#define CAL_SysParameterSettings_GetWatchdogStatus  SysParameterSettings_GetWatchdogStatus
	#define CHK_SysParameterSettings_GetWatchdogStatus  TRUE
	#define EXP_SysParameterSettings_GetWatchdogStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogStatus", (RTS_UINTPTR)SysParameterSettings_GetWatchdogStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWatchdogStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetWatchdogStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetWatchdogStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWatchdogStatus pISysParameterSettings->ISysParameterSettings_GetWatchdogStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetWatchdogStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWatchdogStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWatchdogStatus
	#define EXT_SysParameterSettings_GetWatchdogStatus
	#define GET_SysParameterSettings_GetWatchdogStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogStatus" ) 
	#define CAL_SysParameterSettings_GetWatchdogStatus pISysParameterSettings->ISysParameterSettings_GetWatchdogStatus
	#define CHK_SysParameterSettings_GetWatchdogStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWatchdogStatus  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWatchdogStatus  PFSYSPARAMETERSETTINGS_GETWATCHDOGSTATUS pfSysParameterSettings_GetWatchdogStatus;
	#define EXT_SysParameterSettings_GetWatchdogStatus  extern PFSYSPARAMETERSETTINGS_GETWATCHDOGSTATUS pfSysParameterSettings_GetWatchdogStatus;
	#define GET_SysParameterSettings_GetWatchdogStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWatchdogStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWatchdogStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWatchdogStatus  pfSysParameterSettings_GetWatchdogStatus
	#define CHK_SysParameterSettings_GetWatchdogStatus  (pfSysParameterSettings_GetWatchdogStatus != NULL)
	#define EXP_SysParameterSettings_GetWatchdogStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogStatus", (RTS_UINTPTR)SysParameterSettings_GetWatchdogStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWatchdogStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWATCHDOGSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWATCHDOGSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWatchdogStatus
	#define EXT_SysParameterSettings_SetWatchdogStatus
	#define GET_SysParameterSettings_SetWatchdogStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWatchdogStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWatchdogStatus  FALSE
	#define EXP_SysParameterSettings_SetWatchdogStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWatchdogStatus
	#define EXT_SysParameterSettings_SetWatchdogStatus
	#define GET_SysParameterSettings_SetWatchdogStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWatchdogStatus" ) 
	#define CAL_SysParameterSettings_SetWatchdogStatus  SysParameterSettings_SetWatchdogStatus
	#define CHK_SysParameterSettings_SetWatchdogStatus  TRUE
	#define EXP_SysParameterSettings_SetWatchdogStatus  CAL_CMEXPAPI( "SysParameterSettings_SetWatchdogStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWatchdogStatus
	#define EXT_SysParameterSettings_SetWatchdogStatus
	#define GET_SysParameterSettings_SetWatchdogStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWatchdogStatus" ) 
	#define CAL_SysParameterSettings_SetWatchdogStatus  SysParameterSettings_SetWatchdogStatus
	#define CHK_SysParameterSettings_SetWatchdogStatus  TRUE
	#define EXP_SysParameterSettings_SetWatchdogStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWatchdogStatus", (RTS_UINTPTR)SysParameterSettings_SetWatchdogStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWatchdogStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetWatchdogStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetWatchdogStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWatchdogStatus pISysParameterSettings->ISysParameterSettings_SetWatchdogStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetWatchdogStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWatchdogStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWatchdogStatus
	#define EXT_SysParameterSettings_SetWatchdogStatus
	#define GET_SysParameterSettings_SetWatchdogStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWatchdogStatus" ) 
	#define CAL_SysParameterSettings_SetWatchdogStatus pISysParameterSettings->ISysParameterSettings_SetWatchdogStatus
	#define CHK_SysParameterSettings_SetWatchdogStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWatchdogStatus  CAL_CMEXPAPI( "SysParameterSettings_SetWatchdogStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWatchdogStatus  PFSYSPARAMETERSETTINGS_SETWATCHDOGSTATUS pfSysParameterSettings_SetWatchdogStatus;
	#define EXT_SysParameterSettings_SetWatchdogStatus  extern PFSYSPARAMETERSETTINGS_SETWATCHDOGSTATUS pfSysParameterSettings_SetWatchdogStatus;
	#define GET_SysParameterSettings_SetWatchdogStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWatchdogStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWatchdogStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWatchdogStatus  pfSysParameterSettings_SetWatchdogStatus
	#define CHK_SysParameterSettings_SetWatchdogStatus  (pfSysParameterSettings_SetWatchdogStatus != NULL)
	#define EXP_SysParameterSettings_SetWatchdogStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWatchdogStatus", (RTS_UINTPTR)SysParameterSettings_SetWatchdogStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWatchdogTime(RTS_UI32 *ptimeout);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWATCHDOGTIME) (RTS_UI32 *ptimeout);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWATCHDOGTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWatchdogTime
	#define EXT_SysParameterSettings_GetWatchdogTime
	#define GET_SysParameterSettings_GetWatchdogTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWatchdogTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWatchdogTime  FALSE
	#define EXP_SysParameterSettings_GetWatchdogTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWatchdogTime
	#define EXT_SysParameterSettings_GetWatchdogTime
	#define GET_SysParameterSettings_GetWatchdogTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTime" ) 
	#define CAL_SysParameterSettings_GetWatchdogTime  SysParameterSettings_GetWatchdogTime
	#define CHK_SysParameterSettings_GetWatchdogTime  TRUE
	#define EXP_SysParameterSettings_GetWatchdogTime  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWatchdogTime
	#define EXT_SysParameterSettings_GetWatchdogTime
	#define GET_SysParameterSettings_GetWatchdogTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTime" ) 
	#define CAL_SysParameterSettings_GetWatchdogTime  SysParameterSettings_GetWatchdogTime
	#define CHK_SysParameterSettings_GetWatchdogTime  TRUE
	#define EXP_SysParameterSettings_GetWatchdogTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogTime", (RTS_UINTPTR)SysParameterSettings_GetWatchdogTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWatchdogTime
	#define EXT_SysParameterSettingsSysParameterSettings_GetWatchdogTime
	#define GET_SysParameterSettingsSysParameterSettings_GetWatchdogTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWatchdogTime pISysParameterSettings->ISysParameterSettings_GetWatchdogTime
	#define CHK_SysParameterSettingsSysParameterSettings_GetWatchdogTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWatchdogTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWatchdogTime
	#define EXT_SysParameterSettings_GetWatchdogTime
	#define GET_SysParameterSettings_GetWatchdogTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTime" ) 
	#define CAL_SysParameterSettings_GetWatchdogTime pISysParameterSettings->ISysParameterSettings_GetWatchdogTime
	#define CHK_SysParameterSettings_GetWatchdogTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWatchdogTime  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWatchdogTime  PFSYSPARAMETERSETTINGS_GETWATCHDOGTIME pfSysParameterSettings_GetWatchdogTime;
	#define EXT_SysParameterSettings_GetWatchdogTime  extern PFSYSPARAMETERSETTINGS_GETWATCHDOGTIME pfSysParameterSettings_GetWatchdogTime;
	#define GET_SysParameterSettings_GetWatchdogTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWatchdogTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWatchdogTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWatchdogTime  pfSysParameterSettings_GetWatchdogTime
	#define CHK_SysParameterSettings_GetWatchdogTime  (pfSysParameterSettings_GetWatchdogTime != NULL)
	#define EXP_SysParameterSettings_GetWatchdogTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogTime", (RTS_UINTPTR)SysParameterSettings_GetWatchdogTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWatchdogTime(RTS_UI32 timeout);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWATCHDOGTIME) (RTS_UI32 timeout);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWATCHDOGTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWatchdogTime
	#define EXT_SysParameterSettings_SetWatchdogTime
	#define GET_SysParameterSettings_SetWatchdogTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWatchdogTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWatchdogTime  FALSE
	#define EXP_SysParameterSettings_SetWatchdogTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWatchdogTime
	#define EXT_SysParameterSettings_SetWatchdogTime
	#define GET_SysParameterSettings_SetWatchdogTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWatchdogTime" ) 
	#define CAL_SysParameterSettings_SetWatchdogTime  SysParameterSettings_SetWatchdogTime
	#define CHK_SysParameterSettings_SetWatchdogTime  TRUE
	#define EXP_SysParameterSettings_SetWatchdogTime  CAL_CMEXPAPI( "SysParameterSettings_SetWatchdogTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWatchdogTime
	#define EXT_SysParameterSettings_SetWatchdogTime
	#define GET_SysParameterSettings_SetWatchdogTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWatchdogTime" ) 
	#define CAL_SysParameterSettings_SetWatchdogTime  SysParameterSettings_SetWatchdogTime
	#define CHK_SysParameterSettings_SetWatchdogTime  TRUE
	#define EXP_SysParameterSettings_SetWatchdogTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWatchdogTime", (RTS_UINTPTR)SysParameterSettings_SetWatchdogTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWatchdogTime
	#define EXT_SysParameterSettingsSysParameterSettings_SetWatchdogTime
	#define GET_SysParameterSettingsSysParameterSettings_SetWatchdogTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWatchdogTime pISysParameterSettings->ISysParameterSettings_SetWatchdogTime
	#define CHK_SysParameterSettingsSysParameterSettings_SetWatchdogTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWatchdogTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWatchdogTime
	#define EXT_SysParameterSettings_SetWatchdogTime
	#define GET_SysParameterSettings_SetWatchdogTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWatchdogTime" ) 
	#define CAL_SysParameterSettings_SetWatchdogTime pISysParameterSettings->ISysParameterSettings_SetWatchdogTime
	#define CHK_SysParameterSettings_SetWatchdogTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWatchdogTime  CAL_CMEXPAPI( "SysParameterSettings_SetWatchdogTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWatchdogTime  PFSYSPARAMETERSETTINGS_SETWATCHDOGTIME pfSysParameterSettings_SetWatchdogTime;
	#define EXT_SysParameterSettings_SetWatchdogTime  extern PFSYSPARAMETERSETTINGS_SETWATCHDOGTIME pfSysParameterSettings_SetWatchdogTime;
	#define GET_SysParameterSettings_SetWatchdogTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWatchdogTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWatchdogTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWatchdogTime  pfSysParameterSettings_SetWatchdogTime
	#define CHK_SysParameterSettings_SetWatchdogTime  (pfSysParameterSettings_SetWatchdogTime != NULL)
	#define EXP_SysParameterSettings_SetWatchdogTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWatchdogTime", (RTS_UINTPTR)SysParameterSettings_SetWatchdogTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWatchdogTimeMs(RTS_I32 *pStatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMS) (RTS_I32 *pStatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWATCHDOGTIMEMS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWatchdogTimeMs
	#define EXT_SysParameterSettings_GetWatchdogTimeMs
	#define GET_SysParameterSettings_GetWatchdogTimeMs(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWatchdogTimeMs(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWatchdogTimeMs  FALSE
	#define EXP_SysParameterSettings_GetWatchdogTimeMs  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWatchdogTimeMs
	#define EXT_SysParameterSettings_GetWatchdogTimeMs
	#define GET_SysParameterSettings_GetWatchdogTimeMs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTimeMs" ) 
	#define CAL_SysParameterSettings_GetWatchdogTimeMs  SysParameterSettings_GetWatchdogTimeMs
	#define CHK_SysParameterSettings_GetWatchdogTimeMs  TRUE
	#define EXP_SysParameterSettings_GetWatchdogTimeMs  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogTimeMs" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWatchdogTimeMs
	#define EXT_SysParameterSettings_GetWatchdogTimeMs
	#define GET_SysParameterSettings_GetWatchdogTimeMs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTimeMs" ) 
	#define CAL_SysParameterSettings_GetWatchdogTimeMs  SysParameterSettings_GetWatchdogTimeMs
	#define CHK_SysParameterSettings_GetWatchdogTimeMs  TRUE
	#define EXP_SysParameterSettings_GetWatchdogTimeMs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogTimeMs", (RTS_UINTPTR)SysParameterSettings_GetWatchdogTimeMs, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMs
	#define EXT_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMs
	#define GET_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMs  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMs pISysParameterSettings->ISysParameterSettings_GetWatchdogTimeMs
	#define CHK_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMs  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWatchdogTimeMs
	#define EXT_SysParameterSettings_GetWatchdogTimeMs
	#define GET_SysParameterSettings_GetWatchdogTimeMs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTimeMs" ) 
	#define CAL_SysParameterSettings_GetWatchdogTimeMs pISysParameterSettings->ISysParameterSettings_GetWatchdogTimeMs
	#define CHK_SysParameterSettings_GetWatchdogTimeMs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWatchdogTimeMs  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogTimeMs" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWatchdogTimeMs  PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMS pfSysParameterSettings_GetWatchdogTimeMs;
	#define EXT_SysParameterSettings_GetWatchdogTimeMs  extern PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMS pfSysParameterSettings_GetWatchdogTimeMs;
	#define GET_SysParameterSettings_GetWatchdogTimeMs(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWatchdogTimeMs", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWatchdogTimeMs, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWatchdogTimeMs  pfSysParameterSettings_GetWatchdogTimeMs
	#define CHK_SysParameterSettings_GetWatchdogTimeMs  (pfSysParameterSettings_GetWatchdogTimeMs != NULL)
	#define EXP_SysParameterSettings_GetWatchdogTimeMs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogTimeMs", (RTS_UINTPTR)SysParameterSettings_GetWatchdogTimeMs, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWatchdogTimeMinMax(RTS_UI32 *pMin, RTS_UI32 *pMax);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMINMAX) (RTS_UI32 *pMin, RTS_UI32 *pMax);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWATCHDOGTIMEMINMAX_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWatchdogTimeMinMax
	#define EXT_SysParameterSettings_GetWatchdogTimeMinMax
	#define GET_SysParameterSettings_GetWatchdogTimeMinMax(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWatchdogTimeMinMax(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWatchdogTimeMinMax  FALSE
	#define EXP_SysParameterSettings_GetWatchdogTimeMinMax  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWatchdogTimeMinMax
	#define EXT_SysParameterSettings_GetWatchdogTimeMinMax
	#define GET_SysParameterSettings_GetWatchdogTimeMinMax(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTimeMinMax" ) 
	#define CAL_SysParameterSettings_GetWatchdogTimeMinMax  SysParameterSettings_GetWatchdogTimeMinMax
	#define CHK_SysParameterSettings_GetWatchdogTimeMinMax  TRUE
	#define EXP_SysParameterSettings_GetWatchdogTimeMinMax  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogTimeMinMax" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWatchdogTimeMinMax
	#define EXT_SysParameterSettings_GetWatchdogTimeMinMax
	#define GET_SysParameterSettings_GetWatchdogTimeMinMax(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTimeMinMax" ) 
	#define CAL_SysParameterSettings_GetWatchdogTimeMinMax  SysParameterSettings_GetWatchdogTimeMinMax
	#define CHK_SysParameterSettings_GetWatchdogTimeMinMax  TRUE
	#define EXP_SysParameterSettings_GetWatchdogTimeMinMax  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogTimeMinMax", (RTS_UINTPTR)SysParameterSettings_GetWatchdogTimeMinMax, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMinMax
	#define EXT_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMinMax
	#define GET_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMinMax  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMinMax pISysParameterSettings->ISysParameterSettings_GetWatchdogTimeMinMax
	#define CHK_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMinMax (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWatchdogTimeMinMax  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWatchdogTimeMinMax
	#define EXT_SysParameterSettings_GetWatchdogTimeMinMax
	#define GET_SysParameterSettings_GetWatchdogTimeMinMax(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWatchdogTimeMinMax" ) 
	#define CAL_SysParameterSettings_GetWatchdogTimeMinMax pISysParameterSettings->ISysParameterSettings_GetWatchdogTimeMinMax
	#define CHK_SysParameterSettings_GetWatchdogTimeMinMax (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWatchdogTimeMinMax  CAL_CMEXPAPI( "SysParameterSettings_GetWatchdogTimeMinMax" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWatchdogTimeMinMax  PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMINMAX pfSysParameterSettings_GetWatchdogTimeMinMax;
	#define EXT_SysParameterSettings_GetWatchdogTimeMinMax  extern PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMINMAX pfSysParameterSettings_GetWatchdogTimeMinMax;
	#define GET_SysParameterSettings_GetWatchdogTimeMinMax(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWatchdogTimeMinMax", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWatchdogTimeMinMax, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWatchdogTimeMinMax  pfSysParameterSettings_GetWatchdogTimeMinMax
	#define CHK_SysParameterSettings_GetWatchdogTimeMinMax  (pfSysParameterSettings_GetWatchdogTimeMinMax != NULL)
	#define EXP_SysParameterSettings_GetWatchdogTimeMinMax  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWatchdogTimeMinMax", (RTS_UINTPTR)SysParameterSettings_GetWatchdogTimeMinMax, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetCanBridge(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETCANBRIDGE) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETCANBRIDGE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetCanBridge
	#define EXT_SysParameterSettings_GetCanBridge
	#define GET_SysParameterSettings_GetCanBridge(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetCanBridge(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetCanBridge  FALSE
	#define EXP_SysParameterSettings_GetCanBridge  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetCanBridge
	#define EXT_SysParameterSettings_GetCanBridge
	#define GET_SysParameterSettings_GetCanBridge(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCanBridge" ) 
	#define CAL_SysParameterSettings_GetCanBridge  SysParameterSettings_GetCanBridge
	#define CHK_SysParameterSettings_GetCanBridge  TRUE
	#define EXP_SysParameterSettings_GetCanBridge  CAL_CMEXPAPI( "SysParameterSettings_GetCanBridge" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetCanBridge
	#define EXT_SysParameterSettings_GetCanBridge
	#define GET_SysParameterSettings_GetCanBridge(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCanBridge" ) 
	#define CAL_SysParameterSettings_GetCanBridge  SysParameterSettings_GetCanBridge
	#define CHK_SysParameterSettings_GetCanBridge  TRUE
	#define EXP_SysParameterSettings_GetCanBridge  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetCanBridge", (RTS_UINTPTR)SysParameterSettings_GetCanBridge, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetCanBridge
	#define EXT_SysParameterSettingsSysParameterSettings_GetCanBridge
	#define GET_SysParameterSettingsSysParameterSettings_GetCanBridge  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetCanBridge pISysParameterSettings->ISysParameterSettings_GetCanBridge
	#define CHK_SysParameterSettingsSysParameterSettings_GetCanBridge (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetCanBridge  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetCanBridge
	#define EXT_SysParameterSettings_GetCanBridge
	#define GET_SysParameterSettings_GetCanBridge(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCanBridge" ) 
	#define CAL_SysParameterSettings_GetCanBridge pISysParameterSettings->ISysParameterSettings_GetCanBridge
	#define CHK_SysParameterSettings_GetCanBridge (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetCanBridge  CAL_CMEXPAPI( "SysParameterSettings_GetCanBridge" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetCanBridge  PFSYSPARAMETERSETTINGS_GETCANBRIDGE pfSysParameterSettings_GetCanBridge;
	#define EXT_SysParameterSettings_GetCanBridge  extern PFSYSPARAMETERSETTINGS_GETCANBRIDGE pfSysParameterSettings_GetCanBridge;
	#define GET_SysParameterSettings_GetCanBridge(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetCanBridge", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetCanBridge, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetCanBridge  pfSysParameterSettings_GetCanBridge
	#define CHK_SysParameterSettings_GetCanBridge  (pfSysParameterSettings_GetCanBridge != NULL)
	#define EXP_SysParameterSettings_GetCanBridge  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetCanBridge", (RTS_UINTPTR)SysParameterSettings_GetCanBridge, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetCanBridge(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETCANBRIDGE) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETCANBRIDGE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetCanBridge
	#define EXT_SysParameterSettings_SetCanBridge
	#define GET_SysParameterSettings_SetCanBridge(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetCanBridge(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetCanBridge  FALSE
	#define EXP_SysParameterSettings_SetCanBridge  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetCanBridge
	#define EXT_SysParameterSettings_SetCanBridge
	#define GET_SysParameterSettings_SetCanBridge(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCanBridge" ) 
	#define CAL_SysParameterSettings_SetCanBridge  SysParameterSettings_SetCanBridge
	#define CHK_SysParameterSettings_SetCanBridge  TRUE
	#define EXP_SysParameterSettings_SetCanBridge  CAL_CMEXPAPI( "SysParameterSettings_SetCanBridge" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetCanBridge
	#define EXT_SysParameterSettings_SetCanBridge
	#define GET_SysParameterSettings_SetCanBridge(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCanBridge" ) 
	#define CAL_SysParameterSettings_SetCanBridge  SysParameterSettings_SetCanBridge
	#define CHK_SysParameterSettings_SetCanBridge  TRUE
	#define EXP_SysParameterSettings_SetCanBridge  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetCanBridge", (RTS_UINTPTR)SysParameterSettings_SetCanBridge, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetCanBridge
	#define EXT_SysParameterSettingsSysParameterSettings_SetCanBridge
	#define GET_SysParameterSettingsSysParameterSettings_SetCanBridge  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetCanBridge pISysParameterSettings->ISysParameterSettings_SetCanBridge
	#define CHK_SysParameterSettingsSysParameterSettings_SetCanBridge (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetCanBridge  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetCanBridge
	#define EXT_SysParameterSettings_SetCanBridge
	#define GET_SysParameterSettings_SetCanBridge(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCanBridge" ) 
	#define CAL_SysParameterSettings_SetCanBridge pISysParameterSettings->ISysParameterSettings_SetCanBridge
	#define CHK_SysParameterSettings_SetCanBridge (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetCanBridge  CAL_CMEXPAPI( "SysParameterSettings_SetCanBridge" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetCanBridge  PFSYSPARAMETERSETTINGS_SETCANBRIDGE pfSysParameterSettings_SetCanBridge;
	#define EXT_SysParameterSettings_SetCanBridge  extern PFSYSPARAMETERSETTINGS_SETCANBRIDGE pfSysParameterSettings_SetCanBridge;
	#define GET_SysParameterSettings_SetCanBridge(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetCanBridge", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetCanBridge, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetCanBridge  pfSysParameterSettings_SetCanBridge
	#define CHK_SysParameterSettings_SetCanBridge  (pfSysParameterSettings_SetCanBridge != NULL)
	#define EXP_SysParameterSettings_SetCanBridge  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetCanBridge", (RTS_UINTPTR)SysParameterSettings_SetCanBridge, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetUart0Baudrate(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETUART0BAUDRATE) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETUART0BAUDRATE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetUart0Baudrate
	#define EXT_SysParameterSettings_GetUart0Baudrate
	#define GET_SysParameterSettings_GetUart0Baudrate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetUart0Baudrate(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetUart0Baudrate  FALSE
	#define EXP_SysParameterSettings_GetUart0Baudrate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetUart0Baudrate
	#define EXT_SysParameterSettings_GetUart0Baudrate
	#define GET_SysParameterSettings_GetUart0Baudrate(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Baudrate" ) 
	#define CAL_SysParameterSettings_GetUart0Baudrate  SysParameterSettings_GetUart0Baudrate
	#define CHK_SysParameterSettings_GetUart0Baudrate  TRUE
	#define EXP_SysParameterSettings_GetUart0Baudrate  CAL_CMEXPAPI( "SysParameterSettings_GetUart0Baudrate" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetUart0Baudrate
	#define EXT_SysParameterSettings_GetUart0Baudrate
	#define GET_SysParameterSettings_GetUart0Baudrate(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Baudrate" ) 
	#define CAL_SysParameterSettings_GetUart0Baudrate  SysParameterSettings_GetUart0Baudrate
	#define CHK_SysParameterSettings_GetUart0Baudrate  TRUE
	#define EXP_SysParameterSettings_GetUart0Baudrate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUart0Baudrate", (RTS_UINTPTR)SysParameterSettings_GetUart0Baudrate, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetUart0Baudrate
	#define EXT_SysParameterSettingsSysParameterSettings_GetUart0Baudrate
	#define GET_SysParameterSettingsSysParameterSettings_GetUart0Baudrate  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetUart0Baudrate pISysParameterSettings->ISysParameterSettings_GetUart0Baudrate
	#define CHK_SysParameterSettingsSysParameterSettings_GetUart0Baudrate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetUart0Baudrate  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetUart0Baudrate
	#define EXT_SysParameterSettings_GetUart0Baudrate
	#define GET_SysParameterSettings_GetUart0Baudrate(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Baudrate" ) 
	#define CAL_SysParameterSettings_GetUart0Baudrate pISysParameterSettings->ISysParameterSettings_GetUart0Baudrate
	#define CHK_SysParameterSettings_GetUart0Baudrate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetUart0Baudrate  CAL_CMEXPAPI( "SysParameterSettings_GetUart0Baudrate" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetUart0Baudrate  PFSYSPARAMETERSETTINGS_GETUART0BAUDRATE pfSysParameterSettings_GetUart0Baudrate;
	#define EXT_SysParameterSettings_GetUart0Baudrate  extern PFSYSPARAMETERSETTINGS_GETUART0BAUDRATE pfSysParameterSettings_GetUart0Baudrate;
	#define GET_SysParameterSettings_GetUart0Baudrate(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetUart0Baudrate", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetUart0Baudrate, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetUart0Baudrate  pfSysParameterSettings_GetUart0Baudrate
	#define CHK_SysParameterSettings_GetUart0Baudrate  (pfSysParameterSettings_GetUart0Baudrate != NULL)
	#define EXP_SysParameterSettings_GetUart0Baudrate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUart0Baudrate", (RTS_UINTPTR)SysParameterSettings_GetUart0Baudrate, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetUart0Baudrate(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETUART0BAUDRATE) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETUART0BAUDRATE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetUart0Baudrate
	#define EXT_SysParameterSettings_SetUart0Baudrate
	#define GET_SysParameterSettings_SetUart0Baudrate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetUart0Baudrate(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetUart0Baudrate  FALSE
	#define EXP_SysParameterSettings_SetUart0Baudrate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetUart0Baudrate
	#define EXT_SysParameterSettings_SetUart0Baudrate
	#define GET_SysParameterSettings_SetUart0Baudrate(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Baudrate" ) 
	#define CAL_SysParameterSettings_SetUart0Baudrate  SysParameterSettings_SetUart0Baudrate
	#define CHK_SysParameterSettings_SetUart0Baudrate  TRUE
	#define EXP_SysParameterSettings_SetUart0Baudrate  CAL_CMEXPAPI( "SysParameterSettings_SetUart0Baudrate" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetUart0Baudrate
	#define EXT_SysParameterSettings_SetUart0Baudrate
	#define GET_SysParameterSettings_SetUart0Baudrate(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Baudrate" ) 
	#define CAL_SysParameterSettings_SetUart0Baudrate  SysParameterSettings_SetUart0Baudrate
	#define CHK_SysParameterSettings_SetUart0Baudrate  TRUE
	#define EXP_SysParameterSettings_SetUart0Baudrate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUart0Baudrate", (RTS_UINTPTR)SysParameterSettings_SetUart0Baudrate, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetUart0Baudrate
	#define EXT_SysParameterSettingsSysParameterSettings_SetUart0Baudrate
	#define GET_SysParameterSettingsSysParameterSettings_SetUart0Baudrate  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetUart0Baudrate pISysParameterSettings->ISysParameterSettings_SetUart0Baudrate
	#define CHK_SysParameterSettingsSysParameterSettings_SetUart0Baudrate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetUart0Baudrate  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetUart0Baudrate
	#define EXT_SysParameterSettings_SetUart0Baudrate
	#define GET_SysParameterSettings_SetUart0Baudrate(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Baudrate" ) 
	#define CAL_SysParameterSettings_SetUart0Baudrate pISysParameterSettings->ISysParameterSettings_SetUart0Baudrate
	#define CHK_SysParameterSettings_SetUart0Baudrate (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetUart0Baudrate  CAL_CMEXPAPI( "SysParameterSettings_SetUart0Baudrate" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetUart0Baudrate  PFSYSPARAMETERSETTINGS_SETUART0BAUDRATE pfSysParameterSettings_SetUart0Baudrate;
	#define EXT_SysParameterSettings_SetUart0Baudrate  extern PFSYSPARAMETERSETTINGS_SETUART0BAUDRATE pfSysParameterSettings_SetUart0Baudrate;
	#define GET_SysParameterSettings_SetUart0Baudrate(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetUart0Baudrate", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetUart0Baudrate, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetUart0Baudrate  pfSysParameterSettings_SetUart0Baudrate
	#define CHK_SysParameterSettings_SetUart0Baudrate  (pfSysParameterSettings_SetUart0Baudrate != NULL)
	#define EXP_SysParameterSettings_SetUart0Baudrate  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUart0Baudrate", (RTS_UINTPTR)SysParameterSettings_SetUart0Baudrate, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetUart0Parity(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETUART0PARITY) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETUART0PARITY_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetUart0Parity
	#define EXT_SysParameterSettings_GetUart0Parity
	#define GET_SysParameterSettings_GetUart0Parity(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetUart0Parity(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetUart0Parity  FALSE
	#define EXP_SysParameterSettings_GetUart0Parity  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetUart0Parity
	#define EXT_SysParameterSettings_GetUart0Parity
	#define GET_SysParameterSettings_GetUart0Parity(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Parity" ) 
	#define CAL_SysParameterSettings_GetUart0Parity  SysParameterSettings_GetUart0Parity
	#define CHK_SysParameterSettings_GetUart0Parity  TRUE
	#define EXP_SysParameterSettings_GetUart0Parity  CAL_CMEXPAPI( "SysParameterSettings_GetUart0Parity" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetUart0Parity
	#define EXT_SysParameterSettings_GetUart0Parity
	#define GET_SysParameterSettings_GetUart0Parity(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Parity" ) 
	#define CAL_SysParameterSettings_GetUart0Parity  SysParameterSettings_GetUart0Parity
	#define CHK_SysParameterSettings_GetUart0Parity  TRUE
	#define EXP_SysParameterSettings_GetUart0Parity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUart0Parity", (RTS_UINTPTR)SysParameterSettings_GetUart0Parity, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetUart0Parity
	#define EXT_SysParameterSettingsSysParameterSettings_GetUart0Parity
	#define GET_SysParameterSettingsSysParameterSettings_GetUart0Parity  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetUart0Parity pISysParameterSettings->ISysParameterSettings_GetUart0Parity
	#define CHK_SysParameterSettingsSysParameterSettings_GetUart0Parity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetUart0Parity  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetUart0Parity
	#define EXT_SysParameterSettings_GetUart0Parity
	#define GET_SysParameterSettings_GetUart0Parity(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Parity" ) 
	#define CAL_SysParameterSettings_GetUart0Parity pISysParameterSettings->ISysParameterSettings_GetUart0Parity
	#define CHK_SysParameterSettings_GetUart0Parity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetUart0Parity  CAL_CMEXPAPI( "SysParameterSettings_GetUart0Parity" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetUart0Parity  PFSYSPARAMETERSETTINGS_GETUART0PARITY pfSysParameterSettings_GetUart0Parity;
	#define EXT_SysParameterSettings_GetUart0Parity  extern PFSYSPARAMETERSETTINGS_GETUART0PARITY pfSysParameterSettings_GetUart0Parity;
	#define GET_SysParameterSettings_GetUart0Parity(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetUart0Parity", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetUart0Parity, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetUart0Parity  pfSysParameterSettings_GetUart0Parity
	#define CHK_SysParameterSettings_GetUart0Parity  (pfSysParameterSettings_GetUart0Parity != NULL)
	#define EXP_SysParameterSettings_GetUart0Parity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUart0Parity", (RTS_UINTPTR)SysParameterSettings_GetUart0Parity, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetUart0Parity(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETUART0PARITY) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETUART0PARITY_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetUart0Parity
	#define EXT_SysParameterSettings_SetUart0Parity
	#define GET_SysParameterSettings_SetUart0Parity(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetUart0Parity(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetUart0Parity  FALSE
	#define EXP_SysParameterSettings_SetUart0Parity  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetUart0Parity
	#define EXT_SysParameterSettings_SetUart0Parity
	#define GET_SysParameterSettings_SetUart0Parity(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Parity" ) 
	#define CAL_SysParameterSettings_SetUart0Parity  SysParameterSettings_SetUart0Parity
	#define CHK_SysParameterSettings_SetUart0Parity  TRUE
	#define EXP_SysParameterSettings_SetUart0Parity  CAL_CMEXPAPI( "SysParameterSettings_SetUart0Parity" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetUart0Parity
	#define EXT_SysParameterSettings_SetUart0Parity
	#define GET_SysParameterSettings_SetUart0Parity(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Parity" ) 
	#define CAL_SysParameterSettings_SetUart0Parity  SysParameterSettings_SetUart0Parity
	#define CHK_SysParameterSettings_SetUart0Parity  TRUE
	#define EXP_SysParameterSettings_SetUart0Parity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUart0Parity", (RTS_UINTPTR)SysParameterSettings_SetUart0Parity, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetUart0Parity
	#define EXT_SysParameterSettingsSysParameterSettings_SetUart0Parity
	#define GET_SysParameterSettingsSysParameterSettings_SetUart0Parity  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetUart0Parity pISysParameterSettings->ISysParameterSettings_SetUart0Parity
	#define CHK_SysParameterSettingsSysParameterSettings_SetUart0Parity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetUart0Parity  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetUart0Parity
	#define EXT_SysParameterSettings_SetUart0Parity
	#define GET_SysParameterSettings_SetUart0Parity(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Parity" ) 
	#define CAL_SysParameterSettings_SetUart0Parity pISysParameterSettings->ISysParameterSettings_SetUart0Parity
	#define CHK_SysParameterSettings_SetUart0Parity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetUart0Parity  CAL_CMEXPAPI( "SysParameterSettings_SetUart0Parity" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetUart0Parity  PFSYSPARAMETERSETTINGS_SETUART0PARITY pfSysParameterSettings_SetUart0Parity;
	#define EXT_SysParameterSettings_SetUart0Parity  extern PFSYSPARAMETERSETTINGS_SETUART0PARITY pfSysParameterSettings_SetUart0Parity;
	#define GET_SysParameterSettings_SetUart0Parity(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetUart0Parity", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetUart0Parity, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetUart0Parity  pfSysParameterSettings_SetUart0Parity
	#define CHK_SysParameterSettings_SetUart0Parity  (pfSysParameterSettings_SetUart0Parity != NULL)
	#define EXP_SysParameterSettings_SetUart0Parity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUart0Parity", (RTS_UINTPTR)SysParameterSettings_SetUart0Parity, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetUart0Stopbits(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETUART0STOPBITS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETUART0STOPBITS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetUart0Stopbits
	#define EXT_SysParameterSettings_GetUart0Stopbits
	#define GET_SysParameterSettings_GetUart0Stopbits(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetUart0Stopbits(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetUart0Stopbits  FALSE
	#define EXP_SysParameterSettings_GetUart0Stopbits  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetUart0Stopbits
	#define EXT_SysParameterSettings_GetUart0Stopbits
	#define GET_SysParameterSettings_GetUart0Stopbits(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Stopbits" ) 
	#define CAL_SysParameterSettings_GetUart0Stopbits  SysParameterSettings_GetUart0Stopbits
	#define CHK_SysParameterSettings_GetUart0Stopbits  TRUE
	#define EXP_SysParameterSettings_GetUart0Stopbits  CAL_CMEXPAPI( "SysParameterSettings_GetUart0Stopbits" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetUart0Stopbits
	#define EXT_SysParameterSettings_GetUart0Stopbits
	#define GET_SysParameterSettings_GetUart0Stopbits(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Stopbits" ) 
	#define CAL_SysParameterSettings_GetUart0Stopbits  SysParameterSettings_GetUart0Stopbits
	#define CHK_SysParameterSettings_GetUart0Stopbits  TRUE
	#define EXP_SysParameterSettings_GetUart0Stopbits  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUart0Stopbits", (RTS_UINTPTR)SysParameterSettings_GetUart0Stopbits, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetUart0Stopbits
	#define EXT_SysParameterSettingsSysParameterSettings_GetUart0Stopbits
	#define GET_SysParameterSettingsSysParameterSettings_GetUart0Stopbits  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetUart0Stopbits pISysParameterSettings->ISysParameterSettings_GetUart0Stopbits
	#define CHK_SysParameterSettingsSysParameterSettings_GetUart0Stopbits (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetUart0Stopbits  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetUart0Stopbits
	#define EXT_SysParameterSettings_GetUart0Stopbits
	#define GET_SysParameterSettings_GetUart0Stopbits(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUart0Stopbits" ) 
	#define CAL_SysParameterSettings_GetUart0Stopbits pISysParameterSettings->ISysParameterSettings_GetUart0Stopbits
	#define CHK_SysParameterSettings_GetUart0Stopbits (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetUart0Stopbits  CAL_CMEXPAPI( "SysParameterSettings_GetUart0Stopbits" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetUart0Stopbits  PFSYSPARAMETERSETTINGS_GETUART0STOPBITS pfSysParameterSettings_GetUart0Stopbits;
	#define EXT_SysParameterSettings_GetUart0Stopbits  extern PFSYSPARAMETERSETTINGS_GETUART0STOPBITS pfSysParameterSettings_GetUart0Stopbits;
	#define GET_SysParameterSettings_GetUart0Stopbits(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetUart0Stopbits", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetUart0Stopbits, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetUart0Stopbits  pfSysParameterSettings_GetUart0Stopbits
	#define CHK_SysParameterSettings_GetUart0Stopbits  (pfSysParameterSettings_GetUart0Stopbits != NULL)
	#define EXP_SysParameterSettings_GetUart0Stopbits  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUart0Stopbits", (RTS_UINTPTR)SysParameterSettings_GetUart0Stopbits, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetUart0Stopbits(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETUART0STOPBITS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETUART0STOPBITS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetUart0Stopbits
	#define EXT_SysParameterSettings_SetUart0Stopbits
	#define GET_SysParameterSettings_SetUart0Stopbits(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetUart0Stopbits(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetUart0Stopbits  FALSE
	#define EXP_SysParameterSettings_SetUart0Stopbits  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetUart0Stopbits
	#define EXT_SysParameterSettings_SetUart0Stopbits
	#define GET_SysParameterSettings_SetUart0Stopbits(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Stopbits" ) 
	#define CAL_SysParameterSettings_SetUart0Stopbits  SysParameterSettings_SetUart0Stopbits
	#define CHK_SysParameterSettings_SetUart0Stopbits  TRUE
	#define EXP_SysParameterSettings_SetUart0Stopbits  CAL_CMEXPAPI( "SysParameterSettings_SetUart0Stopbits" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetUart0Stopbits
	#define EXT_SysParameterSettings_SetUart0Stopbits
	#define GET_SysParameterSettings_SetUart0Stopbits(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Stopbits" ) 
	#define CAL_SysParameterSettings_SetUart0Stopbits  SysParameterSettings_SetUart0Stopbits
	#define CHK_SysParameterSettings_SetUart0Stopbits  TRUE
	#define EXP_SysParameterSettings_SetUart0Stopbits  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUart0Stopbits", (RTS_UINTPTR)SysParameterSettings_SetUart0Stopbits, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetUart0Stopbits
	#define EXT_SysParameterSettingsSysParameterSettings_SetUart0Stopbits
	#define GET_SysParameterSettingsSysParameterSettings_SetUart0Stopbits  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetUart0Stopbits pISysParameterSettings->ISysParameterSettings_SetUart0Stopbits
	#define CHK_SysParameterSettingsSysParameterSettings_SetUart0Stopbits (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetUart0Stopbits  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetUart0Stopbits
	#define EXT_SysParameterSettings_SetUart0Stopbits
	#define GET_SysParameterSettings_SetUart0Stopbits(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUart0Stopbits" ) 
	#define CAL_SysParameterSettings_SetUart0Stopbits pISysParameterSettings->ISysParameterSettings_SetUart0Stopbits
	#define CHK_SysParameterSettings_SetUart0Stopbits (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetUart0Stopbits  CAL_CMEXPAPI( "SysParameterSettings_SetUart0Stopbits" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetUart0Stopbits  PFSYSPARAMETERSETTINGS_SETUART0STOPBITS pfSysParameterSettings_SetUart0Stopbits;
	#define EXT_SysParameterSettings_SetUart0Stopbits  extern PFSYSPARAMETERSETTINGS_SETUART0STOPBITS pfSysParameterSettings_SetUart0Stopbits;
	#define GET_SysParameterSettings_SetUart0Stopbits(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetUart0Stopbits", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetUart0Stopbits, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetUart0Stopbits  pfSysParameterSettings_SetUart0Stopbits
	#define CHK_SysParameterSettings_SetUart0Stopbits  (pfSysParameterSettings_SetUart0Stopbits != NULL)
	#define EXP_SysParameterSettings_SetUart0Stopbits  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUart0Stopbits", (RTS_UINTPTR)SysParameterSettings_SetUart0Stopbits, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetRightsForParameter(char * pszUserName, RTS_UI32 bcReadAccess, RTS_UI32 bcWriteAccess);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETRIGHTSFORPARAMETER) (char * pszUserName, RTS_UI32 bcReadAccess, RTS_UI32 bcWriteAccess);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETRIGHTSFORPARAMETER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetRightsForParameter
	#define EXT_SysParameterSettings_GetRightsForParameter
	#define GET_SysParameterSettings_GetRightsForParameter(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetRightsForParameter(p0,p1,p2)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetRightsForParameter  FALSE
	#define EXP_SysParameterSettings_GetRightsForParameter  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetRightsForParameter
	#define EXT_SysParameterSettings_GetRightsForParameter
	#define GET_SysParameterSettings_GetRightsForParameter(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightsForParameter" ) 
	#define CAL_SysParameterSettings_GetRightsForParameter  SysParameterSettings_GetRightsForParameter
	#define CHK_SysParameterSettings_GetRightsForParameter  TRUE
	#define EXP_SysParameterSettings_GetRightsForParameter  CAL_CMEXPAPI( "SysParameterSettings_GetRightsForParameter" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetRightsForParameter
	#define EXT_SysParameterSettings_GetRightsForParameter
	#define GET_SysParameterSettings_GetRightsForParameter(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightsForParameter" ) 
	#define CAL_SysParameterSettings_GetRightsForParameter  SysParameterSettings_GetRightsForParameter
	#define CHK_SysParameterSettings_GetRightsForParameter  TRUE
	#define EXP_SysParameterSettings_GetRightsForParameter  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRightsForParameter", (RTS_UINTPTR)SysParameterSettings_GetRightsForParameter, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetRightsForParameter
	#define EXT_SysParameterSettingsSysParameterSettings_GetRightsForParameter
	#define GET_SysParameterSettingsSysParameterSettings_GetRightsForParameter  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetRightsForParameter pISysParameterSettings->ISysParameterSettings_GetRightsForParameter
	#define CHK_SysParameterSettingsSysParameterSettings_GetRightsForParameter (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetRightsForParameter  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetRightsForParameter
	#define EXT_SysParameterSettings_GetRightsForParameter
	#define GET_SysParameterSettings_GetRightsForParameter(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightsForParameter" ) 
	#define CAL_SysParameterSettings_GetRightsForParameter pISysParameterSettings->ISysParameterSettings_GetRightsForParameter
	#define CHK_SysParameterSettings_GetRightsForParameter (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetRightsForParameter  CAL_CMEXPAPI( "SysParameterSettings_GetRightsForParameter" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetRightsForParameter  PFSYSPARAMETERSETTINGS_GETRIGHTSFORPARAMETER pfSysParameterSettings_GetRightsForParameter;
	#define EXT_SysParameterSettings_GetRightsForParameter  extern PFSYSPARAMETERSETTINGS_GETRIGHTSFORPARAMETER pfSysParameterSettings_GetRightsForParameter;
	#define GET_SysParameterSettings_GetRightsForParameter(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetRightsForParameter", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetRightsForParameter, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetRightsForParameter  pfSysParameterSettings_GetRightsForParameter
	#define CHK_SysParameterSettings_GetRightsForParameter  (pfSysParameterSettings_GetRightsForParameter != NULL)
	#define EXP_SysParameterSettings_GetRightsForParameter  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRightsForParameter", (RTS_UINTPTR)SysParameterSettings_GetRightsForParameter, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_DeleteUser(char * szUsername);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_DELETEUSER) (char * szUsername);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_DELETEUSER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_DeleteUser
	#define EXT_SysParameterSettings_DeleteUser
	#define GET_SysParameterSettings_DeleteUser(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_DeleteUser(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_DeleteUser  FALSE
	#define EXP_SysParameterSettings_DeleteUser  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_DeleteUser
	#define EXT_SysParameterSettings_DeleteUser
	#define GET_SysParameterSettings_DeleteUser(fl)  CAL_CMGETAPI( "SysParameterSettings_DeleteUser" ) 
	#define CAL_SysParameterSettings_DeleteUser  SysParameterSettings_DeleteUser
	#define CHK_SysParameterSettings_DeleteUser  TRUE
	#define EXP_SysParameterSettings_DeleteUser  CAL_CMEXPAPI( "SysParameterSettings_DeleteUser" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_DeleteUser
	#define EXT_SysParameterSettings_DeleteUser
	#define GET_SysParameterSettings_DeleteUser(fl)  CAL_CMGETAPI( "SysParameterSettings_DeleteUser" ) 
	#define CAL_SysParameterSettings_DeleteUser  SysParameterSettings_DeleteUser
	#define CHK_SysParameterSettings_DeleteUser  TRUE
	#define EXP_SysParameterSettings_DeleteUser  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_DeleteUser", (RTS_UINTPTR)SysParameterSettings_DeleteUser, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_DeleteUser
	#define EXT_SysParameterSettingsSysParameterSettings_DeleteUser
	#define GET_SysParameterSettingsSysParameterSettings_DeleteUser  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_DeleteUser pISysParameterSettings->ISysParameterSettings_DeleteUser
	#define CHK_SysParameterSettingsSysParameterSettings_DeleteUser (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_DeleteUser  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_DeleteUser
	#define EXT_SysParameterSettings_DeleteUser
	#define GET_SysParameterSettings_DeleteUser(fl)  CAL_CMGETAPI( "SysParameterSettings_DeleteUser" ) 
	#define CAL_SysParameterSettings_DeleteUser pISysParameterSettings->ISysParameterSettings_DeleteUser
	#define CHK_SysParameterSettings_DeleteUser (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_DeleteUser  CAL_CMEXPAPI( "SysParameterSettings_DeleteUser" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_DeleteUser  PFSYSPARAMETERSETTINGS_DELETEUSER pfSysParameterSettings_DeleteUser;
	#define EXT_SysParameterSettings_DeleteUser  extern PFSYSPARAMETERSETTINGS_DELETEUSER pfSysParameterSettings_DeleteUser;
	#define GET_SysParameterSettings_DeleteUser(fl)  s_pfCMGetAPI2( "SysParameterSettings_DeleteUser", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_DeleteUser, (fl), 0, 0)
	#define CAL_SysParameterSettings_DeleteUser  pfSysParameterSettings_DeleteUser
	#define CHK_SysParameterSettings_DeleteUser  (pfSysParameterSettings_DeleteUser != NULL)
	#define EXP_SysParameterSettings_DeleteUser  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_DeleteUser", (RTS_UINTPTR)SysParameterSettings_DeleteUser, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetSoftware_version(char * szOutput, int buflen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSOFTWARE_VERSION) (char * szOutput, int buflen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSOFTWARE_VERSION_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetSoftware_version
	#define EXT_SysParameterSettings_GetSoftware_version
	#define GET_SysParameterSettings_GetSoftware_version(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetSoftware_version(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetSoftware_version  FALSE
	#define EXP_SysParameterSettings_GetSoftware_version  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetSoftware_version
	#define EXT_SysParameterSettings_GetSoftware_version
	#define GET_SysParameterSettings_GetSoftware_version(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSoftware_version" ) 
	#define CAL_SysParameterSettings_GetSoftware_version  SysParameterSettings_GetSoftware_version
	#define CHK_SysParameterSettings_GetSoftware_version  TRUE
	#define EXP_SysParameterSettings_GetSoftware_version  CAL_CMEXPAPI( "SysParameterSettings_GetSoftware_version" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetSoftware_version
	#define EXT_SysParameterSettings_GetSoftware_version
	#define GET_SysParameterSettings_GetSoftware_version(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSoftware_version" ) 
	#define CAL_SysParameterSettings_GetSoftware_version  SysParameterSettings_GetSoftware_version
	#define CHK_SysParameterSettings_GetSoftware_version  TRUE
	#define EXP_SysParameterSettings_GetSoftware_version  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSoftware_version", (RTS_UINTPTR)SysParameterSettings_GetSoftware_version, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetSoftware_version
	#define EXT_SysParameterSettingsSysParameterSettings_GetSoftware_version
	#define GET_SysParameterSettingsSysParameterSettings_GetSoftware_version  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetSoftware_version pISysParameterSettings->ISysParameterSettings_GetSoftware_version
	#define CHK_SysParameterSettingsSysParameterSettings_GetSoftware_version (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetSoftware_version  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetSoftware_version
	#define EXT_SysParameterSettings_GetSoftware_version
	#define GET_SysParameterSettings_GetSoftware_version(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSoftware_version" ) 
	#define CAL_SysParameterSettings_GetSoftware_version pISysParameterSettings->ISysParameterSettings_GetSoftware_version
	#define CHK_SysParameterSettings_GetSoftware_version (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetSoftware_version  CAL_CMEXPAPI( "SysParameterSettings_GetSoftware_version" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetSoftware_version  PFSYSPARAMETERSETTINGS_GETSOFTWARE_VERSION pfSysParameterSettings_GetSoftware_version;
	#define EXT_SysParameterSettings_GetSoftware_version  extern PFSYSPARAMETERSETTINGS_GETSOFTWARE_VERSION pfSysParameterSettings_GetSoftware_version;
	#define GET_SysParameterSettings_GetSoftware_version(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetSoftware_version", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetSoftware_version, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetSoftware_version  pfSysParameterSettings_GetSoftware_version
	#define CHK_SysParameterSettings_GetSoftware_version  (pfSysParameterSettings_GetSoftware_version != NULL)
	#define EXP_SysParameterSettings_GetSoftware_version  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSoftware_version", (RTS_UINTPTR)SysParameterSettings_GetSoftware_version, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDeviceTemperature(RTS_REAL32 * pTemperature);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDEVICETEMPERATURE) (RTS_REAL32 * pTemperature);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDEVICETEMPERATURE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDeviceTemperature
	#define EXT_SysParameterSettings_GetDeviceTemperature
	#define GET_SysParameterSettings_GetDeviceTemperature(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDeviceTemperature(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDeviceTemperature  FALSE
	#define EXP_SysParameterSettings_GetDeviceTemperature  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDeviceTemperature
	#define EXT_SysParameterSettings_GetDeviceTemperature
	#define GET_SysParameterSettings_GetDeviceTemperature(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDeviceTemperature" ) 
	#define CAL_SysParameterSettings_GetDeviceTemperature  SysParameterSettings_GetDeviceTemperature
	#define CHK_SysParameterSettings_GetDeviceTemperature  TRUE
	#define EXP_SysParameterSettings_GetDeviceTemperature  CAL_CMEXPAPI( "SysParameterSettings_GetDeviceTemperature" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDeviceTemperature
	#define EXT_SysParameterSettings_GetDeviceTemperature
	#define GET_SysParameterSettings_GetDeviceTemperature(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDeviceTemperature" ) 
	#define CAL_SysParameterSettings_GetDeviceTemperature  SysParameterSettings_GetDeviceTemperature
	#define CHK_SysParameterSettings_GetDeviceTemperature  TRUE
	#define EXP_SysParameterSettings_GetDeviceTemperature  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDeviceTemperature", (RTS_UINTPTR)SysParameterSettings_GetDeviceTemperature, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDeviceTemperature
	#define EXT_SysParameterSettingsSysParameterSettings_GetDeviceTemperature
	#define GET_SysParameterSettingsSysParameterSettings_GetDeviceTemperature  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDeviceTemperature pISysParameterSettings->ISysParameterSettings_GetDeviceTemperature
	#define CHK_SysParameterSettingsSysParameterSettings_GetDeviceTemperature (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDeviceTemperature  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDeviceTemperature
	#define EXT_SysParameterSettings_GetDeviceTemperature
	#define GET_SysParameterSettings_GetDeviceTemperature(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDeviceTemperature" ) 
	#define CAL_SysParameterSettings_GetDeviceTemperature pISysParameterSettings->ISysParameterSettings_GetDeviceTemperature
	#define CHK_SysParameterSettings_GetDeviceTemperature (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDeviceTemperature  CAL_CMEXPAPI( "SysParameterSettings_GetDeviceTemperature" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDeviceTemperature  PFSYSPARAMETERSETTINGS_GETDEVICETEMPERATURE pfSysParameterSettings_GetDeviceTemperature;
	#define EXT_SysParameterSettings_GetDeviceTemperature  extern PFSYSPARAMETERSETTINGS_GETDEVICETEMPERATURE pfSysParameterSettings_GetDeviceTemperature;
	#define GET_SysParameterSettings_GetDeviceTemperature(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDeviceTemperature", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDeviceTemperature, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDeviceTemperature  pfSysParameterSettings_GetDeviceTemperature
	#define CHK_SysParameterSettings_GetDeviceTemperature  (pfSysParameterSettings_GetDeviceTemperature != NULL)
	#define EXP_SysParameterSettings_GetDeviceTemperature  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDeviceTemperature", (RTS_UINTPTR)SysParameterSettings_GetDeviceTemperature, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetPromisc1(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETPROMISC1) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETPROMISC1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetPromisc1
	#define EXT_SysParameterSettings_GetPromisc1
	#define GET_SysParameterSettings_GetPromisc1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetPromisc1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetPromisc1  FALSE
	#define EXP_SysParameterSettings_GetPromisc1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetPromisc1
	#define EXT_SysParameterSettings_GetPromisc1
	#define GET_SysParameterSettings_GetPromisc1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPromisc1" ) 
	#define CAL_SysParameterSettings_GetPromisc1  SysParameterSettings_GetPromisc1
	#define CHK_SysParameterSettings_GetPromisc1  TRUE
	#define EXP_SysParameterSettings_GetPromisc1  CAL_CMEXPAPI( "SysParameterSettings_GetPromisc1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetPromisc1
	#define EXT_SysParameterSettings_GetPromisc1
	#define GET_SysParameterSettings_GetPromisc1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPromisc1" ) 
	#define CAL_SysParameterSettings_GetPromisc1  SysParameterSettings_GetPromisc1
	#define CHK_SysParameterSettings_GetPromisc1  TRUE
	#define EXP_SysParameterSettings_GetPromisc1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetPromisc1", (RTS_UINTPTR)SysParameterSettings_GetPromisc1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetPromisc1
	#define EXT_SysParameterSettingsSysParameterSettings_GetPromisc1
	#define GET_SysParameterSettingsSysParameterSettings_GetPromisc1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetPromisc1 pISysParameterSettings->ISysParameterSettings_GetPromisc1
	#define CHK_SysParameterSettingsSysParameterSettings_GetPromisc1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetPromisc1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetPromisc1
	#define EXT_SysParameterSettings_GetPromisc1
	#define GET_SysParameterSettings_GetPromisc1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPromisc1" ) 
	#define CAL_SysParameterSettings_GetPromisc1 pISysParameterSettings->ISysParameterSettings_GetPromisc1
	#define CHK_SysParameterSettings_GetPromisc1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetPromisc1  CAL_CMEXPAPI( "SysParameterSettings_GetPromisc1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetPromisc1  PFSYSPARAMETERSETTINGS_GETPROMISC1 pfSysParameterSettings_GetPromisc1;
	#define EXT_SysParameterSettings_GetPromisc1  extern PFSYSPARAMETERSETTINGS_GETPROMISC1 pfSysParameterSettings_GetPromisc1;
	#define GET_SysParameterSettings_GetPromisc1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetPromisc1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetPromisc1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetPromisc1  pfSysParameterSettings_GetPromisc1
	#define CHK_SysParameterSettings_GetPromisc1  (pfSysParameterSettings_GetPromisc1 != NULL)
	#define EXP_SysParameterSettings_GetPromisc1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetPromisc1", (RTS_UINTPTR)SysParameterSettings_GetPromisc1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetPromisc1(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETPROMISC1) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETPROMISC1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetPromisc1
	#define EXT_SysParameterSettings_SetPromisc1
	#define GET_SysParameterSettings_SetPromisc1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetPromisc1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetPromisc1  FALSE
	#define EXP_SysParameterSettings_SetPromisc1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetPromisc1
	#define EXT_SysParameterSettings_SetPromisc1
	#define GET_SysParameterSettings_SetPromisc1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPromisc1" ) 
	#define CAL_SysParameterSettings_SetPromisc1  SysParameterSettings_SetPromisc1
	#define CHK_SysParameterSettings_SetPromisc1  TRUE
	#define EXP_SysParameterSettings_SetPromisc1  CAL_CMEXPAPI( "SysParameterSettings_SetPromisc1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetPromisc1
	#define EXT_SysParameterSettings_SetPromisc1
	#define GET_SysParameterSettings_SetPromisc1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPromisc1" ) 
	#define CAL_SysParameterSettings_SetPromisc1  SysParameterSettings_SetPromisc1
	#define CHK_SysParameterSettings_SetPromisc1  TRUE
	#define EXP_SysParameterSettings_SetPromisc1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetPromisc1", (RTS_UINTPTR)SysParameterSettings_SetPromisc1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetPromisc1
	#define EXT_SysParameterSettingsSysParameterSettings_SetPromisc1
	#define GET_SysParameterSettingsSysParameterSettings_SetPromisc1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetPromisc1 pISysParameterSettings->ISysParameterSettings_SetPromisc1
	#define CHK_SysParameterSettingsSysParameterSettings_SetPromisc1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetPromisc1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetPromisc1
	#define EXT_SysParameterSettings_SetPromisc1
	#define GET_SysParameterSettings_SetPromisc1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPromisc1" ) 
	#define CAL_SysParameterSettings_SetPromisc1 pISysParameterSettings->ISysParameterSettings_SetPromisc1
	#define CHK_SysParameterSettings_SetPromisc1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetPromisc1  CAL_CMEXPAPI( "SysParameterSettings_SetPromisc1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetPromisc1  PFSYSPARAMETERSETTINGS_SETPROMISC1 pfSysParameterSettings_SetPromisc1;
	#define EXT_SysParameterSettings_SetPromisc1  extern PFSYSPARAMETERSETTINGS_SETPROMISC1 pfSysParameterSettings_SetPromisc1;
	#define GET_SysParameterSettings_SetPromisc1(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetPromisc1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetPromisc1, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetPromisc1  pfSysParameterSettings_SetPromisc1
	#define CHK_SysParameterSettings_SetPromisc1  (pfSysParameterSettings_SetPromisc1 != NULL)
	#define EXP_SysParameterSettings_SetPromisc1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetPromisc1", (RTS_UINTPTR)SysParameterSettings_SetPromisc1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetPromisc2(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETPROMISC2) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETPROMISC2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetPromisc2
	#define EXT_SysParameterSettings_GetPromisc2
	#define GET_SysParameterSettings_GetPromisc2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetPromisc2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetPromisc2  FALSE
	#define EXP_SysParameterSettings_GetPromisc2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetPromisc2
	#define EXT_SysParameterSettings_GetPromisc2
	#define GET_SysParameterSettings_GetPromisc2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPromisc2" ) 
	#define CAL_SysParameterSettings_GetPromisc2  SysParameterSettings_GetPromisc2
	#define CHK_SysParameterSettings_GetPromisc2  TRUE
	#define EXP_SysParameterSettings_GetPromisc2  CAL_CMEXPAPI( "SysParameterSettings_GetPromisc2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetPromisc2
	#define EXT_SysParameterSettings_GetPromisc2
	#define GET_SysParameterSettings_GetPromisc2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPromisc2" ) 
	#define CAL_SysParameterSettings_GetPromisc2  SysParameterSettings_GetPromisc2
	#define CHK_SysParameterSettings_GetPromisc2  TRUE
	#define EXP_SysParameterSettings_GetPromisc2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetPromisc2", (RTS_UINTPTR)SysParameterSettings_GetPromisc2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetPromisc2
	#define EXT_SysParameterSettingsSysParameterSettings_GetPromisc2
	#define GET_SysParameterSettingsSysParameterSettings_GetPromisc2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetPromisc2 pISysParameterSettings->ISysParameterSettings_GetPromisc2
	#define CHK_SysParameterSettingsSysParameterSettings_GetPromisc2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetPromisc2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetPromisc2
	#define EXT_SysParameterSettings_GetPromisc2
	#define GET_SysParameterSettings_GetPromisc2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPromisc2" ) 
	#define CAL_SysParameterSettings_GetPromisc2 pISysParameterSettings->ISysParameterSettings_GetPromisc2
	#define CHK_SysParameterSettings_GetPromisc2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetPromisc2  CAL_CMEXPAPI( "SysParameterSettings_GetPromisc2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetPromisc2  PFSYSPARAMETERSETTINGS_GETPROMISC2 pfSysParameterSettings_GetPromisc2;
	#define EXT_SysParameterSettings_GetPromisc2  extern PFSYSPARAMETERSETTINGS_GETPROMISC2 pfSysParameterSettings_GetPromisc2;
	#define GET_SysParameterSettings_GetPromisc2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetPromisc2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetPromisc2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetPromisc2  pfSysParameterSettings_GetPromisc2
	#define CHK_SysParameterSettings_GetPromisc2  (pfSysParameterSettings_GetPromisc2 != NULL)
	#define EXP_SysParameterSettings_GetPromisc2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetPromisc2", (RTS_UINTPTR)SysParameterSettings_GetPromisc2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetPromisc2(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETPROMISC2) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETPROMISC2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetPromisc2
	#define EXT_SysParameterSettings_SetPromisc2
	#define GET_SysParameterSettings_SetPromisc2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetPromisc2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetPromisc2  FALSE
	#define EXP_SysParameterSettings_SetPromisc2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetPromisc2
	#define EXT_SysParameterSettings_SetPromisc2
	#define GET_SysParameterSettings_SetPromisc2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPromisc2" ) 
	#define CAL_SysParameterSettings_SetPromisc2  SysParameterSettings_SetPromisc2
	#define CHK_SysParameterSettings_SetPromisc2  TRUE
	#define EXP_SysParameterSettings_SetPromisc2  CAL_CMEXPAPI( "SysParameterSettings_SetPromisc2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetPromisc2
	#define EXT_SysParameterSettings_SetPromisc2
	#define GET_SysParameterSettings_SetPromisc2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPromisc2" ) 
	#define CAL_SysParameterSettings_SetPromisc2  SysParameterSettings_SetPromisc2
	#define CHK_SysParameterSettings_SetPromisc2  TRUE
	#define EXP_SysParameterSettings_SetPromisc2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetPromisc2", (RTS_UINTPTR)SysParameterSettings_SetPromisc2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetPromisc2
	#define EXT_SysParameterSettingsSysParameterSettings_SetPromisc2
	#define GET_SysParameterSettingsSysParameterSettings_SetPromisc2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetPromisc2 pISysParameterSettings->ISysParameterSettings_SetPromisc2
	#define CHK_SysParameterSettingsSysParameterSettings_SetPromisc2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetPromisc2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetPromisc2
	#define EXT_SysParameterSettings_SetPromisc2
	#define GET_SysParameterSettings_SetPromisc2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPromisc2" ) 
	#define CAL_SysParameterSettings_SetPromisc2 pISysParameterSettings->ISysParameterSettings_SetPromisc2
	#define CHK_SysParameterSettings_SetPromisc2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetPromisc2  CAL_CMEXPAPI( "SysParameterSettings_SetPromisc2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetPromisc2  PFSYSPARAMETERSETTINGS_SETPROMISC2 pfSysParameterSettings_SetPromisc2;
	#define EXT_SysParameterSettings_SetPromisc2  extern PFSYSPARAMETERSETTINGS_SETPROMISC2 pfSysParameterSettings_SetPromisc2;
	#define GET_SysParameterSettings_SetPromisc2(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetPromisc2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetPromisc2, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetPromisc2  pfSysParameterSettings_SetPromisc2
	#define CHK_SysParameterSettings_SetPromisc2  (pfSysParameterSettings_SetPromisc2 != NULL)
	#define EXP_SysParameterSettings_SetPromisc2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetPromisc2", (RTS_UINTPTR)SysParameterSettings_SetPromisc2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMulticast1(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMULTICAST1) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMULTICAST1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMulticast1
	#define EXT_SysParameterSettings_GetMulticast1
	#define GET_SysParameterSettings_GetMulticast1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMulticast1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMulticast1  FALSE
	#define EXP_SysParameterSettings_GetMulticast1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMulticast1
	#define EXT_SysParameterSettings_GetMulticast1
	#define GET_SysParameterSettings_GetMulticast1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMulticast1" ) 
	#define CAL_SysParameterSettings_GetMulticast1  SysParameterSettings_GetMulticast1
	#define CHK_SysParameterSettings_GetMulticast1  TRUE
	#define EXP_SysParameterSettings_GetMulticast1  CAL_CMEXPAPI( "SysParameterSettings_GetMulticast1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMulticast1
	#define EXT_SysParameterSettings_GetMulticast1
	#define GET_SysParameterSettings_GetMulticast1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMulticast1" ) 
	#define CAL_SysParameterSettings_GetMulticast1  SysParameterSettings_GetMulticast1
	#define CHK_SysParameterSettings_GetMulticast1  TRUE
	#define EXP_SysParameterSettings_GetMulticast1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMulticast1", (RTS_UINTPTR)SysParameterSettings_GetMulticast1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMulticast1
	#define EXT_SysParameterSettingsSysParameterSettings_GetMulticast1
	#define GET_SysParameterSettingsSysParameterSettings_GetMulticast1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMulticast1 pISysParameterSettings->ISysParameterSettings_GetMulticast1
	#define CHK_SysParameterSettingsSysParameterSettings_GetMulticast1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMulticast1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMulticast1
	#define EXT_SysParameterSettings_GetMulticast1
	#define GET_SysParameterSettings_GetMulticast1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMulticast1" ) 
	#define CAL_SysParameterSettings_GetMulticast1 pISysParameterSettings->ISysParameterSettings_GetMulticast1
	#define CHK_SysParameterSettings_GetMulticast1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMulticast1  CAL_CMEXPAPI( "SysParameterSettings_GetMulticast1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMulticast1  PFSYSPARAMETERSETTINGS_GETMULTICAST1 pfSysParameterSettings_GetMulticast1;
	#define EXT_SysParameterSettings_GetMulticast1  extern PFSYSPARAMETERSETTINGS_GETMULTICAST1 pfSysParameterSettings_GetMulticast1;
	#define GET_SysParameterSettings_GetMulticast1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMulticast1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMulticast1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMulticast1  pfSysParameterSettings_GetMulticast1
	#define CHK_SysParameterSettings_GetMulticast1  (pfSysParameterSettings_GetMulticast1 != NULL)
	#define EXP_SysParameterSettings_GetMulticast1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMulticast1", (RTS_UINTPTR)SysParameterSettings_GetMulticast1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetMulticast1(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETMULTICAST1) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETMULTICAST1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetMulticast1
	#define EXT_SysParameterSettings_SetMulticast1
	#define GET_SysParameterSettings_SetMulticast1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetMulticast1(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetMulticast1  FALSE
	#define EXP_SysParameterSettings_SetMulticast1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetMulticast1
	#define EXT_SysParameterSettings_SetMulticast1
	#define GET_SysParameterSettings_SetMulticast1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMulticast1" ) 
	#define CAL_SysParameterSettings_SetMulticast1  SysParameterSettings_SetMulticast1
	#define CHK_SysParameterSettings_SetMulticast1  TRUE
	#define EXP_SysParameterSettings_SetMulticast1  CAL_CMEXPAPI( "SysParameterSettings_SetMulticast1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetMulticast1
	#define EXT_SysParameterSettings_SetMulticast1
	#define GET_SysParameterSettings_SetMulticast1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMulticast1" ) 
	#define CAL_SysParameterSettings_SetMulticast1  SysParameterSettings_SetMulticast1
	#define CHK_SysParameterSettings_SetMulticast1  TRUE
	#define EXP_SysParameterSettings_SetMulticast1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMulticast1", (RTS_UINTPTR)SysParameterSettings_SetMulticast1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetMulticast1
	#define EXT_SysParameterSettingsSysParameterSettings_SetMulticast1
	#define GET_SysParameterSettingsSysParameterSettings_SetMulticast1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetMulticast1 pISysParameterSettings->ISysParameterSettings_SetMulticast1
	#define CHK_SysParameterSettingsSysParameterSettings_SetMulticast1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetMulticast1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetMulticast1
	#define EXT_SysParameterSettings_SetMulticast1
	#define GET_SysParameterSettings_SetMulticast1(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMulticast1" ) 
	#define CAL_SysParameterSettings_SetMulticast1 pISysParameterSettings->ISysParameterSettings_SetMulticast1
	#define CHK_SysParameterSettings_SetMulticast1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetMulticast1  CAL_CMEXPAPI( "SysParameterSettings_SetMulticast1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetMulticast1  PFSYSPARAMETERSETTINGS_SETMULTICAST1 pfSysParameterSettings_SetMulticast1;
	#define EXT_SysParameterSettings_SetMulticast1  extern PFSYSPARAMETERSETTINGS_SETMULTICAST1 pfSysParameterSettings_SetMulticast1;
	#define GET_SysParameterSettings_SetMulticast1(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetMulticast1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetMulticast1, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetMulticast1  pfSysParameterSettings_SetMulticast1
	#define CHK_SysParameterSettings_SetMulticast1  (pfSysParameterSettings_SetMulticast1 != NULL)
	#define EXP_SysParameterSettings_SetMulticast1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMulticast1", (RTS_UINTPTR)SysParameterSettings_SetMulticast1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMulticast2(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMULTICAST2) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMULTICAST2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMulticast2
	#define EXT_SysParameterSettings_GetMulticast2
	#define GET_SysParameterSettings_GetMulticast2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMulticast2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMulticast2  FALSE
	#define EXP_SysParameterSettings_GetMulticast2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMulticast2
	#define EXT_SysParameterSettings_GetMulticast2
	#define GET_SysParameterSettings_GetMulticast2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMulticast2" ) 
	#define CAL_SysParameterSettings_GetMulticast2  SysParameterSettings_GetMulticast2
	#define CHK_SysParameterSettings_GetMulticast2  TRUE
	#define EXP_SysParameterSettings_GetMulticast2  CAL_CMEXPAPI( "SysParameterSettings_GetMulticast2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMulticast2
	#define EXT_SysParameterSettings_GetMulticast2
	#define GET_SysParameterSettings_GetMulticast2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMulticast2" ) 
	#define CAL_SysParameterSettings_GetMulticast2  SysParameterSettings_GetMulticast2
	#define CHK_SysParameterSettings_GetMulticast2  TRUE
	#define EXP_SysParameterSettings_GetMulticast2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMulticast2", (RTS_UINTPTR)SysParameterSettings_GetMulticast2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMulticast2
	#define EXT_SysParameterSettingsSysParameterSettings_GetMulticast2
	#define GET_SysParameterSettingsSysParameterSettings_GetMulticast2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMulticast2 pISysParameterSettings->ISysParameterSettings_GetMulticast2
	#define CHK_SysParameterSettingsSysParameterSettings_GetMulticast2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMulticast2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMulticast2
	#define EXT_SysParameterSettings_GetMulticast2
	#define GET_SysParameterSettings_GetMulticast2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMulticast2" ) 
	#define CAL_SysParameterSettings_GetMulticast2 pISysParameterSettings->ISysParameterSettings_GetMulticast2
	#define CHK_SysParameterSettings_GetMulticast2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMulticast2  CAL_CMEXPAPI( "SysParameterSettings_GetMulticast2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMulticast2  PFSYSPARAMETERSETTINGS_GETMULTICAST2 pfSysParameterSettings_GetMulticast2;
	#define EXT_SysParameterSettings_GetMulticast2  extern PFSYSPARAMETERSETTINGS_GETMULTICAST2 pfSysParameterSettings_GetMulticast2;
	#define GET_SysParameterSettings_GetMulticast2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMulticast2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMulticast2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMulticast2  pfSysParameterSettings_GetMulticast2
	#define CHK_SysParameterSettings_GetMulticast2  (pfSysParameterSettings_GetMulticast2 != NULL)
	#define EXP_SysParameterSettings_GetMulticast2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMulticast2", (RTS_UINTPTR)SysParameterSettings_GetMulticast2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetMulticast2(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETMULTICAST2) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETMULTICAST2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetMulticast2
	#define EXT_SysParameterSettings_SetMulticast2
	#define GET_SysParameterSettings_SetMulticast2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetMulticast2(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetMulticast2  FALSE
	#define EXP_SysParameterSettings_SetMulticast2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetMulticast2
	#define EXT_SysParameterSettings_SetMulticast2
	#define GET_SysParameterSettings_SetMulticast2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMulticast2" ) 
	#define CAL_SysParameterSettings_SetMulticast2  SysParameterSettings_SetMulticast2
	#define CHK_SysParameterSettings_SetMulticast2  TRUE
	#define EXP_SysParameterSettings_SetMulticast2  CAL_CMEXPAPI( "SysParameterSettings_SetMulticast2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetMulticast2
	#define EXT_SysParameterSettings_SetMulticast2
	#define GET_SysParameterSettings_SetMulticast2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMulticast2" ) 
	#define CAL_SysParameterSettings_SetMulticast2  SysParameterSettings_SetMulticast2
	#define CHK_SysParameterSettings_SetMulticast2  TRUE
	#define EXP_SysParameterSettings_SetMulticast2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMulticast2", (RTS_UINTPTR)SysParameterSettings_SetMulticast2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetMulticast2
	#define EXT_SysParameterSettingsSysParameterSettings_SetMulticast2
	#define GET_SysParameterSettingsSysParameterSettings_SetMulticast2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetMulticast2 pISysParameterSettings->ISysParameterSettings_SetMulticast2
	#define CHK_SysParameterSettingsSysParameterSettings_SetMulticast2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetMulticast2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetMulticast2
	#define EXT_SysParameterSettings_SetMulticast2
	#define GET_SysParameterSettings_SetMulticast2(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMulticast2" ) 
	#define CAL_SysParameterSettings_SetMulticast2 pISysParameterSettings->ISysParameterSettings_SetMulticast2
	#define CHK_SysParameterSettings_SetMulticast2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetMulticast2  CAL_CMEXPAPI( "SysParameterSettings_SetMulticast2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetMulticast2  PFSYSPARAMETERSETTINGS_SETMULTICAST2 pfSysParameterSettings_SetMulticast2;
	#define EXT_SysParameterSettings_SetMulticast2  extern PFSYSPARAMETERSETTINGS_SETMULTICAST2 pfSysParameterSettings_SetMulticast2;
	#define GET_SysParameterSettings_SetMulticast2(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetMulticast2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetMulticast2, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetMulticast2  pfSysParameterSettings_SetMulticast2
	#define CHK_SysParameterSettings_SetMulticast2  (pfSysParameterSettings_SetMulticast2 != NULL)
	#define EXP_SysParameterSettings_SetMulticast2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMulticast2", (RTS_UINTPTR)SysParameterSettings_SetMulticast2, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMountsJSON(char * szOutput, int maxlen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMOUNTSJSON) (char * szOutput, int maxlen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMOUNTSJSON_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMountsJSON
	#define EXT_SysParameterSettings_GetMountsJSON
	#define GET_SysParameterSettings_GetMountsJSON(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMountsJSON(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMountsJSON  FALSE
	#define EXP_SysParameterSettings_GetMountsJSON  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMountsJSON
	#define EXT_SysParameterSettings_GetMountsJSON
	#define GET_SysParameterSettings_GetMountsJSON(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMountsJSON" ) 
	#define CAL_SysParameterSettings_GetMountsJSON  SysParameterSettings_GetMountsJSON
	#define CHK_SysParameterSettings_GetMountsJSON  TRUE
	#define EXP_SysParameterSettings_GetMountsJSON  CAL_CMEXPAPI( "SysParameterSettings_GetMountsJSON" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMountsJSON
	#define EXT_SysParameterSettings_GetMountsJSON
	#define GET_SysParameterSettings_GetMountsJSON(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMountsJSON" ) 
	#define CAL_SysParameterSettings_GetMountsJSON  SysParameterSettings_GetMountsJSON
	#define CHK_SysParameterSettings_GetMountsJSON  TRUE
	#define EXP_SysParameterSettings_GetMountsJSON  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMountsJSON", (RTS_UINTPTR)SysParameterSettings_GetMountsJSON, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMountsJSON
	#define EXT_SysParameterSettingsSysParameterSettings_GetMountsJSON
	#define GET_SysParameterSettingsSysParameterSettings_GetMountsJSON  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMountsJSON pISysParameterSettings->ISysParameterSettings_GetMountsJSON
	#define CHK_SysParameterSettingsSysParameterSettings_GetMountsJSON (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMountsJSON  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMountsJSON
	#define EXT_SysParameterSettings_GetMountsJSON
	#define GET_SysParameterSettings_GetMountsJSON(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMountsJSON" ) 
	#define CAL_SysParameterSettings_GetMountsJSON pISysParameterSettings->ISysParameterSettings_GetMountsJSON
	#define CHK_SysParameterSettings_GetMountsJSON (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMountsJSON  CAL_CMEXPAPI( "SysParameterSettings_GetMountsJSON" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMountsJSON  PFSYSPARAMETERSETTINGS_GETMOUNTSJSON pfSysParameterSettings_GetMountsJSON;
	#define EXT_SysParameterSettings_GetMountsJSON  extern PFSYSPARAMETERSETTINGS_GETMOUNTSJSON pfSysParameterSettings_GetMountsJSON;
	#define GET_SysParameterSettings_GetMountsJSON(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMountsJSON", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMountsJSON, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMountsJSON  pfSysParameterSettings_GetMountsJSON
	#define CHK_SysParameterSettings_GetMountsJSON  (pfSysParameterSettings_GetMountsJSON != NULL)
	#define EXP_SysParameterSettings_GetMountsJSON  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMountsJSON", (RTS_UINTPTR)SysParameterSettings_GetMountsJSON, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_Unmount(char * pszDirectory);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_UNMOUNT) (char * pszDirectory);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_UNMOUNT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_Unmount
	#define EXT_SysParameterSettings_Unmount
	#define GET_SysParameterSettings_Unmount(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_Unmount(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_Unmount  FALSE
	#define EXP_SysParameterSettings_Unmount  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_Unmount
	#define EXT_SysParameterSettings_Unmount
	#define GET_SysParameterSettings_Unmount(fl)  CAL_CMGETAPI( "SysParameterSettings_Unmount" ) 
	#define CAL_SysParameterSettings_Unmount  SysParameterSettings_Unmount
	#define CHK_SysParameterSettings_Unmount  TRUE
	#define EXP_SysParameterSettings_Unmount  CAL_CMEXPAPI( "SysParameterSettings_Unmount" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_Unmount
	#define EXT_SysParameterSettings_Unmount
	#define GET_SysParameterSettings_Unmount(fl)  CAL_CMGETAPI( "SysParameterSettings_Unmount" ) 
	#define CAL_SysParameterSettings_Unmount  SysParameterSettings_Unmount
	#define CHK_SysParameterSettings_Unmount  TRUE
	#define EXP_SysParameterSettings_Unmount  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_Unmount", (RTS_UINTPTR)SysParameterSettings_Unmount, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_Unmount
	#define EXT_SysParameterSettingsSysParameterSettings_Unmount
	#define GET_SysParameterSettingsSysParameterSettings_Unmount  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_Unmount pISysParameterSettings->ISysParameterSettings_Unmount
	#define CHK_SysParameterSettingsSysParameterSettings_Unmount (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_Unmount  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_Unmount
	#define EXT_SysParameterSettings_Unmount
	#define GET_SysParameterSettings_Unmount(fl)  CAL_CMGETAPI( "SysParameterSettings_Unmount" ) 
	#define CAL_SysParameterSettings_Unmount pISysParameterSettings->ISysParameterSettings_Unmount
	#define CHK_SysParameterSettings_Unmount (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_Unmount  CAL_CMEXPAPI( "SysParameterSettings_Unmount" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_Unmount  PFSYSPARAMETERSETTINGS_UNMOUNT pfSysParameterSettings_Unmount;
	#define EXT_SysParameterSettings_Unmount  extern PFSYSPARAMETERSETTINGS_UNMOUNT pfSysParameterSettings_Unmount;
	#define GET_SysParameterSettings_Unmount(fl)  s_pfCMGetAPI2( "SysParameterSettings_Unmount", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_Unmount, (fl), 0, 0)
	#define CAL_SysParameterSettings_Unmount  pfSysParameterSettings_Unmount
	#define CHK_SysParameterSettings_Unmount  (pfSysParameterSettings_Unmount != NULL)
	#define EXP_SysParameterSettings_Unmount  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_Unmount", (RTS_UINTPTR)SysParameterSettings_Unmount, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetProfinetName(char * pszName, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETPROFINETNAME) (char * pszName, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETPROFINETNAME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetProfinetName
	#define EXT_SysParameterSettings_GetProfinetName
	#define GET_SysParameterSettings_GetProfinetName(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetProfinetName(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetProfinetName  FALSE
	#define EXP_SysParameterSettings_GetProfinetName  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetProfinetName
	#define EXT_SysParameterSettings_GetProfinetName
	#define GET_SysParameterSettings_GetProfinetName(fl)  CAL_CMGETAPI( "SysParameterSettings_GetProfinetName" ) 
	#define CAL_SysParameterSettings_GetProfinetName  SysParameterSettings_GetProfinetName
	#define CHK_SysParameterSettings_GetProfinetName  TRUE
	#define EXP_SysParameterSettings_GetProfinetName  CAL_CMEXPAPI( "SysParameterSettings_GetProfinetName" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetProfinetName
	#define EXT_SysParameterSettings_GetProfinetName
	#define GET_SysParameterSettings_GetProfinetName(fl)  CAL_CMGETAPI( "SysParameterSettings_GetProfinetName" ) 
	#define CAL_SysParameterSettings_GetProfinetName  SysParameterSettings_GetProfinetName
	#define CHK_SysParameterSettings_GetProfinetName  TRUE
	#define EXP_SysParameterSettings_GetProfinetName  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetProfinetName", (RTS_UINTPTR)SysParameterSettings_GetProfinetName, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetProfinetName
	#define EXT_SysParameterSettingsSysParameterSettings_GetProfinetName
	#define GET_SysParameterSettingsSysParameterSettings_GetProfinetName  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetProfinetName pISysParameterSettings->ISysParameterSettings_GetProfinetName
	#define CHK_SysParameterSettingsSysParameterSettings_GetProfinetName (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetProfinetName  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetProfinetName
	#define EXT_SysParameterSettings_GetProfinetName
	#define GET_SysParameterSettings_GetProfinetName(fl)  CAL_CMGETAPI( "SysParameterSettings_GetProfinetName" ) 
	#define CAL_SysParameterSettings_GetProfinetName pISysParameterSettings->ISysParameterSettings_GetProfinetName
	#define CHK_SysParameterSettings_GetProfinetName (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetProfinetName  CAL_CMEXPAPI( "SysParameterSettings_GetProfinetName" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetProfinetName  PFSYSPARAMETERSETTINGS_GETPROFINETNAME pfSysParameterSettings_GetProfinetName;
	#define EXT_SysParameterSettings_GetProfinetName  extern PFSYSPARAMETERSETTINGS_GETPROFINETNAME pfSysParameterSettings_GetProfinetName;
	#define GET_SysParameterSettings_GetProfinetName(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetProfinetName", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetProfinetName, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetProfinetName  pfSysParameterSettings_GetProfinetName
	#define CHK_SysParameterSettings_GetProfinetName  (pfSysParameterSettings_GetProfinetName != NULL)
	#define EXP_SysParameterSettings_GetProfinetName  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetProfinetName", (RTS_UINTPTR)SysParameterSettings_GetProfinetName, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetProfinetName(char * pszName);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETPROFINETNAME) (char * pszName);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETPROFINETNAME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetProfinetName
	#define EXT_SysParameterSettings_SetProfinetName
	#define GET_SysParameterSettings_SetProfinetName(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetProfinetName(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetProfinetName  FALSE
	#define EXP_SysParameterSettings_SetProfinetName  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetProfinetName
	#define EXT_SysParameterSettings_SetProfinetName
	#define GET_SysParameterSettings_SetProfinetName(fl)  CAL_CMGETAPI( "SysParameterSettings_SetProfinetName" ) 
	#define CAL_SysParameterSettings_SetProfinetName  SysParameterSettings_SetProfinetName
	#define CHK_SysParameterSettings_SetProfinetName  TRUE
	#define EXP_SysParameterSettings_SetProfinetName  CAL_CMEXPAPI( "SysParameterSettings_SetProfinetName" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetProfinetName
	#define EXT_SysParameterSettings_SetProfinetName
	#define GET_SysParameterSettings_SetProfinetName(fl)  CAL_CMGETAPI( "SysParameterSettings_SetProfinetName" ) 
	#define CAL_SysParameterSettings_SetProfinetName  SysParameterSettings_SetProfinetName
	#define CHK_SysParameterSettings_SetProfinetName  TRUE
	#define EXP_SysParameterSettings_SetProfinetName  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetProfinetName", (RTS_UINTPTR)SysParameterSettings_SetProfinetName, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetProfinetName
	#define EXT_SysParameterSettingsSysParameterSettings_SetProfinetName
	#define GET_SysParameterSettingsSysParameterSettings_SetProfinetName  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetProfinetName pISysParameterSettings->ISysParameterSettings_SetProfinetName
	#define CHK_SysParameterSettingsSysParameterSettings_SetProfinetName (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetProfinetName  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetProfinetName
	#define EXT_SysParameterSettings_SetProfinetName
	#define GET_SysParameterSettings_SetProfinetName(fl)  CAL_CMGETAPI( "SysParameterSettings_SetProfinetName" ) 
	#define CAL_SysParameterSettings_SetProfinetName pISysParameterSettings->ISysParameterSettings_SetProfinetName
	#define CHK_SysParameterSettings_SetProfinetName (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetProfinetName  CAL_CMEXPAPI( "SysParameterSettings_SetProfinetName" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetProfinetName  PFSYSPARAMETERSETTINGS_SETPROFINETNAME pfSysParameterSettings_SetProfinetName;
	#define EXT_SysParameterSettings_SetProfinetName  extern PFSYSPARAMETERSETTINGS_SETPROFINETNAME pfSysParameterSettings_SetProfinetName;
	#define GET_SysParameterSettings_SetProfinetName(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetProfinetName", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetProfinetName, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetProfinetName  pfSysParameterSettings_SetProfinetName
	#define CHK_SysParameterSettings_SetProfinetName  (pfSysParameterSettings_SetProfinetName != NULL)
	#define EXP_SysParameterSettings_SetProfinetName  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetProfinetName", (RTS_UINTPTR)SysParameterSettings_SetProfinetName, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetMysqlBindAddress(char * pszBindAddress, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETMYSQLBINDADDRESS) (char * pszBindAddress, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETMYSQLBINDADDRESS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetMysqlBindAddress
	#define EXT_SysParameterSettings_GetMysqlBindAddress
	#define GET_SysParameterSettings_GetMysqlBindAddress(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetMysqlBindAddress(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetMysqlBindAddress  FALSE
	#define EXP_SysParameterSettings_GetMysqlBindAddress  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetMysqlBindAddress
	#define EXT_SysParameterSettings_GetMysqlBindAddress
	#define GET_SysParameterSettings_GetMysqlBindAddress(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlBindAddress" ) 
	#define CAL_SysParameterSettings_GetMysqlBindAddress  SysParameterSettings_GetMysqlBindAddress
	#define CHK_SysParameterSettings_GetMysqlBindAddress  TRUE
	#define EXP_SysParameterSettings_GetMysqlBindAddress  CAL_CMEXPAPI( "SysParameterSettings_GetMysqlBindAddress" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetMysqlBindAddress
	#define EXT_SysParameterSettings_GetMysqlBindAddress
	#define GET_SysParameterSettings_GetMysqlBindAddress(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlBindAddress" ) 
	#define CAL_SysParameterSettings_GetMysqlBindAddress  SysParameterSettings_GetMysqlBindAddress
	#define CHK_SysParameterSettings_GetMysqlBindAddress  TRUE
	#define EXP_SysParameterSettings_GetMysqlBindAddress  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMysqlBindAddress", (RTS_UINTPTR)SysParameterSettings_GetMysqlBindAddress, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetMysqlBindAddress
	#define EXT_SysParameterSettingsSysParameterSettings_GetMysqlBindAddress
	#define GET_SysParameterSettingsSysParameterSettings_GetMysqlBindAddress  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetMysqlBindAddress pISysParameterSettings->ISysParameterSettings_GetMysqlBindAddress
	#define CHK_SysParameterSettingsSysParameterSettings_GetMysqlBindAddress (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetMysqlBindAddress  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetMysqlBindAddress
	#define EXT_SysParameterSettings_GetMysqlBindAddress
	#define GET_SysParameterSettings_GetMysqlBindAddress(fl)  CAL_CMGETAPI( "SysParameterSettings_GetMysqlBindAddress" ) 
	#define CAL_SysParameterSettings_GetMysqlBindAddress pISysParameterSettings->ISysParameterSettings_GetMysqlBindAddress
	#define CHK_SysParameterSettings_GetMysqlBindAddress (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetMysqlBindAddress  CAL_CMEXPAPI( "SysParameterSettings_GetMysqlBindAddress" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetMysqlBindAddress  PFSYSPARAMETERSETTINGS_GETMYSQLBINDADDRESS pfSysParameterSettings_GetMysqlBindAddress;
	#define EXT_SysParameterSettings_GetMysqlBindAddress  extern PFSYSPARAMETERSETTINGS_GETMYSQLBINDADDRESS pfSysParameterSettings_GetMysqlBindAddress;
	#define GET_SysParameterSettings_GetMysqlBindAddress(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetMysqlBindAddress", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetMysqlBindAddress, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetMysqlBindAddress  pfSysParameterSettings_GetMysqlBindAddress
	#define CHK_SysParameterSettings_GetMysqlBindAddress  (pfSysParameterSettings_GetMysqlBindAddress != NULL)
	#define EXP_SysParameterSettings_GetMysqlBindAddress  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetMysqlBindAddress", (RTS_UINTPTR)SysParameterSettings_GetMysqlBindAddress, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetMysqlBindAddress(char * pszBindAddress);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETMYSQLBINDADDRESS) (char * pszBindAddress);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETMYSQLBINDADDRESS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetMysqlBindAddress
	#define EXT_SysParameterSettings_SetMysqlBindAddress
	#define GET_SysParameterSettings_SetMysqlBindAddress(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetMysqlBindAddress(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetMysqlBindAddress  FALSE
	#define EXP_SysParameterSettings_SetMysqlBindAddress  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetMysqlBindAddress
	#define EXT_SysParameterSettings_SetMysqlBindAddress
	#define GET_SysParameterSettings_SetMysqlBindAddress(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlBindAddress" ) 
	#define CAL_SysParameterSettings_SetMysqlBindAddress  SysParameterSettings_SetMysqlBindAddress
	#define CHK_SysParameterSettings_SetMysqlBindAddress  TRUE
	#define EXP_SysParameterSettings_SetMysqlBindAddress  CAL_CMEXPAPI( "SysParameterSettings_SetMysqlBindAddress" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetMysqlBindAddress
	#define EXT_SysParameterSettings_SetMysqlBindAddress
	#define GET_SysParameterSettings_SetMysqlBindAddress(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlBindAddress" ) 
	#define CAL_SysParameterSettings_SetMysqlBindAddress  SysParameterSettings_SetMysqlBindAddress
	#define CHK_SysParameterSettings_SetMysqlBindAddress  TRUE
	#define EXP_SysParameterSettings_SetMysqlBindAddress  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMysqlBindAddress", (RTS_UINTPTR)SysParameterSettings_SetMysqlBindAddress, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetMysqlBindAddress
	#define EXT_SysParameterSettingsSysParameterSettings_SetMysqlBindAddress
	#define GET_SysParameterSettingsSysParameterSettings_SetMysqlBindAddress  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetMysqlBindAddress pISysParameterSettings->ISysParameterSettings_SetMysqlBindAddress
	#define CHK_SysParameterSettingsSysParameterSettings_SetMysqlBindAddress (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetMysqlBindAddress  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetMysqlBindAddress
	#define EXT_SysParameterSettings_SetMysqlBindAddress
	#define GET_SysParameterSettings_SetMysqlBindAddress(fl)  CAL_CMGETAPI( "SysParameterSettings_SetMysqlBindAddress" ) 
	#define CAL_SysParameterSettings_SetMysqlBindAddress pISysParameterSettings->ISysParameterSettings_SetMysqlBindAddress
	#define CHK_SysParameterSettings_SetMysqlBindAddress (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetMysqlBindAddress  CAL_CMEXPAPI( "SysParameterSettings_SetMysqlBindAddress" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetMysqlBindAddress  PFSYSPARAMETERSETTINGS_SETMYSQLBINDADDRESS pfSysParameterSettings_SetMysqlBindAddress;
	#define EXT_SysParameterSettings_SetMysqlBindAddress  extern PFSYSPARAMETERSETTINGS_SETMYSQLBINDADDRESS pfSysParameterSettings_SetMysqlBindAddress;
	#define GET_SysParameterSettings_SetMysqlBindAddress(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetMysqlBindAddress", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetMysqlBindAddress, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetMysqlBindAddress  pfSysParameterSettings_SetMysqlBindAddress
	#define CHK_SysParameterSettings_SetMysqlBindAddress  (pfSysParameterSettings_SetMysqlBindAddress != NULL)
	#define EXP_SysParameterSettings_SetMysqlBindAddress  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetMysqlBindAddress", (RTS_UINTPTR)SysParameterSettings_SetMysqlBindAddress, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWebServerStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWEBSERVERSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWEBSERVERSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWebServerStatus
	#define EXT_SysParameterSettings_GetWebServerStatus
	#define GET_SysParameterSettings_GetWebServerStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWebServerStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWebServerStatus  FALSE
	#define EXP_SysParameterSettings_GetWebServerStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWebServerStatus
	#define EXT_SysParameterSettings_GetWebServerStatus
	#define GET_SysParameterSettings_GetWebServerStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerStatus" ) 
	#define CAL_SysParameterSettings_GetWebServerStatus  SysParameterSettings_GetWebServerStatus
	#define CHK_SysParameterSettings_GetWebServerStatus  TRUE
	#define EXP_SysParameterSettings_GetWebServerStatus  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWebServerStatus
	#define EXT_SysParameterSettings_GetWebServerStatus
	#define GET_SysParameterSettings_GetWebServerStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerStatus" ) 
	#define CAL_SysParameterSettings_GetWebServerStatus  SysParameterSettings_GetWebServerStatus
	#define CHK_SysParameterSettings_GetWebServerStatus  TRUE
	#define EXP_SysParameterSettings_GetWebServerStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerStatus", (RTS_UINTPTR)SysParameterSettings_GetWebServerStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWebServerStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetWebServerStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetWebServerStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWebServerStatus pISysParameterSettings->ISysParameterSettings_GetWebServerStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetWebServerStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWebServerStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWebServerStatus
	#define EXT_SysParameterSettings_GetWebServerStatus
	#define GET_SysParameterSettings_GetWebServerStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerStatus" ) 
	#define CAL_SysParameterSettings_GetWebServerStatus pISysParameterSettings->ISysParameterSettings_GetWebServerStatus
	#define CHK_SysParameterSettings_GetWebServerStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWebServerStatus  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWebServerStatus  PFSYSPARAMETERSETTINGS_GETWEBSERVERSTATUS pfSysParameterSettings_GetWebServerStatus;
	#define EXT_SysParameterSettings_GetWebServerStatus  extern PFSYSPARAMETERSETTINGS_GETWEBSERVERSTATUS pfSysParameterSettings_GetWebServerStatus;
	#define GET_SysParameterSettings_GetWebServerStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWebServerStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWebServerStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWebServerStatus  pfSysParameterSettings_GetWebServerStatus
	#define CHK_SysParameterSettings_GetWebServerStatus  (pfSysParameterSettings_GetWebServerStatus != NULL)
	#define EXP_SysParameterSettings_GetWebServerStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerStatus", (RTS_UINTPTR)SysParameterSettings_GetWebServerStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWebServerStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWEBSERVERSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWEBSERVERSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWebServerStatus
	#define EXT_SysParameterSettings_SetWebServerStatus
	#define GET_SysParameterSettings_SetWebServerStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWebServerStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWebServerStatus  FALSE
	#define EXP_SysParameterSettings_SetWebServerStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWebServerStatus
	#define EXT_SysParameterSettings_SetWebServerStatus
	#define GET_SysParameterSettings_SetWebServerStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerStatus" ) 
	#define CAL_SysParameterSettings_SetWebServerStatus  SysParameterSettings_SetWebServerStatus
	#define CHK_SysParameterSettings_SetWebServerStatus  TRUE
	#define EXP_SysParameterSettings_SetWebServerStatus  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWebServerStatus
	#define EXT_SysParameterSettings_SetWebServerStatus
	#define GET_SysParameterSettings_SetWebServerStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerStatus" ) 
	#define CAL_SysParameterSettings_SetWebServerStatus  SysParameterSettings_SetWebServerStatus
	#define CHK_SysParameterSettings_SetWebServerStatus  TRUE
	#define EXP_SysParameterSettings_SetWebServerStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerStatus", (RTS_UINTPTR)SysParameterSettings_SetWebServerStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWebServerStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetWebServerStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetWebServerStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWebServerStatus pISysParameterSettings->ISysParameterSettings_SetWebServerStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetWebServerStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWebServerStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWebServerStatus
	#define EXT_SysParameterSettings_SetWebServerStatus
	#define GET_SysParameterSettings_SetWebServerStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerStatus" ) 
	#define CAL_SysParameterSettings_SetWebServerStatus pISysParameterSettings->ISysParameterSettings_SetWebServerStatus
	#define CHK_SysParameterSettings_SetWebServerStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWebServerStatus  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWebServerStatus  PFSYSPARAMETERSETTINGS_SETWEBSERVERSTATUS pfSysParameterSettings_SetWebServerStatus;
	#define EXT_SysParameterSettings_SetWebServerStatus  extern PFSYSPARAMETERSETTINGS_SETWEBSERVERSTATUS pfSysParameterSettings_SetWebServerStatus;
	#define GET_SysParameterSettings_SetWebServerStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWebServerStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWebServerStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWebServerStatus  pfSysParameterSettings_SetWebServerStatus
	#define CHK_SysParameterSettings_SetWebServerStatus  (pfSysParameterSettings_SetWebServerStatus != NULL)
	#define EXP_SysParameterSettings_SetWebServerStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerStatus", (RTS_UINTPTR)SysParameterSettings_SetWebServerStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWebServerHTTP(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTP) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWEBSERVERHTTP_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWebServerHTTP
	#define EXT_SysParameterSettings_GetWebServerHTTP
	#define GET_SysParameterSettings_GetWebServerHTTP(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWebServerHTTP(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWebServerHTTP  FALSE
	#define EXP_SysParameterSettings_GetWebServerHTTP  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWebServerHTTP
	#define EXT_SysParameterSettings_GetWebServerHTTP
	#define GET_SysParameterSettings_GetWebServerHTTP(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTP" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTP  SysParameterSettings_GetWebServerHTTP
	#define CHK_SysParameterSettings_GetWebServerHTTP  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTP  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTP" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWebServerHTTP
	#define EXT_SysParameterSettings_GetWebServerHTTP
	#define GET_SysParameterSettings_GetWebServerHTTP(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTP" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTP  SysParameterSettings_GetWebServerHTTP
	#define CHK_SysParameterSettings_GetWebServerHTTP  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTP  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTP", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTP, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWebServerHTTP
	#define EXT_SysParameterSettingsSysParameterSettings_GetWebServerHTTP
	#define GET_SysParameterSettingsSysParameterSettings_GetWebServerHTTP  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWebServerHTTP pISysParameterSettings->ISysParameterSettings_GetWebServerHTTP
	#define CHK_SysParameterSettingsSysParameterSettings_GetWebServerHTTP (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWebServerHTTP  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWebServerHTTP
	#define EXT_SysParameterSettings_GetWebServerHTTP
	#define GET_SysParameterSettings_GetWebServerHTTP(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTP" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTP pISysParameterSettings->ISysParameterSettings_GetWebServerHTTP
	#define CHK_SysParameterSettings_GetWebServerHTTP (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTP  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTP" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWebServerHTTP  PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTP pfSysParameterSettings_GetWebServerHTTP;
	#define EXT_SysParameterSettings_GetWebServerHTTP  extern PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTP pfSysParameterSettings_GetWebServerHTTP;
	#define GET_SysParameterSettings_GetWebServerHTTP(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWebServerHTTP", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWebServerHTTP, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWebServerHTTP  pfSysParameterSettings_GetWebServerHTTP
	#define CHK_SysParameterSettings_GetWebServerHTTP  (pfSysParameterSettings_GetWebServerHTTP != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTP  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTP", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTP, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWebServerHTTP(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTP) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWEBSERVERHTTP_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWebServerHTTP
	#define EXT_SysParameterSettings_SetWebServerHTTP
	#define GET_SysParameterSettings_SetWebServerHTTP(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWebServerHTTP(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWebServerHTTP  FALSE
	#define EXP_SysParameterSettings_SetWebServerHTTP  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWebServerHTTP
	#define EXT_SysParameterSettings_SetWebServerHTTP
	#define GET_SysParameterSettings_SetWebServerHTTP(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTP" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTP  SysParameterSettings_SetWebServerHTTP
	#define CHK_SysParameterSettings_SetWebServerHTTP  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTP  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTP" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWebServerHTTP
	#define EXT_SysParameterSettings_SetWebServerHTTP
	#define GET_SysParameterSettings_SetWebServerHTTP(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTP" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTP  SysParameterSettings_SetWebServerHTTP
	#define CHK_SysParameterSettings_SetWebServerHTTP  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTP  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTP", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTP, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWebServerHTTP
	#define EXT_SysParameterSettingsSysParameterSettings_SetWebServerHTTP
	#define GET_SysParameterSettingsSysParameterSettings_SetWebServerHTTP  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWebServerHTTP pISysParameterSettings->ISysParameterSettings_SetWebServerHTTP
	#define CHK_SysParameterSettingsSysParameterSettings_SetWebServerHTTP (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWebServerHTTP  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWebServerHTTP
	#define EXT_SysParameterSettings_SetWebServerHTTP
	#define GET_SysParameterSettings_SetWebServerHTTP(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTP" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTP pISysParameterSettings->ISysParameterSettings_SetWebServerHTTP
	#define CHK_SysParameterSettings_SetWebServerHTTP (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTP  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTP" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWebServerHTTP  PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTP pfSysParameterSettings_SetWebServerHTTP;
	#define EXT_SysParameterSettings_SetWebServerHTTP  extern PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTP pfSysParameterSettings_SetWebServerHTTP;
	#define GET_SysParameterSettings_SetWebServerHTTP(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWebServerHTTP", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWebServerHTTP, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWebServerHTTP  pfSysParameterSettings_SetWebServerHTTP
	#define CHK_SysParameterSettings_SetWebServerHTTP  (pfSysParameterSettings_SetWebServerHTTP != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTP  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTP", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTP, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWebServerHTTPPort(RTS_UI32 *pport);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPPORT) (RTS_UI32 *pport);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWEBSERVERHTTPPORT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWebServerHTTPPort
	#define EXT_SysParameterSettings_GetWebServerHTTPPort
	#define GET_SysParameterSettings_GetWebServerHTTPPort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWebServerHTTPPort(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWebServerHTTPPort  FALSE
	#define EXP_SysParameterSettings_GetWebServerHTTPPort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWebServerHTTPPort
	#define EXT_SysParameterSettings_GetWebServerHTTPPort
	#define GET_SysParameterSettings_GetWebServerHTTPPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPPort" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPPort  SysParameterSettings_GetWebServerHTTPPort
	#define CHK_SysParameterSettings_GetWebServerHTTPPort  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTPPort  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTPPort" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWebServerHTTPPort
	#define EXT_SysParameterSettings_GetWebServerHTTPPort
	#define GET_SysParameterSettings_GetWebServerHTTPPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPPort" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPPort  SysParameterSettings_GetWebServerHTTPPort
	#define CHK_SysParameterSettings_GetWebServerHTTPPort  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTPPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTPPort", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTPPort, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWebServerHTTPPort
	#define EXT_SysParameterSettingsSysParameterSettings_GetWebServerHTTPPort
	#define GET_SysParameterSettingsSysParameterSettings_GetWebServerHTTPPort  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWebServerHTTPPort pISysParameterSettings->ISysParameterSettings_GetWebServerHTTPPort
	#define CHK_SysParameterSettingsSysParameterSettings_GetWebServerHTTPPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWebServerHTTPPort  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWebServerHTTPPort
	#define EXT_SysParameterSettings_GetWebServerHTTPPort
	#define GET_SysParameterSettings_GetWebServerHTTPPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPPort" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPPort pISysParameterSettings->ISysParameterSettings_GetWebServerHTTPPort
	#define CHK_SysParameterSettings_GetWebServerHTTPPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTPPort  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTPPort" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWebServerHTTPPort  PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPPORT pfSysParameterSettings_GetWebServerHTTPPort;
	#define EXT_SysParameterSettings_GetWebServerHTTPPort  extern PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPPORT pfSysParameterSettings_GetWebServerHTTPPort;
	#define GET_SysParameterSettings_GetWebServerHTTPPort(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWebServerHTTPPort", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWebServerHTTPPort, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWebServerHTTPPort  pfSysParameterSettings_GetWebServerHTTPPort
	#define CHK_SysParameterSettings_GetWebServerHTTPPort  (pfSysParameterSettings_GetWebServerHTTPPort != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTPPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTPPort", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTPPort, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWebServerHTTPPort(RTS_UI32 port);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPPORT) (RTS_UI32 port);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWEBSERVERHTTPPORT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWebServerHTTPPort
	#define EXT_SysParameterSettings_SetWebServerHTTPPort
	#define GET_SysParameterSettings_SetWebServerHTTPPort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWebServerHTTPPort(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWebServerHTTPPort  FALSE
	#define EXP_SysParameterSettings_SetWebServerHTTPPort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWebServerHTTPPort
	#define EXT_SysParameterSettings_SetWebServerHTTPPort
	#define GET_SysParameterSettings_SetWebServerHTTPPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPPort" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPPort  SysParameterSettings_SetWebServerHTTPPort
	#define CHK_SysParameterSettings_SetWebServerHTTPPort  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTPPort  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTPPort" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWebServerHTTPPort
	#define EXT_SysParameterSettings_SetWebServerHTTPPort
	#define GET_SysParameterSettings_SetWebServerHTTPPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPPort" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPPort  SysParameterSettings_SetWebServerHTTPPort
	#define CHK_SysParameterSettings_SetWebServerHTTPPort  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTPPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTPPort", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTPPort, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWebServerHTTPPort
	#define EXT_SysParameterSettingsSysParameterSettings_SetWebServerHTTPPort
	#define GET_SysParameterSettingsSysParameterSettings_SetWebServerHTTPPort  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWebServerHTTPPort pISysParameterSettings->ISysParameterSettings_SetWebServerHTTPPort
	#define CHK_SysParameterSettingsSysParameterSettings_SetWebServerHTTPPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWebServerHTTPPort  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWebServerHTTPPort
	#define EXT_SysParameterSettings_SetWebServerHTTPPort
	#define GET_SysParameterSettings_SetWebServerHTTPPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPPort" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPPort pISysParameterSettings->ISysParameterSettings_SetWebServerHTTPPort
	#define CHK_SysParameterSettings_SetWebServerHTTPPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTPPort  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTPPort" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWebServerHTTPPort  PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPPORT pfSysParameterSettings_SetWebServerHTTPPort;
	#define EXT_SysParameterSettings_SetWebServerHTTPPort  extern PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPPORT pfSysParameterSettings_SetWebServerHTTPPort;
	#define GET_SysParameterSettings_SetWebServerHTTPPort(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWebServerHTTPPort", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWebServerHTTPPort, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWebServerHTTPPort  pfSysParameterSettings_SetWebServerHTTPPort
	#define CHK_SysParameterSettings_SetWebServerHTTPPort  (pfSysParameterSettings_SetWebServerHTTPPort != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTPPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTPPort", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTPPort, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWebServerHTTPS(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWEBSERVERHTTPS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWebServerHTTPS
	#define EXT_SysParameterSettings_GetWebServerHTTPS
	#define GET_SysParameterSettings_GetWebServerHTTPS(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWebServerHTTPS(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWebServerHTTPS  FALSE
	#define EXP_SysParameterSettings_GetWebServerHTTPS  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWebServerHTTPS
	#define EXT_SysParameterSettings_GetWebServerHTTPS
	#define GET_SysParameterSettings_GetWebServerHTTPS(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPS" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPS  SysParameterSettings_GetWebServerHTTPS
	#define CHK_SysParameterSettings_GetWebServerHTTPS  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTPS  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTPS" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWebServerHTTPS
	#define EXT_SysParameterSettings_GetWebServerHTTPS
	#define GET_SysParameterSettings_GetWebServerHTTPS(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPS" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPS  SysParameterSettings_GetWebServerHTTPS
	#define CHK_SysParameterSettings_GetWebServerHTTPS  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTPS  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTPS", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTPS, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWebServerHTTPS
	#define EXT_SysParameterSettingsSysParameterSettings_GetWebServerHTTPS
	#define GET_SysParameterSettingsSysParameterSettings_GetWebServerHTTPS  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWebServerHTTPS pISysParameterSettings->ISysParameterSettings_GetWebServerHTTPS
	#define CHK_SysParameterSettingsSysParameterSettings_GetWebServerHTTPS (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWebServerHTTPS  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWebServerHTTPS
	#define EXT_SysParameterSettings_GetWebServerHTTPS
	#define GET_SysParameterSettings_GetWebServerHTTPS(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPS" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPS pISysParameterSettings->ISysParameterSettings_GetWebServerHTTPS
	#define CHK_SysParameterSettings_GetWebServerHTTPS (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTPS  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTPS" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWebServerHTTPS  PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPS pfSysParameterSettings_GetWebServerHTTPS;
	#define EXT_SysParameterSettings_GetWebServerHTTPS  extern PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPS pfSysParameterSettings_GetWebServerHTTPS;
	#define GET_SysParameterSettings_GetWebServerHTTPS(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWebServerHTTPS", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWebServerHTTPS, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWebServerHTTPS  pfSysParameterSettings_GetWebServerHTTPS
	#define CHK_SysParameterSettings_GetWebServerHTTPS  (pfSysParameterSettings_GetWebServerHTTPS != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTPS  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTPS", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTPS, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWebServerHTTPS(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWEBSERVERHTTPS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWebServerHTTPS
	#define EXT_SysParameterSettings_SetWebServerHTTPS
	#define GET_SysParameterSettings_SetWebServerHTTPS(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWebServerHTTPS(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWebServerHTTPS  FALSE
	#define EXP_SysParameterSettings_SetWebServerHTTPS  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWebServerHTTPS
	#define EXT_SysParameterSettings_SetWebServerHTTPS
	#define GET_SysParameterSettings_SetWebServerHTTPS(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPS" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPS  SysParameterSettings_SetWebServerHTTPS
	#define CHK_SysParameterSettings_SetWebServerHTTPS  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTPS  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTPS" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWebServerHTTPS
	#define EXT_SysParameterSettings_SetWebServerHTTPS
	#define GET_SysParameterSettings_SetWebServerHTTPS(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPS" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPS  SysParameterSettings_SetWebServerHTTPS
	#define CHK_SysParameterSettings_SetWebServerHTTPS  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTPS  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTPS", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTPS, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWebServerHTTPS
	#define EXT_SysParameterSettingsSysParameterSettings_SetWebServerHTTPS
	#define GET_SysParameterSettingsSysParameterSettings_SetWebServerHTTPS  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWebServerHTTPS pISysParameterSettings->ISysParameterSettings_SetWebServerHTTPS
	#define CHK_SysParameterSettingsSysParameterSettings_SetWebServerHTTPS (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWebServerHTTPS  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWebServerHTTPS
	#define EXT_SysParameterSettings_SetWebServerHTTPS
	#define GET_SysParameterSettings_SetWebServerHTTPS(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPS" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPS pISysParameterSettings->ISysParameterSettings_SetWebServerHTTPS
	#define CHK_SysParameterSettings_SetWebServerHTTPS (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTPS  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTPS" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWebServerHTTPS  PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPS pfSysParameterSettings_SetWebServerHTTPS;
	#define EXT_SysParameterSettings_SetWebServerHTTPS  extern PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPS pfSysParameterSettings_SetWebServerHTTPS;
	#define GET_SysParameterSettings_SetWebServerHTTPS(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWebServerHTTPS", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWebServerHTTPS, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWebServerHTTPS  pfSysParameterSettings_SetWebServerHTTPS
	#define CHK_SysParameterSettings_SetWebServerHTTPS  (pfSysParameterSettings_SetWebServerHTTPS != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTPS  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTPS", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTPS, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWebServerHTTPSPort(RTS_UI32 *pport);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPSPORT) (RTS_UI32 *pport);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWEBSERVERHTTPSPORT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWebServerHTTPSPort
	#define EXT_SysParameterSettings_GetWebServerHTTPSPort
	#define GET_SysParameterSettings_GetWebServerHTTPSPort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWebServerHTTPSPort(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWebServerHTTPSPort  FALSE
	#define EXP_SysParameterSettings_GetWebServerHTTPSPort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWebServerHTTPSPort
	#define EXT_SysParameterSettings_GetWebServerHTTPSPort
	#define GET_SysParameterSettings_GetWebServerHTTPSPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPSPort" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPSPort  SysParameterSettings_GetWebServerHTTPSPort
	#define CHK_SysParameterSettings_GetWebServerHTTPSPort  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTPSPort  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTPSPort" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWebServerHTTPSPort
	#define EXT_SysParameterSettings_GetWebServerHTTPSPort
	#define GET_SysParameterSettings_GetWebServerHTTPSPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPSPort" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPSPort  SysParameterSettings_GetWebServerHTTPSPort
	#define CHK_SysParameterSettings_GetWebServerHTTPSPort  TRUE
	#define EXP_SysParameterSettings_GetWebServerHTTPSPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTPSPort", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTPSPort, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWebServerHTTPSPort
	#define EXT_SysParameterSettingsSysParameterSettings_GetWebServerHTTPSPort
	#define GET_SysParameterSettingsSysParameterSettings_GetWebServerHTTPSPort  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWebServerHTTPSPort pISysParameterSettings->ISysParameterSettings_GetWebServerHTTPSPort
	#define CHK_SysParameterSettingsSysParameterSettings_GetWebServerHTTPSPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWebServerHTTPSPort  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWebServerHTTPSPort
	#define EXT_SysParameterSettings_GetWebServerHTTPSPort
	#define GET_SysParameterSettings_GetWebServerHTTPSPort(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWebServerHTTPSPort" ) 
	#define CAL_SysParameterSettings_GetWebServerHTTPSPort pISysParameterSettings->ISysParameterSettings_GetWebServerHTTPSPort
	#define CHK_SysParameterSettings_GetWebServerHTTPSPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTPSPort  CAL_CMEXPAPI( "SysParameterSettings_GetWebServerHTTPSPort" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWebServerHTTPSPort  PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPSPORT pfSysParameterSettings_GetWebServerHTTPSPort;
	#define EXT_SysParameterSettings_GetWebServerHTTPSPort  extern PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPSPORT pfSysParameterSettings_GetWebServerHTTPSPort;
	#define GET_SysParameterSettings_GetWebServerHTTPSPort(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWebServerHTTPSPort", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWebServerHTTPSPort, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWebServerHTTPSPort  pfSysParameterSettings_GetWebServerHTTPSPort
	#define CHK_SysParameterSettings_GetWebServerHTTPSPort  (pfSysParameterSettings_GetWebServerHTTPSPort != NULL)
	#define EXP_SysParameterSettings_GetWebServerHTTPSPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWebServerHTTPSPort", (RTS_UINTPTR)SysParameterSettings_GetWebServerHTTPSPort, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWebServerHTTPSPort(RTS_UI32 port);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPSPORT) (RTS_UI32 port);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWEBSERVERHTTPSPORT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWebServerHTTPSPort
	#define EXT_SysParameterSettings_SetWebServerHTTPSPort
	#define GET_SysParameterSettings_SetWebServerHTTPSPort(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWebServerHTTPSPort(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWebServerHTTPSPort  FALSE
	#define EXP_SysParameterSettings_SetWebServerHTTPSPort  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWebServerHTTPSPort
	#define EXT_SysParameterSettings_SetWebServerHTTPSPort
	#define GET_SysParameterSettings_SetWebServerHTTPSPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPSPort" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPSPort  SysParameterSettings_SetWebServerHTTPSPort
	#define CHK_SysParameterSettings_SetWebServerHTTPSPort  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTPSPort  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTPSPort" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWebServerHTTPSPort
	#define EXT_SysParameterSettings_SetWebServerHTTPSPort
	#define GET_SysParameterSettings_SetWebServerHTTPSPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPSPort" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPSPort  SysParameterSettings_SetWebServerHTTPSPort
	#define CHK_SysParameterSettings_SetWebServerHTTPSPort  TRUE
	#define EXP_SysParameterSettings_SetWebServerHTTPSPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTPSPort", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTPSPort, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWebServerHTTPSPort
	#define EXT_SysParameterSettingsSysParameterSettings_SetWebServerHTTPSPort
	#define GET_SysParameterSettingsSysParameterSettings_SetWebServerHTTPSPort  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWebServerHTTPSPort pISysParameterSettings->ISysParameterSettings_SetWebServerHTTPSPort
	#define CHK_SysParameterSettingsSysParameterSettings_SetWebServerHTTPSPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWebServerHTTPSPort  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWebServerHTTPSPort
	#define EXT_SysParameterSettings_SetWebServerHTTPSPort
	#define GET_SysParameterSettings_SetWebServerHTTPSPort(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWebServerHTTPSPort" ) 
	#define CAL_SysParameterSettings_SetWebServerHTTPSPort pISysParameterSettings->ISysParameterSettings_SetWebServerHTTPSPort
	#define CHK_SysParameterSettings_SetWebServerHTTPSPort (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTPSPort  CAL_CMEXPAPI( "SysParameterSettings_SetWebServerHTTPSPort" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWebServerHTTPSPort  PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPSPORT pfSysParameterSettings_SetWebServerHTTPSPort;
	#define EXT_SysParameterSettings_SetWebServerHTTPSPort  extern PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPSPORT pfSysParameterSettings_SetWebServerHTTPSPort;
	#define GET_SysParameterSettings_SetWebServerHTTPSPort(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWebServerHTTPSPort", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWebServerHTTPSPort, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWebServerHTTPSPort  pfSysParameterSettings_SetWebServerHTTPSPort
	#define CHK_SysParameterSettings_SetWebServerHTTPSPort  (pfSysParameterSettings_SetWebServerHTTPSPort != NULL)
	#define EXP_SysParameterSettings_SetWebServerHTTPSPort  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWebServerHTTPSPort", (RTS_UINTPTR)SysParameterSettings_SetWebServerHTTPSPort, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetLanguage(char * szLanguage, int buflen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETLANGUAGE) (char * szLanguage, int buflen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETLANGUAGE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetLanguage
	#define EXT_SysParameterSettings_GetLanguage
	#define GET_SysParameterSettings_GetLanguage(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetLanguage(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetLanguage  FALSE
	#define EXP_SysParameterSettings_GetLanguage  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetLanguage
	#define EXT_SysParameterSettings_GetLanguage
	#define GET_SysParameterSettings_GetLanguage(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLanguage" ) 
	#define CAL_SysParameterSettings_GetLanguage  SysParameterSettings_GetLanguage
	#define CHK_SysParameterSettings_GetLanguage  TRUE
	#define EXP_SysParameterSettings_GetLanguage  CAL_CMEXPAPI( "SysParameterSettings_GetLanguage" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetLanguage
	#define EXT_SysParameterSettings_GetLanguage
	#define GET_SysParameterSettings_GetLanguage(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLanguage" ) 
	#define CAL_SysParameterSettings_GetLanguage  SysParameterSettings_GetLanguage
	#define CHK_SysParameterSettings_GetLanguage  TRUE
	#define EXP_SysParameterSettings_GetLanguage  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetLanguage", (RTS_UINTPTR)SysParameterSettings_GetLanguage, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetLanguage
	#define EXT_SysParameterSettingsSysParameterSettings_GetLanguage
	#define GET_SysParameterSettingsSysParameterSettings_GetLanguage  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetLanguage pISysParameterSettings->ISysParameterSettings_GetLanguage
	#define CHK_SysParameterSettingsSysParameterSettings_GetLanguage (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetLanguage  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetLanguage
	#define EXT_SysParameterSettings_GetLanguage
	#define GET_SysParameterSettings_GetLanguage(fl)  CAL_CMGETAPI( "SysParameterSettings_GetLanguage" ) 
	#define CAL_SysParameterSettings_GetLanguage pISysParameterSettings->ISysParameterSettings_GetLanguage
	#define CHK_SysParameterSettings_GetLanguage (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetLanguage  CAL_CMEXPAPI( "SysParameterSettings_GetLanguage" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetLanguage  PFSYSPARAMETERSETTINGS_GETLANGUAGE pfSysParameterSettings_GetLanguage;
	#define EXT_SysParameterSettings_GetLanguage  extern PFSYSPARAMETERSETTINGS_GETLANGUAGE pfSysParameterSettings_GetLanguage;
	#define GET_SysParameterSettings_GetLanguage(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetLanguage", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetLanguage, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetLanguage  pfSysParameterSettings_GetLanguage
	#define CHK_SysParameterSettings_GetLanguage  (pfSysParameterSettings_GetLanguage != NULL)
	#define EXP_SysParameterSettings_GetLanguage  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetLanguage", (RTS_UINTPTR)SysParameterSettings_GetLanguage, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetLanguage(char * szLanguage);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETLANGUAGE) (char * szLanguage);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETLANGUAGE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetLanguage
	#define EXT_SysParameterSettings_SetLanguage
	#define GET_SysParameterSettings_SetLanguage(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetLanguage(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetLanguage  FALSE
	#define EXP_SysParameterSettings_SetLanguage  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetLanguage
	#define EXT_SysParameterSettings_SetLanguage
	#define GET_SysParameterSettings_SetLanguage(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLanguage" ) 
	#define CAL_SysParameterSettings_SetLanguage  SysParameterSettings_SetLanguage
	#define CHK_SysParameterSettings_SetLanguage  TRUE
	#define EXP_SysParameterSettings_SetLanguage  CAL_CMEXPAPI( "SysParameterSettings_SetLanguage" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetLanguage
	#define EXT_SysParameterSettings_SetLanguage
	#define GET_SysParameterSettings_SetLanguage(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLanguage" ) 
	#define CAL_SysParameterSettings_SetLanguage  SysParameterSettings_SetLanguage
	#define CHK_SysParameterSettings_SetLanguage  TRUE
	#define EXP_SysParameterSettings_SetLanguage  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetLanguage", (RTS_UINTPTR)SysParameterSettings_SetLanguage, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetLanguage
	#define EXT_SysParameterSettingsSysParameterSettings_SetLanguage
	#define GET_SysParameterSettingsSysParameterSettings_SetLanguage  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetLanguage pISysParameterSettings->ISysParameterSettings_SetLanguage
	#define CHK_SysParameterSettingsSysParameterSettings_SetLanguage (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetLanguage  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetLanguage
	#define EXT_SysParameterSettings_SetLanguage
	#define GET_SysParameterSettings_SetLanguage(fl)  CAL_CMGETAPI( "SysParameterSettings_SetLanguage" ) 
	#define CAL_SysParameterSettings_SetLanguage pISysParameterSettings->ISysParameterSettings_SetLanguage
	#define CHK_SysParameterSettings_SetLanguage (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetLanguage  CAL_CMEXPAPI( "SysParameterSettings_SetLanguage" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetLanguage  PFSYSPARAMETERSETTINGS_SETLANGUAGE pfSysParameterSettings_SetLanguage;
	#define EXT_SysParameterSettings_SetLanguage  extern PFSYSPARAMETERSETTINGS_SETLANGUAGE pfSysParameterSettings_SetLanguage;
	#define GET_SysParameterSettings_SetLanguage(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetLanguage", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetLanguage, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetLanguage  pfSysParameterSettings_SetLanguage
	#define CHK_SysParameterSettings_SetLanguage  (pfSysParameterSettings_SetLanguage != NULL)
	#define EXP_SysParameterSettings_SetLanguage  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetLanguage", (RTS_UINTPTR)SysParameterSettings_SetLanguage, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetQuickLaunchBarStatus(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARSTATUS) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETQUICKLAUNCHBARSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_GetQuickLaunchBarStatus
	#define GET_SysParameterSettings_GetQuickLaunchBarStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetQuickLaunchBarStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetQuickLaunchBarStatus  FALSE
	#define EXP_SysParameterSettings_GetQuickLaunchBarStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_GetQuickLaunchBarStatus
	#define GET_SysParameterSettings_GetQuickLaunchBarStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetQuickLaunchBarStatus" ) 
	#define CAL_SysParameterSettings_GetQuickLaunchBarStatus  SysParameterSettings_GetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_GetQuickLaunchBarStatus  TRUE
	#define EXP_SysParameterSettings_GetQuickLaunchBarStatus  CAL_CMEXPAPI( "SysParameterSettings_GetQuickLaunchBarStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_GetQuickLaunchBarStatus
	#define GET_SysParameterSettings_GetQuickLaunchBarStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetQuickLaunchBarStatus" ) 
	#define CAL_SysParameterSettings_GetQuickLaunchBarStatus  SysParameterSettings_GetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_GetQuickLaunchBarStatus  TRUE
	#define EXP_SysParameterSettings_GetQuickLaunchBarStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetQuickLaunchBarStatus", (RTS_UINTPTR)SysParameterSettings_GetQuickLaunchBarStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarStatus
	#define EXT_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarStatus
	#define GET_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarStatus pISysParameterSettings->ISysParameterSettings_GetQuickLaunchBarStatus
	#define CHK_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_GetQuickLaunchBarStatus
	#define GET_SysParameterSettings_GetQuickLaunchBarStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetQuickLaunchBarStatus" ) 
	#define CAL_SysParameterSettings_GetQuickLaunchBarStatus pISysParameterSettings->ISysParameterSettings_GetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_GetQuickLaunchBarStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetQuickLaunchBarStatus  CAL_CMEXPAPI( "SysParameterSettings_GetQuickLaunchBarStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetQuickLaunchBarStatus  PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARSTATUS pfSysParameterSettings_GetQuickLaunchBarStatus;
	#define EXT_SysParameterSettings_GetQuickLaunchBarStatus  extern PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARSTATUS pfSysParameterSettings_GetQuickLaunchBarStatus;
	#define GET_SysParameterSettings_GetQuickLaunchBarStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetQuickLaunchBarStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetQuickLaunchBarStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetQuickLaunchBarStatus  pfSysParameterSettings_GetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_GetQuickLaunchBarStatus  (pfSysParameterSettings_GetQuickLaunchBarStatus != NULL)
	#define EXP_SysParameterSettings_GetQuickLaunchBarStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetQuickLaunchBarStatus", (RTS_UINTPTR)SysParameterSettings_GetQuickLaunchBarStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetQuickLaunchBarStatus(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARSTATUS) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETQUICKLAUNCHBARSTATUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_SetQuickLaunchBarStatus
	#define GET_SysParameterSettings_SetQuickLaunchBarStatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetQuickLaunchBarStatus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetQuickLaunchBarStatus  FALSE
	#define EXP_SysParameterSettings_SetQuickLaunchBarStatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_SetQuickLaunchBarStatus
	#define GET_SysParameterSettings_SetQuickLaunchBarStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetQuickLaunchBarStatus" ) 
	#define CAL_SysParameterSettings_SetQuickLaunchBarStatus  SysParameterSettings_SetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_SetQuickLaunchBarStatus  TRUE
	#define EXP_SysParameterSettings_SetQuickLaunchBarStatus  CAL_CMEXPAPI( "SysParameterSettings_SetQuickLaunchBarStatus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_SetQuickLaunchBarStatus
	#define GET_SysParameterSettings_SetQuickLaunchBarStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetQuickLaunchBarStatus" ) 
	#define CAL_SysParameterSettings_SetQuickLaunchBarStatus  SysParameterSettings_SetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_SetQuickLaunchBarStatus  TRUE
	#define EXP_SysParameterSettings_SetQuickLaunchBarStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetQuickLaunchBarStatus", (RTS_UINTPTR)SysParameterSettings_SetQuickLaunchBarStatus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarStatus
	#define EXT_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarStatus
	#define GET_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarStatus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarStatus pISysParameterSettings->ISysParameterSettings_SetQuickLaunchBarStatus
	#define CHK_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarStatus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetQuickLaunchBarStatus
	#define EXT_SysParameterSettings_SetQuickLaunchBarStatus
	#define GET_SysParameterSettings_SetQuickLaunchBarStatus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetQuickLaunchBarStatus" ) 
	#define CAL_SysParameterSettings_SetQuickLaunchBarStatus pISysParameterSettings->ISysParameterSettings_SetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_SetQuickLaunchBarStatus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetQuickLaunchBarStatus  CAL_CMEXPAPI( "SysParameterSettings_SetQuickLaunchBarStatus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetQuickLaunchBarStatus  PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARSTATUS pfSysParameterSettings_SetQuickLaunchBarStatus;
	#define EXT_SysParameterSettings_SetQuickLaunchBarStatus  extern PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARSTATUS pfSysParameterSettings_SetQuickLaunchBarStatus;
	#define GET_SysParameterSettings_SetQuickLaunchBarStatus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetQuickLaunchBarStatus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetQuickLaunchBarStatus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetQuickLaunchBarStatus  pfSysParameterSettings_SetQuickLaunchBarStatus
	#define CHK_SysParameterSettings_SetQuickLaunchBarStatus  (pfSysParameterSettings_SetQuickLaunchBarStatus != NULL)
	#define EXP_SysParameterSettings_SetQuickLaunchBarStatus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetQuickLaunchBarStatus", (RTS_UINTPTR)SysParameterSettings_SetQuickLaunchBarStatus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetQuickLaunchBarMenus(char * szMenus, int buflen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARMENUS) (char * szMenus, int buflen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETQUICKLAUNCHBARMENUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_GetQuickLaunchBarMenus
	#define GET_SysParameterSettings_GetQuickLaunchBarMenus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetQuickLaunchBarMenus(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetQuickLaunchBarMenus  FALSE
	#define EXP_SysParameterSettings_GetQuickLaunchBarMenus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_GetQuickLaunchBarMenus
	#define GET_SysParameterSettings_GetQuickLaunchBarMenus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetQuickLaunchBarMenus" ) 
	#define CAL_SysParameterSettings_GetQuickLaunchBarMenus  SysParameterSettings_GetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_GetQuickLaunchBarMenus  TRUE
	#define EXP_SysParameterSettings_GetQuickLaunchBarMenus  CAL_CMEXPAPI( "SysParameterSettings_GetQuickLaunchBarMenus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_GetQuickLaunchBarMenus
	#define GET_SysParameterSettings_GetQuickLaunchBarMenus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetQuickLaunchBarMenus" ) 
	#define CAL_SysParameterSettings_GetQuickLaunchBarMenus  SysParameterSettings_GetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_GetQuickLaunchBarMenus  TRUE
	#define EXP_SysParameterSettings_GetQuickLaunchBarMenus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetQuickLaunchBarMenus", (RTS_UINTPTR)SysParameterSettings_GetQuickLaunchBarMenus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarMenus
	#define EXT_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarMenus
	#define GET_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarMenus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarMenus pISysParameterSettings->ISysParameterSettings_GetQuickLaunchBarMenus
	#define CHK_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarMenus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetQuickLaunchBarMenus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_GetQuickLaunchBarMenus
	#define GET_SysParameterSettings_GetQuickLaunchBarMenus(fl)  CAL_CMGETAPI( "SysParameterSettings_GetQuickLaunchBarMenus" ) 
	#define CAL_SysParameterSettings_GetQuickLaunchBarMenus pISysParameterSettings->ISysParameterSettings_GetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_GetQuickLaunchBarMenus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetQuickLaunchBarMenus  CAL_CMEXPAPI( "SysParameterSettings_GetQuickLaunchBarMenus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetQuickLaunchBarMenus  PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARMENUS pfSysParameterSettings_GetQuickLaunchBarMenus;
	#define EXT_SysParameterSettings_GetQuickLaunchBarMenus  extern PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARMENUS pfSysParameterSettings_GetQuickLaunchBarMenus;
	#define GET_SysParameterSettings_GetQuickLaunchBarMenus(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetQuickLaunchBarMenus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetQuickLaunchBarMenus, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetQuickLaunchBarMenus  pfSysParameterSettings_GetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_GetQuickLaunchBarMenus  (pfSysParameterSettings_GetQuickLaunchBarMenus != NULL)
	#define EXP_SysParameterSettings_GetQuickLaunchBarMenus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetQuickLaunchBarMenus", (RTS_UINTPTR)SysParameterSettings_GetQuickLaunchBarMenus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetQuickLaunchBarMenus(char * szMenus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARMENUS) (char * szMenus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETQUICKLAUNCHBARMENUS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_SetQuickLaunchBarMenus
	#define GET_SysParameterSettings_SetQuickLaunchBarMenus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetQuickLaunchBarMenus(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetQuickLaunchBarMenus  FALSE
	#define EXP_SysParameterSettings_SetQuickLaunchBarMenus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_SetQuickLaunchBarMenus
	#define GET_SysParameterSettings_SetQuickLaunchBarMenus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetQuickLaunchBarMenus" ) 
	#define CAL_SysParameterSettings_SetQuickLaunchBarMenus  SysParameterSettings_SetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_SetQuickLaunchBarMenus  TRUE
	#define EXP_SysParameterSettings_SetQuickLaunchBarMenus  CAL_CMEXPAPI( "SysParameterSettings_SetQuickLaunchBarMenus" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_SetQuickLaunchBarMenus
	#define GET_SysParameterSettings_SetQuickLaunchBarMenus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetQuickLaunchBarMenus" ) 
	#define CAL_SysParameterSettings_SetQuickLaunchBarMenus  SysParameterSettings_SetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_SetQuickLaunchBarMenus  TRUE
	#define EXP_SysParameterSettings_SetQuickLaunchBarMenus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetQuickLaunchBarMenus", (RTS_UINTPTR)SysParameterSettings_SetQuickLaunchBarMenus, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarMenus
	#define EXT_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarMenus
	#define GET_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarMenus  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarMenus pISysParameterSettings->ISysParameterSettings_SetQuickLaunchBarMenus
	#define CHK_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarMenus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetQuickLaunchBarMenus  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetQuickLaunchBarMenus
	#define EXT_SysParameterSettings_SetQuickLaunchBarMenus
	#define GET_SysParameterSettings_SetQuickLaunchBarMenus(fl)  CAL_CMGETAPI( "SysParameterSettings_SetQuickLaunchBarMenus" ) 
	#define CAL_SysParameterSettings_SetQuickLaunchBarMenus pISysParameterSettings->ISysParameterSettings_SetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_SetQuickLaunchBarMenus (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetQuickLaunchBarMenus  CAL_CMEXPAPI( "SysParameterSettings_SetQuickLaunchBarMenus" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetQuickLaunchBarMenus  PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARMENUS pfSysParameterSettings_SetQuickLaunchBarMenus;
	#define EXT_SysParameterSettings_SetQuickLaunchBarMenus  extern PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARMENUS pfSysParameterSettings_SetQuickLaunchBarMenus;
	#define GET_SysParameterSettings_SetQuickLaunchBarMenus(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetQuickLaunchBarMenus", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetQuickLaunchBarMenus, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetQuickLaunchBarMenus  pfSysParameterSettings_SetQuickLaunchBarMenus
	#define CHK_SysParameterSettings_SetQuickLaunchBarMenus  (pfSysParameterSettings_SetQuickLaunchBarMenus != NULL)
	#define EXP_SysParameterSettings_SetQuickLaunchBarMenus  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetQuickLaunchBarMenus", (RTS_UINTPTR)SysParameterSettings_SetQuickLaunchBarMenus, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetFonts(char * szFonts, RTS_IEC_DWORD* pSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETFONTS) (char * szFonts, RTS_IEC_DWORD* pSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETFONTS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetFonts
	#define EXT_SysParameterSettings_GetFonts
	#define GET_SysParameterSettings_GetFonts(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetFonts(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetFonts  FALSE
	#define EXP_SysParameterSettings_GetFonts  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetFonts
	#define EXT_SysParameterSettings_GetFonts
	#define GET_SysParameterSettings_GetFonts(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFonts" ) 
	#define CAL_SysParameterSettings_GetFonts  SysParameterSettings_GetFonts
	#define CHK_SysParameterSettings_GetFonts  TRUE
	#define EXP_SysParameterSettings_GetFonts  CAL_CMEXPAPI( "SysParameterSettings_GetFonts" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetFonts
	#define EXT_SysParameterSettings_GetFonts
	#define GET_SysParameterSettings_GetFonts(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFonts" ) 
	#define CAL_SysParameterSettings_GetFonts  SysParameterSettings_GetFonts
	#define CHK_SysParameterSettings_GetFonts  TRUE
	#define EXP_SysParameterSettings_GetFonts  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFonts", (RTS_UINTPTR)SysParameterSettings_GetFonts, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetFonts
	#define EXT_SysParameterSettingsSysParameterSettings_GetFonts
	#define GET_SysParameterSettingsSysParameterSettings_GetFonts  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetFonts pISysParameterSettings->ISysParameterSettings_GetFonts
	#define CHK_SysParameterSettingsSysParameterSettings_GetFonts (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetFonts  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetFonts
	#define EXT_SysParameterSettings_GetFonts
	#define GET_SysParameterSettings_GetFonts(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFonts" ) 
	#define CAL_SysParameterSettings_GetFonts pISysParameterSettings->ISysParameterSettings_GetFonts
	#define CHK_SysParameterSettings_GetFonts (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetFonts  CAL_CMEXPAPI( "SysParameterSettings_GetFonts" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetFonts  PFSYSPARAMETERSETTINGS_GETFONTS pfSysParameterSettings_GetFonts;
	#define EXT_SysParameterSettings_GetFonts  extern PFSYSPARAMETERSETTINGS_GETFONTS pfSysParameterSettings_GetFonts;
	#define GET_SysParameterSettings_GetFonts(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetFonts", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetFonts, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetFonts  pfSysParameterSettings_GetFonts
	#define CHK_SysParameterSettings_GetFonts  (pfSysParameterSettings_GetFonts != NULL)
	#define EXP_SysParameterSettings_GetFonts  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFonts", (RTS_UINTPTR)SysParameterSettings_GetFonts, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetFontsFamilies(char * szFonts, RTS_IEC_DWORD* pSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETFONTSFAMILIES) (char * szFonts, RTS_IEC_DWORD* pSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETFONTSFAMILIES_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetFontsFamilies
	#define EXT_SysParameterSettings_GetFontsFamilies
	#define GET_SysParameterSettings_GetFontsFamilies(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetFontsFamilies(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetFontsFamilies  FALSE
	#define EXP_SysParameterSettings_GetFontsFamilies  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetFontsFamilies
	#define EXT_SysParameterSettings_GetFontsFamilies
	#define GET_SysParameterSettings_GetFontsFamilies(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFontsFamilies" ) 
	#define CAL_SysParameterSettings_GetFontsFamilies  SysParameterSettings_GetFontsFamilies
	#define CHK_SysParameterSettings_GetFontsFamilies  TRUE
	#define EXP_SysParameterSettings_GetFontsFamilies  CAL_CMEXPAPI( "SysParameterSettings_GetFontsFamilies" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetFontsFamilies
	#define EXT_SysParameterSettings_GetFontsFamilies
	#define GET_SysParameterSettings_GetFontsFamilies(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFontsFamilies" ) 
	#define CAL_SysParameterSettings_GetFontsFamilies  SysParameterSettings_GetFontsFamilies
	#define CHK_SysParameterSettings_GetFontsFamilies  TRUE
	#define EXP_SysParameterSettings_GetFontsFamilies  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFontsFamilies", (RTS_UINTPTR)SysParameterSettings_GetFontsFamilies, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetFontsFamilies
	#define EXT_SysParameterSettingsSysParameterSettings_GetFontsFamilies
	#define GET_SysParameterSettingsSysParameterSettings_GetFontsFamilies  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetFontsFamilies pISysParameterSettings->ISysParameterSettings_GetFontsFamilies
	#define CHK_SysParameterSettingsSysParameterSettings_GetFontsFamilies (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetFontsFamilies  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetFontsFamilies
	#define EXT_SysParameterSettings_GetFontsFamilies
	#define GET_SysParameterSettings_GetFontsFamilies(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFontsFamilies" ) 
	#define CAL_SysParameterSettings_GetFontsFamilies pISysParameterSettings->ISysParameterSettings_GetFontsFamilies
	#define CHK_SysParameterSettings_GetFontsFamilies (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetFontsFamilies  CAL_CMEXPAPI( "SysParameterSettings_GetFontsFamilies" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetFontsFamilies  PFSYSPARAMETERSETTINGS_GETFONTSFAMILIES pfSysParameterSettings_GetFontsFamilies;
	#define EXT_SysParameterSettings_GetFontsFamilies  extern PFSYSPARAMETERSETTINGS_GETFONTSFAMILIES pfSysParameterSettings_GetFontsFamilies;
	#define GET_SysParameterSettings_GetFontsFamilies(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetFontsFamilies", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetFontsFamilies, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetFontsFamilies  pfSysParameterSettings_GetFontsFamilies
	#define CHK_SysParameterSettings_GetFontsFamilies  (pfSysParameterSettings_GetFontsFamilies != NULL)
	#define EXP_SysParameterSettings_GetFontsFamilies  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFontsFamilies", (RTS_UINTPTR)SysParameterSettings_GetFontsFamilies, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_DeleteFont(char * szFont);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_DELETEFONT) (char * szFont);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_DELETEFONT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_DeleteFont
	#define EXT_SysParameterSettings_DeleteFont
	#define GET_SysParameterSettings_DeleteFont(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_DeleteFont(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_DeleteFont  FALSE
	#define EXP_SysParameterSettings_DeleteFont  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_DeleteFont
	#define EXT_SysParameterSettings_DeleteFont
	#define GET_SysParameterSettings_DeleteFont(fl)  CAL_CMGETAPI( "SysParameterSettings_DeleteFont" ) 
	#define CAL_SysParameterSettings_DeleteFont  SysParameterSettings_DeleteFont
	#define CHK_SysParameterSettings_DeleteFont  TRUE
	#define EXP_SysParameterSettings_DeleteFont  CAL_CMEXPAPI( "SysParameterSettings_DeleteFont" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_DeleteFont
	#define EXT_SysParameterSettings_DeleteFont
	#define GET_SysParameterSettings_DeleteFont(fl)  CAL_CMGETAPI( "SysParameterSettings_DeleteFont" ) 
	#define CAL_SysParameterSettings_DeleteFont  SysParameterSettings_DeleteFont
	#define CHK_SysParameterSettings_DeleteFont  TRUE
	#define EXP_SysParameterSettings_DeleteFont  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_DeleteFont", (RTS_UINTPTR)SysParameterSettings_DeleteFont, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_DeleteFont
	#define EXT_SysParameterSettingsSysParameterSettings_DeleteFont
	#define GET_SysParameterSettingsSysParameterSettings_DeleteFont  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_DeleteFont pISysParameterSettings->ISysParameterSettings_DeleteFont
	#define CHK_SysParameterSettingsSysParameterSettings_DeleteFont (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_DeleteFont  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_DeleteFont
	#define EXT_SysParameterSettings_DeleteFont
	#define GET_SysParameterSettings_DeleteFont(fl)  CAL_CMGETAPI( "SysParameterSettings_DeleteFont" ) 
	#define CAL_SysParameterSettings_DeleteFont pISysParameterSettings->ISysParameterSettings_DeleteFont
	#define CHK_SysParameterSettings_DeleteFont (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_DeleteFont  CAL_CMEXPAPI( "SysParameterSettings_DeleteFont" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_DeleteFont  PFSYSPARAMETERSETTINGS_DELETEFONT pfSysParameterSettings_DeleteFont;
	#define EXT_SysParameterSettings_DeleteFont  extern PFSYSPARAMETERSETTINGS_DELETEFONT pfSysParameterSettings_DeleteFont;
	#define GET_SysParameterSettings_DeleteFont(fl)  s_pfCMGetAPI2( "SysParameterSettings_DeleteFont", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_DeleteFont, (fl), 0, 0)
	#define CAL_SysParameterSettings_DeleteFont  pfSysParameterSettings_DeleteFont
	#define CHK_SysParameterSettings_DeleteFont  (pfSysParameterSettings_DeleteFont != NULL)
	#define EXP_SysParameterSettings_DeleteFont  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_DeleteFont", (RTS_UINTPTR)SysParameterSettings_DeleteFont, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SubstituteFont(char * szFontToSubstitute, char* szFont);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SUBSTITUTEFONT) (char * szFontToSubstitute, char* szFont);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SUBSTITUTEFONT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SubstituteFont
	#define EXT_SysParameterSettings_SubstituteFont
	#define GET_SysParameterSettings_SubstituteFont(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SubstituteFont(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SubstituteFont  FALSE
	#define EXP_SysParameterSettings_SubstituteFont  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SubstituteFont
	#define EXT_SysParameterSettings_SubstituteFont
	#define GET_SysParameterSettings_SubstituteFont(fl)  CAL_CMGETAPI( "SysParameterSettings_SubstituteFont" ) 
	#define CAL_SysParameterSettings_SubstituteFont  SysParameterSettings_SubstituteFont
	#define CHK_SysParameterSettings_SubstituteFont  TRUE
	#define EXP_SysParameterSettings_SubstituteFont  CAL_CMEXPAPI( "SysParameterSettings_SubstituteFont" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SubstituteFont
	#define EXT_SysParameterSettings_SubstituteFont
	#define GET_SysParameterSettings_SubstituteFont(fl)  CAL_CMGETAPI( "SysParameterSettings_SubstituteFont" ) 
	#define CAL_SysParameterSettings_SubstituteFont  SysParameterSettings_SubstituteFont
	#define CHK_SysParameterSettings_SubstituteFont  TRUE
	#define EXP_SysParameterSettings_SubstituteFont  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SubstituteFont", (RTS_UINTPTR)SysParameterSettings_SubstituteFont, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SubstituteFont
	#define EXT_SysParameterSettingsSysParameterSettings_SubstituteFont
	#define GET_SysParameterSettingsSysParameterSettings_SubstituteFont  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SubstituteFont pISysParameterSettings->ISysParameterSettings_SubstituteFont
	#define CHK_SysParameterSettingsSysParameterSettings_SubstituteFont (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SubstituteFont  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SubstituteFont
	#define EXT_SysParameterSettings_SubstituteFont
	#define GET_SysParameterSettings_SubstituteFont(fl)  CAL_CMGETAPI( "SysParameterSettings_SubstituteFont" ) 
	#define CAL_SysParameterSettings_SubstituteFont pISysParameterSettings->ISysParameterSettings_SubstituteFont
	#define CHK_SysParameterSettings_SubstituteFont (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SubstituteFont  CAL_CMEXPAPI( "SysParameterSettings_SubstituteFont" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SubstituteFont  PFSYSPARAMETERSETTINGS_SUBSTITUTEFONT pfSysParameterSettings_SubstituteFont;
	#define EXT_SysParameterSettings_SubstituteFont  extern PFSYSPARAMETERSETTINGS_SUBSTITUTEFONT pfSysParameterSettings_SubstituteFont;
	#define GET_SysParameterSettings_SubstituteFont(fl)  s_pfCMGetAPI2( "SysParameterSettings_SubstituteFont", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SubstituteFont, (fl), 0, 0)
	#define CAL_SysParameterSettings_SubstituteFont  pfSysParameterSettings_SubstituteFont
	#define CHK_SysParameterSettings_SubstituteFont  (pfSysParameterSettings_SubstituteFont != NULL)
	#define EXP_SysParameterSettings_SubstituteFont  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SubstituteFont", (RTS_UINTPTR)SysParameterSettings_SubstituteFont, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetFontsSubst(char * szFontsSubst, RTS_IEC_DWORD* pSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETFONTSSUBST) (char * szFontsSubst, RTS_IEC_DWORD* pSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETFONTSSUBST_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetFontsSubst
	#define EXT_SysParameterSettings_GetFontsSubst
	#define GET_SysParameterSettings_GetFontsSubst(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetFontsSubst(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetFontsSubst  FALSE
	#define EXP_SysParameterSettings_GetFontsSubst  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetFontsSubst
	#define EXT_SysParameterSettings_GetFontsSubst
	#define GET_SysParameterSettings_GetFontsSubst(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFontsSubst" ) 
	#define CAL_SysParameterSettings_GetFontsSubst  SysParameterSettings_GetFontsSubst
	#define CHK_SysParameterSettings_GetFontsSubst  TRUE
	#define EXP_SysParameterSettings_GetFontsSubst  CAL_CMEXPAPI( "SysParameterSettings_GetFontsSubst" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetFontsSubst
	#define EXT_SysParameterSettings_GetFontsSubst
	#define GET_SysParameterSettings_GetFontsSubst(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFontsSubst" ) 
	#define CAL_SysParameterSettings_GetFontsSubst  SysParameterSettings_GetFontsSubst
	#define CHK_SysParameterSettings_GetFontsSubst  TRUE
	#define EXP_SysParameterSettings_GetFontsSubst  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFontsSubst", (RTS_UINTPTR)SysParameterSettings_GetFontsSubst, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetFontsSubst
	#define EXT_SysParameterSettingsSysParameterSettings_GetFontsSubst
	#define GET_SysParameterSettingsSysParameterSettings_GetFontsSubst  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetFontsSubst pISysParameterSettings->ISysParameterSettings_GetFontsSubst
	#define CHK_SysParameterSettingsSysParameterSettings_GetFontsSubst (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetFontsSubst  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetFontsSubst
	#define EXT_SysParameterSettings_GetFontsSubst
	#define GET_SysParameterSettings_GetFontsSubst(fl)  CAL_CMGETAPI( "SysParameterSettings_GetFontsSubst" ) 
	#define CAL_SysParameterSettings_GetFontsSubst pISysParameterSettings->ISysParameterSettings_GetFontsSubst
	#define CHK_SysParameterSettings_GetFontsSubst (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetFontsSubst  CAL_CMEXPAPI( "SysParameterSettings_GetFontsSubst" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetFontsSubst  PFSYSPARAMETERSETTINGS_GETFONTSSUBST pfSysParameterSettings_GetFontsSubst;
	#define EXT_SysParameterSettings_GetFontsSubst  extern PFSYSPARAMETERSETTINGS_GETFONTSSUBST pfSysParameterSettings_GetFontsSubst;
	#define GET_SysParameterSettings_GetFontsSubst(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetFontsSubst", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetFontsSubst, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetFontsSubst  pfSysParameterSettings_GetFontsSubst
	#define CHK_SysParameterSettings_GetFontsSubst  (pfSysParameterSettings_GetFontsSubst != NULL)
	#define EXP_SysParameterSettings_GetFontsSubst  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetFontsSubst", (RTS_UINTPTR)SysParameterSettings_GetFontsSubst, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetFontsSubst(char * szFontsSubst, RTS_IEC_DWORD siSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETFONTSSUBST) (char * szFontsSubst, RTS_IEC_DWORD siSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETFONTSSUBST_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetFontsSubst
	#define EXT_SysParameterSettings_SetFontsSubst
	#define GET_SysParameterSettings_SetFontsSubst(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetFontsSubst(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetFontsSubst  FALSE
	#define EXP_SysParameterSettings_SetFontsSubst  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetFontsSubst
	#define EXT_SysParameterSettings_SetFontsSubst
	#define GET_SysParameterSettings_SetFontsSubst(fl)  CAL_CMGETAPI( "SysParameterSettings_SetFontsSubst" ) 
	#define CAL_SysParameterSettings_SetFontsSubst  SysParameterSettings_SetFontsSubst
	#define CHK_SysParameterSettings_SetFontsSubst  TRUE
	#define EXP_SysParameterSettings_SetFontsSubst  CAL_CMEXPAPI( "SysParameterSettings_SetFontsSubst" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetFontsSubst
	#define EXT_SysParameterSettings_SetFontsSubst
	#define GET_SysParameterSettings_SetFontsSubst(fl)  CAL_CMGETAPI( "SysParameterSettings_SetFontsSubst" ) 
	#define CAL_SysParameterSettings_SetFontsSubst  SysParameterSettings_SetFontsSubst
	#define CHK_SysParameterSettings_SetFontsSubst  TRUE
	#define EXP_SysParameterSettings_SetFontsSubst  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetFontsSubst", (RTS_UINTPTR)SysParameterSettings_SetFontsSubst, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetFontsSubst
	#define EXT_SysParameterSettingsSysParameterSettings_SetFontsSubst
	#define GET_SysParameterSettingsSysParameterSettings_SetFontsSubst  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetFontsSubst pISysParameterSettings->ISysParameterSettings_SetFontsSubst
	#define CHK_SysParameterSettingsSysParameterSettings_SetFontsSubst (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetFontsSubst  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetFontsSubst
	#define EXT_SysParameterSettings_SetFontsSubst
	#define GET_SysParameterSettings_SetFontsSubst(fl)  CAL_CMGETAPI( "SysParameterSettings_SetFontsSubst" ) 
	#define CAL_SysParameterSettings_SetFontsSubst pISysParameterSettings->ISysParameterSettings_SetFontsSubst
	#define CHK_SysParameterSettings_SetFontsSubst (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetFontsSubst  CAL_CMEXPAPI( "SysParameterSettings_SetFontsSubst" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetFontsSubst  PFSYSPARAMETERSETTINGS_SETFONTSSUBST pfSysParameterSettings_SetFontsSubst;
	#define EXT_SysParameterSettings_SetFontsSubst  extern PFSYSPARAMETERSETTINGS_SETFONTSSUBST pfSysParameterSettings_SetFontsSubst;
	#define GET_SysParameterSettings_SetFontsSubst(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetFontsSubst", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetFontsSubst, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetFontsSubst  pfSysParameterSettings_SetFontsSubst
	#define CHK_SysParameterSettings_SetFontsSubst  (pfSysParameterSettings_SetFontsSubst != NULL)
	#define EXP_SysParameterSettings_SetFontsSubst  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetFontsSubst", (RTS_UINTPTR)SysParameterSettings_SetFontsSubst, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_uploadFonts();
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_UPLOADFONTS) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_UPLOADFONTS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_uploadFonts
	#define EXT_SysParameterSettings_uploadFonts
	#define GET_SysParameterSettings_uploadFonts(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_uploadFonts()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_uploadFonts  FALSE
	#define EXP_SysParameterSettings_uploadFonts  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_uploadFonts
	#define EXT_SysParameterSettings_uploadFonts
	#define GET_SysParameterSettings_uploadFonts(fl)  CAL_CMGETAPI( "SysParameterSettings_uploadFonts" ) 
	#define CAL_SysParameterSettings_uploadFonts  SysParameterSettings_uploadFonts
	#define CHK_SysParameterSettings_uploadFonts  TRUE
	#define EXP_SysParameterSettings_uploadFonts  CAL_CMEXPAPI( "SysParameterSettings_uploadFonts" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_uploadFonts
	#define EXT_SysParameterSettings_uploadFonts
	#define GET_SysParameterSettings_uploadFonts(fl)  CAL_CMGETAPI( "SysParameterSettings_uploadFonts" ) 
	#define CAL_SysParameterSettings_uploadFonts  SysParameterSettings_uploadFonts
	#define CHK_SysParameterSettings_uploadFonts  TRUE
	#define EXP_SysParameterSettings_uploadFonts  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_uploadFonts", (RTS_UINTPTR)SysParameterSettings_uploadFonts, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_uploadFonts
	#define EXT_SysParameterSettingsSysParameterSettings_uploadFonts
	#define GET_SysParameterSettingsSysParameterSettings_uploadFonts  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_uploadFonts pISysParameterSettings->ISysParameterSettings_uploadFonts
	#define CHK_SysParameterSettingsSysParameterSettings_uploadFonts (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_uploadFonts  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_uploadFonts
	#define EXT_SysParameterSettings_uploadFonts
	#define GET_SysParameterSettings_uploadFonts(fl)  CAL_CMGETAPI( "SysParameterSettings_uploadFonts" ) 
	#define CAL_SysParameterSettings_uploadFonts pISysParameterSettings->ISysParameterSettings_uploadFonts
	#define CHK_SysParameterSettings_uploadFonts (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_uploadFonts  CAL_CMEXPAPI( "SysParameterSettings_uploadFonts" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_uploadFonts  PFSYSPARAMETERSETTINGS_UPLOADFONTS pfSysParameterSettings_uploadFonts;
	#define EXT_SysParameterSettings_uploadFonts  extern PFSYSPARAMETERSETTINGS_UPLOADFONTS pfSysParameterSettings_uploadFonts;
	#define GET_SysParameterSettings_uploadFonts(fl)  s_pfCMGetAPI2( "SysParameterSettings_uploadFonts", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_uploadFonts, (fl), 0, 0)
	#define CAL_SysParameterSettings_uploadFonts  pfSysParameterSettings_uploadFonts
	#define CHK_SysParameterSettings_uploadFonts  (pfSysParameterSettings_uploadFonts != NULL)
	#define EXP_SysParameterSettings_uploadFonts  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_uploadFonts", (RTS_UINTPTR)SysParameterSettings_uploadFonts, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplayResolution(RTS_UI16 * pX, RTS_UI16* pY);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYRESOLUTION) (RTS_UI16 * pX, RTS_UI16* pY);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYRESOLUTION_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplayResolution
	#define EXT_SysParameterSettings_GetDisplayResolution
	#define GET_SysParameterSettings_GetDisplayResolution(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplayResolution(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplayResolution  FALSE
	#define EXP_SysParameterSettings_GetDisplayResolution  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplayResolution
	#define EXT_SysParameterSettings_GetDisplayResolution
	#define GET_SysParameterSettings_GetDisplayResolution(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayResolution" ) 
	#define CAL_SysParameterSettings_GetDisplayResolution  SysParameterSettings_GetDisplayResolution
	#define CHK_SysParameterSettings_GetDisplayResolution  TRUE
	#define EXP_SysParameterSettings_GetDisplayResolution  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayResolution" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplayResolution
	#define EXT_SysParameterSettings_GetDisplayResolution
	#define GET_SysParameterSettings_GetDisplayResolution(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayResolution" ) 
	#define CAL_SysParameterSettings_GetDisplayResolution  SysParameterSettings_GetDisplayResolution
	#define CHK_SysParameterSettings_GetDisplayResolution  TRUE
	#define EXP_SysParameterSettings_GetDisplayResolution  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayResolution", (RTS_UINTPTR)SysParameterSettings_GetDisplayResolution, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplayResolution
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplayResolution
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplayResolution  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplayResolution pISysParameterSettings->ISysParameterSettings_GetDisplayResolution
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplayResolution (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplayResolution  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplayResolution
	#define EXT_SysParameterSettings_GetDisplayResolution
	#define GET_SysParameterSettings_GetDisplayResolution(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayResolution" ) 
	#define CAL_SysParameterSettings_GetDisplayResolution pISysParameterSettings->ISysParameterSettings_GetDisplayResolution
	#define CHK_SysParameterSettings_GetDisplayResolution (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplayResolution  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayResolution" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplayResolution  PFSYSPARAMETERSETTINGS_GETDISPLAYRESOLUTION pfSysParameterSettings_GetDisplayResolution;
	#define EXT_SysParameterSettings_GetDisplayResolution  extern PFSYSPARAMETERSETTINGS_GETDISPLAYRESOLUTION pfSysParameterSettings_GetDisplayResolution;
	#define GET_SysParameterSettings_GetDisplayResolution(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplayResolution", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplayResolution, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplayResolution  pfSysParameterSettings_GetDisplayResolution
	#define CHK_SysParameterSettings_GetDisplayResolution  (pfSysParameterSettings_GetDisplayResolution != NULL)
	#define EXP_SysParameterSettings_GetDisplayResolution  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayResolution", (RTS_UINTPTR)SysParameterSettings_GetDisplayResolution, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplayOrientation(RTS_UI16* pOrientation);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYORIENTATION) (RTS_UI16* pOrientation);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYORIENTATION_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplayOrientation
	#define EXT_SysParameterSettings_GetDisplayOrientation
	#define GET_SysParameterSettings_GetDisplayOrientation(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplayOrientation(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplayOrientation  FALSE
	#define EXP_SysParameterSettings_GetDisplayOrientation  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplayOrientation
	#define EXT_SysParameterSettings_GetDisplayOrientation
	#define GET_SysParameterSettings_GetDisplayOrientation(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayOrientation" ) 
	#define CAL_SysParameterSettings_GetDisplayOrientation  SysParameterSettings_GetDisplayOrientation
	#define CHK_SysParameterSettings_GetDisplayOrientation  TRUE
	#define EXP_SysParameterSettings_GetDisplayOrientation  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayOrientation" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplayOrientation
	#define EXT_SysParameterSettings_GetDisplayOrientation
	#define GET_SysParameterSettings_GetDisplayOrientation(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayOrientation" ) 
	#define CAL_SysParameterSettings_GetDisplayOrientation  SysParameterSettings_GetDisplayOrientation
	#define CHK_SysParameterSettings_GetDisplayOrientation  TRUE
	#define EXP_SysParameterSettings_GetDisplayOrientation  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayOrientation", (RTS_UINTPTR)SysParameterSettings_GetDisplayOrientation, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplayOrientation
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplayOrientation
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplayOrientation  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplayOrientation pISysParameterSettings->ISysParameterSettings_GetDisplayOrientation
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplayOrientation (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplayOrientation  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplayOrientation
	#define EXT_SysParameterSettings_GetDisplayOrientation
	#define GET_SysParameterSettings_GetDisplayOrientation(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayOrientation" ) 
	#define CAL_SysParameterSettings_GetDisplayOrientation pISysParameterSettings->ISysParameterSettings_GetDisplayOrientation
	#define CHK_SysParameterSettings_GetDisplayOrientation (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplayOrientation  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayOrientation" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplayOrientation  PFSYSPARAMETERSETTINGS_GETDISPLAYORIENTATION pfSysParameterSettings_GetDisplayOrientation;
	#define EXT_SysParameterSettings_GetDisplayOrientation  extern PFSYSPARAMETERSETTINGS_GETDISPLAYORIENTATION pfSysParameterSettings_GetDisplayOrientation;
	#define GET_SysParameterSettings_GetDisplayOrientation(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplayOrientation", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplayOrientation, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplayOrientation  pfSysParameterSettings_GetDisplayOrientation
	#define CHK_SysParameterSettings_GetDisplayOrientation  (pfSysParameterSettings_GetDisplayOrientation != NULL)
	#define EXP_SysParameterSettings_GetDisplayOrientation  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayOrientation", (RTS_UINTPTR)SysParameterSettings_GetDisplayOrientation, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplayOrientation(RTS_UI16 nOrientation);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYORIENTATION) (RTS_UI16 nOrientation);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYORIENTATION_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplayOrientation
	#define EXT_SysParameterSettings_SetDisplayOrientation
	#define GET_SysParameterSettings_SetDisplayOrientation(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplayOrientation(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplayOrientation  FALSE
	#define EXP_SysParameterSettings_SetDisplayOrientation  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplayOrientation
	#define EXT_SysParameterSettings_SetDisplayOrientation
	#define GET_SysParameterSettings_SetDisplayOrientation(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayOrientation" ) 
	#define CAL_SysParameterSettings_SetDisplayOrientation  SysParameterSettings_SetDisplayOrientation
	#define CHK_SysParameterSettings_SetDisplayOrientation  TRUE
	#define EXP_SysParameterSettings_SetDisplayOrientation  CAL_CMEXPAPI( "SysParameterSettings_SetDisplayOrientation" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplayOrientation
	#define EXT_SysParameterSettings_SetDisplayOrientation
	#define GET_SysParameterSettings_SetDisplayOrientation(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayOrientation" ) 
	#define CAL_SysParameterSettings_SetDisplayOrientation  SysParameterSettings_SetDisplayOrientation
	#define CHK_SysParameterSettings_SetDisplayOrientation  TRUE
	#define EXP_SysParameterSettings_SetDisplayOrientation  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplayOrientation", (RTS_UINTPTR)SysParameterSettings_SetDisplayOrientation, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplayOrientation
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplayOrientation
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplayOrientation  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplayOrientation pISysParameterSettings->ISysParameterSettings_SetDisplayOrientation
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplayOrientation (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplayOrientation  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplayOrientation
	#define EXT_SysParameterSettings_SetDisplayOrientation
	#define GET_SysParameterSettings_SetDisplayOrientation(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayOrientation" ) 
	#define CAL_SysParameterSettings_SetDisplayOrientation pISysParameterSettings->ISysParameterSettings_SetDisplayOrientation
	#define CHK_SysParameterSettings_SetDisplayOrientation (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplayOrientation  CAL_CMEXPAPI( "SysParameterSettings_SetDisplayOrientation" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplayOrientation  PFSYSPARAMETERSETTINGS_SETDISPLAYORIENTATION pfSysParameterSettings_SetDisplayOrientation;
	#define EXT_SysParameterSettings_SetDisplayOrientation  extern PFSYSPARAMETERSETTINGS_SETDISPLAYORIENTATION pfSysParameterSettings_SetDisplayOrientation;
	#define GET_SysParameterSettings_SetDisplayOrientation(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplayOrientation", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplayOrientation, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplayOrientation  pfSysParameterSettings_SetDisplayOrientation
	#define CHK_SysParameterSettings_SetDisplayOrientation  (pfSysParameterSettings_SetDisplayOrientation != NULL)
	#define EXP_SysParameterSettings_SetDisplayOrientation  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplayOrientation", (RTS_UINTPTR)SysParameterSettings_SetDisplayOrientation, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplayBrightness(RTS_UI8 * pBrightness);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYBRIGHTNESS) (RTS_UI8 * pBrightness);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYBRIGHTNESS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplayBrightness
	#define EXT_SysParameterSettings_GetDisplayBrightness
	#define GET_SysParameterSettings_GetDisplayBrightness(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplayBrightness(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplayBrightness  FALSE
	#define EXP_SysParameterSettings_GetDisplayBrightness  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplayBrightness
	#define EXT_SysParameterSettings_GetDisplayBrightness
	#define GET_SysParameterSettings_GetDisplayBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayBrightness" ) 
	#define CAL_SysParameterSettings_GetDisplayBrightness  SysParameterSettings_GetDisplayBrightness
	#define CHK_SysParameterSettings_GetDisplayBrightness  TRUE
	#define EXP_SysParameterSettings_GetDisplayBrightness  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayBrightness" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplayBrightness
	#define EXT_SysParameterSettings_GetDisplayBrightness
	#define GET_SysParameterSettings_GetDisplayBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayBrightness" ) 
	#define CAL_SysParameterSettings_GetDisplayBrightness  SysParameterSettings_GetDisplayBrightness
	#define CHK_SysParameterSettings_GetDisplayBrightness  TRUE
	#define EXP_SysParameterSettings_GetDisplayBrightness  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayBrightness", (RTS_UINTPTR)SysParameterSettings_GetDisplayBrightness, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplayBrightness
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplayBrightness
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplayBrightness  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplayBrightness pISysParameterSettings->ISysParameterSettings_GetDisplayBrightness
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplayBrightness (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplayBrightness  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplayBrightness
	#define EXT_SysParameterSettings_GetDisplayBrightness
	#define GET_SysParameterSettings_GetDisplayBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayBrightness" ) 
	#define CAL_SysParameterSettings_GetDisplayBrightness pISysParameterSettings->ISysParameterSettings_GetDisplayBrightness
	#define CHK_SysParameterSettings_GetDisplayBrightness (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplayBrightness  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayBrightness" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplayBrightness  PFSYSPARAMETERSETTINGS_GETDISPLAYBRIGHTNESS pfSysParameterSettings_GetDisplayBrightness;
	#define EXT_SysParameterSettings_GetDisplayBrightness  extern PFSYSPARAMETERSETTINGS_GETDISPLAYBRIGHTNESS pfSysParameterSettings_GetDisplayBrightness;
	#define GET_SysParameterSettings_GetDisplayBrightness(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplayBrightness", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplayBrightness, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplayBrightness  pfSysParameterSettings_GetDisplayBrightness
	#define CHK_SysParameterSettings_GetDisplayBrightness  (pfSysParameterSettings_GetDisplayBrightness != NULL)
	#define EXP_SysParameterSettings_GetDisplayBrightness  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayBrightness", (RTS_UINTPTR)SysParameterSettings_GetDisplayBrightness, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplayBrightness(RTS_UI8 nBrightness);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYBRIGHTNESS) (RTS_UI8 nBrightness);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYBRIGHTNESS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplayBrightness
	#define EXT_SysParameterSettings_SetDisplayBrightness
	#define GET_SysParameterSettings_SetDisplayBrightness(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplayBrightness(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplayBrightness  FALSE
	#define EXP_SysParameterSettings_SetDisplayBrightness  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplayBrightness
	#define EXT_SysParameterSettings_SetDisplayBrightness
	#define GET_SysParameterSettings_SetDisplayBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayBrightness" ) 
	#define CAL_SysParameterSettings_SetDisplayBrightness  SysParameterSettings_SetDisplayBrightness
	#define CHK_SysParameterSettings_SetDisplayBrightness  TRUE
	#define EXP_SysParameterSettings_SetDisplayBrightness  CAL_CMEXPAPI( "SysParameterSettings_SetDisplayBrightness" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplayBrightness
	#define EXT_SysParameterSettings_SetDisplayBrightness
	#define GET_SysParameterSettings_SetDisplayBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayBrightness" ) 
	#define CAL_SysParameterSettings_SetDisplayBrightness  SysParameterSettings_SetDisplayBrightness
	#define CHK_SysParameterSettings_SetDisplayBrightness  TRUE
	#define EXP_SysParameterSettings_SetDisplayBrightness  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplayBrightness", (RTS_UINTPTR)SysParameterSettings_SetDisplayBrightness, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplayBrightness
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplayBrightness
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplayBrightness  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplayBrightness pISysParameterSettings->ISysParameterSettings_SetDisplayBrightness
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplayBrightness (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplayBrightness  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplayBrightness
	#define EXT_SysParameterSettings_SetDisplayBrightness
	#define GET_SysParameterSettings_SetDisplayBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayBrightness" ) 
	#define CAL_SysParameterSettings_SetDisplayBrightness pISysParameterSettings->ISysParameterSettings_SetDisplayBrightness
	#define CHK_SysParameterSettings_SetDisplayBrightness (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplayBrightness  CAL_CMEXPAPI( "SysParameterSettings_SetDisplayBrightness" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplayBrightness  PFSYSPARAMETERSETTINGS_SETDISPLAYBRIGHTNESS pfSysParameterSettings_SetDisplayBrightness;
	#define EXT_SysParameterSettings_SetDisplayBrightness  extern PFSYSPARAMETERSETTINGS_SETDISPLAYBRIGHTNESS pfSysParameterSettings_SetDisplayBrightness;
	#define GET_SysParameterSettings_SetDisplayBrightness(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplayBrightness", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplayBrightness, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplayBrightness  pfSysParameterSettings_SetDisplayBrightness
	#define CHK_SysParameterSettings_SetDisplayBrightness  (pfSysParameterSettings_SetDisplayBrightness != NULL)
	#define EXP_SysParameterSettings_SetDisplayBrightness  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplayBrightness", (RTS_UINTPTR)SysParameterSettings_SetDisplayBrightness, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_changeBrightness(RTS_UI8 nBrightness);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_CHANGEBRIGHTNESS) (RTS_UI8 nBrightness);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_CHANGEBRIGHTNESS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_changeBrightness
	#define EXT_SysParameterSettings_changeBrightness
	#define GET_SysParameterSettings_changeBrightness(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_changeBrightness(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_changeBrightness  FALSE
	#define EXP_SysParameterSettings_changeBrightness  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_changeBrightness
	#define EXT_SysParameterSettings_changeBrightness
	#define GET_SysParameterSettings_changeBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_changeBrightness" ) 
	#define CAL_SysParameterSettings_changeBrightness  SysParameterSettings_changeBrightness
	#define CHK_SysParameterSettings_changeBrightness  TRUE
	#define EXP_SysParameterSettings_changeBrightness  CAL_CMEXPAPI( "SysParameterSettings_changeBrightness" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_changeBrightness
	#define EXT_SysParameterSettings_changeBrightness
	#define GET_SysParameterSettings_changeBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_changeBrightness" ) 
	#define CAL_SysParameterSettings_changeBrightness  SysParameterSettings_changeBrightness
	#define CHK_SysParameterSettings_changeBrightness  TRUE
	#define EXP_SysParameterSettings_changeBrightness  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_changeBrightness", (RTS_UINTPTR)SysParameterSettings_changeBrightness, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_changeBrightness
	#define EXT_SysParameterSettingsSysParameterSettings_changeBrightness
	#define GET_SysParameterSettingsSysParameterSettings_changeBrightness  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_changeBrightness pISysParameterSettings->ISysParameterSettings_changeBrightness
	#define CHK_SysParameterSettingsSysParameterSettings_changeBrightness (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_changeBrightness  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_changeBrightness
	#define EXT_SysParameterSettings_changeBrightness
	#define GET_SysParameterSettings_changeBrightness(fl)  CAL_CMGETAPI( "SysParameterSettings_changeBrightness" ) 
	#define CAL_SysParameterSettings_changeBrightness pISysParameterSettings->ISysParameterSettings_changeBrightness
	#define CHK_SysParameterSettings_changeBrightness (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_changeBrightness  CAL_CMEXPAPI( "SysParameterSettings_changeBrightness" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_changeBrightness  PFSYSPARAMETERSETTINGS_CHANGEBRIGHTNESS pfSysParameterSettings_changeBrightness;
	#define EXT_SysParameterSettings_changeBrightness  extern PFSYSPARAMETERSETTINGS_CHANGEBRIGHTNESS pfSysParameterSettings_changeBrightness;
	#define GET_SysParameterSettings_changeBrightness(fl)  s_pfCMGetAPI2( "SysParameterSettings_changeBrightness", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_changeBrightness, (fl), 0, 0)
	#define CAL_SysParameterSettings_changeBrightness  pfSysParameterSettings_changeBrightness
	#define CHK_SysParameterSettings_changeBrightness  (pfSysParameterSettings_changeBrightness != NULL)
	#define EXP_SysParameterSettings_changeBrightness  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_changeBrightness", (RTS_UINTPTR)SysParameterSettings_changeBrightness, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplayCleanTime(RTS_UI32* pCleanTime);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYCLEANTIME) (RTS_UI32* pCleanTime);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYCLEANTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplayCleanTime
	#define EXT_SysParameterSettings_GetDisplayCleanTime
	#define GET_SysParameterSettings_GetDisplayCleanTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplayCleanTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplayCleanTime  FALSE
	#define EXP_SysParameterSettings_GetDisplayCleanTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplayCleanTime
	#define EXT_SysParameterSettings_GetDisplayCleanTime
	#define GET_SysParameterSettings_GetDisplayCleanTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayCleanTime" ) 
	#define CAL_SysParameterSettings_GetDisplayCleanTime  SysParameterSettings_GetDisplayCleanTime
	#define CHK_SysParameterSettings_GetDisplayCleanTime  TRUE
	#define EXP_SysParameterSettings_GetDisplayCleanTime  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayCleanTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplayCleanTime
	#define EXT_SysParameterSettings_GetDisplayCleanTime
	#define GET_SysParameterSettings_GetDisplayCleanTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayCleanTime" ) 
	#define CAL_SysParameterSettings_GetDisplayCleanTime  SysParameterSettings_GetDisplayCleanTime
	#define CHK_SysParameterSettings_GetDisplayCleanTime  TRUE
	#define EXP_SysParameterSettings_GetDisplayCleanTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayCleanTime", (RTS_UINTPTR)SysParameterSettings_GetDisplayCleanTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplayCleanTime
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplayCleanTime
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplayCleanTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplayCleanTime pISysParameterSettings->ISysParameterSettings_GetDisplayCleanTime
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplayCleanTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplayCleanTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplayCleanTime
	#define EXT_SysParameterSettings_GetDisplayCleanTime
	#define GET_SysParameterSettings_GetDisplayCleanTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplayCleanTime" ) 
	#define CAL_SysParameterSettings_GetDisplayCleanTime pISysParameterSettings->ISysParameterSettings_GetDisplayCleanTime
	#define CHK_SysParameterSettings_GetDisplayCleanTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplayCleanTime  CAL_CMEXPAPI( "SysParameterSettings_GetDisplayCleanTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplayCleanTime  PFSYSPARAMETERSETTINGS_GETDISPLAYCLEANTIME pfSysParameterSettings_GetDisplayCleanTime;
	#define EXT_SysParameterSettings_GetDisplayCleanTime  extern PFSYSPARAMETERSETTINGS_GETDISPLAYCLEANTIME pfSysParameterSettings_GetDisplayCleanTime;
	#define GET_SysParameterSettings_GetDisplayCleanTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplayCleanTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplayCleanTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplayCleanTime  pfSysParameterSettings_GetDisplayCleanTime
	#define CHK_SysParameterSettings_GetDisplayCleanTime  (pfSysParameterSettings_GetDisplayCleanTime != NULL)
	#define EXP_SysParameterSettings_GetDisplayCleanTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplayCleanTime", (RTS_UINTPTR)SysParameterSettings_GetDisplayCleanTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplayCleanTime(RTS_UI32 nCleanTime);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYCLEANTIME) (RTS_UI32 nCleanTime);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYCLEANTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplayCleanTime
	#define EXT_SysParameterSettings_SetDisplayCleanTime
	#define GET_SysParameterSettings_SetDisplayCleanTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplayCleanTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplayCleanTime  FALSE
	#define EXP_SysParameterSettings_SetDisplayCleanTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplayCleanTime
	#define EXT_SysParameterSettings_SetDisplayCleanTime
	#define GET_SysParameterSettings_SetDisplayCleanTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayCleanTime" ) 
	#define CAL_SysParameterSettings_SetDisplayCleanTime  SysParameterSettings_SetDisplayCleanTime
	#define CHK_SysParameterSettings_SetDisplayCleanTime  TRUE
	#define EXP_SysParameterSettings_SetDisplayCleanTime  CAL_CMEXPAPI( "SysParameterSettings_SetDisplayCleanTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplayCleanTime
	#define EXT_SysParameterSettings_SetDisplayCleanTime
	#define GET_SysParameterSettings_SetDisplayCleanTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayCleanTime" ) 
	#define CAL_SysParameterSettings_SetDisplayCleanTime  SysParameterSettings_SetDisplayCleanTime
	#define CHK_SysParameterSettings_SetDisplayCleanTime  TRUE
	#define EXP_SysParameterSettings_SetDisplayCleanTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplayCleanTime", (RTS_UINTPTR)SysParameterSettings_SetDisplayCleanTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplayCleanTime
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplayCleanTime
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplayCleanTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplayCleanTime pISysParameterSettings->ISysParameterSettings_SetDisplayCleanTime
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplayCleanTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplayCleanTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplayCleanTime
	#define EXT_SysParameterSettings_SetDisplayCleanTime
	#define GET_SysParameterSettings_SetDisplayCleanTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplayCleanTime" ) 
	#define CAL_SysParameterSettings_SetDisplayCleanTime pISysParameterSettings->ISysParameterSettings_SetDisplayCleanTime
	#define CHK_SysParameterSettings_SetDisplayCleanTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplayCleanTime  CAL_CMEXPAPI( "SysParameterSettings_SetDisplayCleanTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplayCleanTime  PFSYSPARAMETERSETTINGS_SETDISPLAYCLEANTIME pfSysParameterSettings_SetDisplayCleanTime;
	#define EXT_SysParameterSettings_SetDisplayCleanTime  extern PFSYSPARAMETERSETTINGS_SETDISPLAYCLEANTIME pfSysParameterSettings_SetDisplayCleanTime;
	#define GET_SysParameterSettings_SetDisplayCleanTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplayCleanTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplayCleanTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplayCleanTime  pfSysParameterSettings_SetDisplayCleanTime
	#define CHK_SysParameterSettings_SetDisplayCleanTime  (pfSysParameterSettings_SetDisplayCleanTime != NULL)
	#define EXP_SysParameterSettings_SetDisplayCleanTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplayCleanTime", (RTS_UINTPTR)SysParameterSettings_SetDisplayCleanTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplaySSEnable(RTS_BOOL* pEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYSSENABLE) (RTS_BOOL* pEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYSSENABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplaySSEnable
	#define EXT_SysParameterSettings_GetDisplaySSEnable
	#define GET_SysParameterSettings_GetDisplaySSEnable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplaySSEnable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplaySSEnable  FALSE
	#define EXP_SysParameterSettings_GetDisplaySSEnable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplaySSEnable
	#define EXT_SysParameterSettings_GetDisplaySSEnable
	#define GET_SysParameterSettings_GetDisplaySSEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSEnable" ) 
	#define CAL_SysParameterSettings_GetDisplaySSEnable  SysParameterSettings_GetDisplaySSEnable
	#define CHK_SysParameterSettings_GetDisplaySSEnable  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSEnable  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSEnable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplaySSEnable
	#define EXT_SysParameterSettings_GetDisplaySSEnable
	#define GET_SysParameterSettings_GetDisplaySSEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSEnable" ) 
	#define CAL_SysParameterSettings_GetDisplaySSEnable  SysParameterSettings_GetDisplaySSEnable
	#define CHK_SysParameterSettings_GetDisplaySSEnable  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSEnable", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSEnable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplaySSEnable
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplaySSEnable
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplaySSEnable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplaySSEnable pISysParameterSettings->ISysParameterSettings_GetDisplaySSEnable
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplaySSEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplaySSEnable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplaySSEnable
	#define EXT_SysParameterSettings_GetDisplaySSEnable
	#define GET_SysParameterSettings_GetDisplaySSEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSEnable" ) 
	#define CAL_SysParameterSettings_GetDisplaySSEnable pISysParameterSettings->ISysParameterSettings_GetDisplaySSEnable
	#define CHK_SysParameterSettings_GetDisplaySSEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSEnable  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSEnable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplaySSEnable  PFSYSPARAMETERSETTINGS_GETDISPLAYSSENABLE pfSysParameterSettings_GetDisplaySSEnable;
	#define EXT_SysParameterSettings_GetDisplaySSEnable  extern PFSYSPARAMETERSETTINGS_GETDISPLAYSSENABLE pfSysParameterSettings_GetDisplaySSEnable;
	#define GET_SysParameterSettings_GetDisplaySSEnable(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplaySSEnable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplaySSEnable, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplaySSEnable  pfSysParameterSettings_GetDisplaySSEnable
	#define CHK_SysParameterSettings_GetDisplaySSEnable  (pfSysParameterSettings_GetDisplaySSEnable != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSEnable", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSEnable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplaySSEnable(RTS_BOOL bEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYSSENABLE) (RTS_BOOL bEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYSSENABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplaySSEnable
	#define EXT_SysParameterSettings_SetDisplaySSEnable
	#define GET_SysParameterSettings_SetDisplaySSEnable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplaySSEnable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplaySSEnable  FALSE
	#define EXP_SysParameterSettings_SetDisplaySSEnable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplaySSEnable
	#define EXT_SysParameterSettings_SetDisplaySSEnable
	#define GET_SysParameterSettings_SetDisplaySSEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSEnable" ) 
	#define CAL_SysParameterSettings_SetDisplaySSEnable  SysParameterSettings_SetDisplaySSEnable
	#define CHK_SysParameterSettings_SetDisplaySSEnable  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSEnable  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSEnable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplaySSEnable
	#define EXT_SysParameterSettings_SetDisplaySSEnable
	#define GET_SysParameterSettings_SetDisplaySSEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSEnable" ) 
	#define CAL_SysParameterSettings_SetDisplaySSEnable  SysParameterSettings_SetDisplaySSEnable
	#define CHK_SysParameterSettings_SetDisplaySSEnable  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSEnable", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSEnable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplaySSEnable
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplaySSEnable
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplaySSEnable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplaySSEnable pISysParameterSettings->ISysParameterSettings_SetDisplaySSEnable
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplaySSEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplaySSEnable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplaySSEnable
	#define EXT_SysParameterSettings_SetDisplaySSEnable
	#define GET_SysParameterSettings_SetDisplaySSEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSEnable" ) 
	#define CAL_SysParameterSettings_SetDisplaySSEnable pISysParameterSettings->ISysParameterSettings_SetDisplaySSEnable
	#define CHK_SysParameterSettings_SetDisplaySSEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSEnable  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSEnable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplaySSEnable  PFSYSPARAMETERSETTINGS_SETDISPLAYSSENABLE pfSysParameterSettings_SetDisplaySSEnable;
	#define EXT_SysParameterSettings_SetDisplaySSEnable  extern PFSYSPARAMETERSETTINGS_SETDISPLAYSSENABLE pfSysParameterSettings_SetDisplaySSEnable;
	#define GET_SysParameterSettings_SetDisplaySSEnable(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplaySSEnable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplaySSEnable, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplaySSEnable  pfSysParameterSettings_SetDisplaySSEnable
	#define CHK_SysParameterSettings_SetDisplaySSEnable  (pfSysParameterSettings_SetDisplaySSEnable != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSEnable", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSEnable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplaySSTime(RTS_UI32* pSSTime);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYSSTIME) (RTS_UI32* pSSTime);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYSSTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplaySSTime
	#define EXT_SysParameterSettings_GetDisplaySSTime
	#define GET_SysParameterSettings_GetDisplaySSTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplaySSTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplaySSTime  FALSE
	#define EXP_SysParameterSettings_GetDisplaySSTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplaySSTime
	#define EXT_SysParameterSettings_GetDisplaySSTime
	#define GET_SysParameterSettings_GetDisplaySSTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSTime" ) 
	#define CAL_SysParameterSettings_GetDisplaySSTime  SysParameterSettings_GetDisplaySSTime
	#define CHK_SysParameterSettings_GetDisplaySSTime  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSTime  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplaySSTime
	#define EXT_SysParameterSettings_GetDisplaySSTime
	#define GET_SysParameterSettings_GetDisplaySSTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSTime" ) 
	#define CAL_SysParameterSettings_GetDisplaySSTime  SysParameterSettings_GetDisplaySSTime
	#define CHK_SysParameterSettings_GetDisplaySSTime  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSTime", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplaySSTime
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplaySSTime
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplaySSTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplaySSTime pISysParameterSettings->ISysParameterSettings_GetDisplaySSTime
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplaySSTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplaySSTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplaySSTime
	#define EXT_SysParameterSettings_GetDisplaySSTime
	#define GET_SysParameterSettings_GetDisplaySSTime(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSTime" ) 
	#define CAL_SysParameterSettings_GetDisplaySSTime pISysParameterSettings->ISysParameterSettings_GetDisplaySSTime
	#define CHK_SysParameterSettings_GetDisplaySSTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSTime  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplaySSTime  PFSYSPARAMETERSETTINGS_GETDISPLAYSSTIME pfSysParameterSettings_GetDisplaySSTime;
	#define EXT_SysParameterSettings_GetDisplaySSTime  extern PFSYSPARAMETERSETTINGS_GETDISPLAYSSTIME pfSysParameterSettings_GetDisplaySSTime;
	#define GET_SysParameterSettings_GetDisplaySSTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplaySSTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplaySSTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplaySSTime  pfSysParameterSettings_GetDisplaySSTime
	#define CHK_SysParameterSettings_GetDisplaySSTime  (pfSysParameterSettings_GetDisplaySSTime != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSTime", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplaySSTime(RTS_UI32 nSSTime);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYSSTIME) (RTS_UI32 nSSTime);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYSSTIME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplaySSTime
	#define EXT_SysParameterSettings_SetDisplaySSTime
	#define GET_SysParameterSettings_SetDisplaySSTime(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplaySSTime(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplaySSTime  FALSE
	#define EXP_SysParameterSettings_SetDisplaySSTime  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplaySSTime
	#define EXT_SysParameterSettings_SetDisplaySSTime
	#define GET_SysParameterSettings_SetDisplaySSTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSTime" ) 
	#define CAL_SysParameterSettings_SetDisplaySSTime  SysParameterSettings_SetDisplaySSTime
	#define CHK_SysParameterSettings_SetDisplaySSTime  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSTime  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSTime" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplaySSTime
	#define EXT_SysParameterSettings_SetDisplaySSTime
	#define GET_SysParameterSettings_SetDisplaySSTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSTime" ) 
	#define CAL_SysParameterSettings_SetDisplaySSTime  SysParameterSettings_SetDisplaySSTime
	#define CHK_SysParameterSettings_SetDisplaySSTime  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSTime", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSTime, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplaySSTime
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplaySSTime
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplaySSTime  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplaySSTime pISysParameterSettings->ISysParameterSettings_SetDisplaySSTime
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplaySSTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplaySSTime  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplaySSTime
	#define EXT_SysParameterSettings_SetDisplaySSTime
	#define GET_SysParameterSettings_SetDisplaySSTime(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSTime" ) 
	#define CAL_SysParameterSettings_SetDisplaySSTime pISysParameterSettings->ISysParameterSettings_SetDisplaySSTime
	#define CHK_SysParameterSettings_SetDisplaySSTime (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSTime  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSTime" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplaySSTime  PFSYSPARAMETERSETTINGS_SETDISPLAYSSTIME pfSysParameterSettings_SetDisplaySSTime;
	#define EXT_SysParameterSettings_SetDisplaySSTime  extern PFSYSPARAMETERSETTINGS_SETDISPLAYSSTIME pfSysParameterSettings_SetDisplaySSTime;
	#define GET_SysParameterSettings_SetDisplaySSTime(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplaySSTime", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplaySSTime, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplaySSTime  pfSysParameterSettings_SetDisplaySSTime
	#define CHK_SysParameterSettings_SetDisplaySSTime  (pfSysParameterSettings_SetDisplaySSTime != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSTime  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSTime", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSTime, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplaySSTheme(RTS_UI8 * pValue);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYSSTHEME) (RTS_UI8 * pValue);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYSSTHEME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplaySSTheme
	#define EXT_SysParameterSettings_GetDisplaySSTheme
	#define GET_SysParameterSettings_GetDisplaySSTheme(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplaySSTheme(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplaySSTheme  FALSE
	#define EXP_SysParameterSettings_GetDisplaySSTheme  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplaySSTheme
	#define EXT_SysParameterSettings_GetDisplaySSTheme
	#define GET_SysParameterSettings_GetDisplaySSTheme(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSTheme" ) 
	#define CAL_SysParameterSettings_GetDisplaySSTheme  SysParameterSettings_GetDisplaySSTheme
	#define CHK_SysParameterSettings_GetDisplaySSTheme  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSTheme  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSTheme" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplaySSTheme
	#define EXT_SysParameterSettings_GetDisplaySSTheme
	#define GET_SysParameterSettings_GetDisplaySSTheme(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSTheme" ) 
	#define CAL_SysParameterSettings_GetDisplaySSTheme  SysParameterSettings_GetDisplaySSTheme
	#define CHK_SysParameterSettings_GetDisplaySSTheme  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSTheme  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSTheme", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSTheme, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplaySSTheme
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplaySSTheme
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplaySSTheme  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplaySSTheme pISysParameterSettings->ISysParameterSettings_GetDisplaySSTheme
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplaySSTheme (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplaySSTheme  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplaySSTheme
	#define EXT_SysParameterSettings_GetDisplaySSTheme
	#define GET_SysParameterSettings_GetDisplaySSTheme(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSTheme" ) 
	#define CAL_SysParameterSettings_GetDisplaySSTheme pISysParameterSettings->ISysParameterSettings_GetDisplaySSTheme
	#define CHK_SysParameterSettings_GetDisplaySSTheme (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSTheme  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSTheme" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplaySSTheme  PFSYSPARAMETERSETTINGS_GETDISPLAYSSTHEME pfSysParameterSettings_GetDisplaySSTheme;
	#define EXT_SysParameterSettings_GetDisplaySSTheme  extern PFSYSPARAMETERSETTINGS_GETDISPLAYSSTHEME pfSysParameterSettings_GetDisplaySSTheme;
	#define GET_SysParameterSettings_GetDisplaySSTheme(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplaySSTheme", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplaySSTheme, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplaySSTheme  pfSysParameterSettings_GetDisplaySSTheme
	#define CHK_SysParameterSettings_GetDisplaySSTheme  (pfSysParameterSettings_GetDisplaySSTheme != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSTheme  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSTheme", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSTheme, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplaySSTheme(RTS_UI8 nValue);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYSSTHEME) (RTS_UI8 nValue);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYSSTHEME_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplaySSTheme
	#define EXT_SysParameterSettings_SetDisplaySSTheme
	#define GET_SysParameterSettings_SetDisplaySSTheme(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplaySSTheme(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplaySSTheme  FALSE
	#define EXP_SysParameterSettings_SetDisplaySSTheme  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplaySSTheme
	#define EXT_SysParameterSettings_SetDisplaySSTheme
	#define GET_SysParameterSettings_SetDisplaySSTheme(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSTheme" ) 
	#define CAL_SysParameterSettings_SetDisplaySSTheme  SysParameterSettings_SetDisplaySSTheme
	#define CHK_SysParameterSettings_SetDisplaySSTheme  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSTheme  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSTheme" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplaySSTheme
	#define EXT_SysParameterSettings_SetDisplaySSTheme
	#define GET_SysParameterSettings_SetDisplaySSTheme(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSTheme" ) 
	#define CAL_SysParameterSettings_SetDisplaySSTheme  SysParameterSettings_SetDisplaySSTheme
	#define CHK_SysParameterSettings_SetDisplaySSTheme  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSTheme  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSTheme", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSTheme, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplaySSTheme
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplaySSTheme
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplaySSTheme  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplaySSTheme pISysParameterSettings->ISysParameterSettings_SetDisplaySSTheme
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplaySSTheme (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplaySSTheme  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplaySSTheme
	#define EXT_SysParameterSettings_SetDisplaySSTheme
	#define GET_SysParameterSettings_SetDisplaySSTheme(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSTheme" ) 
	#define CAL_SysParameterSettings_SetDisplaySSTheme pISysParameterSettings->ISysParameterSettings_SetDisplaySSTheme
	#define CHK_SysParameterSettings_SetDisplaySSTheme (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSTheme  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSTheme" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplaySSTheme  PFSYSPARAMETERSETTINGS_SETDISPLAYSSTHEME pfSysParameterSettings_SetDisplaySSTheme;
	#define EXT_SysParameterSettings_SetDisplaySSTheme  extern PFSYSPARAMETERSETTINGS_SETDISPLAYSSTHEME pfSysParameterSettings_SetDisplaySSTheme;
	#define GET_SysParameterSettings_SetDisplaySSTheme(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplaySSTheme", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplaySSTheme, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplaySSTheme  pfSysParameterSettings_SetDisplaySSTheme
	#define CHK_SysParameterSettings_SetDisplaySSTheme  (pfSysParameterSettings_SetDisplaySSTheme != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSTheme  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSTheme", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSTheme, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetDisplaySSText(char * pszText, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETDISPLAYSSTEXT) (char * pszText, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETDISPLAYSSTEXT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetDisplaySSText
	#define EXT_SysParameterSettings_GetDisplaySSText
	#define GET_SysParameterSettings_GetDisplaySSText(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetDisplaySSText(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetDisplaySSText  FALSE
	#define EXP_SysParameterSettings_GetDisplaySSText  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetDisplaySSText
	#define EXT_SysParameterSettings_GetDisplaySSText
	#define GET_SysParameterSettings_GetDisplaySSText(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSText" ) 
	#define CAL_SysParameterSettings_GetDisplaySSText  SysParameterSettings_GetDisplaySSText
	#define CHK_SysParameterSettings_GetDisplaySSText  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSText  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSText" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetDisplaySSText
	#define EXT_SysParameterSettings_GetDisplaySSText
	#define GET_SysParameterSettings_GetDisplaySSText(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSText" ) 
	#define CAL_SysParameterSettings_GetDisplaySSText  SysParameterSettings_GetDisplaySSText
	#define CHK_SysParameterSettings_GetDisplaySSText  TRUE
	#define EXP_SysParameterSettings_GetDisplaySSText  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSText", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSText, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetDisplaySSText
	#define EXT_SysParameterSettingsSysParameterSettings_GetDisplaySSText
	#define GET_SysParameterSettingsSysParameterSettings_GetDisplaySSText  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetDisplaySSText pISysParameterSettings->ISysParameterSettings_GetDisplaySSText
	#define CHK_SysParameterSettingsSysParameterSettings_GetDisplaySSText (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetDisplaySSText  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetDisplaySSText
	#define EXT_SysParameterSettings_GetDisplaySSText
	#define GET_SysParameterSettings_GetDisplaySSText(fl)  CAL_CMGETAPI( "SysParameterSettings_GetDisplaySSText" ) 
	#define CAL_SysParameterSettings_GetDisplaySSText pISysParameterSettings->ISysParameterSettings_GetDisplaySSText
	#define CHK_SysParameterSettings_GetDisplaySSText (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSText  CAL_CMEXPAPI( "SysParameterSettings_GetDisplaySSText" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetDisplaySSText  PFSYSPARAMETERSETTINGS_GETDISPLAYSSTEXT pfSysParameterSettings_GetDisplaySSText;
	#define EXT_SysParameterSettings_GetDisplaySSText  extern PFSYSPARAMETERSETTINGS_GETDISPLAYSSTEXT pfSysParameterSettings_GetDisplaySSText;
	#define GET_SysParameterSettings_GetDisplaySSText(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetDisplaySSText", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetDisplaySSText, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetDisplaySSText  pfSysParameterSettings_GetDisplaySSText
	#define CHK_SysParameterSettings_GetDisplaySSText  (pfSysParameterSettings_GetDisplaySSText != NULL)
	#define EXP_SysParameterSettings_GetDisplaySSText  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetDisplaySSText", (RTS_UINTPTR)SysParameterSettings_GetDisplaySSText, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetDisplaySSText(char * pszText);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETDISPLAYSSTEXT) (char * pszText);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETDISPLAYSSTEXT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetDisplaySSText
	#define EXT_SysParameterSettings_SetDisplaySSText
	#define GET_SysParameterSettings_SetDisplaySSText(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetDisplaySSText(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetDisplaySSText  FALSE
	#define EXP_SysParameterSettings_SetDisplaySSText  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetDisplaySSText
	#define EXT_SysParameterSettings_SetDisplaySSText
	#define GET_SysParameterSettings_SetDisplaySSText(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSText" ) 
	#define CAL_SysParameterSettings_SetDisplaySSText  SysParameterSettings_SetDisplaySSText
	#define CHK_SysParameterSettings_SetDisplaySSText  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSText  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSText" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetDisplaySSText
	#define EXT_SysParameterSettings_SetDisplaySSText
	#define GET_SysParameterSettings_SetDisplaySSText(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSText" ) 
	#define CAL_SysParameterSettings_SetDisplaySSText  SysParameterSettings_SetDisplaySSText
	#define CHK_SysParameterSettings_SetDisplaySSText  TRUE
	#define EXP_SysParameterSettings_SetDisplaySSText  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSText", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSText, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetDisplaySSText
	#define EXT_SysParameterSettingsSysParameterSettings_SetDisplaySSText
	#define GET_SysParameterSettingsSysParameterSettings_SetDisplaySSText  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetDisplaySSText pISysParameterSettings->ISysParameterSettings_SetDisplaySSText
	#define CHK_SysParameterSettingsSysParameterSettings_SetDisplaySSText (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetDisplaySSText  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetDisplaySSText
	#define EXT_SysParameterSettings_SetDisplaySSText
	#define GET_SysParameterSettings_SetDisplaySSText(fl)  CAL_CMGETAPI( "SysParameterSettings_SetDisplaySSText" ) 
	#define CAL_SysParameterSettings_SetDisplaySSText pISysParameterSettings->ISysParameterSettings_SetDisplaySSText
	#define CHK_SysParameterSettings_SetDisplaySSText (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSText  CAL_CMEXPAPI( "SysParameterSettings_SetDisplaySSText" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetDisplaySSText  PFSYSPARAMETERSETTINGS_SETDISPLAYSSTEXT pfSysParameterSettings_SetDisplaySSText;
	#define EXT_SysParameterSettings_SetDisplaySSText  extern PFSYSPARAMETERSETTINGS_SETDISPLAYSSTEXT pfSysParameterSettings_SetDisplaySSText;
	#define GET_SysParameterSettings_SetDisplaySSText(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetDisplaySSText", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetDisplaySSText, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetDisplaySSText  pfSysParameterSettings_SetDisplaySSText
	#define CHK_SysParameterSettings_SetDisplaySSText  (pfSysParameterSettings_SetDisplaySSText != NULL)
	#define EXP_SysParameterSettings_SetDisplaySSText  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetDisplaySSText", (RTS_UINTPTR)SysParameterSettings_SetDisplaySSText, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_turnScreensaver(RTS_BOOL bON);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_TURNSCREENSAVER) (RTS_BOOL bON);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_TURNSCREENSAVER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_turnScreensaver
	#define EXT_SysParameterSettings_turnScreensaver
	#define GET_SysParameterSettings_turnScreensaver(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_turnScreensaver(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_turnScreensaver  FALSE
	#define EXP_SysParameterSettings_turnScreensaver  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_turnScreensaver
	#define EXT_SysParameterSettings_turnScreensaver
	#define GET_SysParameterSettings_turnScreensaver(fl)  CAL_CMGETAPI( "SysParameterSettings_turnScreensaver" ) 
	#define CAL_SysParameterSettings_turnScreensaver  SysParameterSettings_turnScreensaver
	#define CHK_SysParameterSettings_turnScreensaver  TRUE
	#define EXP_SysParameterSettings_turnScreensaver  CAL_CMEXPAPI( "SysParameterSettings_turnScreensaver" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_turnScreensaver
	#define EXT_SysParameterSettings_turnScreensaver
	#define GET_SysParameterSettings_turnScreensaver(fl)  CAL_CMGETAPI( "SysParameterSettings_turnScreensaver" ) 
	#define CAL_SysParameterSettings_turnScreensaver  SysParameterSettings_turnScreensaver
	#define CHK_SysParameterSettings_turnScreensaver  TRUE
	#define EXP_SysParameterSettings_turnScreensaver  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_turnScreensaver", (RTS_UINTPTR)SysParameterSettings_turnScreensaver, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_turnScreensaver
	#define EXT_SysParameterSettingsSysParameterSettings_turnScreensaver
	#define GET_SysParameterSettingsSysParameterSettings_turnScreensaver  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_turnScreensaver pISysParameterSettings->ISysParameterSettings_turnScreensaver
	#define CHK_SysParameterSettingsSysParameterSettings_turnScreensaver (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_turnScreensaver  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_turnScreensaver
	#define EXT_SysParameterSettings_turnScreensaver
	#define GET_SysParameterSettings_turnScreensaver(fl)  CAL_CMGETAPI( "SysParameterSettings_turnScreensaver" ) 
	#define CAL_SysParameterSettings_turnScreensaver pISysParameterSettings->ISysParameterSettings_turnScreensaver
	#define CHK_SysParameterSettings_turnScreensaver (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_turnScreensaver  CAL_CMEXPAPI( "SysParameterSettings_turnScreensaver" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_turnScreensaver  PFSYSPARAMETERSETTINGS_TURNSCREENSAVER pfSysParameterSettings_turnScreensaver;
	#define EXT_SysParameterSettings_turnScreensaver  extern PFSYSPARAMETERSETTINGS_TURNSCREENSAVER pfSysParameterSettings_turnScreensaver;
	#define GET_SysParameterSettings_turnScreensaver(fl)  s_pfCMGetAPI2( "SysParameterSettings_turnScreensaver", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_turnScreensaver, (fl), 0, 0)
	#define CAL_SysParameterSettings_turnScreensaver  pfSysParameterSettings_turnScreensaver
	#define CHK_SysParameterSettings_turnScreensaver  (pfSysParameterSettings_turnScreensaver != NULL)
	#define EXP_SysParameterSettings_turnScreensaver  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_turnScreensaver", (RTS_UINTPTR)SysParameterSettings_turnScreensaver, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_rotateDisplay(RTS_UI8 nRotate);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_ROTATEDISPLAY) (RTS_UI8 nRotate);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ROTATEDISPLAY_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_rotateDisplay
	#define EXT_SysParameterSettings_rotateDisplay
	#define GET_SysParameterSettings_rotateDisplay(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_rotateDisplay(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_rotateDisplay  FALSE
	#define EXP_SysParameterSettings_rotateDisplay  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_rotateDisplay
	#define EXT_SysParameterSettings_rotateDisplay
	#define GET_SysParameterSettings_rotateDisplay(fl)  CAL_CMGETAPI( "SysParameterSettings_rotateDisplay" ) 
	#define CAL_SysParameterSettings_rotateDisplay  SysParameterSettings_rotateDisplay
	#define CHK_SysParameterSettings_rotateDisplay  TRUE
	#define EXP_SysParameterSettings_rotateDisplay  CAL_CMEXPAPI( "SysParameterSettings_rotateDisplay" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_rotateDisplay
	#define EXT_SysParameterSettings_rotateDisplay
	#define GET_SysParameterSettings_rotateDisplay(fl)  CAL_CMGETAPI( "SysParameterSettings_rotateDisplay" ) 
	#define CAL_SysParameterSettings_rotateDisplay  SysParameterSettings_rotateDisplay
	#define CHK_SysParameterSettings_rotateDisplay  TRUE
	#define EXP_SysParameterSettings_rotateDisplay  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_rotateDisplay", (RTS_UINTPTR)SysParameterSettings_rotateDisplay, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_rotateDisplay
	#define EXT_SysParameterSettingsSysParameterSettings_rotateDisplay
	#define GET_SysParameterSettingsSysParameterSettings_rotateDisplay  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_rotateDisplay pISysParameterSettings->ISysParameterSettings_rotateDisplay
	#define CHK_SysParameterSettingsSysParameterSettings_rotateDisplay (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_rotateDisplay  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_rotateDisplay
	#define EXT_SysParameterSettings_rotateDisplay
	#define GET_SysParameterSettings_rotateDisplay(fl)  CAL_CMGETAPI( "SysParameterSettings_rotateDisplay" ) 
	#define CAL_SysParameterSettings_rotateDisplay pISysParameterSettings->ISysParameterSettings_rotateDisplay
	#define CHK_SysParameterSettings_rotateDisplay (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_rotateDisplay  CAL_CMEXPAPI( "SysParameterSettings_rotateDisplay" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_rotateDisplay  PFSYSPARAMETERSETTINGS_ROTATEDISPLAY pfSysParameterSettings_rotateDisplay;
	#define EXT_SysParameterSettings_rotateDisplay  extern PFSYSPARAMETERSETTINGS_ROTATEDISPLAY pfSysParameterSettings_rotateDisplay;
	#define GET_SysParameterSettings_rotateDisplay(fl)  s_pfCMGetAPI2( "SysParameterSettings_rotateDisplay", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_rotateDisplay, (fl), 0, 0)
	#define CAL_SysParameterSettings_rotateDisplay  pfSysParameterSettings_rotateDisplay
	#define CHK_SysParameterSettings_rotateDisplay  (pfSysParameterSettings_rotateDisplay != NULL)
	#define EXP_SysParameterSettings_rotateDisplay  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_rotateDisplay", (RTS_UINTPTR)SysParameterSettings_rotateDisplay, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_ClearRoutingCache(void);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_CLEARROUTINGCACHE) (void);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_CLEARROUTINGCACHE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_ClearRoutingCache
	#define EXT_SysParameterSettings_ClearRoutingCache
	#define GET_SysParameterSettings_ClearRoutingCache(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_ClearRoutingCache()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_ClearRoutingCache  FALSE
	#define EXP_SysParameterSettings_ClearRoutingCache  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_ClearRoutingCache
	#define EXT_SysParameterSettings_ClearRoutingCache
	#define GET_SysParameterSettings_ClearRoutingCache(fl)  CAL_CMGETAPI( "SysParameterSettings_ClearRoutingCache" ) 
	#define CAL_SysParameterSettings_ClearRoutingCache  SysParameterSettings_ClearRoutingCache
	#define CHK_SysParameterSettings_ClearRoutingCache  TRUE
	#define EXP_SysParameterSettings_ClearRoutingCache  CAL_CMEXPAPI( "SysParameterSettings_ClearRoutingCache" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_ClearRoutingCache
	#define EXT_SysParameterSettings_ClearRoutingCache
	#define GET_SysParameterSettings_ClearRoutingCache(fl)  CAL_CMGETAPI( "SysParameterSettings_ClearRoutingCache" ) 
	#define CAL_SysParameterSettings_ClearRoutingCache  SysParameterSettings_ClearRoutingCache
	#define CHK_SysParameterSettings_ClearRoutingCache  TRUE
	#define EXP_SysParameterSettings_ClearRoutingCache  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_ClearRoutingCache", (RTS_UINTPTR)SysParameterSettings_ClearRoutingCache, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_ClearRoutingCache
	#define EXT_SysParameterSettingsSysParameterSettings_ClearRoutingCache
	#define GET_SysParameterSettingsSysParameterSettings_ClearRoutingCache  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_ClearRoutingCache pISysParameterSettings->ISysParameterSettings_ClearRoutingCache
	#define CHK_SysParameterSettingsSysParameterSettings_ClearRoutingCache (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_ClearRoutingCache  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_ClearRoutingCache
	#define EXT_SysParameterSettings_ClearRoutingCache
	#define GET_SysParameterSettings_ClearRoutingCache(fl)  CAL_CMGETAPI( "SysParameterSettings_ClearRoutingCache" ) 
	#define CAL_SysParameterSettings_ClearRoutingCache pISysParameterSettings->ISysParameterSettings_ClearRoutingCache
	#define CHK_SysParameterSettings_ClearRoutingCache (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_ClearRoutingCache  CAL_CMEXPAPI( "SysParameterSettings_ClearRoutingCache" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_ClearRoutingCache  PFSYSPARAMETERSETTINGS_CLEARROUTINGCACHE pfSysParameterSettings_ClearRoutingCache;
	#define EXT_SysParameterSettings_ClearRoutingCache  extern PFSYSPARAMETERSETTINGS_CLEARROUTINGCACHE pfSysParameterSettings_ClearRoutingCache;
	#define GET_SysParameterSettings_ClearRoutingCache(fl)  s_pfCMGetAPI2( "SysParameterSettings_ClearRoutingCache", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_ClearRoutingCache, (fl), 0, 0)
	#define CAL_SysParameterSettings_ClearRoutingCache  pfSysParameterSettings_ClearRoutingCache
	#define CHK_SysParameterSettings_ClearRoutingCache  (pfSysParameterSettings_ClearRoutingCache != NULL)
	#define EXP_SysParameterSettings_ClearRoutingCache  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_ClearRoutingCache", (RTS_UINTPTR)SysParameterSettings_ClearRoutingCache, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetBrowserTabable(RTS_BOOL* pEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETBROWSERTABABLE) (RTS_BOOL* pEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETBROWSERTABABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetBrowserTabable
	#define EXT_SysParameterSettings_GetBrowserTabable
	#define GET_SysParameterSettings_GetBrowserTabable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetBrowserTabable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetBrowserTabable  FALSE
	#define EXP_SysParameterSettings_GetBrowserTabable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetBrowserTabable
	#define EXT_SysParameterSettings_GetBrowserTabable
	#define GET_SysParameterSettings_GetBrowserTabable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserTabable" ) 
	#define CAL_SysParameterSettings_GetBrowserTabable  SysParameterSettings_GetBrowserTabable
	#define CHK_SysParameterSettings_GetBrowserTabable  TRUE
	#define EXP_SysParameterSettings_GetBrowserTabable  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserTabable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetBrowserTabable
	#define EXT_SysParameterSettings_GetBrowserTabable
	#define GET_SysParameterSettings_GetBrowserTabable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserTabable" ) 
	#define CAL_SysParameterSettings_GetBrowserTabable  SysParameterSettings_GetBrowserTabable
	#define CHK_SysParameterSettings_GetBrowserTabable  TRUE
	#define EXP_SysParameterSettings_GetBrowserTabable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserTabable", (RTS_UINTPTR)SysParameterSettings_GetBrowserTabable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetBrowserTabable
	#define EXT_SysParameterSettingsSysParameterSettings_GetBrowserTabable
	#define GET_SysParameterSettingsSysParameterSettings_GetBrowserTabable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetBrowserTabable pISysParameterSettings->ISysParameterSettings_GetBrowserTabable
	#define CHK_SysParameterSettingsSysParameterSettings_GetBrowserTabable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetBrowserTabable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetBrowserTabable
	#define EXT_SysParameterSettings_GetBrowserTabable
	#define GET_SysParameterSettings_GetBrowserTabable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserTabable" ) 
	#define CAL_SysParameterSettings_GetBrowserTabable pISysParameterSettings->ISysParameterSettings_GetBrowserTabable
	#define CHK_SysParameterSettings_GetBrowserTabable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetBrowserTabable  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserTabable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetBrowserTabable  PFSYSPARAMETERSETTINGS_GETBROWSERTABABLE pfSysParameterSettings_GetBrowserTabable;
	#define EXT_SysParameterSettings_GetBrowserTabable  extern PFSYSPARAMETERSETTINGS_GETBROWSERTABABLE pfSysParameterSettings_GetBrowserTabable;
	#define GET_SysParameterSettings_GetBrowserTabable(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetBrowserTabable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetBrowserTabable, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetBrowserTabable  pfSysParameterSettings_GetBrowserTabable
	#define CHK_SysParameterSettings_GetBrowserTabable  (pfSysParameterSettings_GetBrowserTabable != NULL)
	#define EXP_SysParameterSettings_GetBrowserTabable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserTabable", (RTS_UINTPTR)SysParameterSettings_GetBrowserTabable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetBrowserTabable(RTS_BOOL bEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETBROWSERTABABLE) (RTS_BOOL bEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETBROWSERTABABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetBrowserTabable
	#define EXT_SysParameterSettings_SetBrowserTabable
	#define GET_SysParameterSettings_SetBrowserTabable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetBrowserTabable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetBrowserTabable  FALSE
	#define EXP_SysParameterSettings_SetBrowserTabable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetBrowserTabable
	#define EXT_SysParameterSettings_SetBrowserTabable
	#define GET_SysParameterSettings_SetBrowserTabable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserTabable" ) 
	#define CAL_SysParameterSettings_SetBrowserTabable  SysParameterSettings_SetBrowserTabable
	#define CHK_SysParameterSettings_SetBrowserTabable  TRUE
	#define EXP_SysParameterSettings_SetBrowserTabable  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserTabable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetBrowserTabable
	#define EXT_SysParameterSettings_SetBrowserTabable
	#define GET_SysParameterSettings_SetBrowserTabable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserTabable" ) 
	#define CAL_SysParameterSettings_SetBrowserTabable  SysParameterSettings_SetBrowserTabable
	#define CHK_SysParameterSettings_SetBrowserTabable  TRUE
	#define EXP_SysParameterSettings_SetBrowserTabable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserTabable", (RTS_UINTPTR)SysParameterSettings_SetBrowserTabable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetBrowserTabable
	#define EXT_SysParameterSettingsSysParameterSettings_SetBrowserTabable
	#define GET_SysParameterSettingsSysParameterSettings_SetBrowserTabable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetBrowserTabable pISysParameterSettings->ISysParameterSettings_SetBrowserTabable
	#define CHK_SysParameterSettingsSysParameterSettings_SetBrowserTabable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetBrowserTabable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetBrowserTabable
	#define EXT_SysParameterSettings_SetBrowserTabable
	#define GET_SysParameterSettings_SetBrowserTabable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserTabable" ) 
	#define CAL_SysParameterSettings_SetBrowserTabable pISysParameterSettings->ISysParameterSettings_SetBrowserTabable
	#define CHK_SysParameterSettings_SetBrowserTabable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetBrowserTabable  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserTabable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetBrowserTabable  PFSYSPARAMETERSETTINGS_SETBROWSERTABABLE pfSysParameterSettings_SetBrowserTabable;
	#define EXT_SysParameterSettings_SetBrowserTabable  extern PFSYSPARAMETERSETTINGS_SETBROWSERTABABLE pfSysParameterSettings_SetBrowserTabable;
	#define GET_SysParameterSettings_SetBrowserTabable(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetBrowserTabable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetBrowserTabable, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetBrowserTabable  pfSysParameterSettings_SetBrowserTabable
	#define CHK_SysParameterSettings_SetBrowserTabable  (pfSysParameterSettings_SetBrowserTabable != NULL)
	#define EXP_SysParameterSettings_SetBrowserTabable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserTabable", (RTS_UINTPTR)SysParameterSettings_SetBrowserTabable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetBrowserAddressBar(RTS_BOOL* pEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETBROWSERADDRESSBAR) (RTS_BOOL* pEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETBROWSERADDRESSBAR_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetBrowserAddressBar
	#define EXT_SysParameterSettings_GetBrowserAddressBar
	#define GET_SysParameterSettings_GetBrowserAddressBar(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetBrowserAddressBar(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetBrowserAddressBar  FALSE
	#define EXP_SysParameterSettings_GetBrowserAddressBar  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetBrowserAddressBar
	#define EXT_SysParameterSettings_GetBrowserAddressBar
	#define GET_SysParameterSettings_GetBrowserAddressBar(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserAddressBar" ) 
	#define CAL_SysParameterSettings_GetBrowserAddressBar  SysParameterSettings_GetBrowserAddressBar
	#define CHK_SysParameterSettings_GetBrowserAddressBar  TRUE
	#define EXP_SysParameterSettings_GetBrowserAddressBar  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserAddressBar" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetBrowserAddressBar
	#define EXT_SysParameterSettings_GetBrowserAddressBar
	#define GET_SysParameterSettings_GetBrowserAddressBar(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserAddressBar" ) 
	#define CAL_SysParameterSettings_GetBrowserAddressBar  SysParameterSettings_GetBrowserAddressBar
	#define CHK_SysParameterSettings_GetBrowserAddressBar  TRUE
	#define EXP_SysParameterSettings_GetBrowserAddressBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserAddressBar", (RTS_UINTPTR)SysParameterSettings_GetBrowserAddressBar, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetBrowserAddressBar
	#define EXT_SysParameterSettingsSysParameterSettings_GetBrowserAddressBar
	#define GET_SysParameterSettingsSysParameterSettings_GetBrowserAddressBar  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetBrowserAddressBar pISysParameterSettings->ISysParameterSettings_GetBrowserAddressBar
	#define CHK_SysParameterSettingsSysParameterSettings_GetBrowserAddressBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetBrowserAddressBar  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetBrowserAddressBar
	#define EXT_SysParameterSettings_GetBrowserAddressBar
	#define GET_SysParameterSettings_GetBrowserAddressBar(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserAddressBar" ) 
	#define CAL_SysParameterSettings_GetBrowserAddressBar pISysParameterSettings->ISysParameterSettings_GetBrowserAddressBar
	#define CHK_SysParameterSettings_GetBrowserAddressBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetBrowserAddressBar  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserAddressBar" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetBrowserAddressBar  PFSYSPARAMETERSETTINGS_GETBROWSERADDRESSBAR pfSysParameterSettings_GetBrowserAddressBar;
	#define EXT_SysParameterSettings_GetBrowserAddressBar  extern PFSYSPARAMETERSETTINGS_GETBROWSERADDRESSBAR pfSysParameterSettings_GetBrowserAddressBar;
	#define GET_SysParameterSettings_GetBrowserAddressBar(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetBrowserAddressBar", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetBrowserAddressBar, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetBrowserAddressBar  pfSysParameterSettings_GetBrowserAddressBar
	#define CHK_SysParameterSettings_GetBrowserAddressBar  (pfSysParameterSettings_GetBrowserAddressBar != NULL)
	#define EXP_SysParameterSettings_GetBrowserAddressBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserAddressBar", (RTS_UINTPTR)SysParameterSettings_GetBrowserAddressBar, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetBrowserAddressBar(RTS_BOOL bEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETBROWSERADDRESSBAR) (RTS_BOOL bEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETBROWSERADDRESSBAR_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetBrowserAddressBar
	#define EXT_SysParameterSettings_SetBrowserAddressBar
	#define GET_SysParameterSettings_SetBrowserAddressBar(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetBrowserAddressBar(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetBrowserAddressBar  FALSE
	#define EXP_SysParameterSettings_SetBrowserAddressBar  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetBrowserAddressBar
	#define EXT_SysParameterSettings_SetBrowserAddressBar
	#define GET_SysParameterSettings_SetBrowserAddressBar(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserAddressBar" ) 
	#define CAL_SysParameterSettings_SetBrowserAddressBar  SysParameterSettings_SetBrowserAddressBar
	#define CHK_SysParameterSettings_SetBrowserAddressBar  TRUE
	#define EXP_SysParameterSettings_SetBrowserAddressBar  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserAddressBar" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetBrowserAddressBar
	#define EXT_SysParameterSettings_SetBrowserAddressBar
	#define GET_SysParameterSettings_SetBrowserAddressBar(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserAddressBar" ) 
	#define CAL_SysParameterSettings_SetBrowserAddressBar  SysParameterSettings_SetBrowserAddressBar
	#define CHK_SysParameterSettings_SetBrowserAddressBar  TRUE
	#define EXP_SysParameterSettings_SetBrowserAddressBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserAddressBar", (RTS_UINTPTR)SysParameterSettings_SetBrowserAddressBar, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetBrowserAddressBar
	#define EXT_SysParameterSettingsSysParameterSettings_SetBrowserAddressBar
	#define GET_SysParameterSettingsSysParameterSettings_SetBrowserAddressBar  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetBrowserAddressBar pISysParameterSettings->ISysParameterSettings_SetBrowserAddressBar
	#define CHK_SysParameterSettingsSysParameterSettings_SetBrowserAddressBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetBrowserAddressBar  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetBrowserAddressBar
	#define EXT_SysParameterSettings_SetBrowserAddressBar
	#define GET_SysParameterSettings_SetBrowserAddressBar(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserAddressBar" ) 
	#define CAL_SysParameterSettings_SetBrowserAddressBar pISysParameterSettings->ISysParameterSettings_SetBrowserAddressBar
	#define CHK_SysParameterSettings_SetBrowserAddressBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetBrowserAddressBar  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserAddressBar" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetBrowserAddressBar  PFSYSPARAMETERSETTINGS_SETBROWSERADDRESSBAR pfSysParameterSettings_SetBrowserAddressBar;
	#define EXT_SysParameterSettings_SetBrowserAddressBar  extern PFSYSPARAMETERSETTINGS_SETBROWSERADDRESSBAR pfSysParameterSettings_SetBrowserAddressBar;
	#define GET_SysParameterSettings_SetBrowserAddressBar(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetBrowserAddressBar", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetBrowserAddressBar, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetBrowserAddressBar  pfSysParameterSettings_SetBrowserAddressBar
	#define CHK_SysParameterSettings_SetBrowserAddressBar  (pfSysParameterSettings_SetBrowserAddressBar != NULL)
	#define EXP_SysParameterSettings_SetBrowserAddressBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserAddressBar", (RTS_UINTPTR)SysParameterSettings_SetBrowserAddressBar, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetBrowserFavouriteBar(RTS_BOOL* pEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETBROWSERFAVOURITEBAR) (RTS_BOOL* pEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETBROWSERFAVOURITEBAR_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetBrowserFavouriteBar
	#define EXT_SysParameterSettings_GetBrowserFavouriteBar
	#define GET_SysParameterSettings_GetBrowserFavouriteBar(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetBrowserFavouriteBar(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetBrowserFavouriteBar  FALSE
	#define EXP_SysParameterSettings_GetBrowserFavouriteBar  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetBrowserFavouriteBar
	#define EXT_SysParameterSettings_GetBrowserFavouriteBar
	#define GET_SysParameterSettings_GetBrowserFavouriteBar(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserFavouriteBar" ) 
	#define CAL_SysParameterSettings_GetBrowserFavouriteBar  SysParameterSettings_GetBrowserFavouriteBar
	#define CHK_SysParameterSettings_GetBrowserFavouriteBar  TRUE
	#define EXP_SysParameterSettings_GetBrowserFavouriteBar  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserFavouriteBar" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetBrowserFavouriteBar
	#define EXT_SysParameterSettings_GetBrowserFavouriteBar
	#define GET_SysParameterSettings_GetBrowserFavouriteBar(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserFavouriteBar" ) 
	#define CAL_SysParameterSettings_GetBrowserFavouriteBar  SysParameterSettings_GetBrowserFavouriteBar
	#define CHK_SysParameterSettings_GetBrowserFavouriteBar  TRUE
	#define EXP_SysParameterSettings_GetBrowserFavouriteBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserFavouriteBar", (RTS_UINTPTR)SysParameterSettings_GetBrowserFavouriteBar, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetBrowserFavouriteBar
	#define EXT_SysParameterSettingsSysParameterSettings_GetBrowserFavouriteBar
	#define GET_SysParameterSettingsSysParameterSettings_GetBrowserFavouriteBar  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetBrowserFavouriteBar pISysParameterSettings->ISysParameterSettings_GetBrowserFavouriteBar
	#define CHK_SysParameterSettingsSysParameterSettings_GetBrowserFavouriteBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetBrowserFavouriteBar  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetBrowserFavouriteBar
	#define EXT_SysParameterSettings_GetBrowserFavouriteBar
	#define GET_SysParameterSettings_GetBrowserFavouriteBar(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserFavouriteBar" ) 
	#define CAL_SysParameterSettings_GetBrowserFavouriteBar pISysParameterSettings->ISysParameterSettings_GetBrowserFavouriteBar
	#define CHK_SysParameterSettings_GetBrowserFavouriteBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetBrowserFavouriteBar  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserFavouriteBar" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetBrowserFavouriteBar  PFSYSPARAMETERSETTINGS_GETBROWSERFAVOURITEBAR pfSysParameterSettings_GetBrowserFavouriteBar;
	#define EXT_SysParameterSettings_GetBrowserFavouriteBar  extern PFSYSPARAMETERSETTINGS_GETBROWSERFAVOURITEBAR pfSysParameterSettings_GetBrowserFavouriteBar;
	#define GET_SysParameterSettings_GetBrowserFavouriteBar(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetBrowserFavouriteBar", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetBrowserFavouriteBar, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetBrowserFavouriteBar  pfSysParameterSettings_GetBrowserFavouriteBar
	#define CHK_SysParameterSettings_GetBrowserFavouriteBar  (pfSysParameterSettings_GetBrowserFavouriteBar != NULL)
	#define EXP_SysParameterSettings_GetBrowserFavouriteBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserFavouriteBar", (RTS_UINTPTR)SysParameterSettings_GetBrowserFavouriteBar, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetBrowserFavouriteBar(RTS_BOOL bEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETBROWSERFAVOURITEBAR) (RTS_BOOL bEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETBROWSERFAVOURITEBAR_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetBrowserFavouriteBar
	#define EXT_SysParameterSettings_SetBrowserFavouriteBar
	#define GET_SysParameterSettings_SetBrowserFavouriteBar(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetBrowserFavouriteBar(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetBrowserFavouriteBar  FALSE
	#define EXP_SysParameterSettings_SetBrowserFavouriteBar  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetBrowserFavouriteBar
	#define EXT_SysParameterSettings_SetBrowserFavouriteBar
	#define GET_SysParameterSettings_SetBrowserFavouriteBar(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserFavouriteBar" ) 
	#define CAL_SysParameterSettings_SetBrowserFavouriteBar  SysParameterSettings_SetBrowserFavouriteBar
	#define CHK_SysParameterSettings_SetBrowserFavouriteBar  TRUE
	#define EXP_SysParameterSettings_SetBrowserFavouriteBar  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserFavouriteBar" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetBrowserFavouriteBar
	#define EXT_SysParameterSettings_SetBrowserFavouriteBar
	#define GET_SysParameterSettings_SetBrowserFavouriteBar(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserFavouriteBar" ) 
	#define CAL_SysParameterSettings_SetBrowserFavouriteBar  SysParameterSettings_SetBrowserFavouriteBar
	#define CHK_SysParameterSettings_SetBrowserFavouriteBar  TRUE
	#define EXP_SysParameterSettings_SetBrowserFavouriteBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserFavouriteBar", (RTS_UINTPTR)SysParameterSettings_SetBrowserFavouriteBar, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetBrowserFavouriteBar
	#define EXT_SysParameterSettingsSysParameterSettings_SetBrowserFavouriteBar
	#define GET_SysParameterSettingsSysParameterSettings_SetBrowserFavouriteBar  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetBrowserFavouriteBar pISysParameterSettings->ISysParameterSettings_SetBrowserFavouriteBar
	#define CHK_SysParameterSettingsSysParameterSettings_SetBrowserFavouriteBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetBrowserFavouriteBar  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetBrowserFavouriteBar
	#define EXT_SysParameterSettings_SetBrowserFavouriteBar
	#define GET_SysParameterSettings_SetBrowserFavouriteBar(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserFavouriteBar" ) 
	#define CAL_SysParameterSettings_SetBrowserFavouriteBar pISysParameterSettings->ISysParameterSettings_SetBrowserFavouriteBar
	#define CHK_SysParameterSettings_SetBrowserFavouriteBar (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetBrowserFavouriteBar  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserFavouriteBar" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetBrowserFavouriteBar  PFSYSPARAMETERSETTINGS_SETBROWSERFAVOURITEBAR pfSysParameterSettings_SetBrowserFavouriteBar;
	#define EXT_SysParameterSettings_SetBrowserFavouriteBar  extern PFSYSPARAMETERSETTINGS_SETBROWSERFAVOURITEBAR pfSysParameterSettings_SetBrowserFavouriteBar;
	#define GET_SysParameterSettings_SetBrowserFavouriteBar(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetBrowserFavouriteBar", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetBrowserFavouriteBar, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetBrowserFavouriteBar  pfSysParameterSettings_SetBrowserFavouriteBar
	#define CHK_SysParameterSettings_SetBrowserFavouriteBar  (pfSysParameterSettings_SetBrowserFavouriteBar != NULL)
	#define EXP_SysParameterSettings_SetBrowserFavouriteBar  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserFavouriteBar", (RTS_UINTPTR)SysParameterSettings_SetBrowserFavouriteBar, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetBrowserZoomable(RTS_BOOL* pEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETBROWSERZOOMABLE) (RTS_BOOL* pEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETBROWSERZOOMABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetBrowserZoomable
	#define EXT_SysParameterSettings_GetBrowserZoomable
	#define GET_SysParameterSettings_GetBrowserZoomable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetBrowserZoomable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetBrowserZoomable  FALSE
	#define EXP_SysParameterSettings_GetBrowserZoomable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetBrowserZoomable
	#define EXT_SysParameterSettings_GetBrowserZoomable
	#define GET_SysParameterSettings_GetBrowserZoomable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserZoomable" ) 
	#define CAL_SysParameterSettings_GetBrowserZoomable  SysParameterSettings_GetBrowserZoomable
	#define CHK_SysParameterSettings_GetBrowserZoomable  TRUE
	#define EXP_SysParameterSettings_GetBrowserZoomable  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserZoomable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetBrowserZoomable
	#define EXT_SysParameterSettings_GetBrowserZoomable
	#define GET_SysParameterSettings_GetBrowserZoomable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserZoomable" ) 
	#define CAL_SysParameterSettings_GetBrowserZoomable  SysParameterSettings_GetBrowserZoomable
	#define CHK_SysParameterSettings_GetBrowserZoomable  TRUE
	#define EXP_SysParameterSettings_GetBrowserZoomable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserZoomable", (RTS_UINTPTR)SysParameterSettings_GetBrowserZoomable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetBrowserZoomable
	#define EXT_SysParameterSettingsSysParameterSettings_GetBrowserZoomable
	#define GET_SysParameterSettingsSysParameterSettings_GetBrowserZoomable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetBrowserZoomable pISysParameterSettings->ISysParameterSettings_GetBrowserZoomable
	#define CHK_SysParameterSettingsSysParameterSettings_GetBrowserZoomable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetBrowserZoomable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetBrowserZoomable
	#define EXT_SysParameterSettings_GetBrowserZoomable
	#define GET_SysParameterSettings_GetBrowserZoomable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserZoomable" ) 
	#define CAL_SysParameterSettings_GetBrowserZoomable pISysParameterSettings->ISysParameterSettings_GetBrowserZoomable
	#define CHK_SysParameterSettings_GetBrowserZoomable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetBrowserZoomable  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserZoomable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetBrowserZoomable  PFSYSPARAMETERSETTINGS_GETBROWSERZOOMABLE pfSysParameterSettings_GetBrowserZoomable;
	#define EXT_SysParameterSettings_GetBrowserZoomable  extern PFSYSPARAMETERSETTINGS_GETBROWSERZOOMABLE pfSysParameterSettings_GetBrowserZoomable;
	#define GET_SysParameterSettings_GetBrowserZoomable(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetBrowserZoomable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetBrowserZoomable, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetBrowserZoomable  pfSysParameterSettings_GetBrowserZoomable
	#define CHK_SysParameterSettings_GetBrowserZoomable  (pfSysParameterSettings_GetBrowserZoomable != NULL)
	#define EXP_SysParameterSettings_GetBrowserZoomable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserZoomable", (RTS_UINTPTR)SysParameterSettings_GetBrowserZoomable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetBrowserZoomable(RTS_BOOL bEnable);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETBROWSERZOOMABLE) (RTS_BOOL bEnable);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETBROWSERZOOMABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetBrowserZoomable
	#define EXT_SysParameterSettings_SetBrowserZoomable
	#define GET_SysParameterSettings_SetBrowserZoomable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetBrowserZoomable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetBrowserZoomable  FALSE
	#define EXP_SysParameterSettings_SetBrowserZoomable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetBrowserZoomable
	#define EXT_SysParameterSettings_SetBrowserZoomable
	#define GET_SysParameterSettings_SetBrowserZoomable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserZoomable" ) 
	#define CAL_SysParameterSettings_SetBrowserZoomable  SysParameterSettings_SetBrowserZoomable
	#define CHK_SysParameterSettings_SetBrowserZoomable  TRUE
	#define EXP_SysParameterSettings_SetBrowserZoomable  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserZoomable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetBrowserZoomable
	#define EXT_SysParameterSettings_SetBrowserZoomable
	#define GET_SysParameterSettings_SetBrowserZoomable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserZoomable" ) 
	#define CAL_SysParameterSettings_SetBrowserZoomable  SysParameterSettings_SetBrowserZoomable
	#define CHK_SysParameterSettings_SetBrowserZoomable  TRUE
	#define EXP_SysParameterSettings_SetBrowserZoomable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserZoomable", (RTS_UINTPTR)SysParameterSettings_SetBrowserZoomable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetBrowserZoomable
	#define EXT_SysParameterSettingsSysParameterSettings_SetBrowserZoomable
	#define GET_SysParameterSettingsSysParameterSettings_SetBrowserZoomable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetBrowserZoomable pISysParameterSettings->ISysParameterSettings_SetBrowserZoomable
	#define CHK_SysParameterSettingsSysParameterSettings_SetBrowserZoomable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetBrowserZoomable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetBrowserZoomable
	#define EXT_SysParameterSettings_SetBrowserZoomable
	#define GET_SysParameterSettings_SetBrowserZoomable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserZoomable" ) 
	#define CAL_SysParameterSettings_SetBrowserZoomable pISysParameterSettings->ISysParameterSettings_SetBrowserZoomable
	#define CHK_SysParameterSettings_SetBrowserZoomable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetBrowserZoomable  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserZoomable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetBrowserZoomable  PFSYSPARAMETERSETTINGS_SETBROWSERZOOMABLE pfSysParameterSettings_SetBrowserZoomable;
	#define EXT_SysParameterSettings_SetBrowserZoomable  extern PFSYSPARAMETERSETTINGS_SETBROWSERZOOMABLE pfSysParameterSettings_SetBrowserZoomable;
	#define GET_SysParameterSettings_SetBrowserZoomable(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetBrowserZoomable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetBrowserZoomable, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetBrowserZoomable  pfSysParameterSettings_SetBrowserZoomable
	#define CHK_SysParameterSettings_SetBrowserZoomable  (pfSysParameterSettings_SetBrowserZoomable != NULL)
	#define EXP_SysParameterSettings_SetBrowserZoomable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserZoomable", (RTS_UINTPTR)SysParameterSettings_SetBrowserZoomable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetBrowserURLs(char * szURLs, RTS_IEC_DWORD* pSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETBROWSERURLS) (char * szURLs, RTS_IEC_DWORD* pSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETBROWSERURLS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetBrowserURLs
	#define EXT_SysParameterSettings_GetBrowserURLs
	#define GET_SysParameterSettings_GetBrowserURLs(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetBrowserURLs(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetBrowserURLs  FALSE
	#define EXP_SysParameterSettings_GetBrowserURLs  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetBrowserURLs
	#define EXT_SysParameterSettings_GetBrowserURLs
	#define GET_SysParameterSettings_GetBrowserURLs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserURLs" ) 
	#define CAL_SysParameterSettings_GetBrowserURLs  SysParameterSettings_GetBrowserURLs
	#define CHK_SysParameterSettings_GetBrowserURLs  TRUE
	#define EXP_SysParameterSettings_GetBrowserURLs  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserURLs" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetBrowserURLs
	#define EXT_SysParameterSettings_GetBrowserURLs
	#define GET_SysParameterSettings_GetBrowserURLs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserURLs" ) 
	#define CAL_SysParameterSettings_GetBrowserURLs  SysParameterSettings_GetBrowserURLs
	#define CHK_SysParameterSettings_GetBrowserURLs  TRUE
	#define EXP_SysParameterSettings_GetBrowserURLs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserURLs", (RTS_UINTPTR)SysParameterSettings_GetBrowserURLs, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetBrowserURLs
	#define EXT_SysParameterSettingsSysParameterSettings_GetBrowserURLs
	#define GET_SysParameterSettingsSysParameterSettings_GetBrowserURLs  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetBrowserURLs pISysParameterSettings->ISysParameterSettings_GetBrowserURLs
	#define CHK_SysParameterSettingsSysParameterSettings_GetBrowserURLs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetBrowserURLs  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetBrowserURLs
	#define EXT_SysParameterSettings_GetBrowserURLs
	#define GET_SysParameterSettings_GetBrowserURLs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserURLs" ) 
	#define CAL_SysParameterSettings_GetBrowserURLs pISysParameterSettings->ISysParameterSettings_GetBrowserURLs
	#define CHK_SysParameterSettings_GetBrowserURLs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetBrowserURLs  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserURLs" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetBrowserURLs  PFSYSPARAMETERSETTINGS_GETBROWSERURLS pfSysParameterSettings_GetBrowserURLs;
	#define EXT_SysParameterSettings_GetBrowserURLs  extern PFSYSPARAMETERSETTINGS_GETBROWSERURLS pfSysParameterSettings_GetBrowserURLs;
	#define GET_SysParameterSettings_GetBrowserURLs(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetBrowserURLs", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetBrowserURLs, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetBrowserURLs  pfSysParameterSettings_GetBrowserURLs
	#define CHK_SysParameterSettings_GetBrowserURLs  (pfSysParameterSettings_GetBrowserURLs != NULL)
	#define EXP_SysParameterSettings_GetBrowserURLs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserURLs", (RTS_UINTPTR)SysParameterSettings_GetBrowserURLs, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetBrowserURLs(char * szURLs, RTS_IEC_DWORD siSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETBROWSERURLS) (char * szURLs, RTS_IEC_DWORD siSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETBROWSERURLS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetBrowserURLs
	#define EXT_SysParameterSettings_SetBrowserURLs
	#define GET_SysParameterSettings_SetBrowserURLs(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetBrowserURLs(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetBrowserURLs  FALSE
	#define EXP_SysParameterSettings_SetBrowserURLs  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetBrowserURLs
	#define EXT_SysParameterSettings_SetBrowserURLs
	#define GET_SysParameterSettings_SetBrowserURLs(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserURLs" ) 
	#define CAL_SysParameterSettings_SetBrowserURLs  SysParameterSettings_SetBrowserURLs
	#define CHK_SysParameterSettings_SetBrowserURLs  TRUE
	#define EXP_SysParameterSettings_SetBrowserURLs  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserURLs" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetBrowserURLs
	#define EXT_SysParameterSettings_SetBrowserURLs
	#define GET_SysParameterSettings_SetBrowserURLs(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserURLs" ) 
	#define CAL_SysParameterSettings_SetBrowserURLs  SysParameterSettings_SetBrowserURLs
	#define CHK_SysParameterSettings_SetBrowserURLs  TRUE
	#define EXP_SysParameterSettings_SetBrowserURLs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserURLs", (RTS_UINTPTR)SysParameterSettings_SetBrowserURLs, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetBrowserURLs
	#define EXT_SysParameterSettingsSysParameterSettings_SetBrowserURLs
	#define GET_SysParameterSettingsSysParameterSettings_SetBrowserURLs  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetBrowserURLs pISysParameterSettings->ISysParameterSettings_SetBrowserURLs
	#define CHK_SysParameterSettingsSysParameterSettings_SetBrowserURLs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetBrowserURLs  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetBrowserURLs
	#define EXT_SysParameterSettings_SetBrowserURLs
	#define GET_SysParameterSettings_SetBrowserURLs(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserURLs" ) 
	#define CAL_SysParameterSettings_SetBrowserURLs pISysParameterSettings->ISysParameterSettings_SetBrowserURLs
	#define CHK_SysParameterSettings_SetBrowserURLs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetBrowserURLs  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserURLs" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetBrowserURLs  PFSYSPARAMETERSETTINGS_SETBROWSERURLS pfSysParameterSettings_SetBrowserURLs;
	#define EXT_SysParameterSettings_SetBrowserURLs  extern PFSYSPARAMETERSETTINGS_SETBROWSERURLS pfSysParameterSettings_SetBrowserURLs;
	#define GET_SysParameterSettings_SetBrowserURLs(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetBrowserURLs", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetBrowserURLs, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetBrowserURLs  pfSysParameterSettings_SetBrowserURLs
	#define CHK_SysParameterSettings_SetBrowserURLs  (pfSysParameterSettings_SetBrowserURLs != NULL)
	#define EXP_SysParameterSettings_SetBrowserURLs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserURLs", (RTS_UINTPTR)SysParameterSettings_SetBrowserURLs, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_getSSImage();
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSSIMAGE) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSSIMAGE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_getSSImage
	#define EXT_SysParameterSettings_getSSImage
	#define GET_SysParameterSettings_getSSImage(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_getSSImage()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_getSSImage  FALSE
	#define EXP_SysParameterSettings_getSSImage  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_getSSImage
	#define EXT_SysParameterSettings_getSSImage
	#define GET_SysParameterSettings_getSSImage(fl)  CAL_CMGETAPI( "SysParameterSettings_getSSImage" ) 
	#define CAL_SysParameterSettings_getSSImage  SysParameterSettings_getSSImage
	#define CHK_SysParameterSettings_getSSImage  TRUE
	#define EXP_SysParameterSettings_getSSImage  CAL_CMEXPAPI( "SysParameterSettings_getSSImage" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_getSSImage
	#define EXT_SysParameterSettings_getSSImage
	#define GET_SysParameterSettings_getSSImage(fl)  CAL_CMGETAPI( "SysParameterSettings_getSSImage" ) 
	#define CAL_SysParameterSettings_getSSImage  SysParameterSettings_getSSImage
	#define CHK_SysParameterSettings_getSSImage  TRUE
	#define EXP_SysParameterSettings_getSSImage  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_getSSImage", (RTS_UINTPTR)SysParameterSettings_getSSImage, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_getSSImage
	#define EXT_SysParameterSettingsSysParameterSettings_getSSImage
	#define GET_SysParameterSettingsSysParameterSettings_getSSImage  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_getSSImage pISysParameterSettings->ISysParameterSettings_getSSImage
	#define CHK_SysParameterSettingsSysParameterSettings_getSSImage (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_getSSImage  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_getSSImage
	#define EXT_SysParameterSettings_getSSImage
	#define GET_SysParameterSettings_getSSImage(fl)  CAL_CMGETAPI( "SysParameterSettings_getSSImage" ) 
	#define CAL_SysParameterSettings_getSSImage pISysParameterSettings->ISysParameterSettings_getSSImage
	#define CHK_SysParameterSettings_getSSImage (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_getSSImage  CAL_CMEXPAPI( "SysParameterSettings_getSSImage" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_getSSImage  PFSYSPARAMETERSETTINGS_GETSSIMAGE pfSysParameterSettings_getSSImage;
	#define EXT_SysParameterSettings_getSSImage  extern PFSYSPARAMETERSETTINGS_GETSSIMAGE pfSysParameterSettings_getSSImage;
	#define GET_SysParameterSettings_getSSImage(fl)  s_pfCMGetAPI2( "SysParameterSettings_getSSImage", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_getSSImage, (fl), 0, 0)
	#define CAL_SysParameterSettings_getSSImage  pfSysParameterSettings_getSSImage
	#define CHK_SysParameterSettings_getSSImage  (pfSysParameterSettings_getSSImage != NULL)
	#define EXP_SysParameterSettings_getSSImage  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_getSSImage", (RTS_UINTPTR)SysParameterSettings_getSSImage, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetStartCountdown(RTS_UI16* pStartCountdown);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSTARTCOUNTDOWN) (RTS_UI16* pStartCountdown);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSTARTCOUNTDOWN_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetStartCountdown
	#define EXT_SysParameterSettings_GetStartCountdown
	#define GET_SysParameterSettings_GetStartCountdown(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetStartCountdown(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetStartCountdown  FALSE
	#define EXP_SysParameterSettings_GetStartCountdown  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetStartCountdown
	#define EXT_SysParameterSettings_GetStartCountdown
	#define GET_SysParameterSettings_GetStartCountdown(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStartCountdown" ) 
	#define CAL_SysParameterSettings_GetStartCountdown  SysParameterSettings_GetStartCountdown
	#define CHK_SysParameterSettings_GetStartCountdown  TRUE
	#define EXP_SysParameterSettings_GetStartCountdown  CAL_CMEXPAPI( "SysParameterSettings_GetStartCountdown" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetStartCountdown
	#define EXT_SysParameterSettings_GetStartCountdown
	#define GET_SysParameterSettings_GetStartCountdown(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStartCountdown" ) 
	#define CAL_SysParameterSettings_GetStartCountdown  SysParameterSettings_GetStartCountdown
	#define CHK_SysParameterSettings_GetStartCountdown  TRUE
	#define EXP_SysParameterSettings_GetStartCountdown  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetStartCountdown", (RTS_UINTPTR)SysParameterSettings_GetStartCountdown, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetStartCountdown
	#define EXT_SysParameterSettingsSysParameterSettings_GetStartCountdown
	#define GET_SysParameterSettingsSysParameterSettings_GetStartCountdown  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetStartCountdown pISysParameterSettings->ISysParameterSettings_GetStartCountdown
	#define CHK_SysParameterSettingsSysParameterSettings_GetStartCountdown (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetStartCountdown  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetStartCountdown
	#define EXT_SysParameterSettings_GetStartCountdown
	#define GET_SysParameterSettings_GetStartCountdown(fl)  CAL_CMGETAPI( "SysParameterSettings_GetStartCountdown" ) 
	#define CAL_SysParameterSettings_GetStartCountdown pISysParameterSettings->ISysParameterSettings_GetStartCountdown
	#define CHK_SysParameterSettings_GetStartCountdown (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetStartCountdown  CAL_CMEXPAPI( "SysParameterSettings_GetStartCountdown" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetStartCountdown  PFSYSPARAMETERSETTINGS_GETSTARTCOUNTDOWN pfSysParameterSettings_GetStartCountdown;
	#define EXT_SysParameterSettings_GetStartCountdown  extern PFSYSPARAMETERSETTINGS_GETSTARTCOUNTDOWN pfSysParameterSettings_GetStartCountdown;
	#define GET_SysParameterSettings_GetStartCountdown(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetStartCountdown", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetStartCountdown, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetStartCountdown  pfSysParameterSettings_GetStartCountdown
	#define CHK_SysParameterSettings_GetStartCountdown  (pfSysParameterSettings_GetStartCountdown != NULL)
	#define EXP_SysParameterSettings_GetStartCountdown  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetStartCountdown", (RTS_UINTPTR)SysParameterSettings_GetStartCountdown, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetStartCountdown(RTS_UI16 nStartCountdown);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETSTARTCOUNTDOWN) (RTS_UI16 nStartCountdown);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETSTARTCOUNTDOWN_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetStartCountdown
	#define EXT_SysParameterSettings_SetStartCountdown
	#define GET_SysParameterSettings_SetStartCountdown(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetStartCountdown(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetStartCountdown  FALSE
	#define EXP_SysParameterSettings_SetStartCountdown  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetStartCountdown
	#define EXT_SysParameterSettings_SetStartCountdown
	#define GET_SysParameterSettings_SetStartCountdown(fl)  CAL_CMGETAPI( "SysParameterSettings_SetStartCountdown" ) 
	#define CAL_SysParameterSettings_SetStartCountdown  SysParameterSettings_SetStartCountdown
	#define CHK_SysParameterSettings_SetStartCountdown  TRUE
	#define EXP_SysParameterSettings_SetStartCountdown  CAL_CMEXPAPI( "SysParameterSettings_SetStartCountdown" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetStartCountdown
	#define EXT_SysParameterSettings_SetStartCountdown
	#define GET_SysParameterSettings_SetStartCountdown(fl)  CAL_CMGETAPI( "SysParameterSettings_SetStartCountdown" ) 
	#define CAL_SysParameterSettings_SetStartCountdown  SysParameterSettings_SetStartCountdown
	#define CHK_SysParameterSettings_SetStartCountdown  TRUE
	#define EXP_SysParameterSettings_SetStartCountdown  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetStartCountdown", (RTS_UINTPTR)SysParameterSettings_SetStartCountdown, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetStartCountdown
	#define EXT_SysParameterSettingsSysParameterSettings_SetStartCountdown
	#define GET_SysParameterSettingsSysParameterSettings_SetStartCountdown  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetStartCountdown pISysParameterSettings->ISysParameterSettings_SetStartCountdown
	#define CHK_SysParameterSettingsSysParameterSettings_SetStartCountdown (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetStartCountdown  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetStartCountdown
	#define EXT_SysParameterSettings_SetStartCountdown
	#define GET_SysParameterSettings_SetStartCountdown(fl)  CAL_CMGETAPI( "SysParameterSettings_SetStartCountdown" ) 
	#define CAL_SysParameterSettings_SetStartCountdown pISysParameterSettings->ISysParameterSettings_SetStartCountdown
	#define CHK_SysParameterSettings_SetStartCountdown (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetStartCountdown  CAL_CMEXPAPI( "SysParameterSettings_SetStartCountdown" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetStartCountdown  PFSYSPARAMETERSETTINGS_SETSTARTCOUNTDOWN pfSysParameterSettings_SetStartCountdown;
	#define EXT_SysParameterSettings_SetStartCountdown  extern PFSYSPARAMETERSETTINGS_SETSTARTCOUNTDOWN pfSysParameterSettings_SetStartCountdown;
	#define GET_SysParameterSettings_SetStartCountdown(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetStartCountdown", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetStartCountdown, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetStartCountdown  pfSysParameterSettings_SetStartCountdown
	#define CHK_SysParameterSettings_SetStartCountdown  (pfSysParameterSettings_SetStartCountdown != NULL)
	#define EXP_SysParameterSettings_SetStartCountdown  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetStartCountdown", (RTS_UINTPTR)SysParameterSettings_SetStartCountdown, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetBrowserSecurity(char * szSecurity, int buflen);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETBROWSERSECURITY) (char * szSecurity, int buflen);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETBROWSERSECURITY_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetBrowserSecurity
	#define EXT_SysParameterSettings_GetBrowserSecurity
	#define GET_SysParameterSettings_GetBrowserSecurity(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetBrowserSecurity(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetBrowserSecurity  FALSE
	#define EXP_SysParameterSettings_GetBrowserSecurity  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetBrowserSecurity
	#define EXT_SysParameterSettings_GetBrowserSecurity
	#define GET_SysParameterSettings_GetBrowserSecurity(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserSecurity" ) 
	#define CAL_SysParameterSettings_GetBrowserSecurity  SysParameterSettings_GetBrowserSecurity
	#define CHK_SysParameterSettings_GetBrowserSecurity  TRUE
	#define EXP_SysParameterSettings_GetBrowserSecurity  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserSecurity" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetBrowserSecurity
	#define EXT_SysParameterSettings_GetBrowserSecurity
	#define GET_SysParameterSettings_GetBrowserSecurity(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserSecurity" ) 
	#define CAL_SysParameterSettings_GetBrowserSecurity  SysParameterSettings_GetBrowserSecurity
	#define CHK_SysParameterSettings_GetBrowserSecurity  TRUE
	#define EXP_SysParameterSettings_GetBrowserSecurity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserSecurity", (RTS_UINTPTR)SysParameterSettings_GetBrowserSecurity, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetBrowserSecurity
	#define EXT_SysParameterSettingsSysParameterSettings_GetBrowserSecurity
	#define GET_SysParameterSettingsSysParameterSettings_GetBrowserSecurity  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetBrowserSecurity pISysParameterSettings->ISysParameterSettings_GetBrowserSecurity
	#define CHK_SysParameterSettingsSysParameterSettings_GetBrowserSecurity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetBrowserSecurity  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetBrowserSecurity
	#define EXT_SysParameterSettings_GetBrowserSecurity
	#define GET_SysParameterSettings_GetBrowserSecurity(fl)  CAL_CMGETAPI( "SysParameterSettings_GetBrowserSecurity" ) 
	#define CAL_SysParameterSettings_GetBrowserSecurity pISysParameterSettings->ISysParameterSettings_GetBrowserSecurity
	#define CHK_SysParameterSettings_GetBrowserSecurity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetBrowserSecurity  CAL_CMEXPAPI( "SysParameterSettings_GetBrowserSecurity" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetBrowserSecurity  PFSYSPARAMETERSETTINGS_GETBROWSERSECURITY pfSysParameterSettings_GetBrowserSecurity;
	#define EXT_SysParameterSettings_GetBrowserSecurity  extern PFSYSPARAMETERSETTINGS_GETBROWSERSECURITY pfSysParameterSettings_GetBrowserSecurity;
	#define GET_SysParameterSettings_GetBrowserSecurity(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetBrowserSecurity", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetBrowserSecurity, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetBrowserSecurity  pfSysParameterSettings_GetBrowserSecurity
	#define CHK_SysParameterSettings_GetBrowserSecurity  (pfSysParameterSettings_GetBrowserSecurity != NULL)
	#define EXP_SysParameterSettings_GetBrowserSecurity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetBrowserSecurity", (RTS_UINTPTR)SysParameterSettings_GetBrowserSecurity, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetBrowserSecurity(char * szSecurity);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETBROWSERSECURITY) (char * szSecurity);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETBROWSERSECURITY_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetBrowserSecurity
	#define EXT_SysParameterSettings_SetBrowserSecurity
	#define GET_SysParameterSettings_SetBrowserSecurity(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetBrowserSecurity(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetBrowserSecurity  FALSE
	#define EXP_SysParameterSettings_SetBrowserSecurity  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetBrowserSecurity
	#define EXT_SysParameterSettings_SetBrowserSecurity
	#define GET_SysParameterSettings_SetBrowserSecurity(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserSecurity" ) 
	#define CAL_SysParameterSettings_SetBrowserSecurity  SysParameterSettings_SetBrowserSecurity
	#define CHK_SysParameterSettings_SetBrowserSecurity  TRUE
	#define EXP_SysParameterSettings_SetBrowserSecurity  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserSecurity" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetBrowserSecurity
	#define EXT_SysParameterSettings_SetBrowserSecurity
	#define GET_SysParameterSettings_SetBrowserSecurity(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserSecurity" ) 
	#define CAL_SysParameterSettings_SetBrowserSecurity  SysParameterSettings_SetBrowserSecurity
	#define CHK_SysParameterSettings_SetBrowserSecurity  TRUE
	#define EXP_SysParameterSettings_SetBrowserSecurity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserSecurity", (RTS_UINTPTR)SysParameterSettings_SetBrowserSecurity, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetBrowserSecurity
	#define EXT_SysParameterSettingsSysParameterSettings_SetBrowserSecurity
	#define GET_SysParameterSettingsSysParameterSettings_SetBrowserSecurity  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetBrowserSecurity pISysParameterSettings->ISysParameterSettings_SetBrowserSecurity
	#define CHK_SysParameterSettingsSysParameterSettings_SetBrowserSecurity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetBrowserSecurity  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetBrowserSecurity
	#define EXT_SysParameterSettings_SetBrowserSecurity
	#define GET_SysParameterSettings_SetBrowserSecurity(fl)  CAL_CMGETAPI( "SysParameterSettings_SetBrowserSecurity" ) 
	#define CAL_SysParameterSettings_SetBrowserSecurity pISysParameterSettings->ISysParameterSettings_SetBrowserSecurity
	#define CHK_SysParameterSettings_SetBrowserSecurity (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetBrowserSecurity  CAL_CMEXPAPI( "SysParameterSettings_SetBrowserSecurity" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetBrowserSecurity  PFSYSPARAMETERSETTINGS_SETBROWSERSECURITY pfSysParameterSettings_SetBrowserSecurity;
	#define EXT_SysParameterSettings_SetBrowserSecurity  extern PFSYSPARAMETERSETTINGS_SETBROWSERSECURITY pfSysParameterSettings_SetBrowserSecurity;
	#define GET_SysParameterSettings_SetBrowserSecurity(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetBrowserSecurity", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetBrowserSecurity, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetBrowserSecurity  pfSysParameterSettings_SetBrowserSecurity
	#define CHK_SysParameterSettings_SetBrowserSecurity  (pfSysParameterSettings_SetBrowserSecurity != NULL)
	#define EXP_SysParameterSettings_SetBrowserSecurity  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetBrowserSecurity", (RTS_UINTPTR)SysParameterSettings_SetBrowserSecurity, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetUsePasswordVnc(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETUSEPASSWORDVNC) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETUSEPASSWORDVNC_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetUsePasswordVnc
	#define EXT_SysParameterSettings_GetUsePasswordVnc
	#define GET_SysParameterSettings_GetUsePasswordVnc(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetUsePasswordVnc(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetUsePasswordVnc  FALSE
	#define EXP_SysParameterSettings_GetUsePasswordVnc  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetUsePasswordVnc
	#define EXT_SysParameterSettings_GetUsePasswordVnc
	#define GET_SysParameterSettings_GetUsePasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUsePasswordVnc" ) 
	#define CAL_SysParameterSettings_GetUsePasswordVnc  SysParameterSettings_GetUsePasswordVnc
	#define CHK_SysParameterSettings_GetUsePasswordVnc  TRUE
	#define EXP_SysParameterSettings_GetUsePasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_GetUsePasswordVnc" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetUsePasswordVnc
	#define EXT_SysParameterSettings_GetUsePasswordVnc
	#define GET_SysParameterSettings_GetUsePasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUsePasswordVnc" ) 
	#define CAL_SysParameterSettings_GetUsePasswordVnc  SysParameterSettings_GetUsePasswordVnc
	#define CHK_SysParameterSettings_GetUsePasswordVnc  TRUE
	#define EXP_SysParameterSettings_GetUsePasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUsePasswordVnc", (RTS_UINTPTR)SysParameterSettings_GetUsePasswordVnc, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetUsePasswordVnc
	#define EXT_SysParameterSettingsSysParameterSettings_GetUsePasswordVnc
	#define GET_SysParameterSettingsSysParameterSettings_GetUsePasswordVnc  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetUsePasswordVnc pISysParameterSettings->ISysParameterSettings_GetUsePasswordVnc
	#define CHK_SysParameterSettingsSysParameterSettings_GetUsePasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetUsePasswordVnc  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetUsePasswordVnc
	#define EXT_SysParameterSettings_GetUsePasswordVnc
	#define GET_SysParameterSettings_GetUsePasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_GetUsePasswordVnc" ) 
	#define CAL_SysParameterSettings_GetUsePasswordVnc pISysParameterSettings->ISysParameterSettings_GetUsePasswordVnc
	#define CHK_SysParameterSettings_GetUsePasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetUsePasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_GetUsePasswordVnc" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetUsePasswordVnc  PFSYSPARAMETERSETTINGS_GETUSEPASSWORDVNC pfSysParameterSettings_GetUsePasswordVnc;
	#define EXT_SysParameterSettings_GetUsePasswordVnc  extern PFSYSPARAMETERSETTINGS_GETUSEPASSWORDVNC pfSysParameterSettings_GetUsePasswordVnc;
	#define GET_SysParameterSettings_GetUsePasswordVnc(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetUsePasswordVnc", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetUsePasswordVnc, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetUsePasswordVnc  pfSysParameterSettings_GetUsePasswordVnc
	#define CHK_SysParameterSettings_GetUsePasswordVnc  (pfSysParameterSettings_GetUsePasswordVnc != NULL)
	#define EXP_SysParameterSettings_GetUsePasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetUsePasswordVnc", (RTS_UINTPTR)SysParameterSettings_GetUsePasswordVnc, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetUsePasswordVnc(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETUSEPASSWORDVNC) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETUSEPASSWORDVNC_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetUsePasswordVnc
	#define EXT_SysParameterSettings_SetUsePasswordVnc
	#define GET_SysParameterSettings_SetUsePasswordVnc(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetUsePasswordVnc(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetUsePasswordVnc  FALSE
	#define EXP_SysParameterSettings_SetUsePasswordVnc  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetUsePasswordVnc
	#define EXT_SysParameterSettings_SetUsePasswordVnc
	#define GET_SysParameterSettings_SetUsePasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUsePasswordVnc" ) 
	#define CAL_SysParameterSettings_SetUsePasswordVnc  SysParameterSettings_SetUsePasswordVnc
	#define CHK_SysParameterSettings_SetUsePasswordVnc  TRUE
	#define EXP_SysParameterSettings_SetUsePasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_SetUsePasswordVnc" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetUsePasswordVnc
	#define EXT_SysParameterSettings_SetUsePasswordVnc
	#define GET_SysParameterSettings_SetUsePasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUsePasswordVnc" ) 
	#define CAL_SysParameterSettings_SetUsePasswordVnc  SysParameterSettings_SetUsePasswordVnc
	#define CHK_SysParameterSettings_SetUsePasswordVnc  TRUE
	#define EXP_SysParameterSettings_SetUsePasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUsePasswordVnc", (RTS_UINTPTR)SysParameterSettings_SetUsePasswordVnc, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetUsePasswordVnc
	#define EXT_SysParameterSettingsSysParameterSettings_SetUsePasswordVnc
	#define GET_SysParameterSettingsSysParameterSettings_SetUsePasswordVnc  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetUsePasswordVnc pISysParameterSettings->ISysParameterSettings_SetUsePasswordVnc
	#define CHK_SysParameterSettingsSysParameterSettings_SetUsePasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetUsePasswordVnc  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetUsePasswordVnc
	#define EXT_SysParameterSettings_SetUsePasswordVnc
	#define GET_SysParameterSettings_SetUsePasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_SetUsePasswordVnc" ) 
	#define CAL_SysParameterSettings_SetUsePasswordVnc pISysParameterSettings->ISysParameterSettings_SetUsePasswordVnc
	#define CHK_SysParameterSettings_SetUsePasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetUsePasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_SetUsePasswordVnc" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetUsePasswordVnc  PFSYSPARAMETERSETTINGS_SETUSEPASSWORDVNC pfSysParameterSettings_SetUsePasswordVnc;
	#define EXT_SysParameterSettings_SetUsePasswordVnc  extern PFSYSPARAMETERSETTINGS_SETUSEPASSWORDVNC pfSysParameterSettings_SetUsePasswordVnc;
	#define GET_SysParameterSettings_SetUsePasswordVnc(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetUsePasswordVnc", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetUsePasswordVnc, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetUsePasswordVnc  pfSysParameterSettings_SetUsePasswordVnc
	#define CHK_SysParameterSettings_SetUsePasswordVnc  (pfSysParameterSettings_SetUsePasswordVnc != NULL)
	#define EXP_SysParameterSettings_SetUsePasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetUsePasswordVnc", (RTS_UINTPTR)SysParameterSettings_SetUsePasswordVnc, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetPasswordVnc(char * pszValue, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETPASSWORDVNC) (char * pszValue, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETPASSWORDVNC_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetPasswordVnc
	#define EXT_SysParameterSettings_GetPasswordVnc
	#define GET_SysParameterSettings_GetPasswordVnc(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetPasswordVnc(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetPasswordVnc  FALSE
	#define EXP_SysParameterSettings_GetPasswordVnc  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetPasswordVnc
	#define EXT_SysParameterSettings_GetPasswordVnc
	#define GET_SysParameterSettings_GetPasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPasswordVnc" ) 
	#define CAL_SysParameterSettings_GetPasswordVnc  SysParameterSettings_GetPasswordVnc
	#define CHK_SysParameterSettings_GetPasswordVnc  TRUE
	#define EXP_SysParameterSettings_GetPasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_GetPasswordVnc" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetPasswordVnc
	#define EXT_SysParameterSettings_GetPasswordVnc
	#define GET_SysParameterSettings_GetPasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPasswordVnc" ) 
	#define CAL_SysParameterSettings_GetPasswordVnc  SysParameterSettings_GetPasswordVnc
	#define CHK_SysParameterSettings_GetPasswordVnc  TRUE
	#define EXP_SysParameterSettings_GetPasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetPasswordVnc", (RTS_UINTPTR)SysParameterSettings_GetPasswordVnc, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetPasswordVnc
	#define EXT_SysParameterSettingsSysParameterSettings_GetPasswordVnc
	#define GET_SysParameterSettingsSysParameterSettings_GetPasswordVnc  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetPasswordVnc pISysParameterSettings->ISysParameterSettings_GetPasswordVnc
	#define CHK_SysParameterSettingsSysParameterSettings_GetPasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetPasswordVnc  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetPasswordVnc
	#define EXT_SysParameterSettings_GetPasswordVnc
	#define GET_SysParameterSettings_GetPasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_GetPasswordVnc" ) 
	#define CAL_SysParameterSettings_GetPasswordVnc pISysParameterSettings->ISysParameterSettings_GetPasswordVnc
	#define CHK_SysParameterSettings_GetPasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetPasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_GetPasswordVnc" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetPasswordVnc  PFSYSPARAMETERSETTINGS_GETPASSWORDVNC pfSysParameterSettings_GetPasswordVnc;
	#define EXT_SysParameterSettings_GetPasswordVnc  extern PFSYSPARAMETERSETTINGS_GETPASSWORDVNC pfSysParameterSettings_GetPasswordVnc;
	#define GET_SysParameterSettings_GetPasswordVnc(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetPasswordVnc", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetPasswordVnc, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetPasswordVnc  pfSysParameterSettings_GetPasswordVnc
	#define CHK_SysParameterSettings_GetPasswordVnc  (pfSysParameterSettings_GetPasswordVnc != NULL)
	#define EXP_SysParameterSettings_GetPasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetPasswordVnc", (RTS_UINTPTR)SysParameterSettings_GetPasswordVnc, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetPasswordVnc(char * pszValue);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETPASSWORDVNC) (char * pszValue);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETPASSWORDVNC_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetPasswordVnc
	#define EXT_SysParameterSettings_SetPasswordVnc
	#define GET_SysParameterSettings_SetPasswordVnc(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetPasswordVnc(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetPasswordVnc  FALSE
	#define EXP_SysParameterSettings_SetPasswordVnc  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetPasswordVnc
	#define EXT_SysParameterSettings_SetPasswordVnc
	#define GET_SysParameterSettings_SetPasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPasswordVnc" ) 
	#define CAL_SysParameterSettings_SetPasswordVnc  SysParameterSettings_SetPasswordVnc
	#define CHK_SysParameterSettings_SetPasswordVnc  TRUE
	#define EXP_SysParameterSettings_SetPasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_SetPasswordVnc" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetPasswordVnc
	#define EXT_SysParameterSettings_SetPasswordVnc
	#define GET_SysParameterSettings_SetPasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPasswordVnc" ) 
	#define CAL_SysParameterSettings_SetPasswordVnc  SysParameterSettings_SetPasswordVnc
	#define CHK_SysParameterSettings_SetPasswordVnc  TRUE
	#define EXP_SysParameterSettings_SetPasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetPasswordVnc", (RTS_UINTPTR)SysParameterSettings_SetPasswordVnc, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetPasswordVnc
	#define EXT_SysParameterSettingsSysParameterSettings_SetPasswordVnc
	#define GET_SysParameterSettingsSysParameterSettings_SetPasswordVnc  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetPasswordVnc pISysParameterSettings->ISysParameterSettings_SetPasswordVnc
	#define CHK_SysParameterSettingsSysParameterSettings_SetPasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetPasswordVnc  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetPasswordVnc
	#define EXT_SysParameterSettings_SetPasswordVnc
	#define GET_SysParameterSettings_SetPasswordVnc(fl)  CAL_CMGETAPI( "SysParameterSettings_SetPasswordVnc" ) 
	#define CAL_SysParameterSettings_SetPasswordVnc pISysParameterSettings->ISysParameterSettings_SetPasswordVnc
	#define CHK_SysParameterSettings_SetPasswordVnc (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetPasswordVnc  CAL_CMEXPAPI( "SysParameterSettings_SetPasswordVnc" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetPasswordVnc  PFSYSPARAMETERSETTINGS_SETPASSWORDVNC pfSysParameterSettings_SetPasswordVnc;
	#define EXT_SysParameterSettings_SetPasswordVnc  extern PFSYSPARAMETERSETTINGS_SETPASSWORDVNC pfSysParameterSettings_SetPasswordVnc;
	#define GET_SysParameterSettings_SetPasswordVnc(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetPasswordVnc", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetPasswordVnc, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetPasswordVnc  pfSysParameterSettings_SetPasswordVnc
	#define CHK_SysParameterSettings_SetPasswordVnc  (pfSysParameterSettings_SetPasswordVnc != NULL)
	#define EXP_SysParameterSettings_SetPasswordVnc  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetPasswordVnc", (RTS_UINTPTR)SysParameterSettings_SetPasswordVnc, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetVncServer(char * pszText, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETVNCSERVER) (char * pszText, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETVNCSERVER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetVncServer
	#define EXT_SysParameterSettings_GetVncServer
	#define GET_SysParameterSettings_GetVncServer(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetVncServer(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetVncServer  FALSE
	#define EXP_SysParameterSettings_GetVncServer  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetVncServer
	#define EXT_SysParameterSettings_GetVncServer
	#define GET_SysParameterSettings_GetVncServer(fl)  CAL_CMGETAPI( "SysParameterSettings_GetVncServer" ) 
	#define CAL_SysParameterSettings_GetVncServer  SysParameterSettings_GetVncServer
	#define CHK_SysParameterSettings_GetVncServer  TRUE
	#define EXP_SysParameterSettings_GetVncServer  CAL_CMEXPAPI( "SysParameterSettings_GetVncServer" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetVncServer
	#define EXT_SysParameterSettings_GetVncServer
	#define GET_SysParameterSettings_GetVncServer(fl)  CAL_CMGETAPI( "SysParameterSettings_GetVncServer" ) 
	#define CAL_SysParameterSettings_GetVncServer  SysParameterSettings_GetVncServer
	#define CHK_SysParameterSettings_GetVncServer  TRUE
	#define EXP_SysParameterSettings_GetVncServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetVncServer", (RTS_UINTPTR)SysParameterSettings_GetVncServer, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetVncServer
	#define EXT_SysParameterSettingsSysParameterSettings_GetVncServer
	#define GET_SysParameterSettingsSysParameterSettings_GetVncServer  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetVncServer pISysParameterSettings->ISysParameterSettings_GetVncServer
	#define CHK_SysParameterSettingsSysParameterSettings_GetVncServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetVncServer  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetVncServer
	#define EXT_SysParameterSettings_GetVncServer
	#define GET_SysParameterSettings_GetVncServer(fl)  CAL_CMGETAPI( "SysParameterSettings_GetVncServer" ) 
	#define CAL_SysParameterSettings_GetVncServer pISysParameterSettings->ISysParameterSettings_GetVncServer
	#define CHK_SysParameterSettings_GetVncServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetVncServer  CAL_CMEXPAPI( "SysParameterSettings_GetVncServer" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetVncServer  PFSYSPARAMETERSETTINGS_GETVNCSERVER pfSysParameterSettings_GetVncServer;
	#define EXT_SysParameterSettings_GetVncServer  extern PFSYSPARAMETERSETTINGS_GETVNCSERVER pfSysParameterSettings_GetVncServer;
	#define GET_SysParameterSettings_GetVncServer(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetVncServer", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetVncServer, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetVncServer  pfSysParameterSettings_GetVncServer
	#define CHK_SysParameterSettings_GetVncServer  (pfSysParameterSettings_GetVncServer != NULL)
	#define EXP_SysParameterSettings_GetVncServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetVncServer", (RTS_UINTPTR)SysParameterSettings_GetVncServer, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetVncServer(char * pszText);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETVNCSERVER) (char * pszText);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETVNCSERVER_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetVncServer
	#define EXT_SysParameterSettings_SetVncServer
	#define GET_SysParameterSettings_SetVncServer(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetVncServer(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetVncServer  FALSE
	#define EXP_SysParameterSettings_SetVncServer  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetVncServer
	#define EXT_SysParameterSettings_SetVncServer
	#define GET_SysParameterSettings_SetVncServer(fl)  CAL_CMGETAPI( "SysParameterSettings_SetVncServer" ) 
	#define CAL_SysParameterSettings_SetVncServer  SysParameterSettings_SetVncServer
	#define CHK_SysParameterSettings_SetVncServer  TRUE
	#define EXP_SysParameterSettings_SetVncServer  CAL_CMEXPAPI( "SysParameterSettings_SetVncServer" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetVncServer
	#define EXT_SysParameterSettings_SetVncServer
	#define GET_SysParameterSettings_SetVncServer(fl)  CAL_CMGETAPI( "SysParameterSettings_SetVncServer" ) 
	#define CAL_SysParameterSettings_SetVncServer  SysParameterSettings_SetVncServer
	#define CHK_SysParameterSettings_SetVncServer  TRUE
	#define EXP_SysParameterSettings_SetVncServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetVncServer", (RTS_UINTPTR)SysParameterSettings_SetVncServer, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetVncServer
	#define EXT_SysParameterSettingsSysParameterSettings_SetVncServer
	#define GET_SysParameterSettingsSysParameterSettings_SetVncServer  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetVncServer pISysParameterSettings->ISysParameterSettings_SetVncServer
	#define CHK_SysParameterSettingsSysParameterSettings_SetVncServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetVncServer  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetVncServer
	#define EXT_SysParameterSettings_SetVncServer
	#define GET_SysParameterSettings_SetVncServer(fl)  CAL_CMGETAPI( "SysParameterSettings_SetVncServer" ) 
	#define CAL_SysParameterSettings_SetVncServer pISysParameterSettings->ISysParameterSettings_SetVncServer
	#define CHK_SysParameterSettings_SetVncServer (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetVncServer  CAL_CMEXPAPI( "SysParameterSettings_SetVncServer" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetVncServer  PFSYSPARAMETERSETTINGS_SETVNCSERVER pfSysParameterSettings_SetVncServer;
	#define EXT_SysParameterSettings_SetVncServer  extern PFSYSPARAMETERSETTINGS_SETVNCSERVER pfSysParameterSettings_SetVncServer;
	#define GET_SysParameterSettings_SetVncServer(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetVncServer", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetVncServer, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetVncServer  pfSysParameterSettings_SetVncServer
	#define CHK_SysParameterSettings_SetVncServer  (pfSysParameterSettings_SetVncServer != NULL)
	#define EXP_SysParameterSettings_SetVncServer  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetVncServer", (RTS_UINTPTR)SysParameterSettings_SetVncServer, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetAutostart(char * pszText, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETAUTOSTART) (char * pszText, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETAUTOSTART_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetAutostart
	#define EXT_SysParameterSettings_GetAutostart
	#define GET_SysParameterSettings_GetAutostart(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetAutostart(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetAutostart  FALSE
	#define EXP_SysParameterSettings_GetAutostart  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetAutostart
	#define EXT_SysParameterSettings_GetAutostart
	#define GET_SysParameterSettings_GetAutostart(fl)  CAL_CMGETAPI( "SysParameterSettings_GetAutostart" ) 
	#define CAL_SysParameterSettings_GetAutostart  SysParameterSettings_GetAutostart
	#define CHK_SysParameterSettings_GetAutostart  TRUE
	#define EXP_SysParameterSettings_GetAutostart  CAL_CMEXPAPI( "SysParameterSettings_GetAutostart" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetAutostart
	#define EXT_SysParameterSettings_GetAutostart
	#define GET_SysParameterSettings_GetAutostart(fl)  CAL_CMGETAPI( "SysParameterSettings_GetAutostart" ) 
	#define CAL_SysParameterSettings_GetAutostart  SysParameterSettings_GetAutostart
	#define CHK_SysParameterSettings_GetAutostart  TRUE
	#define EXP_SysParameterSettings_GetAutostart  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetAutostart", (RTS_UINTPTR)SysParameterSettings_GetAutostart, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetAutostart
	#define EXT_SysParameterSettingsSysParameterSettings_GetAutostart
	#define GET_SysParameterSettingsSysParameterSettings_GetAutostart  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetAutostart pISysParameterSettings->ISysParameterSettings_GetAutostart
	#define CHK_SysParameterSettingsSysParameterSettings_GetAutostart (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetAutostart  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetAutostart
	#define EXT_SysParameterSettings_GetAutostart
	#define GET_SysParameterSettings_GetAutostart(fl)  CAL_CMGETAPI( "SysParameterSettings_GetAutostart" ) 
	#define CAL_SysParameterSettings_GetAutostart pISysParameterSettings->ISysParameterSettings_GetAutostart
	#define CHK_SysParameterSettings_GetAutostart (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetAutostart  CAL_CMEXPAPI( "SysParameterSettings_GetAutostart" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetAutostart  PFSYSPARAMETERSETTINGS_GETAUTOSTART pfSysParameterSettings_GetAutostart;
	#define EXT_SysParameterSettings_GetAutostart  extern PFSYSPARAMETERSETTINGS_GETAUTOSTART pfSysParameterSettings_GetAutostart;
	#define GET_SysParameterSettings_GetAutostart(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetAutostart", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetAutostart, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetAutostart  pfSysParameterSettings_GetAutostart
	#define CHK_SysParameterSettings_GetAutostart  (pfSysParameterSettings_GetAutostart != NULL)
	#define EXP_SysParameterSettings_GetAutostart  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetAutostart", (RTS_UINTPTR)SysParameterSettings_GetAutostart, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetAutostart(char * pszText);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETAUTOSTART) (char * pszText);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETAUTOSTART_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetAutostart
	#define EXT_SysParameterSettings_SetAutostart
	#define GET_SysParameterSettings_SetAutostart(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetAutostart(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetAutostart  FALSE
	#define EXP_SysParameterSettings_SetAutostart  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetAutostart
	#define EXT_SysParameterSettings_SetAutostart
	#define GET_SysParameterSettings_SetAutostart(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAutostart" ) 
	#define CAL_SysParameterSettings_SetAutostart  SysParameterSettings_SetAutostart
	#define CHK_SysParameterSettings_SetAutostart  TRUE
	#define EXP_SysParameterSettings_SetAutostart  CAL_CMEXPAPI( "SysParameterSettings_SetAutostart" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetAutostart
	#define EXT_SysParameterSettings_SetAutostart
	#define GET_SysParameterSettings_SetAutostart(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAutostart" ) 
	#define CAL_SysParameterSettings_SetAutostart  SysParameterSettings_SetAutostart
	#define CHK_SysParameterSettings_SetAutostart  TRUE
	#define EXP_SysParameterSettings_SetAutostart  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAutostart", (RTS_UINTPTR)SysParameterSettings_SetAutostart, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetAutostart
	#define EXT_SysParameterSettingsSysParameterSettings_SetAutostart
	#define GET_SysParameterSettingsSysParameterSettings_SetAutostart  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetAutostart pISysParameterSettings->ISysParameterSettings_SetAutostart
	#define CHK_SysParameterSettingsSysParameterSettings_SetAutostart (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetAutostart  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetAutostart
	#define EXT_SysParameterSettings_SetAutostart
	#define GET_SysParameterSettings_SetAutostart(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAutostart" ) 
	#define CAL_SysParameterSettings_SetAutostart pISysParameterSettings->ISysParameterSettings_SetAutostart
	#define CHK_SysParameterSettings_SetAutostart (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetAutostart  CAL_CMEXPAPI( "SysParameterSettings_SetAutostart" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetAutostart  PFSYSPARAMETERSETTINGS_SETAUTOSTART pfSysParameterSettings_SetAutostart;
	#define EXT_SysParameterSettings_SetAutostart  extern PFSYSPARAMETERSETTINGS_SETAUTOSTART pfSysParameterSettings_SetAutostart;
	#define GET_SysParameterSettings_SetAutostart(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetAutostart", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetAutostart, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetAutostart  pfSysParameterSettings_SetAutostart
	#define CHK_SysParameterSettings_SetAutostart  (pfSysParameterSettings_SetAutostart != NULL)
	#define EXP_SysParameterSettings_SetAutostart  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAutostart", (RTS_UINTPTR)SysParameterSettings_SetAutostart, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetSubnetMask1(char * pszOut, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSUBNETMASK1) (char * pszOut, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSUBNETMASK1_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetSubnetMask1
	#define EXT_SysParameterSettings_GetSubnetMask1
	#define GET_SysParameterSettings_GetSubnetMask1(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetSubnetMask1(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetSubnetMask1  FALSE
	#define EXP_SysParameterSettings_GetSubnetMask1  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetSubnetMask1
	#define EXT_SysParameterSettings_GetSubnetMask1
	#define GET_SysParameterSettings_GetSubnetMask1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSubnetMask1" ) 
	#define CAL_SysParameterSettings_GetSubnetMask1  SysParameterSettings_GetSubnetMask1
	#define CHK_SysParameterSettings_GetSubnetMask1  TRUE
	#define EXP_SysParameterSettings_GetSubnetMask1  CAL_CMEXPAPI( "SysParameterSettings_GetSubnetMask1" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetSubnetMask1
	#define EXT_SysParameterSettings_GetSubnetMask1
	#define GET_SysParameterSettings_GetSubnetMask1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSubnetMask1" ) 
	#define CAL_SysParameterSettings_GetSubnetMask1  SysParameterSettings_GetSubnetMask1
	#define CHK_SysParameterSettings_GetSubnetMask1  TRUE
	#define EXP_SysParameterSettings_GetSubnetMask1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSubnetMask1", (RTS_UINTPTR)SysParameterSettings_GetSubnetMask1, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetSubnetMask1
	#define EXT_SysParameterSettingsSysParameterSettings_GetSubnetMask1
	#define GET_SysParameterSettingsSysParameterSettings_GetSubnetMask1  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetSubnetMask1 pISysParameterSettings->ISysParameterSettings_GetSubnetMask1
	#define CHK_SysParameterSettingsSysParameterSettings_GetSubnetMask1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetSubnetMask1  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetSubnetMask1
	#define EXT_SysParameterSettings_GetSubnetMask1
	#define GET_SysParameterSettings_GetSubnetMask1(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSubnetMask1" ) 
	#define CAL_SysParameterSettings_GetSubnetMask1 pISysParameterSettings->ISysParameterSettings_GetSubnetMask1
	#define CHK_SysParameterSettings_GetSubnetMask1 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetSubnetMask1  CAL_CMEXPAPI( "SysParameterSettings_GetSubnetMask1" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetSubnetMask1  PFSYSPARAMETERSETTINGS_GETSUBNETMASK1 pfSysParameterSettings_GetSubnetMask1;
	#define EXT_SysParameterSettings_GetSubnetMask1  extern PFSYSPARAMETERSETTINGS_GETSUBNETMASK1 pfSysParameterSettings_GetSubnetMask1;
	#define GET_SysParameterSettings_GetSubnetMask1(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetSubnetMask1", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetSubnetMask1, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetSubnetMask1  pfSysParameterSettings_GetSubnetMask1
	#define CHK_SysParameterSettings_GetSubnetMask1  (pfSysParameterSettings_GetSubnetMask1 != NULL)
	#define EXP_SysParameterSettings_GetSubnetMask1  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSubnetMask1", (RTS_UINTPTR)SysParameterSettings_GetSubnetMask1, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetSubnetMask2(char * pszOut, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSUBNETMASK2) (char * pszOut, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSUBNETMASK2_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetSubnetMask2
	#define EXT_SysParameterSettings_GetSubnetMask2
	#define GET_SysParameterSettings_GetSubnetMask2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetSubnetMask2(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetSubnetMask2  FALSE
	#define EXP_SysParameterSettings_GetSubnetMask2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetSubnetMask2
	#define EXT_SysParameterSettings_GetSubnetMask2
	#define GET_SysParameterSettings_GetSubnetMask2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSubnetMask2" ) 
	#define CAL_SysParameterSettings_GetSubnetMask2  SysParameterSettings_GetSubnetMask2
	#define CHK_SysParameterSettings_GetSubnetMask2  TRUE
	#define EXP_SysParameterSettings_GetSubnetMask2  CAL_CMEXPAPI( "SysParameterSettings_GetSubnetMask2" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetSubnetMask2
	#define EXT_SysParameterSettings_GetSubnetMask2
	#define GET_SysParameterSettings_GetSubnetMask2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSubnetMask2" ) 
	#define CAL_SysParameterSettings_GetSubnetMask2  SysParameterSettings_GetSubnetMask2
	#define CHK_SysParameterSettings_GetSubnetMask2  TRUE
	#define EXP_SysParameterSettings_GetSubnetMask2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSubnetMask2", (RTS_UINTPTR)SysParameterSettings_GetSubnetMask2, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetSubnetMask2
	#define EXT_SysParameterSettingsSysParameterSettings_GetSubnetMask2
	#define GET_SysParameterSettingsSysParameterSettings_GetSubnetMask2  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetSubnetMask2 pISysParameterSettings->ISysParameterSettings_GetSubnetMask2
	#define CHK_SysParameterSettingsSysParameterSettings_GetSubnetMask2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetSubnetMask2  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetSubnetMask2
	#define EXT_SysParameterSettings_GetSubnetMask2
	#define GET_SysParameterSettings_GetSubnetMask2(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSubnetMask2" ) 
	#define CAL_SysParameterSettings_GetSubnetMask2 pISysParameterSettings->ISysParameterSettings_GetSubnetMask2
	#define CHK_SysParameterSettings_GetSubnetMask2 (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetSubnetMask2  CAL_CMEXPAPI( "SysParameterSettings_GetSubnetMask2" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetSubnetMask2  PFSYSPARAMETERSETTINGS_GETSUBNETMASK2 pfSysParameterSettings_GetSubnetMask2;
	#define EXT_SysParameterSettings_GetSubnetMask2  extern PFSYSPARAMETERSETTINGS_GETSUBNETMASK2 pfSysParameterSettings_GetSubnetMask2;
	#define GET_SysParameterSettings_GetSubnetMask2(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetSubnetMask2", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetSubnetMask2, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetSubnetMask2  pfSysParameterSettings_GetSubnetMask2
	#define CHK_SysParameterSettings_GetSubnetMask2  (pfSysParameterSettings_GetSubnetMask2 != NULL)
	#define EXP_SysParameterSettings_GetSubnetMask2  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSubnetMask2", (RTS_UINTPTR)SysParameterSettings_GetSubnetMask2, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsUnmountSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISUNMOUNTSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISUNMOUNTSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsUnmountSupportted
	#define EXT_SysParameterSettings_IsUnmountSupportted
	#define GET_SysParameterSettings_IsUnmountSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsUnmountSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsUnmountSupportted  FALSE
	#define EXP_SysParameterSettings_IsUnmountSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsUnmountSupportted
	#define EXT_SysParameterSettings_IsUnmountSupportted
	#define GET_SysParameterSettings_IsUnmountSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsUnmountSupportted" ) 
	#define CAL_SysParameterSettings_IsUnmountSupportted  SysParameterSettings_IsUnmountSupportted
	#define CHK_SysParameterSettings_IsUnmountSupportted  TRUE
	#define EXP_SysParameterSettings_IsUnmountSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsUnmountSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsUnmountSupportted
	#define EXT_SysParameterSettings_IsUnmountSupportted
	#define GET_SysParameterSettings_IsUnmountSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsUnmountSupportted" ) 
	#define CAL_SysParameterSettings_IsUnmountSupportted  SysParameterSettings_IsUnmountSupportted
	#define CHK_SysParameterSettings_IsUnmountSupportted  TRUE
	#define EXP_SysParameterSettings_IsUnmountSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsUnmountSupportted", (RTS_UINTPTR)SysParameterSettings_IsUnmountSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsUnmountSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsUnmountSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsUnmountSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsUnmountSupportted pISysParameterSettings->ISysParameterSettings_IsUnmountSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsUnmountSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsUnmountSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsUnmountSupportted
	#define EXT_SysParameterSettings_IsUnmountSupportted
	#define GET_SysParameterSettings_IsUnmountSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsUnmountSupportted" ) 
	#define CAL_SysParameterSettings_IsUnmountSupportted pISysParameterSettings->ISysParameterSettings_IsUnmountSupportted
	#define CHK_SysParameterSettings_IsUnmountSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsUnmountSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsUnmountSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsUnmountSupportted  PFSYSPARAMETERSETTINGS_ISUNMOUNTSUPPORTTED pfSysParameterSettings_IsUnmountSupportted;
	#define EXT_SysParameterSettings_IsUnmountSupportted  extern PFSYSPARAMETERSETTINGS_ISUNMOUNTSUPPORTTED pfSysParameterSettings_IsUnmountSupportted;
	#define GET_SysParameterSettings_IsUnmountSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsUnmountSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsUnmountSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsUnmountSupportted  pfSysParameterSettings_IsUnmountSupportted
	#define CHK_SysParameterSettings_IsUnmountSupportted  (pfSysParameterSettings_IsUnmountSupportted != NULL)
	#define EXP_SysParameterSettings_IsUnmountSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsUnmountSupportted", (RTS_UINTPTR)SysParameterSettings_IsUnmountSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsClearRoutingCacheSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISCLEARROUTINGCACHESUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISCLEARROUTINGCACHESUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsClearRoutingCacheSupportted
	#define EXT_SysParameterSettings_IsClearRoutingCacheSupportted
	#define GET_SysParameterSettings_IsClearRoutingCacheSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsClearRoutingCacheSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsClearRoutingCacheSupportted  FALSE
	#define EXP_SysParameterSettings_IsClearRoutingCacheSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsClearRoutingCacheSupportted
	#define EXT_SysParameterSettings_IsClearRoutingCacheSupportted
	#define GET_SysParameterSettings_IsClearRoutingCacheSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsClearRoutingCacheSupportted" ) 
	#define CAL_SysParameterSettings_IsClearRoutingCacheSupportted  SysParameterSettings_IsClearRoutingCacheSupportted
	#define CHK_SysParameterSettings_IsClearRoutingCacheSupportted  TRUE
	#define EXP_SysParameterSettings_IsClearRoutingCacheSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsClearRoutingCacheSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsClearRoutingCacheSupportted
	#define EXT_SysParameterSettings_IsClearRoutingCacheSupportted
	#define GET_SysParameterSettings_IsClearRoutingCacheSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsClearRoutingCacheSupportted" ) 
	#define CAL_SysParameterSettings_IsClearRoutingCacheSupportted  SysParameterSettings_IsClearRoutingCacheSupportted
	#define CHK_SysParameterSettings_IsClearRoutingCacheSupportted  TRUE
	#define EXP_SysParameterSettings_IsClearRoutingCacheSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsClearRoutingCacheSupportted", (RTS_UINTPTR)SysParameterSettings_IsClearRoutingCacheSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsClearRoutingCacheSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsClearRoutingCacheSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsClearRoutingCacheSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsClearRoutingCacheSupportted pISysParameterSettings->ISysParameterSettings_IsClearRoutingCacheSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsClearRoutingCacheSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsClearRoutingCacheSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsClearRoutingCacheSupportted
	#define EXT_SysParameterSettings_IsClearRoutingCacheSupportted
	#define GET_SysParameterSettings_IsClearRoutingCacheSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsClearRoutingCacheSupportted" ) 
	#define CAL_SysParameterSettings_IsClearRoutingCacheSupportted pISysParameterSettings->ISysParameterSettings_IsClearRoutingCacheSupportted
	#define CHK_SysParameterSettings_IsClearRoutingCacheSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsClearRoutingCacheSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsClearRoutingCacheSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsClearRoutingCacheSupportted  PFSYSPARAMETERSETTINGS_ISCLEARROUTINGCACHESUPPORTTED pfSysParameterSettings_IsClearRoutingCacheSupportted;
	#define EXT_SysParameterSettings_IsClearRoutingCacheSupportted  extern PFSYSPARAMETERSETTINGS_ISCLEARROUTINGCACHESUPPORTTED pfSysParameterSettings_IsClearRoutingCacheSupportted;
	#define GET_SysParameterSettings_IsClearRoutingCacheSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsClearRoutingCacheSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsClearRoutingCacheSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsClearRoutingCacheSupportted  pfSysParameterSettings_IsClearRoutingCacheSupportted
	#define CHK_SysParameterSettings_IsClearRoutingCacheSupportted  (pfSysParameterSettings_IsClearRoutingCacheSupportted != NULL)
	#define EXP_SysParameterSettings_IsClearRoutingCacheSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsClearRoutingCacheSupportted", (RTS_UINTPTR)SysParameterSettings_IsClearRoutingCacheSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsdeleteFontSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISDELETEFONTSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISDELETEFONTSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsdeleteFontSupportted
	#define EXT_SysParameterSettings_IsdeleteFontSupportted
	#define GET_SysParameterSettings_IsdeleteFontSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsdeleteFontSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsdeleteFontSupportted  FALSE
	#define EXP_SysParameterSettings_IsdeleteFontSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsdeleteFontSupportted
	#define EXT_SysParameterSettings_IsdeleteFontSupportted
	#define GET_SysParameterSettings_IsdeleteFontSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsdeleteFontSupportted" ) 
	#define CAL_SysParameterSettings_IsdeleteFontSupportted  SysParameterSettings_IsdeleteFontSupportted
	#define CHK_SysParameterSettings_IsdeleteFontSupportted  TRUE
	#define EXP_SysParameterSettings_IsdeleteFontSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsdeleteFontSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsdeleteFontSupportted
	#define EXT_SysParameterSettings_IsdeleteFontSupportted
	#define GET_SysParameterSettings_IsdeleteFontSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsdeleteFontSupportted" ) 
	#define CAL_SysParameterSettings_IsdeleteFontSupportted  SysParameterSettings_IsdeleteFontSupportted
	#define CHK_SysParameterSettings_IsdeleteFontSupportted  TRUE
	#define EXP_SysParameterSettings_IsdeleteFontSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsdeleteFontSupportted", (RTS_UINTPTR)SysParameterSettings_IsdeleteFontSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsdeleteFontSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsdeleteFontSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsdeleteFontSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsdeleteFontSupportted pISysParameterSettings->ISysParameterSettings_IsdeleteFontSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsdeleteFontSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsdeleteFontSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsdeleteFontSupportted
	#define EXT_SysParameterSettings_IsdeleteFontSupportted
	#define GET_SysParameterSettings_IsdeleteFontSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsdeleteFontSupportted" ) 
	#define CAL_SysParameterSettings_IsdeleteFontSupportted pISysParameterSettings->ISysParameterSettings_IsdeleteFontSupportted
	#define CHK_SysParameterSettings_IsdeleteFontSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsdeleteFontSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsdeleteFontSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsdeleteFontSupportted  PFSYSPARAMETERSETTINGS_ISDELETEFONTSUPPORTTED pfSysParameterSettings_IsdeleteFontSupportted;
	#define EXT_SysParameterSettings_IsdeleteFontSupportted  extern PFSYSPARAMETERSETTINGS_ISDELETEFONTSUPPORTTED pfSysParameterSettings_IsdeleteFontSupportted;
	#define GET_SysParameterSettings_IsdeleteFontSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsdeleteFontSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsdeleteFontSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsdeleteFontSupportted  pfSysParameterSettings_IsdeleteFontSupportted
	#define CHK_SysParameterSettings_IsdeleteFontSupportted  (pfSysParameterSettings_IsdeleteFontSupportted != NULL)
	#define EXP_SysParameterSettings_IsdeleteFontSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsdeleteFontSupportted", (RTS_UINTPTR)SysParameterSettings_IsdeleteFontSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IssubstituteFontSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISSUBSTITUTEFONTSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISSUBSTITUTEFONTSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IssubstituteFontSupportted
	#define EXT_SysParameterSettings_IssubstituteFontSupportted
	#define GET_SysParameterSettings_IssubstituteFontSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IssubstituteFontSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IssubstituteFontSupportted  FALSE
	#define EXP_SysParameterSettings_IssubstituteFontSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IssubstituteFontSupportted
	#define EXT_SysParameterSettings_IssubstituteFontSupportted
	#define GET_SysParameterSettings_IssubstituteFontSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IssubstituteFontSupportted" ) 
	#define CAL_SysParameterSettings_IssubstituteFontSupportted  SysParameterSettings_IssubstituteFontSupportted
	#define CHK_SysParameterSettings_IssubstituteFontSupportted  TRUE
	#define EXP_SysParameterSettings_IssubstituteFontSupportted  CAL_CMEXPAPI( "SysParameterSettings_IssubstituteFontSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IssubstituteFontSupportted
	#define EXT_SysParameterSettings_IssubstituteFontSupportted
	#define GET_SysParameterSettings_IssubstituteFontSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IssubstituteFontSupportted" ) 
	#define CAL_SysParameterSettings_IssubstituteFontSupportted  SysParameterSettings_IssubstituteFontSupportted
	#define CHK_SysParameterSettings_IssubstituteFontSupportted  TRUE
	#define EXP_SysParameterSettings_IssubstituteFontSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IssubstituteFontSupportted", (RTS_UINTPTR)SysParameterSettings_IssubstituteFontSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IssubstituteFontSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IssubstituteFontSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IssubstituteFontSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IssubstituteFontSupportted pISysParameterSettings->ISysParameterSettings_IssubstituteFontSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IssubstituteFontSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IssubstituteFontSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IssubstituteFontSupportted
	#define EXT_SysParameterSettings_IssubstituteFontSupportted
	#define GET_SysParameterSettings_IssubstituteFontSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IssubstituteFontSupportted" ) 
	#define CAL_SysParameterSettings_IssubstituteFontSupportted pISysParameterSettings->ISysParameterSettings_IssubstituteFontSupportted
	#define CHK_SysParameterSettings_IssubstituteFontSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IssubstituteFontSupportted  CAL_CMEXPAPI( "SysParameterSettings_IssubstituteFontSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IssubstituteFontSupportted  PFSYSPARAMETERSETTINGS_ISSUBSTITUTEFONTSUPPORTTED pfSysParameterSettings_IssubstituteFontSupportted;
	#define EXT_SysParameterSettings_IssubstituteFontSupportted  extern PFSYSPARAMETERSETTINGS_ISSUBSTITUTEFONTSUPPORTTED pfSysParameterSettings_IssubstituteFontSupportted;
	#define GET_SysParameterSettings_IssubstituteFontSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IssubstituteFontSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IssubstituteFontSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IssubstituteFontSupportted  pfSysParameterSettings_IssubstituteFontSupportted
	#define CHK_SysParameterSettings_IssubstituteFontSupportted  (pfSysParameterSettings_IssubstituteFontSupportted != NULL)
	#define EXP_SysParameterSettings_IssubstituteFontSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IssubstituteFontSupportted", (RTS_UINTPTR)SysParameterSettings_IssubstituteFontSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsuploadFontsSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISUPLOADFONTSSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISUPLOADFONTSSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsuploadFontsSupportted
	#define EXT_SysParameterSettings_IsuploadFontsSupportted
	#define GET_SysParameterSettings_IsuploadFontsSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsuploadFontsSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsuploadFontsSupportted  FALSE
	#define EXP_SysParameterSettings_IsuploadFontsSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsuploadFontsSupportted
	#define EXT_SysParameterSettings_IsuploadFontsSupportted
	#define GET_SysParameterSettings_IsuploadFontsSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsuploadFontsSupportted" ) 
	#define CAL_SysParameterSettings_IsuploadFontsSupportted  SysParameterSettings_IsuploadFontsSupportted
	#define CHK_SysParameterSettings_IsuploadFontsSupportted  TRUE
	#define EXP_SysParameterSettings_IsuploadFontsSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsuploadFontsSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsuploadFontsSupportted
	#define EXT_SysParameterSettings_IsuploadFontsSupportted
	#define GET_SysParameterSettings_IsuploadFontsSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsuploadFontsSupportted" ) 
	#define CAL_SysParameterSettings_IsuploadFontsSupportted  SysParameterSettings_IsuploadFontsSupportted
	#define CHK_SysParameterSettings_IsuploadFontsSupportted  TRUE
	#define EXP_SysParameterSettings_IsuploadFontsSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsuploadFontsSupportted", (RTS_UINTPTR)SysParameterSettings_IsuploadFontsSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsuploadFontsSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsuploadFontsSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsuploadFontsSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsuploadFontsSupportted pISysParameterSettings->ISysParameterSettings_IsuploadFontsSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsuploadFontsSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsuploadFontsSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsuploadFontsSupportted
	#define EXT_SysParameterSettings_IsuploadFontsSupportted
	#define GET_SysParameterSettings_IsuploadFontsSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsuploadFontsSupportted" ) 
	#define CAL_SysParameterSettings_IsuploadFontsSupportted pISysParameterSettings->ISysParameterSettings_IsuploadFontsSupportted
	#define CHK_SysParameterSettings_IsuploadFontsSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsuploadFontsSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsuploadFontsSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsuploadFontsSupportted  PFSYSPARAMETERSETTINGS_ISUPLOADFONTSSUPPORTTED pfSysParameterSettings_IsuploadFontsSupportted;
	#define EXT_SysParameterSettings_IsuploadFontsSupportted  extern PFSYSPARAMETERSETTINGS_ISUPLOADFONTSSUPPORTTED pfSysParameterSettings_IsuploadFontsSupportted;
	#define GET_SysParameterSettings_IsuploadFontsSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsuploadFontsSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsuploadFontsSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsuploadFontsSupportted  pfSysParameterSettings_IsuploadFontsSupportted
	#define CHK_SysParameterSettings_IsuploadFontsSupportted  (pfSysParameterSettings_IsuploadFontsSupportted != NULL)
	#define EXP_SysParameterSettings_IsuploadFontsSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsuploadFontsSupportted", (RTS_UINTPTR)SysParameterSettings_IsuploadFontsSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsCreateUserSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISCREATEUSERSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISCREATEUSERSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsCreateUserSupportted
	#define EXT_SysParameterSettings_IsCreateUserSupportted
	#define GET_SysParameterSettings_IsCreateUserSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsCreateUserSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsCreateUserSupportted  FALSE
	#define EXP_SysParameterSettings_IsCreateUserSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsCreateUserSupportted
	#define EXT_SysParameterSettings_IsCreateUserSupportted
	#define GET_SysParameterSettings_IsCreateUserSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsCreateUserSupportted" ) 
	#define CAL_SysParameterSettings_IsCreateUserSupportted  SysParameterSettings_IsCreateUserSupportted
	#define CHK_SysParameterSettings_IsCreateUserSupportted  TRUE
	#define EXP_SysParameterSettings_IsCreateUserSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsCreateUserSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsCreateUserSupportted
	#define EXT_SysParameterSettings_IsCreateUserSupportted
	#define GET_SysParameterSettings_IsCreateUserSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsCreateUserSupportted" ) 
	#define CAL_SysParameterSettings_IsCreateUserSupportted  SysParameterSettings_IsCreateUserSupportted
	#define CHK_SysParameterSettings_IsCreateUserSupportted  TRUE
	#define EXP_SysParameterSettings_IsCreateUserSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsCreateUserSupportted", (RTS_UINTPTR)SysParameterSettings_IsCreateUserSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsCreateUserSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsCreateUserSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsCreateUserSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsCreateUserSupportted pISysParameterSettings->ISysParameterSettings_IsCreateUserSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsCreateUserSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsCreateUserSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsCreateUserSupportted
	#define EXT_SysParameterSettings_IsCreateUserSupportted
	#define GET_SysParameterSettings_IsCreateUserSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsCreateUserSupportted" ) 
	#define CAL_SysParameterSettings_IsCreateUserSupportted pISysParameterSettings->ISysParameterSettings_IsCreateUserSupportted
	#define CHK_SysParameterSettings_IsCreateUserSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsCreateUserSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsCreateUserSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsCreateUserSupportted  PFSYSPARAMETERSETTINGS_ISCREATEUSERSUPPORTTED pfSysParameterSettings_IsCreateUserSupportted;
	#define EXT_SysParameterSettings_IsCreateUserSupportted  extern PFSYSPARAMETERSETTINGS_ISCREATEUSERSUPPORTTED pfSysParameterSettings_IsCreateUserSupportted;
	#define GET_SysParameterSettings_IsCreateUserSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsCreateUserSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsCreateUserSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsCreateUserSupportted  pfSysParameterSettings_IsCreateUserSupportted
	#define CHK_SysParameterSettings_IsCreateUserSupportted  (pfSysParameterSettings_IsCreateUserSupportted != NULL)
	#define EXP_SysParameterSettings_IsCreateUserSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsCreateUserSupportted", (RTS_UINTPTR)SysParameterSettings_IsCreateUserSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsDeleteUserSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISDELETEUSERSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISDELETEUSERSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsDeleteUserSupportted
	#define EXT_SysParameterSettings_IsDeleteUserSupportted
	#define GET_SysParameterSettings_IsDeleteUserSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsDeleteUserSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsDeleteUserSupportted  FALSE
	#define EXP_SysParameterSettings_IsDeleteUserSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsDeleteUserSupportted
	#define EXT_SysParameterSettings_IsDeleteUserSupportted
	#define GET_SysParameterSettings_IsDeleteUserSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsDeleteUserSupportted" ) 
	#define CAL_SysParameterSettings_IsDeleteUserSupportted  SysParameterSettings_IsDeleteUserSupportted
	#define CHK_SysParameterSettings_IsDeleteUserSupportted  TRUE
	#define EXP_SysParameterSettings_IsDeleteUserSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsDeleteUserSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsDeleteUserSupportted
	#define EXT_SysParameterSettings_IsDeleteUserSupportted
	#define GET_SysParameterSettings_IsDeleteUserSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsDeleteUserSupportted" ) 
	#define CAL_SysParameterSettings_IsDeleteUserSupportted  SysParameterSettings_IsDeleteUserSupportted
	#define CHK_SysParameterSettings_IsDeleteUserSupportted  TRUE
	#define EXP_SysParameterSettings_IsDeleteUserSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsDeleteUserSupportted", (RTS_UINTPTR)SysParameterSettings_IsDeleteUserSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsDeleteUserSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsDeleteUserSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsDeleteUserSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsDeleteUserSupportted pISysParameterSettings->ISysParameterSettings_IsDeleteUserSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsDeleteUserSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsDeleteUserSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsDeleteUserSupportted
	#define EXT_SysParameterSettings_IsDeleteUserSupportted
	#define GET_SysParameterSettings_IsDeleteUserSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsDeleteUserSupportted" ) 
	#define CAL_SysParameterSettings_IsDeleteUserSupportted pISysParameterSettings->ISysParameterSettings_IsDeleteUserSupportted
	#define CHK_SysParameterSettings_IsDeleteUserSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsDeleteUserSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsDeleteUserSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsDeleteUserSupportted  PFSYSPARAMETERSETTINGS_ISDELETEUSERSUPPORTTED pfSysParameterSettings_IsDeleteUserSupportted;
	#define EXT_SysParameterSettings_IsDeleteUserSupportted  extern PFSYSPARAMETERSETTINGS_ISDELETEUSERSUPPORTTED pfSysParameterSettings_IsDeleteUserSupportted;
	#define GET_SysParameterSettings_IsDeleteUserSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsDeleteUserSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsDeleteUserSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsDeleteUserSupportted  pfSysParameterSettings_IsDeleteUserSupportted
	#define CHK_SysParameterSettings_IsDeleteUserSupportted  (pfSysParameterSettings_IsDeleteUserSupportted != NULL)
	#define EXP_SysParameterSettings_IsDeleteUserSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsDeleteUserSupportted", (RTS_UINTPTR)SysParameterSettings_IsDeleteUserSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IschangeBrightnessSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISCHANGEBRIGHTNESSSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISCHANGEBRIGHTNESSSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IschangeBrightnessSupportted
	#define EXT_SysParameterSettings_IschangeBrightnessSupportted
	#define GET_SysParameterSettings_IschangeBrightnessSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IschangeBrightnessSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IschangeBrightnessSupportted  FALSE
	#define EXP_SysParameterSettings_IschangeBrightnessSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IschangeBrightnessSupportted
	#define EXT_SysParameterSettings_IschangeBrightnessSupportted
	#define GET_SysParameterSettings_IschangeBrightnessSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IschangeBrightnessSupportted" ) 
	#define CAL_SysParameterSettings_IschangeBrightnessSupportted  SysParameterSettings_IschangeBrightnessSupportted
	#define CHK_SysParameterSettings_IschangeBrightnessSupportted  TRUE
	#define EXP_SysParameterSettings_IschangeBrightnessSupportted  CAL_CMEXPAPI( "SysParameterSettings_IschangeBrightnessSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IschangeBrightnessSupportted
	#define EXT_SysParameterSettings_IschangeBrightnessSupportted
	#define GET_SysParameterSettings_IschangeBrightnessSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IschangeBrightnessSupportted" ) 
	#define CAL_SysParameterSettings_IschangeBrightnessSupportted  SysParameterSettings_IschangeBrightnessSupportted
	#define CHK_SysParameterSettings_IschangeBrightnessSupportted  TRUE
	#define EXP_SysParameterSettings_IschangeBrightnessSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IschangeBrightnessSupportted", (RTS_UINTPTR)SysParameterSettings_IschangeBrightnessSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IschangeBrightnessSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IschangeBrightnessSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IschangeBrightnessSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IschangeBrightnessSupportted pISysParameterSettings->ISysParameterSettings_IschangeBrightnessSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IschangeBrightnessSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IschangeBrightnessSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IschangeBrightnessSupportted
	#define EXT_SysParameterSettings_IschangeBrightnessSupportted
	#define GET_SysParameterSettings_IschangeBrightnessSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IschangeBrightnessSupportted" ) 
	#define CAL_SysParameterSettings_IschangeBrightnessSupportted pISysParameterSettings->ISysParameterSettings_IschangeBrightnessSupportted
	#define CHK_SysParameterSettings_IschangeBrightnessSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IschangeBrightnessSupportted  CAL_CMEXPAPI( "SysParameterSettings_IschangeBrightnessSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IschangeBrightnessSupportted  PFSYSPARAMETERSETTINGS_ISCHANGEBRIGHTNESSSUPPORTTED pfSysParameterSettings_IschangeBrightnessSupportted;
	#define EXT_SysParameterSettings_IschangeBrightnessSupportted  extern PFSYSPARAMETERSETTINGS_ISCHANGEBRIGHTNESSSUPPORTTED pfSysParameterSettings_IschangeBrightnessSupportted;
	#define GET_SysParameterSettings_IschangeBrightnessSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IschangeBrightnessSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IschangeBrightnessSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IschangeBrightnessSupportted  pfSysParameterSettings_IschangeBrightnessSupportted
	#define CHK_SysParameterSettings_IschangeBrightnessSupportted  (pfSysParameterSettings_IschangeBrightnessSupportted != NULL)
	#define EXP_SysParameterSettings_IschangeBrightnessSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IschangeBrightnessSupportted", (RTS_UINTPTR)SysParameterSettings_IschangeBrightnessSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsturnScreensaverSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISTURNSCREENSAVERSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISTURNSCREENSAVERSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsturnScreensaverSupportted
	#define EXT_SysParameterSettings_IsturnScreensaverSupportted
	#define GET_SysParameterSettings_IsturnScreensaverSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsturnScreensaverSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsturnScreensaverSupportted  FALSE
	#define EXP_SysParameterSettings_IsturnScreensaverSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsturnScreensaverSupportted
	#define EXT_SysParameterSettings_IsturnScreensaverSupportted
	#define GET_SysParameterSettings_IsturnScreensaverSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsturnScreensaverSupportted" ) 
	#define CAL_SysParameterSettings_IsturnScreensaverSupportted  SysParameterSettings_IsturnScreensaverSupportted
	#define CHK_SysParameterSettings_IsturnScreensaverSupportted  TRUE
	#define EXP_SysParameterSettings_IsturnScreensaverSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsturnScreensaverSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsturnScreensaverSupportted
	#define EXT_SysParameterSettings_IsturnScreensaverSupportted
	#define GET_SysParameterSettings_IsturnScreensaverSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsturnScreensaverSupportted" ) 
	#define CAL_SysParameterSettings_IsturnScreensaverSupportted  SysParameterSettings_IsturnScreensaverSupportted
	#define CHK_SysParameterSettings_IsturnScreensaverSupportted  TRUE
	#define EXP_SysParameterSettings_IsturnScreensaverSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsturnScreensaverSupportted", (RTS_UINTPTR)SysParameterSettings_IsturnScreensaverSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsturnScreensaverSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsturnScreensaverSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsturnScreensaverSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsturnScreensaverSupportted pISysParameterSettings->ISysParameterSettings_IsturnScreensaverSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsturnScreensaverSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsturnScreensaverSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsturnScreensaverSupportted
	#define EXT_SysParameterSettings_IsturnScreensaverSupportted
	#define GET_SysParameterSettings_IsturnScreensaverSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsturnScreensaverSupportted" ) 
	#define CAL_SysParameterSettings_IsturnScreensaverSupportted pISysParameterSettings->ISysParameterSettings_IsturnScreensaverSupportted
	#define CHK_SysParameterSettings_IsturnScreensaverSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsturnScreensaverSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsturnScreensaverSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsturnScreensaverSupportted  PFSYSPARAMETERSETTINGS_ISTURNSCREENSAVERSUPPORTTED pfSysParameterSettings_IsturnScreensaverSupportted;
	#define EXT_SysParameterSettings_IsturnScreensaverSupportted  extern PFSYSPARAMETERSETTINGS_ISTURNSCREENSAVERSUPPORTTED pfSysParameterSettings_IsturnScreensaverSupportted;
	#define GET_SysParameterSettings_IsturnScreensaverSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsturnScreensaverSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsturnScreensaverSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsturnScreensaverSupportted  pfSysParameterSettings_IsturnScreensaverSupportted
	#define CHK_SysParameterSettings_IsturnScreensaverSupportted  (pfSysParameterSettings_IsturnScreensaverSupportted != NULL)
	#define EXP_SysParameterSettings_IsturnScreensaverSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsturnScreensaverSupportted", (RTS_UINTPTR)SysParameterSettings_IsturnScreensaverSupportted, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_IsgetSSImageSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_ISGETSSIMAGESUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_ISGETSSIMAGESUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_IsgetSSImageSupportted
	#define EXT_SysParameterSettings_IsgetSSImageSupportted
	#define GET_SysParameterSettings_IsgetSSImageSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_IsgetSSImageSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_IsgetSSImageSupportted  FALSE
	#define EXP_SysParameterSettings_IsgetSSImageSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_IsgetSSImageSupportted
	#define EXT_SysParameterSettings_IsgetSSImageSupportted
	#define GET_SysParameterSettings_IsgetSSImageSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsgetSSImageSupportted" ) 
	#define CAL_SysParameterSettings_IsgetSSImageSupportted  SysParameterSettings_IsgetSSImageSupportted
	#define CHK_SysParameterSettings_IsgetSSImageSupportted  TRUE
	#define EXP_SysParameterSettings_IsgetSSImageSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsgetSSImageSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_IsgetSSImageSupportted
	#define EXT_SysParameterSettings_IsgetSSImageSupportted
	#define GET_SysParameterSettings_IsgetSSImageSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsgetSSImageSupportted" ) 
	#define CAL_SysParameterSettings_IsgetSSImageSupportted  SysParameterSettings_IsgetSSImageSupportted
	#define CHK_SysParameterSettings_IsgetSSImageSupportted  TRUE
	#define EXP_SysParameterSettings_IsgetSSImageSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsgetSSImageSupportted", (RTS_UINTPTR)SysParameterSettings_IsgetSSImageSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_IsgetSSImageSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_IsgetSSImageSupportted
	#define GET_SysParameterSettingsSysParameterSettings_IsgetSSImageSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_IsgetSSImageSupportted pISysParameterSettings->ISysParameterSettings_IsgetSSImageSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_IsgetSSImageSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_IsgetSSImageSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_IsgetSSImageSupportted
	#define EXT_SysParameterSettings_IsgetSSImageSupportted
	#define GET_SysParameterSettings_IsgetSSImageSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_IsgetSSImageSupportted" ) 
	#define CAL_SysParameterSettings_IsgetSSImageSupportted pISysParameterSettings->ISysParameterSettings_IsgetSSImageSupportted
	#define CHK_SysParameterSettings_IsgetSSImageSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_IsgetSSImageSupportted  CAL_CMEXPAPI( "SysParameterSettings_IsgetSSImageSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_IsgetSSImageSupportted  PFSYSPARAMETERSETTINGS_ISGETSSIMAGESUPPORTTED pfSysParameterSettings_IsgetSSImageSupportted;
	#define EXT_SysParameterSettings_IsgetSSImageSupportted  extern PFSYSPARAMETERSETTINGS_ISGETSSIMAGESUPPORTTED pfSysParameterSettings_IsgetSSImageSupportted;
	#define GET_SysParameterSettings_IsgetSSImageSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_IsgetSSImageSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_IsgetSSImageSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_IsgetSSImageSupportted  pfSysParameterSettings_IsgetSSImageSupportted
	#define CHK_SysParameterSettings_IsgetSSImageSupportted  (pfSysParameterSettings_IsgetSSImageSupportted != NULL)
	#define EXP_SysParameterSettings_IsgetSSImageSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_IsgetSSImageSupportted", (RTS_UINTPTR)SysParameterSettings_IsgetSSImageSupportted, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetNETRoutes(char * szRoutes, RTS_IEC_DWORD* pSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETNETROUTES) (char * szRoutes, RTS_IEC_DWORD* pSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETNETROUTES_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetNETRoutes
	#define EXT_SysParameterSettings_GetNETRoutes
	#define GET_SysParameterSettings_GetNETRoutes(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetNETRoutes(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetNETRoutes  FALSE
	#define EXP_SysParameterSettings_GetNETRoutes  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetNETRoutes
	#define EXT_SysParameterSettings_GetNETRoutes
	#define GET_SysParameterSettings_GetNETRoutes(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNETRoutes" ) 
	#define CAL_SysParameterSettings_GetNETRoutes  SysParameterSettings_GetNETRoutes
	#define CHK_SysParameterSettings_GetNETRoutes  TRUE
	#define EXP_SysParameterSettings_GetNETRoutes  CAL_CMEXPAPI( "SysParameterSettings_GetNETRoutes" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetNETRoutes
	#define EXT_SysParameterSettings_GetNETRoutes
	#define GET_SysParameterSettings_GetNETRoutes(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNETRoutes" ) 
	#define CAL_SysParameterSettings_GetNETRoutes  SysParameterSettings_GetNETRoutes
	#define CHK_SysParameterSettings_GetNETRoutes  TRUE
	#define EXP_SysParameterSettings_GetNETRoutes  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNETRoutes", (RTS_UINTPTR)SysParameterSettings_GetNETRoutes, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetNETRoutes
	#define EXT_SysParameterSettingsSysParameterSettings_GetNETRoutes
	#define GET_SysParameterSettingsSysParameterSettings_GetNETRoutes  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetNETRoutes pISysParameterSettings->ISysParameterSettings_GetNETRoutes
	#define CHK_SysParameterSettingsSysParameterSettings_GetNETRoutes (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetNETRoutes  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetNETRoutes
	#define EXT_SysParameterSettings_GetNETRoutes
	#define GET_SysParameterSettings_GetNETRoutes(fl)  CAL_CMGETAPI( "SysParameterSettings_GetNETRoutes" ) 
	#define CAL_SysParameterSettings_GetNETRoutes pISysParameterSettings->ISysParameterSettings_GetNETRoutes
	#define CHK_SysParameterSettings_GetNETRoutes (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetNETRoutes  CAL_CMEXPAPI( "SysParameterSettings_GetNETRoutes" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetNETRoutes  PFSYSPARAMETERSETTINGS_GETNETROUTES pfSysParameterSettings_GetNETRoutes;
	#define EXT_SysParameterSettings_GetNETRoutes  extern PFSYSPARAMETERSETTINGS_GETNETROUTES pfSysParameterSettings_GetNETRoutes;
	#define GET_SysParameterSettings_GetNETRoutes(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetNETRoutes", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetNETRoutes, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetNETRoutes  pfSysParameterSettings_GetNETRoutes
	#define CHK_SysParameterSettings_GetNETRoutes  (pfSysParameterSettings_GetNETRoutes != NULL)
	#define EXP_SysParameterSettings_GetNETRoutes  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetNETRoutes", (RTS_UINTPTR)SysParameterSettings_GetNETRoutes, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetNETRoutes(char * szRoutes, RTS_IEC_DWORD siSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETNETROUTES) (char * szRoutes, RTS_IEC_DWORD siSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETNETROUTES_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetNETRoutes
	#define EXT_SysParameterSettings_SetNETRoutes
	#define GET_SysParameterSettings_SetNETRoutes(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetNETRoutes(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetNETRoutes  FALSE
	#define EXP_SysParameterSettings_SetNETRoutes  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetNETRoutes
	#define EXT_SysParameterSettings_SetNETRoutes
	#define GET_SysParameterSettings_SetNETRoutes(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNETRoutes" ) 
	#define CAL_SysParameterSettings_SetNETRoutes  SysParameterSettings_SetNETRoutes
	#define CHK_SysParameterSettings_SetNETRoutes  TRUE
	#define EXP_SysParameterSettings_SetNETRoutes  CAL_CMEXPAPI( "SysParameterSettings_SetNETRoutes" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetNETRoutes
	#define EXT_SysParameterSettings_SetNETRoutes
	#define GET_SysParameterSettings_SetNETRoutes(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNETRoutes" ) 
	#define CAL_SysParameterSettings_SetNETRoutes  SysParameterSettings_SetNETRoutes
	#define CHK_SysParameterSettings_SetNETRoutes  TRUE
	#define EXP_SysParameterSettings_SetNETRoutes  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetNETRoutes", (RTS_UINTPTR)SysParameterSettings_SetNETRoutes, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetNETRoutes
	#define EXT_SysParameterSettingsSysParameterSettings_SetNETRoutes
	#define GET_SysParameterSettingsSysParameterSettings_SetNETRoutes  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetNETRoutes pISysParameterSettings->ISysParameterSettings_SetNETRoutes
	#define CHK_SysParameterSettingsSysParameterSettings_SetNETRoutes (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetNETRoutes  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetNETRoutes
	#define EXT_SysParameterSettings_SetNETRoutes
	#define GET_SysParameterSettings_SetNETRoutes(fl)  CAL_CMGETAPI( "SysParameterSettings_SetNETRoutes" ) 
	#define CAL_SysParameterSettings_SetNETRoutes pISysParameterSettings->ISysParameterSettings_SetNETRoutes
	#define CHK_SysParameterSettings_SetNETRoutes (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetNETRoutes  CAL_CMEXPAPI( "SysParameterSettings_SetNETRoutes" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetNETRoutes  PFSYSPARAMETERSETTINGS_SETNETROUTES pfSysParameterSettings_SetNETRoutes;
	#define EXT_SysParameterSettings_SetNETRoutes  extern PFSYSPARAMETERSETTINGS_SETNETROUTES pfSysParameterSettings_SetNETRoutes;
	#define GET_SysParameterSettings_SetNETRoutes(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetNETRoutes", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetNETRoutes, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetNETRoutes  pfSysParameterSettings_SetNETRoutes
	#define CHK_SysParameterSettings_SetNETRoutes  (pfSysParameterSettings_SetNETRoutes != NULL)
	#define EXP_SysParameterSettings_SetNETRoutes  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetNETRoutes", (RTS_UINTPTR)SysParameterSettings_SetNETRoutes, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetRS485Term(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETRS485TERM) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETRS485TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetRS485Term
	#define EXT_SysParameterSettings_GetRS485Term
	#define GET_SysParameterSettings_GetRS485Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetRS485Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetRS485Term  FALSE
	#define EXP_SysParameterSettings_GetRS485Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetRS485Term
	#define EXT_SysParameterSettings_GetRS485Term
	#define GET_SysParameterSettings_GetRS485Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRS485Term" ) 
	#define CAL_SysParameterSettings_GetRS485Term  SysParameterSettings_GetRS485Term
	#define CHK_SysParameterSettings_GetRS485Term  TRUE
	#define EXP_SysParameterSettings_GetRS485Term  CAL_CMEXPAPI( "SysParameterSettings_GetRS485Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetRS485Term
	#define EXT_SysParameterSettings_GetRS485Term
	#define GET_SysParameterSettings_GetRS485Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRS485Term" ) 
	#define CAL_SysParameterSettings_GetRS485Term  SysParameterSettings_GetRS485Term
	#define CHK_SysParameterSettings_GetRS485Term  TRUE
	#define EXP_SysParameterSettings_GetRS485Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRS485Term", (RTS_UINTPTR)SysParameterSettings_GetRS485Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetRS485Term
	#define EXT_SysParameterSettingsSysParameterSettings_GetRS485Term
	#define GET_SysParameterSettingsSysParameterSettings_GetRS485Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetRS485Term pISysParameterSettings->ISysParameterSettings_GetRS485Term
	#define CHK_SysParameterSettingsSysParameterSettings_GetRS485Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetRS485Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetRS485Term
	#define EXT_SysParameterSettings_GetRS485Term
	#define GET_SysParameterSettings_GetRS485Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRS485Term" ) 
	#define CAL_SysParameterSettings_GetRS485Term pISysParameterSettings->ISysParameterSettings_GetRS485Term
	#define CHK_SysParameterSettings_GetRS485Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetRS485Term  CAL_CMEXPAPI( "SysParameterSettings_GetRS485Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetRS485Term  PFSYSPARAMETERSETTINGS_GETRS485TERM pfSysParameterSettings_GetRS485Term;
	#define EXT_SysParameterSettings_GetRS485Term  extern PFSYSPARAMETERSETTINGS_GETRS485TERM pfSysParameterSettings_GetRS485Term;
	#define GET_SysParameterSettings_GetRS485Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetRS485Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetRS485Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetRS485Term  pfSysParameterSettings_GetRS485Term
	#define CHK_SysParameterSettings_GetRS485Term  (pfSysParameterSettings_GetRS485Term != NULL)
	#define EXP_SysParameterSettings_GetRS485Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRS485Term", (RTS_UINTPTR)SysParameterSettings_GetRS485Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetRS485Term(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETRS485TERM) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETRS485TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetRS485Term
	#define EXT_SysParameterSettings_SetRS485Term
	#define GET_SysParameterSettings_SetRS485Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetRS485Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetRS485Term  FALSE
	#define EXP_SysParameterSettings_SetRS485Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetRS485Term
	#define EXT_SysParameterSettings_SetRS485Term
	#define GET_SysParameterSettings_SetRS485Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetRS485Term" ) 
	#define CAL_SysParameterSettings_SetRS485Term  SysParameterSettings_SetRS485Term
	#define CHK_SysParameterSettings_SetRS485Term  TRUE
	#define EXP_SysParameterSettings_SetRS485Term  CAL_CMEXPAPI( "SysParameterSettings_SetRS485Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetRS485Term
	#define EXT_SysParameterSettings_SetRS485Term
	#define GET_SysParameterSettings_SetRS485Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetRS485Term" ) 
	#define CAL_SysParameterSettings_SetRS485Term  SysParameterSettings_SetRS485Term
	#define CHK_SysParameterSettings_SetRS485Term  TRUE
	#define EXP_SysParameterSettings_SetRS485Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetRS485Term", (RTS_UINTPTR)SysParameterSettings_SetRS485Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetRS485Term
	#define EXT_SysParameterSettingsSysParameterSettings_SetRS485Term
	#define GET_SysParameterSettingsSysParameterSettings_SetRS485Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetRS485Term pISysParameterSettings->ISysParameterSettings_SetRS485Term
	#define CHK_SysParameterSettingsSysParameterSettings_SetRS485Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetRS485Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetRS485Term
	#define EXT_SysParameterSettings_SetRS485Term
	#define GET_SysParameterSettings_SetRS485Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetRS485Term" ) 
	#define CAL_SysParameterSettings_SetRS485Term pISysParameterSettings->ISysParameterSettings_SetRS485Term
	#define CHK_SysParameterSettings_SetRS485Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetRS485Term  CAL_CMEXPAPI( "SysParameterSettings_SetRS485Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetRS485Term  PFSYSPARAMETERSETTINGS_SETRS485TERM pfSysParameterSettings_SetRS485Term;
	#define EXT_SysParameterSettings_SetRS485Term  extern PFSYSPARAMETERSETTINGS_SETRS485TERM pfSysParameterSettings_SetRS485Term;
	#define GET_SysParameterSettings_SetRS485Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetRS485Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetRS485Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetRS485Term  pfSysParameterSettings_SetRS485Term
	#define CHK_SysParameterSettings_SetRS485Term  (pfSysParameterSettings_SetRS485Term != NULL)
	#define EXP_SysParameterSettings_SetRS485Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetRS485Term", (RTS_UINTPTR)SysParameterSettings_SetRS485Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetRightCAN0Term(char * pszUserName);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETRIGHTCAN0TERM) (char * pszUserName);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETRIGHTCAN0TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetRightCAN0Term
	#define EXT_SysParameterSettings_GetRightCAN0Term
	#define GET_SysParameterSettings_GetRightCAN0Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetRightCAN0Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetRightCAN0Term  FALSE
	#define EXP_SysParameterSettings_GetRightCAN0Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetRightCAN0Term
	#define EXT_SysParameterSettings_GetRightCAN0Term
	#define GET_SysParameterSettings_GetRightCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightCAN0Term" ) 
	#define CAL_SysParameterSettings_GetRightCAN0Term  SysParameterSettings_GetRightCAN0Term
	#define CHK_SysParameterSettings_GetRightCAN0Term  TRUE
	#define EXP_SysParameterSettings_GetRightCAN0Term  CAL_CMEXPAPI( "SysParameterSettings_GetRightCAN0Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetRightCAN0Term
	#define EXT_SysParameterSettings_GetRightCAN0Term
	#define GET_SysParameterSettings_GetRightCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightCAN0Term" ) 
	#define CAL_SysParameterSettings_GetRightCAN0Term  SysParameterSettings_GetRightCAN0Term
	#define CHK_SysParameterSettings_GetRightCAN0Term  TRUE
	#define EXP_SysParameterSettings_GetRightCAN0Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRightCAN0Term", (RTS_UINTPTR)SysParameterSettings_GetRightCAN0Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetRightCAN0Term
	#define EXT_SysParameterSettingsSysParameterSettings_GetRightCAN0Term
	#define GET_SysParameterSettingsSysParameterSettings_GetRightCAN0Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetRightCAN0Term pISysParameterSettings->ISysParameterSettings_GetRightCAN0Term
	#define CHK_SysParameterSettingsSysParameterSettings_GetRightCAN0Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetRightCAN0Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetRightCAN0Term
	#define EXT_SysParameterSettings_GetRightCAN0Term
	#define GET_SysParameterSettings_GetRightCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightCAN0Term" ) 
	#define CAL_SysParameterSettings_GetRightCAN0Term pISysParameterSettings->ISysParameterSettings_GetRightCAN0Term
	#define CHK_SysParameterSettings_GetRightCAN0Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetRightCAN0Term  CAL_CMEXPAPI( "SysParameterSettings_GetRightCAN0Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetRightCAN0Term  PFSYSPARAMETERSETTINGS_GETRIGHTCAN0TERM pfSysParameterSettings_GetRightCAN0Term;
	#define EXT_SysParameterSettings_GetRightCAN0Term  extern PFSYSPARAMETERSETTINGS_GETRIGHTCAN0TERM pfSysParameterSettings_GetRightCAN0Term;
	#define GET_SysParameterSettings_GetRightCAN0Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetRightCAN0Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetRightCAN0Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetRightCAN0Term  pfSysParameterSettings_GetRightCAN0Term
	#define CHK_SysParameterSettings_GetRightCAN0Term  (pfSysParameterSettings_GetRightCAN0Term != NULL)
	#define EXP_SysParameterSettings_GetRightCAN0Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRightCAN0Term", (RTS_UINTPTR)SysParameterSettings_GetRightCAN0Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetCAN0Term(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETCAN0TERM) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETCAN0TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetCAN0Term
	#define EXT_SysParameterSettings_GetCAN0Term
	#define GET_SysParameterSettings_GetCAN0Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetCAN0Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetCAN0Term  FALSE
	#define EXP_SysParameterSettings_GetCAN0Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetCAN0Term
	#define EXT_SysParameterSettings_GetCAN0Term
	#define GET_SysParameterSettings_GetCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCAN0Term" ) 
	#define CAL_SysParameterSettings_GetCAN0Term  SysParameterSettings_GetCAN0Term
	#define CHK_SysParameterSettings_GetCAN0Term  TRUE
	#define EXP_SysParameterSettings_GetCAN0Term  CAL_CMEXPAPI( "SysParameterSettings_GetCAN0Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetCAN0Term
	#define EXT_SysParameterSettings_GetCAN0Term
	#define GET_SysParameterSettings_GetCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCAN0Term" ) 
	#define CAL_SysParameterSettings_GetCAN0Term  SysParameterSettings_GetCAN0Term
	#define CHK_SysParameterSettings_GetCAN0Term  TRUE
	#define EXP_SysParameterSettings_GetCAN0Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetCAN0Term", (RTS_UINTPTR)SysParameterSettings_GetCAN0Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetCAN0Term
	#define EXT_SysParameterSettingsSysParameterSettings_GetCAN0Term
	#define GET_SysParameterSettingsSysParameterSettings_GetCAN0Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetCAN0Term pISysParameterSettings->ISysParameterSettings_GetCAN0Term
	#define CHK_SysParameterSettingsSysParameterSettings_GetCAN0Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetCAN0Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetCAN0Term
	#define EXT_SysParameterSettings_GetCAN0Term
	#define GET_SysParameterSettings_GetCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCAN0Term" ) 
	#define CAL_SysParameterSettings_GetCAN0Term pISysParameterSettings->ISysParameterSettings_GetCAN0Term
	#define CHK_SysParameterSettings_GetCAN0Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetCAN0Term  CAL_CMEXPAPI( "SysParameterSettings_GetCAN0Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetCAN0Term  PFSYSPARAMETERSETTINGS_GETCAN0TERM pfSysParameterSettings_GetCAN0Term;
	#define EXT_SysParameterSettings_GetCAN0Term  extern PFSYSPARAMETERSETTINGS_GETCAN0TERM pfSysParameterSettings_GetCAN0Term;
	#define GET_SysParameterSettings_GetCAN0Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetCAN0Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetCAN0Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetCAN0Term  pfSysParameterSettings_GetCAN0Term
	#define CHK_SysParameterSettings_GetCAN0Term  (pfSysParameterSettings_GetCAN0Term != NULL)
	#define EXP_SysParameterSettings_GetCAN0Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetCAN0Term", (RTS_UINTPTR)SysParameterSettings_GetCAN0Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetCAN0Term(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETCAN0TERM) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETCAN0TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetCAN0Term
	#define EXT_SysParameterSettings_SetCAN0Term
	#define GET_SysParameterSettings_SetCAN0Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetCAN0Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetCAN0Term  FALSE
	#define EXP_SysParameterSettings_SetCAN0Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetCAN0Term
	#define EXT_SysParameterSettings_SetCAN0Term
	#define GET_SysParameterSettings_SetCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCAN0Term" ) 
	#define CAL_SysParameterSettings_SetCAN0Term  SysParameterSettings_SetCAN0Term
	#define CHK_SysParameterSettings_SetCAN0Term  TRUE
	#define EXP_SysParameterSettings_SetCAN0Term  CAL_CMEXPAPI( "SysParameterSettings_SetCAN0Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetCAN0Term
	#define EXT_SysParameterSettings_SetCAN0Term
	#define GET_SysParameterSettings_SetCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCAN0Term" ) 
	#define CAL_SysParameterSettings_SetCAN0Term  SysParameterSettings_SetCAN0Term
	#define CHK_SysParameterSettings_SetCAN0Term  TRUE
	#define EXP_SysParameterSettings_SetCAN0Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetCAN0Term", (RTS_UINTPTR)SysParameterSettings_SetCAN0Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetCAN0Term
	#define EXT_SysParameterSettingsSysParameterSettings_SetCAN0Term
	#define GET_SysParameterSettingsSysParameterSettings_SetCAN0Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetCAN0Term pISysParameterSettings->ISysParameterSettings_SetCAN0Term
	#define CHK_SysParameterSettingsSysParameterSettings_SetCAN0Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetCAN0Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetCAN0Term
	#define EXT_SysParameterSettings_SetCAN0Term
	#define GET_SysParameterSettings_SetCAN0Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCAN0Term" ) 
	#define CAL_SysParameterSettings_SetCAN0Term pISysParameterSettings->ISysParameterSettings_SetCAN0Term
	#define CHK_SysParameterSettings_SetCAN0Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetCAN0Term  CAL_CMEXPAPI( "SysParameterSettings_SetCAN0Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetCAN0Term  PFSYSPARAMETERSETTINGS_SETCAN0TERM pfSysParameterSettings_SetCAN0Term;
	#define EXT_SysParameterSettings_SetCAN0Term  extern PFSYSPARAMETERSETTINGS_SETCAN0TERM pfSysParameterSettings_SetCAN0Term;
	#define GET_SysParameterSettings_SetCAN0Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetCAN0Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetCAN0Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetCAN0Term  pfSysParameterSettings_SetCAN0Term
	#define CHK_SysParameterSettings_SetCAN0Term  (pfSysParameterSettings_SetCAN0Term != NULL)
	#define EXP_SysParameterSettings_SetCAN0Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetCAN0Term", (RTS_UINTPTR)SysParameterSettings_SetCAN0Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetRightCAN1Term(char * pszUserName);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETRIGHTCAN1TERM) (char * pszUserName);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETRIGHTCAN1TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetRightCAN1Term
	#define EXT_SysParameterSettings_GetRightCAN1Term
	#define GET_SysParameterSettings_GetRightCAN1Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetRightCAN1Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetRightCAN1Term  FALSE
	#define EXP_SysParameterSettings_GetRightCAN1Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetRightCAN1Term
	#define EXT_SysParameterSettings_GetRightCAN1Term
	#define GET_SysParameterSettings_GetRightCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightCAN1Term" ) 
	#define CAL_SysParameterSettings_GetRightCAN1Term  SysParameterSettings_GetRightCAN1Term
	#define CHK_SysParameterSettings_GetRightCAN1Term  TRUE
	#define EXP_SysParameterSettings_GetRightCAN1Term  CAL_CMEXPAPI( "SysParameterSettings_GetRightCAN1Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetRightCAN1Term
	#define EXT_SysParameterSettings_GetRightCAN1Term
	#define GET_SysParameterSettings_GetRightCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightCAN1Term" ) 
	#define CAL_SysParameterSettings_GetRightCAN1Term  SysParameterSettings_GetRightCAN1Term
	#define CHK_SysParameterSettings_GetRightCAN1Term  TRUE
	#define EXP_SysParameterSettings_GetRightCAN1Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRightCAN1Term", (RTS_UINTPTR)SysParameterSettings_GetRightCAN1Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetRightCAN1Term
	#define EXT_SysParameterSettingsSysParameterSettings_GetRightCAN1Term
	#define GET_SysParameterSettingsSysParameterSettings_GetRightCAN1Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetRightCAN1Term pISysParameterSettings->ISysParameterSettings_GetRightCAN1Term
	#define CHK_SysParameterSettingsSysParameterSettings_GetRightCAN1Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetRightCAN1Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetRightCAN1Term
	#define EXT_SysParameterSettings_GetRightCAN1Term
	#define GET_SysParameterSettings_GetRightCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetRightCAN1Term" ) 
	#define CAL_SysParameterSettings_GetRightCAN1Term pISysParameterSettings->ISysParameterSettings_GetRightCAN1Term
	#define CHK_SysParameterSettings_GetRightCAN1Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetRightCAN1Term  CAL_CMEXPAPI( "SysParameterSettings_GetRightCAN1Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetRightCAN1Term  PFSYSPARAMETERSETTINGS_GETRIGHTCAN1TERM pfSysParameterSettings_GetRightCAN1Term;
	#define EXT_SysParameterSettings_GetRightCAN1Term  extern PFSYSPARAMETERSETTINGS_GETRIGHTCAN1TERM pfSysParameterSettings_GetRightCAN1Term;
	#define GET_SysParameterSettings_GetRightCAN1Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetRightCAN1Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetRightCAN1Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetRightCAN1Term  pfSysParameterSettings_GetRightCAN1Term
	#define CHK_SysParameterSettings_GetRightCAN1Term  (pfSysParameterSettings_GetRightCAN1Term != NULL)
	#define EXP_SysParameterSettings_GetRightCAN1Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetRightCAN1Term", (RTS_UINTPTR)SysParameterSettings_GetRightCAN1Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetCAN1Term(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETCAN1TERM) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETCAN1TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetCAN1Term
	#define EXT_SysParameterSettings_GetCAN1Term
	#define GET_SysParameterSettings_GetCAN1Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetCAN1Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetCAN1Term  FALSE
	#define EXP_SysParameterSettings_GetCAN1Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetCAN1Term
	#define EXT_SysParameterSettings_GetCAN1Term
	#define GET_SysParameterSettings_GetCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCAN1Term" ) 
	#define CAL_SysParameterSettings_GetCAN1Term  SysParameterSettings_GetCAN1Term
	#define CHK_SysParameterSettings_GetCAN1Term  TRUE
	#define EXP_SysParameterSettings_GetCAN1Term  CAL_CMEXPAPI( "SysParameterSettings_GetCAN1Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetCAN1Term
	#define EXT_SysParameterSettings_GetCAN1Term
	#define GET_SysParameterSettings_GetCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCAN1Term" ) 
	#define CAL_SysParameterSettings_GetCAN1Term  SysParameterSettings_GetCAN1Term
	#define CHK_SysParameterSettings_GetCAN1Term  TRUE
	#define EXP_SysParameterSettings_GetCAN1Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetCAN1Term", (RTS_UINTPTR)SysParameterSettings_GetCAN1Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetCAN1Term
	#define EXT_SysParameterSettingsSysParameterSettings_GetCAN1Term
	#define GET_SysParameterSettingsSysParameterSettings_GetCAN1Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetCAN1Term pISysParameterSettings->ISysParameterSettings_GetCAN1Term
	#define CHK_SysParameterSettingsSysParameterSettings_GetCAN1Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetCAN1Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetCAN1Term
	#define EXT_SysParameterSettings_GetCAN1Term
	#define GET_SysParameterSettings_GetCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_GetCAN1Term" ) 
	#define CAL_SysParameterSettings_GetCAN1Term pISysParameterSettings->ISysParameterSettings_GetCAN1Term
	#define CHK_SysParameterSettings_GetCAN1Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetCAN1Term  CAL_CMEXPAPI( "SysParameterSettings_GetCAN1Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetCAN1Term  PFSYSPARAMETERSETTINGS_GETCAN1TERM pfSysParameterSettings_GetCAN1Term;
	#define EXT_SysParameterSettings_GetCAN1Term  extern PFSYSPARAMETERSETTINGS_GETCAN1TERM pfSysParameterSettings_GetCAN1Term;
	#define GET_SysParameterSettings_GetCAN1Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetCAN1Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetCAN1Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetCAN1Term  pfSysParameterSettings_GetCAN1Term
	#define CHK_SysParameterSettings_GetCAN1Term  (pfSysParameterSettings_GetCAN1Term != NULL)
	#define EXP_SysParameterSettings_GetCAN1Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetCAN1Term", (RTS_UINTPTR)SysParameterSettings_GetCAN1Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetCAN1Term(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETCAN1TERM) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETCAN1TERM_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetCAN1Term
	#define EXT_SysParameterSettings_SetCAN1Term
	#define GET_SysParameterSettings_SetCAN1Term(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetCAN1Term(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetCAN1Term  FALSE
	#define EXP_SysParameterSettings_SetCAN1Term  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetCAN1Term
	#define EXT_SysParameterSettings_SetCAN1Term
	#define GET_SysParameterSettings_SetCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCAN1Term" ) 
	#define CAL_SysParameterSettings_SetCAN1Term  SysParameterSettings_SetCAN1Term
	#define CHK_SysParameterSettings_SetCAN1Term  TRUE
	#define EXP_SysParameterSettings_SetCAN1Term  CAL_CMEXPAPI( "SysParameterSettings_SetCAN1Term" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetCAN1Term
	#define EXT_SysParameterSettings_SetCAN1Term
	#define GET_SysParameterSettings_SetCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCAN1Term" ) 
	#define CAL_SysParameterSettings_SetCAN1Term  SysParameterSettings_SetCAN1Term
	#define CHK_SysParameterSettings_SetCAN1Term  TRUE
	#define EXP_SysParameterSettings_SetCAN1Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetCAN1Term", (RTS_UINTPTR)SysParameterSettings_SetCAN1Term, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetCAN1Term
	#define EXT_SysParameterSettingsSysParameterSettings_SetCAN1Term
	#define GET_SysParameterSettingsSysParameterSettings_SetCAN1Term  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetCAN1Term pISysParameterSettings->ISysParameterSettings_SetCAN1Term
	#define CHK_SysParameterSettingsSysParameterSettings_SetCAN1Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetCAN1Term  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetCAN1Term
	#define EXT_SysParameterSettings_SetCAN1Term
	#define GET_SysParameterSettings_SetCAN1Term(fl)  CAL_CMGETAPI( "SysParameterSettings_SetCAN1Term" ) 
	#define CAL_SysParameterSettings_SetCAN1Term pISysParameterSettings->ISysParameterSettings_SetCAN1Term
	#define CHK_SysParameterSettings_SetCAN1Term (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetCAN1Term  CAL_CMEXPAPI( "SysParameterSettings_SetCAN1Term" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetCAN1Term  PFSYSPARAMETERSETTINGS_SETCAN1TERM pfSysParameterSettings_SetCAN1Term;
	#define EXT_SysParameterSettings_SetCAN1Term  extern PFSYSPARAMETERSETTINGS_SETCAN1TERM pfSysParameterSettings_SetCAN1Term;
	#define GET_SysParameterSettings_SetCAN1Term(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetCAN1Term", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetCAN1Term, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetCAN1Term  pfSysParameterSettings_SetCAN1Term
	#define CHK_SysParameterSettings_SetCAN1Term  (pfSysParameterSettings_SetCAN1Term != NULL)
	#define EXP_SysParameterSettings_SetCAN1Term  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetCAN1Term", (RTS_UINTPTR)SysParameterSettings_SetCAN1Term, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetSDEnable(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSDENABLE) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSDENABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetSDEnable
	#define EXT_SysParameterSettings_GetSDEnable
	#define GET_SysParameterSettings_GetSDEnable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetSDEnable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetSDEnable  FALSE
	#define EXP_SysParameterSettings_GetSDEnable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetSDEnable
	#define EXT_SysParameterSettings_GetSDEnable
	#define GET_SysParameterSettings_GetSDEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSDEnable" ) 
	#define CAL_SysParameterSettings_GetSDEnable  SysParameterSettings_GetSDEnable
	#define CHK_SysParameterSettings_GetSDEnable  TRUE
	#define EXP_SysParameterSettings_GetSDEnable  CAL_CMEXPAPI( "SysParameterSettings_GetSDEnable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetSDEnable
	#define EXT_SysParameterSettings_GetSDEnable
	#define GET_SysParameterSettings_GetSDEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSDEnable" ) 
	#define CAL_SysParameterSettings_GetSDEnable  SysParameterSettings_GetSDEnable
	#define CHK_SysParameterSettings_GetSDEnable  TRUE
	#define EXP_SysParameterSettings_GetSDEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSDEnable", (RTS_UINTPTR)SysParameterSettings_GetSDEnable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetSDEnable
	#define EXT_SysParameterSettingsSysParameterSettings_GetSDEnable
	#define GET_SysParameterSettingsSysParameterSettings_GetSDEnable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetSDEnable pISysParameterSettings->ISysParameterSettings_GetSDEnable
	#define CHK_SysParameterSettingsSysParameterSettings_GetSDEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetSDEnable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetSDEnable
	#define EXT_SysParameterSettings_GetSDEnable
	#define GET_SysParameterSettings_GetSDEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSDEnable" ) 
	#define CAL_SysParameterSettings_GetSDEnable pISysParameterSettings->ISysParameterSettings_GetSDEnable
	#define CHK_SysParameterSettings_GetSDEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetSDEnable  CAL_CMEXPAPI( "SysParameterSettings_GetSDEnable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetSDEnable  PFSYSPARAMETERSETTINGS_GETSDENABLE pfSysParameterSettings_GetSDEnable;
	#define EXT_SysParameterSettings_GetSDEnable  extern PFSYSPARAMETERSETTINGS_GETSDENABLE pfSysParameterSettings_GetSDEnable;
	#define GET_SysParameterSettings_GetSDEnable(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetSDEnable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetSDEnable, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetSDEnable  pfSysParameterSettings_GetSDEnable
	#define CHK_SysParameterSettings_GetSDEnable  (pfSysParameterSettings_GetSDEnable != NULL)
	#define EXP_SysParameterSettings_GetSDEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSDEnable", (RTS_UINTPTR)SysParameterSettings_GetSDEnable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetSDEnable(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETSDENABLE) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETSDENABLE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetSDEnable
	#define EXT_SysParameterSettings_SetSDEnable
	#define GET_SysParameterSettings_SetSDEnable(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetSDEnable(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetSDEnable  FALSE
	#define EXP_SysParameterSettings_SetSDEnable  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetSDEnable
	#define EXT_SysParameterSettings_SetSDEnable
	#define GET_SysParameterSettings_SetSDEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSDEnable" ) 
	#define CAL_SysParameterSettings_SetSDEnable  SysParameterSettings_SetSDEnable
	#define CHK_SysParameterSettings_SetSDEnable  TRUE
	#define EXP_SysParameterSettings_SetSDEnable  CAL_CMEXPAPI( "SysParameterSettings_SetSDEnable" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetSDEnable
	#define EXT_SysParameterSettings_SetSDEnable
	#define GET_SysParameterSettings_SetSDEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSDEnable" ) 
	#define CAL_SysParameterSettings_SetSDEnable  SysParameterSettings_SetSDEnable
	#define CHK_SysParameterSettings_SetSDEnable  TRUE
	#define EXP_SysParameterSettings_SetSDEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetSDEnable", (RTS_UINTPTR)SysParameterSettings_SetSDEnable, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetSDEnable
	#define EXT_SysParameterSettingsSysParameterSettings_SetSDEnable
	#define GET_SysParameterSettingsSysParameterSettings_SetSDEnable  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetSDEnable pISysParameterSettings->ISysParameterSettings_SetSDEnable
	#define CHK_SysParameterSettingsSysParameterSettings_SetSDEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetSDEnable  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetSDEnable
	#define EXT_SysParameterSettings_SetSDEnable
	#define GET_SysParameterSettings_SetSDEnable(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSDEnable" ) 
	#define CAL_SysParameterSettings_SetSDEnable pISysParameterSettings->ISysParameterSettings_SetSDEnable
	#define CHK_SysParameterSettings_SetSDEnable (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetSDEnable  CAL_CMEXPAPI( "SysParameterSettings_SetSDEnable" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetSDEnable  PFSYSPARAMETERSETTINGS_SETSDENABLE pfSysParameterSettings_SetSDEnable;
	#define EXT_SysParameterSettings_SetSDEnable  extern PFSYSPARAMETERSETTINGS_SETSDENABLE pfSysParameterSettings_SetSDEnable;
	#define GET_SysParameterSettings_SetSDEnable(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetSDEnable", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetSDEnable, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetSDEnable  pfSysParameterSettings_SetSDEnable
	#define CHK_SysParameterSettings_SetSDEnable  (pfSysParameterSettings_SetSDEnable != NULL)
	#define EXP_SysParameterSettings_SetSDEnable  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetSDEnable", (RTS_UINTPTR)SysParameterSettings_SetSDEnable, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetAccessPoint(RTS_I32 *pstatus);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETACCESSPOINT) (RTS_I32 *pstatus);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETACCESSPOINT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetAccessPoint
	#define EXT_SysParameterSettings_GetAccessPoint
	#define GET_SysParameterSettings_GetAccessPoint(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetAccessPoint(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetAccessPoint  FALSE
	#define EXP_SysParameterSettings_GetAccessPoint  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetAccessPoint
	#define EXT_SysParameterSettings_GetAccessPoint
	#define GET_SysParameterSettings_GetAccessPoint(fl)  CAL_CMGETAPI( "SysParameterSettings_GetAccessPoint" ) 
	#define CAL_SysParameterSettings_GetAccessPoint  SysParameterSettings_GetAccessPoint
	#define CHK_SysParameterSettings_GetAccessPoint  TRUE
	#define EXP_SysParameterSettings_GetAccessPoint  CAL_CMEXPAPI( "SysParameterSettings_GetAccessPoint" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetAccessPoint
	#define EXT_SysParameterSettings_GetAccessPoint
	#define GET_SysParameterSettings_GetAccessPoint(fl)  CAL_CMGETAPI( "SysParameterSettings_GetAccessPoint" ) 
	#define CAL_SysParameterSettings_GetAccessPoint  SysParameterSettings_GetAccessPoint
	#define CHK_SysParameterSettings_GetAccessPoint  TRUE
	#define EXP_SysParameterSettings_GetAccessPoint  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetAccessPoint", (RTS_UINTPTR)SysParameterSettings_GetAccessPoint, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetAccessPoint
	#define EXT_SysParameterSettingsSysParameterSettings_GetAccessPoint
	#define GET_SysParameterSettingsSysParameterSettings_GetAccessPoint  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetAccessPoint pISysParameterSettings->ISysParameterSettings_GetAccessPoint
	#define CHK_SysParameterSettingsSysParameterSettings_GetAccessPoint (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetAccessPoint  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetAccessPoint
	#define EXT_SysParameterSettings_GetAccessPoint
	#define GET_SysParameterSettings_GetAccessPoint(fl)  CAL_CMGETAPI( "SysParameterSettings_GetAccessPoint" ) 
	#define CAL_SysParameterSettings_GetAccessPoint pISysParameterSettings->ISysParameterSettings_GetAccessPoint
	#define CHK_SysParameterSettings_GetAccessPoint (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetAccessPoint  CAL_CMEXPAPI( "SysParameterSettings_GetAccessPoint" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetAccessPoint  PFSYSPARAMETERSETTINGS_GETACCESSPOINT pfSysParameterSettings_GetAccessPoint;
	#define EXT_SysParameterSettings_GetAccessPoint  extern PFSYSPARAMETERSETTINGS_GETACCESSPOINT pfSysParameterSettings_GetAccessPoint;
	#define GET_SysParameterSettings_GetAccessPoint(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetAccessPoint", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetAccessPoint, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetAccessPoint  pfSysParameterSettings_GetAccessPoint
	#define CHK_SysParameterSettings_GetAccessPoint  (pfSysParameterSettings_GetAccessPoint != NULL)
	#define EXP_SysParameterSettings_GetAccessPoint  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetAccessPoint", (RTS_UINTPTR)SysParameterSettings_GetAccessPoint, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetAccessPoint(RTS_I32 status);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETACCESSPOINT) (RTS_I32 status);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETACCESSPOINT_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetAccessPoint
	#define EXT_SysParameterSettings_SetAccessPoint
	#define GET_SysParameterSettings_SetAccessPoint(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetAccessPoint(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetAccessPoint  FALSE
	#define EXP_SysParameterSettings_SetAccessPoint  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetAccessPoint
	#define EXT_SysParameterSettings_SetAccessPoint
	#define GET_SysParameterSettings_SetAccessPoint(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAccessPoint" ) 
	#define CAL_SysParameterSettings_SetAccessPoint  SysParameterSettings_SetAccessPoint
	#define CHK_SysParameterSettings_SetAccessPoint  TRUE
	#define EXP_SysParameterSettings_SetAccessPoint  CAL_CMEXPAPI( "SysParameterSettings_SetAccessPoint" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetAccessPoint
	#define EXT_SysParameterSettings_SetAccessPoint
	#define GET_SysParameterSettings_SetAccessPoint(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAccessPoint" ) 
	#define CAL_SysParameterSettings_SetAccessPoint  SysParameterSettings_SetAccessPoint
	#define CHK_SysParameterSettings_SetAccessPoint  TRUE
	#define EXP_SysParameterSettings_SetAccessPoint  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAccessPoint", (RTS_UINTPTR)SysParameterSettings_SetAccessPoint, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetAccessPoint
	#define EXT_SysParameterSettingsSysParameterSettings_SetAccessPoint
	#define GET_SysParameterSettingsSysParameterSettings_SetAccessPoint  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetAccessPoint pISysParameterSettings->ISysParameterSettings_SetAccessPoint
	#define CHK_SysParameterSettingsSysParameterSettings_SetAccessPoint (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetAccessPoint  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetAccessPoint
	#define EXT_SysParameterSettings_SetAccessPoint
	#define GET_SysParameterSettings_SetAccessPoint(fl)  CAL_CMGETAPI( "SysParameterSettings_SetAccessPoint" ) 
	#define CAL_SysParameterSettings_SetAccessPoint pISysParameterSettings->ISysParameterSettings_SetAccessPoint
	#define CHK_SysParameterSettings_SetAccessPoint (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetAccessPoint  CAL_CMEXPAPI( "SysParameterSettings_SetAccessPoint" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetAccessPoint  PFSYSPARAMETERSETTINGS_SETACCESSPOINT pfSysParameterSettings_SetAccessPoint;
	#define EXT_SysParameterSettings_SetAccessPoint  extern PFSYSPARAMETERSETTINGS_SETACCESSPOINT pfSysParameterSettings_SetAccessPoint;
	#define GET_SysParameterSettings_SetAccessPoint(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetAccessPoint", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetAccessPoint, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetAccessPoint  pfSysParameterSettings_SetAccessPoint
	#define CHK_SysParameterSettings_SetAccessPoint  (pfSysParameterSettings_SetAccessPoint != NULL)
	#define EXP_SysParameterSettings_SetAccessPoint  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetAccessPoint", (RTS_UINTPTR)SysParameterSettings_SetAccessPoint, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetSSID(char * pszName, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETSSID) (char * pszName, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETSSID_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetSSID
	#define EXT_SysParameterSettings_GetSSID
	#define GET_SysParameterSettings_GetSSID(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetSSID(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetSSID  FALSE
	#define EXP_SysParameterSettings_GetSSID  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetSSID
	#define EXT_SysParameterSettings_GetSSID
	#define GET_SysParameterSettings_GetSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSSID" ) 
	#define CAL_SysParameterSettings_GetSSID  SysParameterSettings_GetSSID
	#define CHK_SysParameterSettings_GetSSID  TRUE
	#define EXP_SysParameterSettings_GetSSID  CAL_CMEXPAPI( "SysParameterSettings_GetSSID" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetSSID
	#define EXT_SysParameterSettings_GetSSID
	#define GET_SysParameterSettings_GetSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSSID" ) 
	#define CAL_SysParameterSettings_GetSSID  SysParameterSettings_GetSSID
	#define CHK_SysParameterSettings_GetSSID  TRUE
	#define EXP_SysParameterSettings_GetSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSSID", (RTS_UINTPTR)SysParameterSettings_GetSSID, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetSSID
	#define EXT_SysParameterSettingsSysParameterSettings_GetSSID
	#define GET_SysParameterSettingsSysParameterSettings_GetSSID  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetSSID pISysParameterSettings->ISysParameterSettings_GetSSID
	#define CHK_SysParameterSettingsSysParameterSettings_GetSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetSSID  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetSSID
	#define EXT_SysParameterSettings_GetSSID
	#define GET_SysParameterSettings_GetSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_GetSSID" ) 
	#define CAL_SysParameterSettings_GetSSID pISysParameterSettings->ISysParameterSettings_GetSSID
	#define CHK_SysParameterSettings_GetSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetSSID  CAL_CMEXPAPI( "SysParameterSettings_GetSSID" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetSSID  PFSYSPARAMETERSETTINGS_GETSSID pfSysParameterSettings_GetSSID;
	#define EXT_SysParameterSettings_GetSSID  extern PFSYSPARAMETERSETTINGS_GETSSID pfSysParameterSettings_GetSSID;
	#define GET_SysParameterSettings_GetSSID(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetSSID", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetSSID, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetSSID  pfSysParameterSettings_GetSSID
	#define CHK_SysParameterSettings_GetSSID  (pfSysParameterSettings_GetSSID != NULL)
	#define EXP_SysParameterSettings_GetSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetSSID", (RTS_UINTPTR)SysParameterSettings_GetSSID, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetSSID(char * pszName);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETSSID) (char * pszName);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETSSID_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetSSID
	#define EXT_SysParameterSettings_SetSSID
	#define GET_SysParameterSettings_SetSSID(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetSSID(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetSSID  FALSE
	#define EXP_SysParameterSettings_SetSSID  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetSSID
	#define EXT_SysParameterSettings_SetSSID
	#define GET_SysParameterSettings_SetSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSSID" ) 
	#define CAL_SysParameterSettings_SetSSID  SysParameterSettings_SetSSID
	#define CHK_SysParameterSettings_SetSSID  TRUE
	#define EXP_SysParameterSettings_SetSSID  CAL_CMEXPAPI( "SysParameterSettings_SetSSID" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetSSID
	#define EXT_SysParameterSettings_SetSSID
	#define GET_SysParameterSettings_SetSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSSID" ) 
	#define CAL_SysParameterSettings_SetSSID  SysParameterSettings_SetSSID
	#define CHK_SysParameterSettings_SetSSID  TRUE
	#define EXP_SysParameterSettings_SetSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetSSID", (RTS_UINTPTR)SysParameterSettings_SetSSID, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetSSID
	#define EXT_SysParameterSettingsSysParameterSettings_SetSSID
	#define GET_SysParameterSettingsSysParameterSettings_SetSSID  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetSSID pISysParameterSettings->ISysParameterSettings_SetSSID
	#define CHK_SysParameterSettingsSysParameterSettings_SetSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetSSID  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetSSID
	#define EXT_SysParameterSettings_SetSSID
	#define GET_SysParameterSettings_SetSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_SetSSID" ) 
	#define CAL_SysParameterSettings_SetSSID pISysParameterSettings->ISysParameterSettings_SetSSID
	#define CHK_SysParameterSettings_SetSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetSSID  CAL_CMEXPAPI( "SysParameterSettings_SetSSID" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetSSID  PFSYSPARAMETERSETTINGS_SETSSID pfSysParameterSettings_SetSSID;
	#define EXT_SysParameterSettings_SetSSID  extern PFSYSPARAMETERSETTINGS_SETSSID pfSysParameterSettings_SetSSID;
	#define GET_SysParameterSettings_SetSSID(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetSSID", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetSSID, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetSSID  pfSysParameterSettings_SetSSID
	#define CHK_SysParameterSettings_SetSSID  (pfSysParameterSettings_SetSSID != NULL)
	#define EXP_SysParameterSettings_SetSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetSSID", (RTS_UINTPTR)SysParameterSettings_SetSSID, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANAPChannel(RTS_UI8* pChannel);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANAPCHANNEL) (RTS_UI8* pChannel);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANAPCHANNEL_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANAPChannel
	#define EXT_SysParameterSettings_GetWLANAPChannel
	#define GET_SysParameterSettings_GetWLANAPChannel(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANAPChannel(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANAPChannel  FALSE
	#define EXP_SysParameterSettings_GetWLANAPChannel  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANAPChannel
	#define EXT_SysParameterSettings_GetWLANAPChannel
	#define GET_SysParameterSettings_GetWLANAPChannel(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPChannel" ) 
	#define CAL_SysParameterSettings_GetWLANAPChannel  SysParameterSettings_GetWLANAPChannel
	#define CHK_SysParameterSettings_GetWLANAPChannel  TRUE
	#define EXP_SysParameterSettings_GetWLANAPChannel  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPChannel" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANAPChannel
	#define EXT_SysParameterSettings_GetWLANAPChannel
	#define GET_SysParameterSettings_GetWLANAPChannel(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPChannel" ) 
	#define CAL_SysParameterSettings_GetWLANAPChannel  SysParameterSettings_GetWLANAPChannel
	#define CHK_SysParameterSettings_GetWLANAPChannel  TRUE
	#define EXP_SysParameterSettings_GetWLANAPChannel  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPChannel", (RTS_UINTPTR)SysParameterSettings_GetWLANAPChannel, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANAPChannel
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANAPChannel
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANAPChannel  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANAPChannel pISysParameterSettings->ISysParameterSettings_GetWLANAPChannel
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANAPChannel (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANAPChannel  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANAPChannel
	#define EXT_SysParameterSettings_GetWLANAPChannel
	#define GET_SysParameterSettings_GetWLANAPChannel(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPChannel" ) 
	#define CAL_SysParameterSettings_GetWLANAPChannel pISysParameterSettings->ISysParameterSettings_GetWLANAPChannel
	#define CHK_SysParameterSettings_GetWLANAPChannel (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANAPChannel  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPChannel" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANAPChannel  PFSYSPARAMETERSETTINGS_GETWLANAPCHANNEL pfSysParameterSettings_GetWLANAPChannel;
	#define EXT_SysParameterSettings_GetWLANAPChannel  extern PFSYSPARAMETERSETTINGS_GETWLANAPCHANNEL pfSysParameterSettings_GetWLANAPChannel;
	#define GET_SysParameterSettings_GetWLANAPChannel(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANAPChannel", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANAPChannel, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANAPChannel  pfSysParameterSettings_GetWLANAPChannel
	#define CHK_SysParameterSettings_GetWLANAPChannel  (pfSysParameterSettings_GetWLANAPChannel != NULL)
	#define EXP_SysParameterSettings_GetWLANAPChannel  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPChannel", (RTS_UINTPTR)SysParameterSettings_GetWLANAPChannel, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWLANAPChannel(RTS_UI8 nChannel);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWLANAPCHANNEL) (RTS_UI8 nChannel);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWLANAPCHANNEL_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWLANAPChannel
	#define EXT_SysParameterSettings_SetWLANAPChannel
	#define GET_SysParameterSettings_SetWLANAPChannel(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWLANAPChannel(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWLANAPChannel  FALSE
	#define EXP_SysParameterSettings_SetWLANAPChannel  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWLANAPChannel
	#define EXT_SysParameterSettings_SetWLANAPChannel
	#define GET_SysParameterSettings_SetWLANAPChannel(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANAPChannel" ) 
	#define CAL_SysParameterSettings_SetWLANAPChannel  SysParameterSettings_SetWLANAPChannel
	#define CHK_SysParameterSettings_SetWLANAPChannel  TRUE
	#define EXP_SysParameterSettings_SetWLANAPChannel  CAL_CMEXPAPI( "SysParameterSettings_SetWLANAPChannel" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWLANAPChannel
	#define EXT_SysParameterSettings_SetWLANAPChannel
	#define GET_SysParameterSettings_SetWLANAPChannel(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANAPChannel" ) 
	#define CAL_SysParameterSettings_SetWLANAPChannel  SysParameterSettings_SetWLANAPChannel
	#define CHK_SysParameterSettings_SetWLANAPChannel  TRUE
	#define EXP_SysParameterSettings_SetWLANAPChannel  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWLANAPChannel", (RTS_UINTPTR)SysParameterSettings_SetWLANAPChannel, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWLANAPChannel
	#define EXT_SysParameterSettingsSysParameterSettings_SetWLANAPChannel
	#define GET_SysParameterSettingsSysParameterSettings_SetWLANAPChannel  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWLANAPChannel pISysParameterSettings->ISysParameterSettings_SetWLANAPChannel
	#define CHK_SysParameterSettingsSysParameterSettings_SetWLANAPChannel (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWLANAPChannel  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWLANAPChannel
	#define EXT_SysParameterSettings_SetWLANAPChannel
	#define GET_SysParameterSettings_SetWLANAPChannel(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANAPChannel" ) 
	#define CAL_SysParameterSettings_SetWLANAPChannel pISysParameterSettings->ISysParameterSettings_SetWLANAPChannel
	#define CHK_SysParameterSettings_SetWLANAPChannel (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWLANAPChannel  CAL_CMEXPAPI( "SysParameterSettings_SetWLANAPChannel" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWLANAPChannel  PFSYSPARAMETERSETTINGS_SETWLANAPCHANNEL pfSysParameterSettings_SetWLANAPChannel;
	#define EXT_SysParameterSettings_SetWLANAPChannel  extern PFSYSPARAMETERSETTINGS_SETWLANAPCHANNEL pfSysParameterSettings_SetWLANAPChannel;
	#define GET_SysParameterSettings_SetWLANAPChannel(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWLANAPChannel", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWLANAPChannel, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWLANAPChannel  pfSysParameterSettings_SetWLANAPChannel
	#define CHK_SysParameterSettings_SetWLANAPChannel  (pfSysParameterSettings_SetWLANAPChannel != NULL)
	#define EXP_SysParameterSettings_SetWLANAPChannel  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWLANAPChannel", (RTS_UINTPTR)SysParameterSettings_SetWLANAPChannel, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANAPAuthType(RTS_UI8* pAuthType);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANAPAUTHTYPE) (RTS_UI8* pAuthType);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANAPAUTHTYPE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANAPAuthType
	#define EXT_SysParameterSettings_GetWLANAPAuthType
	#define GET_SysParameterSettings_GetWLANAPAuthType(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANAPAuthType(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANAPAuthType  FALSE
	#define EXP_SysParameterSettings_GetWLANAPAuthType  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANAPAuthType
	#define EXT_SysParameterSettings_GetWLANAPAuthType
	#define GET_SysParameterSettings_GetWLANAPAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPAuthType" ) 
	#define CAL_SysParameterSettings_GetWLANAPAuthType  SysParameterSettings_GetWLANAPAuthType
	#define CHK_SysParameterSettings_GetWLANAPAuthType  TRUE
	#define EXP_SysParameterSettings_GetWLANAPAuthType  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPAuthType" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANAPAuthType
	#define EXT_SysParameterSettings_GetWLANAPAuthType
	#define GET_SysParameterSettings_GetWLANAPAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPAuthType" ) 
	#define CAL_SysParameterSettings_GetWLANAPAuthType  SysParameterSettings_GetWLANAPAuthType
	#define CHK_SysParameterSettings_GetWLANAPAuthType  TRUE
	#define EXP_SysParameterSettings_GetWLANAPAuthType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPAuthType", (RTS_UINTPTR)SysParameterSettings_GetWLANAPAuthType, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANAPAuthType
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANAPAuthType
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANAPAuthType  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANAPAuthType pISysParameterSettings->ISysParameterSettings_GetWLANAPAuthType
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANAPAuthType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANAPAuthType  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANAPAuthType
	#define EXT_SysParameterSettings_GetWLANAPAuthType
	#define GET_SysParameterSettings_GetWLANAPAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPAuthType" ) 
	#define CAL_SysParameterSettings_GetWLANAPAuthType pISysParameterSettings->ISysParameterSettings_GetWLANAPAuthType
	#define CHK_SysParameterSettings_GetWLANAPAuthType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANAPAuthType  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPAuthType" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANAPAuthType  PFSYSPARAMETERSETTINGS_GETWLANAPAUTHTYPE pfSysParameterSettings_GetWLANAPAuthType;
	#define EXT_SysParameterSettings_GetWLANAPAuthType  extern PFSYSPARAMETERSETTINGS_GETWLANAPAUTHTYPE pfSysParameterSettings_GetWLANAPAuthType;
	#define GET_SysParameterSettings_GetWLANAPAuthType(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANAPAuthType", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANAPAuthType, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANAPAuthType  pfSysParameterSettings_GetWLANAPAuthType
	#define CHK_SysParameterSettings_GetWLANAPAuthType  (pfSysParameterSettings_GetWLANAPAuthType != NULL)
	#define EXP_SysParameterSettings_GetWLANAPAuthType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPAuthType", (RTS_UINTPTR)SysParameterSettings_GetWLANAPAuthType, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANAPWPAType(RTS_UI8* pWPAType);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANAPWPATYPE) (RTS_UI8* pWPAType);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANAPWPATYPE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANAPWPAType
	#define EXT_SysParameterSettings_GetWLANAPWPAType
	#define GET_SysParameterSettings_GetWLANAPWPAType(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANAPWPAType(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANAPWPAType  FALSE
	#define EXP_SysParameterSettings_GetWLANAPWPAType  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANAPWPAType
	#define EXT_SysParameterSettings_GetWLANAPWPAType
	#define GET_SysParameterSettings_GetWLANAPWPAType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPWPAType" ) 
	#define CAL_SysParameterSettings_GetWLANAPWPAType  SysParameterSettings_GetWLANAPWPAType
	#define CHK_SysParameterSettings_GetWLANAPWPAType  TRUE
	#define EXP_SysParameterSettings_GetWLANAPWPAType  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPWPAType" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANAPWPAType
	#define EXT_SysParameterSettings_GetWLANAPWPAType
	#define GET_SysParameterSettings_GetWLANAPWPAType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPWPAType" ) 
	#define CAL_SysParameterSettings_GetWLANAPWPAType  SysParameterSettings_GetWLANAPWPAType
	#define CHK_SysParameterSettings_GetWLANAPWPAType  TRUE
	#define EXP_SysParameterSettings_GetWLANAPWPAType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPWPAType", (RTS_UINTPTR)SysParameterSettings_GetWLANAPWPAType, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANAPWPAType
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANAPWPAType
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANAPWPAType  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANAPWPAType pISysParameterSettings->ISysParameterSettings_GetWLANAPWPAType
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANAPWPAType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANAPWPAType  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANAPWPAType
	#define EXT_SysParameterSettings_GetWLANAPWPAType
	#define GET_SysParameterSettings_GetWLANAPWPAType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPWPAType" ) 
	#define CAL_SysParameterSettings_GetWLANAPWPAType pISysParameterSettings->ISysParameterSettings_GetWLANAPWPAType
	#define CHK_SysParameterSettings_GetWLANAPWPAType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANAPWPAType  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPWPAType" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANAPWPAType  PFSYSPARAMETERSETTINGS_GETWLANAPWPATYPE pfSysParameterSettings_GetWLANAPWPAType;
	#define EXT_SysParameterSettings_GetWLANAPWPAType  extern PFSYSPARAMETERSETTINGS_GETWLANAPWPATYPE pfSysParameterSettings_GetWLANAPWPAType;
	#define GET_SysParameterSettings_GetWLANAPWPAType(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANAPWPAType", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANAPWPAType, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANAPWPAType  pfSysParameterSettings_GetWLANAPWPAType
	#define CHK_SysParameterSettings_GetWLANAPWPAType  (pfSysParameterSettings_GetWLANAPWPAType != NULL)
	#define EXP_SysParameterSettings_GetWLANAPWPAType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPWPAType", (RTS_UINTPTR)SysParameterSettings_GetWLANAPWPAType, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANAPHWMode(char * pszName, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANAPHWMODE) (char * pszName, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANAPHWMODE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANAPHWMode
	#define EXT_SysParameterSettings_GetWLANAPHWMode
	#define GET_SysParameterSettings_GetWLANAPHWMode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANAPHWMode(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANAPHWMode  FALSE
	#define EXP_SysParameterSettings_GetWLANAPHWMode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANAPHWMode
	#define EXT_SysParameterSettings_GetWLANAPHWMode
	#define GET_SysParameterSettings_GetWLANAPHWMode(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPHWMode" ) 
	#define CAL_SysParameterSettings_GetWLANAPHWMode  SysParameterSettings_GetWLANAPHWMode
	#define CHK_SysParameterSettings_GetWLANAPHWMode  TRUE
	#define EXP_SysParameterSettings_GetWLANAPHWMode  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPHWMode" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANAPHWMode
	#define EXT_SysParameterSettings_GetWLANAPHWMode
	#define GET_SysParameterSettings_GetWLANAPHWMode(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPHWMode" ) 
	#define CAL_SysParameterSettings_GetWLANAPHWMode  SysParameterSettings_GetWLANAPHWMode
	#define CHK_SysParameterSettings_GetWLANAPHWMode  TRUE
	#define EXP_SysParameterSettings_GetWLANAPHWMode  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPHWMode", (RTS_UINTPTR)SysParameterSettings_GetWLANAPHWMode, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANAPHWMode
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANAPHWMode
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANAPHWMode  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANAPHWMode pISysParameterSettings->ISysParameterSettings_GetWLANAPHWMode
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANAPHWMode (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANAPHWMode  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANAPHWMode
	#define EXT_SysParameterSettings_GetWLANAPHWMode
	#define GET_SysParameterSettings_GetWLANAPHWMode(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANAPHWMode" ) 
	#define CAL_SysParameterSettings_GetWLANAPHWMode pISysParameterSettings->ISysParameterSettings_GetWLANAPHWMode
	#define CHK_SysParameterSettings_GetWLANAPHWMode (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANAPHWMode  CAL_CMEXPAPI( "SysParameterSettings_GetWLANAPHWMode" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANAPHWMode  PFSYSPARAMETERSETTINGS_GETWLANAPHWMODE pfSysParameterSettings_GetWLANAPHWMode;
	#define EXT_SysParameterSettings_GetWLANAPHWMode  extern PFSYSPARAMETERSETTINGS_GETWLANAPHWMODE pfSysParameterSettings_GetWLANAPHWMode;
	#define GET_SysParameterSettings_GetWLANAPHWMode(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANAPHWMode", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANAPHWMode, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANAPHWMode  pfSysParameterSettings_GetWLANAPHWMode
	#define CHK_SysParameterSettings_GetWLANAPHWMode  (pfSysParameterSettings_GetWLANAPHWMode != NULL)
	#define EXP_SysParameterSettings_GetWLANAPHWMode  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANAPHWMode", (RTS_UINTPTR)SysParameterSettings_GetWLANAPHWMode, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_WLANRestart();
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_WLANRESTART) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_WLANRESTART_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_WLANRestart
	#define EXT_SysParameterSettings_WLANRestart
	#define GET_SysParameterSettings_WLANRestart(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_WLANRestart()  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_WLANRestart  FALSE
	#define EXP_SysParameterSettings_WLANRestart  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_WLANRestart
	#define EXT_SysParameterSettings_WLANRestart
	#define GET_SysParameterSettings_WLANRestart(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANRestart" ) 
	#define CAL_SysParameterSettings_WLANRestart  SysParameterSettings_WLANRestart
	#define CHK_SysParameterSettings_WLANRestart  TRUE
	#define EXP_SysParameterSettings_WLANRestart  CAL_CMEXPAPI( "SysParameterSettings_WLANRestart" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_WLANRestart
	#define EXT_SysParameterSettings_WLANRestart
	#define GET_SysParameterSettings_WLANRestart(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANRestart" ) 
	#define CAL_SysParameterSettings_WLANRestart  SysParameterSettings_WLANRestart
	#define CHK_SysParameterSettings_WLANRestart  TRUE
	#define EXP_SysParameterSettings_WLANRestart  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANRestart", (RTS_UINTPTR)SysParameterSettings_WLANRestart, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_WLANRestart
	#define EXT_SysParameterSettingsSysParameterSettings_WLANRestart
	#define GET_SysParameterSettingsSysParameterSettings_WLANRestart  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_WLANRestart pISysParameterSettings->ISysParameterSettings_WLANRestart
	#define CHK_SysParameterSettingsSysParameterSettings_WLANRestart (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_WLANRestart  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_WLANRestart
	#define EXT_SysParameterSettings_WLANRestart
	#define GET_SysParameterSettings_WLANRestart(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANRestart" ) 
	#define CAL_SysParameterSettings_WLANRestart pISysParameterSettings->ISysParameterSettings_WLANRestart
	#define CHK_SysParameterSettings_WLANRestart (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_WLANRestart  CAL_CMEXPAPI( "SysParameterSettings_WLANRestart" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_WLANRestart  PFSYSPARAMETERSETTINGS_WLANRESTART pfSysParameterSettings_WLANRestart;
	#define EXT_SysParameterSettings_WLANRestart  extern PFSYSPARAMETERSETTINGS_WLANRESTART pfSysParameterSettings_WLANRestart;
	#define GET_SysParameterSettings_WLANRestart(fl)  s_pfCMGetAPI2( "SysParameterSettings_WLANRestart", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_WLANRestart, (fl), 0, 0)
	#define CAL_SysParameterSettings_WLANRestart  pfSysParameterSettings_WLANRestart
	#define CHK_SysParameterSettings_WLANRestart  (pfSysParameterSettings_WLANRestart != NULL)
	#define EXP_SysParameterSettings_WLANRestart  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANRestart", (RTS_UINTPTR)SysParameterSettings_WLANRestart, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_WLANWPAChangePasswd(char * pszPwd);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_WLANWPACHANGEPASSWD) (char * pszPwd);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_WLANWPACHANGEPASSWD_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_WLANWPAChangePasswd
	#define EXT_SysParameterSettings_WLANWPAChangePasswd
	#define GET_SysParameterSettings_WLANWPAChangePasswd(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_WLANWPAChangePasswd(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_WLANWPAChangePasswd  FALSE
	#define EXP_SysParameterSettings_WLANWPAChangePasswd  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_WLANWPAChangePasswd
	#define EXT_SysParameterSettings_WLANWPAChangePasswd
	#define GET_SysParameterSettings_WLANWPAChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANWPAChangePasswd" ) 
	#define CAL_SysParameterSettings_WLANWPAChangePasswd  SysParameterSettings_WLANWPAChangePasswd
	#define CHK_SysParameterSettings_WLANWPAChangePasswd  TRUE
	#define EXP_SysParameterSettings_WLANWPAChangePasswd  CAL_CMEXPAPI( "SysParameterSettings_WLANWPAChangePasswd" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_WLANWPAChangePasswd
	#define EXT_SysParameterSettings_WLANWPAChangePasswd
	#define GET_SysParameterSettings_WLANWPAChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANWPAChangePasswd" ) 
	#define CAL_SysParameterSettings_WLANWPAChangePasswd  SysParameterSettings_WLANWPAChangePasswd
	#define CHK_SysParameterSettings_WLANWPAChangePasswd  TRUE
	#define EXP_SysParameterSettings_WLANWPAChangePasswd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANWPAChangePasswd", (RTS_UINTPTR)SysParameterSettings_WLANWPAChangePasswd, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_WLANWPAChangePasswd
	#define EXT_SysParameterSettingsSysParameterSettings_WLANWPAChangePasswd
	#define GET_SysParameterSettingsSysParameterSettings_WLANWPAChangePasswd  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_WLANWPAChangePasswd pISysParameterSettings->ISysParameterSettings_WLANWPAChangePasswd
	#define CHK_SysParameterSettingsSysParameterSettings_WLANWPAChangePasswd (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_WLANWPAChangePasswd  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_WLANWPAChangePasswd
	#define EXT_SysParameterSettings_WLANWPAChangePasswd
	#define GET_SysParameterSettings_WLANWPAChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANWPAChangePasswd" ) 
	#define CAL_SysParameterSettings_WLANWPAChangePasswd pISysParameterSettings->ISysParameterSettings_WLANWPAChangePasswd
	#define CHK_SysParameterSettings_WLANWPAChangePasswd (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_WLANWPAChangePasswd  CAL_CMEXPAPI( "SysParameterSettings_WLANWPAChangePasswd" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_WLANWPAChangePasswd  PFSYSPARAMETERSETTINGS_WLANWPACHANGEPASSWD pfSysParameterSettings_WLANWPAChangePasswd;
	#define EXT_SysParameterSettings_WLANWPAChangePasswd  extern PFSYSPARAMETERSETTINGS_WLANWPACHANGEPASSWD pfSysParameterSettings_WLANWPAChangePasswd;
	#define GET_SysParameterSettings_WLANWPAChangePasswd(fl)  s_pfCMGetAPI2( "SysParameterSettings_WLANWPAChangePasswd", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_WLANWPAChangePasswd, (fl), 0, 0)
	#define CAL_SysParameterSettings_WLANWPAChangePasswd  pfSysParameterSettings_WLANWPAChangePasswd
	#define CHK_SysParameterSettings_WLANWPAChangePasswd  (pfSysParameterSettings_WLANWPAChangePasswd != NULL)
	#define EXP_SysParameterSettings_WLANWPAChangePasswd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANWPAChangePasswd", (RTS_UINTPTR)SysParameterSettings_WLANWPAChangePasswd, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_WLANScan(char * sWLANInterface, dynamic_list* pOutput);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_WLANSCAN) (char * sWLANInterface, dynamic_list* pOutput);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_WLANSCAN_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_WLANScan
	#define EXT_SysParameterSettings_WLANScan
	#define GET_SysParameterSettings_WLANScan(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_WLANScan(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_WLANScan  FALSE
	#define EXP_SysParameterSettings_WLANScan  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_WLANScan
	#define EXT_SysParameterSettings_WLANScan
	#define GET_SysParameterSettings_WLANScan(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANScan" ) 
	#define CAL_SysParameterSettings_WLANScan  SysParameterSettings_WLANScan
	#define CHK_SysParameterSettings_WLANScan  TRUE
	#define EXP_SysParameterSettings_WLANScan  CAL_CMEXPAPI( "SysParameterSettings_WLANScan" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_WLANScan
	#define EXT_SysParameterSettings_WLANScan
	#define GET_SysParameterSettings_WLANScan(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANScan" ) 
	#define CAL_SysParameterSettings_WLANScan  SysParameterSettings_WLANScan
	#define CHK_SysParameterSettings_WLANScan  TRUE
	#define EXP_SysParameterSettings_WLANScan  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANScan", (RTS_UINTPTR)SysParameterSettings_WLANScan, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_WLANScan
	#define EXT_SysParameterSettingsSysParameterSettings_WLANScan
	#define GET_SysParameterSettingsSysParameterSettings_WLANScan  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_WLANScan pISysParameterSettings->ISysParameterSettings_WLANScan
	#define CHK_SysParameterSettingsSysParameterSettings_WLANScan (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_WLANScan  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_WLANScan
	#define EXT_SysParameterSettings_WLANScan
	#define GET_SysParameterSettings_WLANScan(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANScan" ) 
	#define CAL_SysParameterSettings_WLANScan pISysParameterSettings->ISysParameterSettings_WLANScan
	#define CHK_SysParameterSettings_WLANScan (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_WLANScan  CAL_CMEXPAPI( "SysParameterSettings_WLANScan" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_WLANScan  PFSYSPARAMETERSETTINGS_WLANSCAN pfSysParameterSettings_WLANScan;
	#define EXT_SysParameterSettings_WLANScan  extern PFSYSPARAMETERSETTINGS_WLANSCAN pfSysParameterSettings_WLANScan;
	#define GET_SysParameterSettings_WLANScan(fl)  s_pfCMGetAPI2( "SysParameterSettings_WLANScan", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_WLANScan, (fl), 0, 0)
	#define CAL_SysParameterSettings_WLANScan  pfSysParameterSettings_WLANScan
	#define CHK_SysParameterSettings_WLANScan  (pfSysParameterSettings_WLANScan != NULL)
	#define EXP_SysParameterSettings_WLANScan  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANScan", (RTS_UINTPTR)SysParameterSettings_WLANScan, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_WLANConnectToAP(char* sInterface, char * sSSID, char* pszPwd, char* sAuthType);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_WLANCONNECTTOAP) (char* sInterface, char * sSSID, char* pszPwd, char* sAuthType);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_WLANCONNECTTOAP_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_WLANConnectToAP
	#define EXT_SysParameterSettings_WLANConnectToAP
	#define GET_SysParameterSettings_WLANConnectToAP(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_WLANConnectToAP(p0,p1,p2,p3)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_WLANConnectToAP  FALSE
	#define EXP_SysParameterSettings_WLANConnectToAP  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_WLANConnectToAP
	#define EXT_SysParameterSettings_WLANConnectToAP
	#define GET_SysParameterSettings_WLANConnectToAP(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANConnectToAP" ) 
	#define CAL_SysParameterSettings_WLANConnectToAP  SysParameterSettings_WLANConnectToAP
	#define CHK_SysParameterSettings_WLANConnectToAP  TRUE
	#define EXP_SysParameterSettings_WLANConnectToAP  CAL_CMEXPAPI( "SysParameterSettings_WLANConnectToAP" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_WLANConnectToAP
	#define EXT_SysParameterSettings_WLANConnectToAP
	#define GET_SysParameterSettings_WLANConnectToAP(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANConnectToAP" ) 
	#define CAL_SysParameterSettings_WLANConnectToAP  SysParameterSettings_WLANConnectToAP
	#define CHK_SysParameterSettings_WLANConnectToAP  TRUE
	#define EXP_SysParameterSettings_WLANConnectToAP  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANConnectToAP", (RTS_UINTPTR)SysParameterSettings_WLANConnectToAP, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_WLANConnectToAP
	#define EXT_SysParameterSettingsSysParameterSettings_WLANConnectToAP
	#define GET_SysParameterSettingsSysParameterSettings_WLANConnectToAP  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_WLANConnectToAP pISysParameterSettings->ISysParameterSettings_WLANConnectToAP
	#define CHK_SysParameterSettingsSysParameterSettings_WLANConnectToAP (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_WLANConnectToAP  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_WLANConnectToAP
	#define EXT_SysParameterSettings_WLANConnectToAP
	#define GET_SysParameterSettings_WLANConnectToAP(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANConnectToAP" ) 
	#define CAL_SysParameterSettings_WLANConnectToAP pISysParameterSettings->ISysParameterSettings_WLANConnectToAP
	#define CHK_SysParameterSettings_WLANConnectToAP (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_WLANConnectToAP  CAL_CMEXPAPI( "SysParameterSettings_WLANConnectToAP" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_WLANConnectToAP  PFSYSPARAMETERSETTINGS_WLANCONNECTTOAP pfSysParameterSettings_WLANConnectToAP;
	#define EXT_SysParameterSettings_WLANConnectToAP  extern PFSYSPARAMETERSETTINGS_WLANCONNECTTOAP pfSysParameterSettings_WLANConnectToAP;
	#define GET_SysParameterSettings_WLANConnectToAP(fl)  s_pfCMGetAPI2( "SysParameterSettings_WLANConnectToAP", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_WLANConnectToAP, (fl), 0, 0)
	#define CAL_SysParameterSettings_WLANConnectToAP  pfSysParameterSettings_WLANConnectToAP
	#define CHK_SysParameterSettings_WLANConnectToAP  (pfSysParameterSettings_WLANConnectToAP != NULL)
	#define EXP_SysParameterSettings_WLANConnectToAP  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANConnectToAP", (RTS_UINTPTR)SysParameterSettings_WLANConnectToAP, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANClientSSID(char * pszName, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANCLIENTSSID) (char * pszName, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANCLIENTSSID_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANClientSSID
	#define EXT_SysParameterSettings_GetWLANClientSSID
	#define GET_SysParameterSettings_GetWLANClientSSID(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANClientSSID(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANClientSSID  FALSE
	#define EXP_SysParameterSettings_GetWLANClientSSID  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANClientSSID
	#define EXT_SysParameterSettings_GetWLANClientSSID
	#define GET_SysParameterSettings_GetWLANClientSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANClientSSID" ) 
	#define CAL_SysParameterSettings_GetWLANClientSSID  SysParameterSettings_GetWLANClientSSID
	#define CHK_SysParameterSettings_GetWLANClientSSID  TRUE
	#define EXP_SysParameterSettings_GetWLANClientSSID  CAL_CMEXPAPI( "SysParameterSettings_GetWLANClientSSID" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANClientSSID
	#define EXT_SysParameterSettings_GetWLANClientSSID
	#define GET_SysParameterSettings_GetWLANClientSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANClientSSID" ) 
	#define CAL_SysParameterSettings_GetWLANClientSSID  SysParameterSettings_GetWLANClientSSID
	#define CHK_SysParameterSettings_GetWLANClientSSID  TRUE
	#define EXP_SysParameterSettings_GetWLANClientSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANClientSSID", (RTS_UINTPTR)SysParameterSettings_GetWLANClientSSID, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANClientSSID
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANClientSSID
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANClientSSID  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANClientSSID pISysParameterSettings->ISysParameterSettings_GetWLANClientSSID
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANClientSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANClientSSID  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANClientSSID
	#define EXT_SysParameterSettings_GetWLANClientSSID
	#define GET_SysParameterSettings_GetWLANClientSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANClientSSID" ) 
	#define CAL_SysParameterSettings_GetWLANClientSSID pISysParameterSettings->ISysParameterSettings_GetWLANClientSSID
	#define CHK_SysParameterSettings_GetWLANClientSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANClientSSID  CAL_CMEXPAPI( "SysParameterSettings_GetWLANClientSSID" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANClientSSID  PFSYSPARAMETERSETTINGS_GETWLANCLIENTSSID pfSysParameterSettings_GetWLANClientSSID;
	#define EXT_SysParameterSettings_GetWLANClientSSID  extern PFSYSPARAMETERSETTINGS_GETWLANCLIENTSSID pfSysParameterSettings_GetWLANClientSSID;
	#define GET_SysParameterSettings_GetWLANClientSSID(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANClientSSID", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANClientSSID, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANClientSSID  pfSysParameterSettings_GetWLANClientSSID
	#define CHK_SysParameterSettings_GetWLANClientSSID  (pfSysParameterSettings_GetWLANClientSSID != NULL)
	#define EXP_SysParameterSettings_GetWLANClientSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANClientSSID", (RTS_UINTPTR)SysParameterSettings_GetWLANClientSSID, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWLANClientSSID(char * pszName);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWLANCLIENTSSID) (char * pszName);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWLANCLIENTSSID_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWLANClientSSID
	#define EXT_SysParameterSettings_SetWLANClientSSID
	#define GET_SysParameterSettings_SetWLANClientSSID(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWLANClientSSID(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWLANClientSSID  FALSE
	#define EXP_SysParameterSettings_SetWLANClientSSID  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWLANClientSSID
	#define EXT_SysParameterSettings_SetWLANClientSSID
	#define GET_SysParameterSettings_SetWLANClientSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANClientSSID" ) 
	#define CAL_SysParameterSettings_SetWLANClientSSID  SysParameterSettings_SetWLANClientSSID
	#define CHK_SysParameterSettings_SetWLANClientSSID  TRUE
	#define EXP_SysParameterSettings_SetWLANClientSSID  CAL_CMEXPAPI( "SysParameterSettings_SetWLANClientSSID" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWLANClientSSID
	#define EXT_SysParameterSettings_SetWLANClientSSID
	#define GET_SysParameterSettings_SetWLANClientSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANClientSSID" ) 
	#define CAL_SysParameterSettings_SetWLANClientSSID  SysParameterSettings_SetWLANClientSSID
	#define CHK_SysParameterSettings_SetWLANClientSSID  TRUE
	#define EXP_SysParameterSettings_SetWLANClientSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWLANClientSSID", (RTS_UINTPTR)SysParameterSettings_SetWLANClientSSID, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWLANClientSSID
	#define EXT_SysParameterSettingsSysParameterSettings_SetWLANClientSSID
	#define GET_SysParameterSettingsSysParameterSettings_SetWLANClientSSID  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWLANClientSSID pISysParameterSettings->ISysParameterSettings_SetWLANClientSSID
	#define CHK_SysParameterSettingsSysParameterSettings_SetWLANClientSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWLANClientSSID  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWLANClientSSID
	#define EXT_SysParameterSettings_SetWLANClientSSID
	#define GET_SysParameterSettings_SetWLANClientSSID(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANClientSSID" ) 
	#define CAL_SysParameterSettings_SetWLANClientSSID pISysParameterSettings->ISysParameterSettings_SetWLANClientSSID
	#define CHK_SysParameterSettings_SetWLANClientSSID (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWLANClientSSID  CAL_CMEXPAPI( "SysParameterSettings_SetWLANClientSSID" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWLANClientSSID  PFSYSPARAMETERSETTINGS_SETWLANCLIENTSSID pfSysParameterSettings_SetWLANClientSSID;
	#define EXT_SysParameterSettings_SetWLANClientSSID  extern PFSYSPARAMETERSETTINGS_SETWLANCLIENTSSID pfSysParameterSettings_SetWLANClientSSID;
	#define GET_SysParameterSettings_SetWLANClientSSID(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWLANClientSSID", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWLANClientSSID, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWLANClientSSID  pfSysParameterSettings_SetWLANClientSSID
	#define CHK_SysParameterSettings_SetWLANClientSSID  (pfSysParameterSettings_SetWLANClientSSID != NULL)
	#define EXP_SysParameterSettings_SetWLANClientSSID  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWLANClientSSID", (RTS_UINTPTR)SysParameterSettings_SetWLANClientSSID, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANClientAuthType(char * pszName, RTS_I32 buffersize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANCLIENTAUTHTYPE) (char * pszName, RTS_I32 buffersize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANCLIENTAUTHTYPE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANClientAuthType
	#define EXT_SysParameterSettings_GetWLANClientAuthType
	#define GET_SysParameterSettings_GetWLANClientAuthType(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANClientAuthType(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANClientAuthType  FALSE
	#define EXP_SysParameterSettings_GetWLANClientAuthType  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANClientAuthType
	#define EXT_SysParameterSettings_GetWLANClientAuthType
	#define GET_SysParameterSettings_GetWLANClientAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANClientAuthType" ) 
	#define CAL_SysParameterSettings_GetWLANClientAuthType  SysParameterSettings_GetWLANClientAuthType
	#define CHK_SysParameterSettings_GetWLANClientAuthType  TRUE
	#define EXP_SysParameterSettings_GetWLANClientAuthType  CAL_CMEXPAPI( "SysParameterSettings_GetWLANClientAuthType" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANClientAuthType
	#define EXT_SysParameterSettings_GetWLANClientAuthType
	#define GET_SysParameterSettings_GetWLANClientAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANClientAuthType" ) 
	#define CAL_SysParameterSettings_GetWLANClientAuthType  SysParameterSettings_GetWLANClientAuthType
	#define CHK_SysParameterSettings_GetWLANClientAuthType  TRUE
	#define EXP_SysParameterSettings_GetWLANClientAuthType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANClientAuthType", (RTS_UINTPTR)SysParameterSettings_GetWLANClientAuthType, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANClientAuthType
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANClientAuthType
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANClientAuthType  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANClientAuthType pISysParameterSettings->ISysParameterSettings_GetWLANClientAuthType
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANClientAuthType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANClientAuthType  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANClientAuthType
	#define EXT_SysParameterSettings_GetWLANClientAuthType
	#define GET_SysParameterSettings_GetWLANClientAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANClientAuthType" ) 
	#define CAL_SysParameterSettings_GetWLANClientAuthType pISysParameterSettings->ISysParameterSettings_GetWLANClientAuthType
	#define CHK_SysParameterSettings_GetWLANClientAuthType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANClientAuthType  CAL_CMEXPAPI( "SysParameterSettings_GetWLANClientAuthType" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANClientAuthType  PFSYSPARAMETERSETTINGS_GETWLANCLIENTAUTHTYPE pfSysParameterSettings_GetWLANClientAuthType;
	#define EXT_SysParameterSettings_GetWLANClientAuthType  extern PFSYSPARAMETERSETTINGS_GETWLANCLIENTAUTHTYPE pfSysParameterSettings_GetWLANClientAuthType;
	#define GET_SysParameterSettings_GetWLANClientAuthType(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANClientAuthType", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANClientAuthType, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANClientAuthType  pfSysParameterSettings_GetWLANClientAuthType
	#define CHK_SysParameterSettings_GetWLANClientAuthType  (pfSysParameterSettings_GetWLANClientAuthType != NULL)
	#define EXP_SysParameterSettings_GetWLANClientAuthType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANClientAuthType", (RTS_UINTPTR)SysParameterSettings_GetWLANClientAuthType, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_SetWLANClientAuthType(char * pszName);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_SETWLANCLIENTAUTHTYPE) (char * pszName);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_SETWLANCLIENTAUTHTYPE_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_SetWLANClientAuthType
	#define EXT_SysParameterSettings_SetWLANClientAuthType
	#define GET_SysParameterSettings_SetWLANClientAuthType(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_SetWLANClientAuthType(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_SetWLANClientAuthType  FALSE
	#define EXP_SysParameterSettings_SetWLANClientAuthType  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_SetWLANClientAuthType
	#define EXT_SysParameterSettings_SetWLANClientAuthType
	#define GET_SysParameterSettings_SetWLANClientAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANClientAuthType" ) 
	#define CAL_SysParameterSettings_SetWLANClientAuthType  SysParameterSettings_SetWLANClientAuthType
	#define CHK_SysParameterSettings_SetWLANClientAuthType  TRUE
	#define EXP_SysParameterSettings_SetWLANClientAuthType  CAL_CMEXPAPI( "SysParameterSettings_SetWLANClientAuthType" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_SetWLANClientAuthType
	#define EXT_SysParameterSettings_SetWLANClientAuthType
	#define GET_SysParameterSettings_SetWLANClientAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANClientAuthType" ) 
	#define CAL_SysParameterSettings_SetWLANClientAuthType  SysParameterSettings_SetWLANClientAuthType
	#define CHK_SysParameterSettings_SetWLANClientAuthType  TRUE
	#define EXP_SysParameterSettings_SetWLANClientAuthType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWLANClientAuthType", (RTS_UINTPTR)SysParameterSettings_SetWLANClientAuthType, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_SetWLANClientAuthType
	#define EXT_SysParameterSettingsSysParameterSettings_SetWLANClientAuthType
	#define GET_SysParameterSettingsSysParameterSettings_SetWLANClientAuthType  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_SetWLANClientAuthType pISysParameterSettings->ISysParameterSettings_SetWLANClientAuthType
	#define CHK_SysParameterSettingsSysParameterSettings_SetWLANClientAuthType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_SetWLANClientAuthType  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_SetWLANClientAuthType
	#define EXT_SysParameterSettings_SetWLANClientAuthType
	#define GET_SysParameterSettings_SetWLANClientAuthType(fl)  CAL_CMGETAPI( "SysParameterSettings_SetWLANClientAuthType" ) 
	#define CAL_SysParameterSettings_SetWLANClientAuthType pISysParameterSettings->ISysParameterSettings_SetWLANClientAuthType
	#define CHK_SysParameterSettings_SetWLANClientAuthType (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_SetWLANClientAuthType  CAL_CMEXPAPI( "SysParameterSettings_SetWLANClientAuthType" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_SetWLANClientAuthType  PFSYSPARAMETERSETTINGS_SETWLANCLIENTAUTHTYPE pfSysParameterSettings_SetWLANClientAuthType;
	#define EXT_SysParameterSettings_SetWLANClientAuthType  extern PFSYSPARAMETERSETTINGS_SETWLANCLIENTAUTHTYPE pfSysParameterSettings_SetWLANClientAuthType;
	#define GET_SysParameterSettings_SetWLANClientAuthType(fl)  s_pfCMGetAPI2( "SysParameterSettings_SetWLANClientAuthType", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_SetWLANClientAuthType, (fl), 0, 0)
	#define CAL_SysParameterSettings_SetWLANClientAuthType  pfSysParameterSettings_SetWLANClientAuthType
	#define CHK_SysParameterSettings_SetWLANClientAuthType  (pfSysParameterSettings_SetWLANClientAuthType != NULL)
	#define EXP_SysParameterSettings_SetWLANClientAuthType  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_SetWLANClientAuthType", (RTS_UINTPTR)SysParameterSettings_SetWLANClientAuthType, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_WLANClientChangePasswd(char * pszPwd);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_WLANCLIENTCHANGEPASSWD) (char * pszPwd);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_WLANCLIENTCHANGEPASSWD_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_WLANClientChangePasswd
	#define EXT_SysParameterSettings_WLANClientChangePasswd
	#define GET_SysParameterSettings_WLANClientChangePasswd(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_WLANClientChangePasswd(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_WLANClientChangePasswd  FALSE
	#define EXP_SysParameterSettings_WLANClientChangePasswd  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_WLANClientChangePasswd
	#define EXT_SysParameterSettings_WLANClientChangePasswd
	#define GET_SysParameterSettings_WLANClientChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANClientChangePasswd" ) 
	#define CAL_SysParameterSettings_WLANClientChangePasswd  SysParameterSettings_WLANClientChangePasswd
	#define CHK_SysParameterSettings_WLANClientChangePasswd  TRUE
	#define EXP_SysParameterSettings_WLANClientChangePasswd  CAL_CMEXPAPI( "SysParameterSettings_WLANClientChangePasswd" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_WLANClientChangePasswd
	#define EXT_SysParameterSettings_WLANClientChangePasswd
	#define GET_SysParameterSettings_WLANClientChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANClientChangePasswd" ) 
	#define CAL_SysParameterSettings_WLANClientChangePasswd  SysParameterSettings_WLANClientChangePasswd
	#define CHK_SysParameterSettings_WLANClientChangePasswd  TRUE
	#define EXP_SysParameterSettings_WLANClientChangePasswd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANClientChangePasswd", (RTS_UINTPTR)SysParameterSettings_WLANClientChangePasswd, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_WLANClientChangePasswd
	#define EXT_SysParameterSettingsSysParameterSettings_WLANClientChangePasswd
	#define GET_SysParameterSettingsSysParameterSettings_WLANClientChangePasswd  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_WLANClientChangePasswd pISysParameterSettings->ISysParameterSettings_WLANClientChangePasswd
	#define CHK_SysParameterSettingsSysParameterSettings_WLANClientChangePasswd (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_WLANClientChangePasswd  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_WLANClientChangePasswd
	#define EXT_SysParameterSettings_WLANClientChangePasswd
	#define GET_SysParameterSettings_WLANClientChangePasswd(fl)  CAL_CMGETAPI( "SysParameterSettings_WLANClientChangePasswd" ) 
	#define CAL_SysParameterSettings_WLANClientChangePasswd pISysParameterSettings->ISysParameterSettings_WLANClientChangePasswd
	#define CHK_SysParameterSettings_WLANClientChangePasswd (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_WLANClientChangePasswd  CAL_CMEXPAPI( "SysParameterSettings_WLANClientChangePasswd" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_WLANClientChangePasswd  PFSYSPARAMETERSETTINGS_WLANCLIENTCHANGEPASSWD pfSysParameterSettings_WLANClientChangePasswd;
	#define EXT_SysParameterSettings_WLANClientChangePasswd  extern PFSYSPARAMETERSETTINGS_WLANCLIENTCHANGEPASSWD pfSysParameterSettings_WLANClientChangePasswd;
	#define GET_SysParameterSettings_WLANClientChangePasswd(fl)  s_pfCMGetAPI2( "SysParameterSettings_WLANClientChangePasswd", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_WLANClientChangePasswd, (fl), 0, 0)
	#define CAL_SysParameterSettings_WLANClientChangePasswd  pfSysParameterSettings_WLANClientChangePasswd
	#define CHK_SysParameterSettings_WLANClientChangePasswd  (pfSysParameterSettings_WLANClientChangePasswd != NULL)
	#define EXP_SysParameterSettings_WLANClientChangePasswd  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_WLANClientChangePasswd", (RTS_UINTPTR)SysParameterSettings_WLANClientChangePasswd, 0, 0) 
#endif



RTS_RESULT CDECL SysParameterSettings_GetWLANs(char * szWLANs, RTS_IEC_DWORD* pSize);
typedef RTS_RESULT (CDECL * PFSYSPARAMETERSETTINGS_GETWLANS) (char * szWLANs, RTS_IEC_DWORD* pSize);
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_GETWLANS_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_GetWLANs
	#define EXT_SysParameterSettings_GetWLANs
	#define GET_SysParameterSettings_GetWLANs(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_GetWLANs(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_GetWLANs  FALSE
	#define EXP_SysParameterSettings_GetWLANs  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_GetWLANs
	#define EXT_SysParameterSettings_GetWLANs
	#define GET_SysParameterSettings_GetWLANs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANs" ) 
	#define CAL_SysParameterSettings_GetWLANs  SysParameterSettings_GetWLANs
	#define CHK_SysParameterSettings_GetWLANs  TRUE
	#define EXP_SysParameterSettings_GetWLANs  CAL_CMEXPAPI( "SysParameterSettings_GetWLANs" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_GetWLANs
	#define EXT_SysParameterSettings_GetWLANs
	#define GET_SysParameterSettings_GetWLANs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANs" ) 
	#define CAL_SysParameterSettings_GetWLANs  SysParameterSettings_GetWLANs
	#define CHK_SysParameterSettings_GetWLANs  TRUE
	#define EXP_SysParameterSettings_GetWLANs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANs", (RTS_UINTPTR)SysParameterSettings_GetWLANs, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_GetWLANs
	#define EXT_SysParameterSettingsSysParameterSettings_GetWLANs
	#define GET_SysParameterSettingsSysParameterSettings_GetWLANs  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_GetWLANs pISysParameterSettings->ISysParameterSettings_GetWLANs
	#define CHK_SysParameterSettingsSysParameterSettings_GetWLANs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_GetWLANs  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_GetWLANs
	#define EXT_SysParameterSettings_GetWLANs
	#define GET_SysParameterSettings_GetWLANs(fl)  CAL_CMGETAPI( "SysParameterSettings_GetWLANs" ) 
	#define CAL_SysParameterSettings_GetWLANs pISysParameterSettings->ISysParameterSettings_GetWLANs
	#define CHK_SysParameterSettings_GetWLANs (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_GetWLANs  CAL_CMEXPAPI( "SysParameterSettings_GetWLANs" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_GetWLANs  PFSYSPARAMETERSETTINGS_GETWLANS pfSysParameterSettings_GetWLANs;
	#define EXT_SysParameterSettings_GetWLANs  extern PFSYSPARAMETERSETTINGS_GETWLANS pfSysParameterSettings_GetWLANs;
	#define GET_SysParameterSettings_GetWLANs(fl)  s_pfCMGetAPI2( "SysParameterSettings_GetWLANs", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_GetWLANs, (fl), 0, 0)
	#define CAL_SysParameterSettings_GetWLANs  pfSysParameterSettings_GetWLANs
	#define CHK_SysParameterSettings_GetWLANs  (pfSysParameterSettings_GetWLANs != NULL)
	#define EXP_SysParameterSettings_GetWLANs  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_GetWLANs", (RTS_UINTPTR)SysParameterSettings_GetWLANs, 0, 0) 
#endif



RTS_IEC_BOOL CDECL SysParameterSettings_Is3SWebServerSupportted();
typedef RTS_IEC_BOOL (CDECL * PFSYSPARAMETERSETTINGS_IS3SWEBSERVERSUPPORTTED) ();
#if defined(SYSPARAMETERSETTINGS_NOTIMPLEMENTED) || defined(SYSPARAMETERSETTINGS_IS3SWEBSERVERSUPPORTTED_NOTIMPLEMENTED)
	#define USE_SysParameterSettings_Is3SWebServerSupportted
	#define EXT_SysParameterSettings_Is3SWebServerSupportted
	#define GET_SysParameterSettings_Is3SWebServerSupportted(fl)  ERR_NOTIMPLEMENTED
	#define CAL_SysParameterSettings_Is3SWebServerSupportted()  (RTS_IEC_BOOL)ERR_NOTIMPLEMENTED
	#define CHK_SysParameterSettings_Is3SWebServerSupportted  FALSE
	#define EXP_SysParameterSettings_Is3SWebServerSupportted  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_SysParameterSettings_Is3SWebServerSupportted
	#define EXT_SysParameterSettings_Is3SWebServerSupportted
	#define GET_SysParameterSettings_Is3SWebServerSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_Is3SWebServerSupportted" ) 
	#define CAL_SysParameterSettings_Is3SWebServerSupportted  SysParameterSettings_Is3SWebServerSupportted
	#define CHK_SysParameterSettings_Is3SWebServerSupportted  TRUE
	#define EXP_SysParameterSettings_Is3SWebServerSupportted  CAL_CMEXPAPI( "SysParameterSettings_Is3SWebServerSupportted" ) 
#elif defined(MIXED_LINK) && !defined(SYSPARAMETERSETTINGS_EXTERNAL)
	#define USE_SysParameterSettings_Is3SWebServerSupportted
	#define EXT_SysParameterSettings_Is3SWebServerSupportted
	#define GET_SysParameterSettings_Is3SWebServerSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_Is3SWebServerSupportted" ) 
	#define CAL_SysParameterSettings_Is3SWebServerSupportted  SysParameterSettings_Is3SWebServerSupportted
	#define CHK_SysParameterSettings_Is3SWebServerSupportted  TRUE
	#define EXP_SysParameterSettings_Is3SWebServerSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_Is3SWebServerSupportted", (RTS_UINTPTR)SysParameterSettings_Is3SWebServerSupportted, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_SysParameterSettingsSysParameterSettings_Is3SWebServerSupportted
	#define EXT_SysParameterSettingsSysParameterSettings_Is3SWebServerSupportted
	#define GET_SysParameterSettingsSysParameterSettings_Is3SWebServerSupportted  ERR_OK
	#define CAL_SysParameterSettingsSysParameterSettings_Is3SWebServerSupportted pISysParameterSettings->ISysParameterSettings_Is3SWebServerSupportted
	#define CHK_SysParameterSettingsSysParameterSettings_Is3SWebServerSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettingsSysParameterSettings_Is3SWebServerSupportted  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_SysParameterSettings_Is3SWebServerSupportted
	#define EXT_SysParameterSettings_Is3SWebServerSupportted
	#define GET_SysParameterSettings_Is3SWebServerSupportted(fl)  CAL_CMGETAPI( "SysParameterSettings_Is3SWebServerSupportted" ) 
	#define CAL_SysParameterSettings_Is3SWebServerSupportted pISysParameterSettings->ISysParameterSettings_Is3SWebServerSupportted
	#define CHK_SysParameterSettings_Is3SWebServerSupportted (pISysParameterSettings != NULL)
	#define EXP_SysParameterSettings_Is3SWebServerSupportted  CAL_CMEXPAPI( "SysParameterSettings_Is3SWebServerSupportted" ) 
#else /* DYNAMIC_LINK */
	#define USE_SysParameterSettings_Is3SWebServerSupportted  PFSYSPARAMETERSETTINGS_IS3SWEBSERVERSUPPORTTED pfSysParameterSettings_Is3SWebServerSupportted;
	#define EXT_SysParameterSettings_Is3SWebServerSupportted  extern PFSYSPARAMETERSETTINGS_IS3SWEBSERVERSUPPORTTED pfSysParameterSettings_Is3SWebServerSupportted;
	#define GET_SysParameterSettings_Is3SWebServerSupportted(fl)  s_pfCMGetAPI2( "SysParameterSettings_Is3SWebServerSupportted", (RTS_VOID_FCTPTR *)&pfSysParameterSettings_Is3SWebServerSupportted, (fl), 0, 0)
	#define CAL_SysParameterSettings_Is3SWebServerSupportted  pfSysParameterSettings_Is3SWebServerSupportted
	#define CHK_SysParameterSettings_Is3SWebServerSupportted  (pfSysParameterSettings_Is3SWebServerSupportted != NULL)
	#define EXP_SysParameterSettings_Is3SWebServerSupportted  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"SysParameterSettings_Is3SWebServerSupportted", (RTS_UINTPTR)SysParameterSettings_Is3SWebServerSupportted, 0, 0) 
#endif




#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/





typedef struct
{
	IBase_C *pBase;
	PFSYSPARAMETERSETTINGS_GETDOMAINNAME1 ISysParameterSettings_GetDomainName1;
 	PFSYSPARAMETERSETTINGS_GETDOMAINNAME2 ISysParameterSettings_GetDomainName2;
 	PFSYSPARAMETERSETTINGS_GETNAMESERVERS1 ISysParameterSettings_GetNameservers1;
 	PFSYSPARAMETERSETTINGS_GETNAMESERVERS2 ISysParameterSettings_GetNameservers2;
 	PFSYSPARAMETERSETTINGS_SETADAPTERINFO1 ISysParameterSettings_SetAdapterInfo1;
 	PFSYSPARAMETERSETTINGS_SETADAPTERINFO2 ISysParameterSettings_SetAdapterInfo2;
 	PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY1 ISysParameterSettings_GetStaticGateway1;
 	PFSYSPARAMETERSETTINGS_GETSTATICGATEWAY2 ISysParameterSettings_GetStaticGateway2;
 	PFSYSPARAMETERSETTINGS_GETFTPSTATUS ISysParameterSettings_GetFtpStatus;
 	PFSYSPARAMETERSETTINGS_SETFTPSTATUS ISysParameterSettings_SetFtpStatus;
 	PFSYSPARAMETERSETTINGS_GETNTPSTATUS ISysParameterSettings_GetNtpStatus;
 	PFSYSPARAMETERSETTINGS_SETNTPSTATUS ISysParameterSettings_SetNtpStatus;
 	PFSYSPARAMETERSETTINGS_GETNTPSERVER ISysParameterSettings_GetNtpServer;
 	PFSYSPARAMETERSETTINGS_SETNTPSERVER ISysParameterSettings_SetNtpServer;
 	PFSYSPARAMETERSETTINGS_GETTIMEZONE ISysParameterSettings_GetTimezone;
 	PFSYSPARAMETERSETTINGS_SETTIMEZONE ISysParameterSettings_SetTimezone;
 	PFSYSPARAMETERSETTINGS_GETDATE ISysParameterSettings_GetDate;
 	PFSYSPARAMETERSETTINGS_SETDATE ISysParameterSettings_SetDate;
 	PFSYSPARAMETERSETTINGS_GETTIME ISysParameterSettings_GetTime;
 	PFSYSPARAMETERSETTINGS_SETTIME ISysParameterSettings_SetTime;
 	PFSYSPARAMETERSETTINGS_GETDHCPSTATUS1 ISysParameterSettings_GetDhcpStatus1;
 	PFSYSPARAMETERSETTINGS_GETDHCPSTATUS2 ISysParameterSettings_GetDhcpStatus2;
 	PFSYSPARAMETERSETTINGS_REBOOT ISysParameterSettings_Reboot;
 	PFSYSPARAMETERSETTINGS_GETMEMTOTAL ISysParameterSettings_GetMemTotal;
 	PFSYSPARAMETERSETTINGS_GETMEMAVAILABLE ISysParameterSettings_GetMemAvailable;
 	PFSYSPARAMETERSETTINGS_GETMEMFLASHTOTAL ISysParameterSettings_GetMemFlashTotal;
 	PFSYSPARAMETERSETTINGS_GETMEMFLASHAVAILABLE ISysParameterSettings_GetMemFlashAvailable;
 	PFSYSPARAMETERSETTINGS_CREATEDEFAULTUSERS ISysParameterSettings_CreateDefaultUsers;
 	PFSYSPARAMETERSETTINGS_CREATEUSER ISysParameterSettings_CreateUser;
 	PFSYSPARAMETERSETTINGS_CHANGEPASSWD ISysParameterSettings_ChangePasswd;
 	PFSYSPARAMETERSETTINGS_GETUSERSGROUPLIST ISysParameterSettings_GetUsersGroupList;
 	PFSYSPARAMETERSETTINGS_ADDUSERTOGROUP ISysParameterSettings_AddUserToGroup;
 	PFSYSPARAMETERSETTINGS_REMOVEUSERFROMGROUP ISysParameterSettings_RemoveUserFromGroup;
 	PFSYSPARAMETERSETTINGS_VERIFYPASSWORD ISysParameterSettings_VerifyPassword;
 	PFSYSPARAMETERSETTINGS_GETGROUPMEMBERS ISysParameterSettings_GetGroupMembers;
 	PFSYSPARAMETERSETTINGS_GETVERSIONS ISysParameterSettings_GetVersions;
 	PFSYSPARAMETERSETTINGS_GETMYSQLSTATUS ISysParameterSettings_GetMysqlStatus;
 	PFSYSPARAMETERSETTINGS_SETMYSQLSTATUS ISysParameterSettings_SetMysqlStatus;
 	PFSYSPARAMETERSETTINGS_GETLIGHTTPDSTATUS ISysParameterSettings_GetLighttpdStatus;
 	PFSYSPARAMETERSETTINGS_SETLIGHTTPDSTATUS ISysParameterSettings_SetLighttpdStatus;
 	PFSYSPARAMETERSETTINGS_GETLIGHTTPDPORT ISysParameterSettings_GetLighttpdPort;
 	PFSYSPARAMETERSETTINGS_SETLIGHTTPDPORT ISysParameterSettings_SetLighttpdPort;
 	PFSYSPARAMETERSETTINGS_GETMYSQLDBDIR ISysParameterSettings_GetMysqlDbDir;
 	PFSYSPARAMETERSETTINGS_SETMYSQLDBDIR ISysParameterSettings_SetMysqlDbDir;
 	PFSYSPARAMETERSETTINGS_GETTELNETSTATUS ISysParameterSettings_GetTelnetStatus;
 	PFSYSPARAMETERSETTINGS_SETTELNETSTATUS ISysParameterSettings_SetTelnetStatus;
 	PFSYSPARAMETERSETTINGS_GETSSHSTATUS ISysParameterSettings_GetSSHStatus;
 	PFSYSPARAMETERSETTINGS_SETSSHSTATUS ISysParameterSettings_SetSSHStatus;
 	PFSYSPARAMETERSETTINGS_GETWATCHDOGSTATUS ISysParameterSettings_GetWatchdogStatus;
 	PFSYSPARAMETERSETTINGS_SETWATCHDOGSTATUS ISysParameterSettings_SetWatchdogStatus;
 	PFSYSPARAMETERSETTINGS_GETWATCHDOGTIME ISysParameterSettings_GetWatchdogTime;
 	PFSYSPARAMETERSETTINGS_SETWATCHDOGTIME ISysParameterSettings_SetWatchdogTime;
 	PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMS ISysParameterSettings_GetWatchdogTimeMs;
 	PFSYSPARAMETERSETTINGS_GETWATCHDOGTIMEMINMAX ISysParameterSettings_GetWatchdogTimeMinMax;
 	PFSYSPARAMETERSETTINGS_GETCANBRIDGE ISysParameterSettings_GetCanBridge;
 	PFSYSPARAMETERSETTINGS_SETCANBRIDGE ISysParameterSettings_SetCanBridge;
 	PFSYSPARAMETERSETTINGS_GETUART0BAUDRATE ISysParameterSettings_GetUart0Baudrate;
 	PFSYSPARAMETERSETTINGS_SETUART0BAUDRATE ISysParameterSettings_SetUart0Baudrate;
 	PFSYSPARAMETERSETTINGS_GETUART0PARITY ISysParameterSettings_GetUart0Parity;
 	PFSYSPARAMETERSETTINGS_SETUART0PARITY ISysParameterSettings_SetUart0Parity;
 	PFSYSPARAMETERSETTINGS_GETUART0STOPBITS ISysParameterSettings_GetUart0Stopbits;
 	PFSYSPARAMETERSETTINGS_SETUART0STOPBITS ISysParameterSettings_SetUart0Stopbits;
 	PFSYSPARAMETERSETTINGS_GETRIGHTSFORPARAMETER ISysParameterSettings_GetRightsForParameter;
 	PFSYSPARAMETERSETTINGS_DELETEUSER ISysParameterSettings_DeleteUser;
 	PFSYSPARAMETERSETTINGS_GETSOFTWARE_VERSION ISysParameterSettings_GetSoftware_version;
 	PFSYSPARAMETERSETTINGS_GETDEVICETEMPERATURE ISysParameterSettings_GetDeviceTemperature;
 	PFSYSPARAMETERSETTINGS_GETPROMISC1 ISysParameterSettings_GetPromisc1;
 	PFSYSPARAMETERSETTINGS_SETPROMISC1 ISysParameterSettings_SetPromisc1;
 	PFSYSPARAMETERSETTINGS_GETPROMISC2 ISysParameterSettings_GetPromisc2;
 	PFSYSPARAMETERSETTINGS_SETPROMISC2 ISysParameterSettings_SetPromisc2;
 	PFSYSPARAMETERSETTINGS_GETMULTICAST1 ISysParameterSettings_GetMulticast1;
 	PFSYSPARAMETERSETTINGS_SETMULTICAST1 ISysParameterSettings_SetMulticast1;
 	PFSYSPARAMETERSETTINGS_GETMULTICAST2 ISysParameterSettings_GetMulticast2;
 	PFSYSPARAMETERSETTINGS_SETMULTICAST2 ISysParameterSettings_SetMulticast2;
 	PFSYSPARAMETERSETTINGS_GETMOUNTSJSON ISysParameterSettings_GetMountsJSON;
 	PFSYSPARAMETERSETTINGS_UNMOUNT ISysParameterSettings_Unmount;
 	PFSYSPARAMETERSETTINGS_GETPROFINETNAME ISysParameterSettings_GetProfinetName;
 	PFSYSPARAMETERSETTINGS_SETPROFINETNAME ISysParameterSettings_SetProfinetName;
 	PFSYSPARAMETERSETTINGS_GETMYSQLBINDADDRESS ISysParameterSettings_GetMysqlBindAddress;
 	PFSYSPARAMETERSETTINGS_SETMYSQLBINDADDRESS ISysParameterSettings_SetMysqlBindAddress;
 	PFSYSPARAMETERSETTINGS_GETWEBSERVERSTATUS ISysParameterSettings_GetWebServerStatus;
 	PFSYSPARAMETERSETTINGS_SETWEBSERVERSTATUS ISysParameterSettings_SetWebServerStatus;
 	PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTP ISysParameterSettings_GetWebServerHTTP;
 	PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTP ISysParameterSettings_SetWebServerHTTP;
 	PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPPORT ISysParameterSettings_GetWebServerHTTPPort;
 	PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPPORT ISysParameterSettings_SetWebServerHTTPPort;
 	PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPS ISysParameterSettings_GetWebServerHTTPS;
 	PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPS ISysParameterSettings_SetWebServerHTTPS;
 	PFSYSPARAMETERSETTINGS_GETWEBSERVERHTTPSPORT ISysParameterSettings_GetWebServerHTTPSPort;
 	PFSYSPARAMETERSETTINGS_SETWEBSERVERHTTPSPORT ISysParameterSettings_SetWebServerHTTPSPort;
 	PFSYSPARAMETERSETTINGS_GETLANGUAGE ISysParameterSettings_GetLanguage;
 	PFSYSPARAMETERSETTINGS_SETLANGUAGE ISysParameterSettings_SetLanguage;
 	PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARSTATUS ISysParameterSettings_GetQuickLaunchBarStatus;
 	PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARSTATUS ISysParameterSettings_SetQuickLaunchBarStatus;
 	PFSYSPARAMETERSETTINGS_GETQUICKLAUNCHBARMENUS ISysParameterSettings_GetQuickLaunchBarMenus;
 	PFSYSPARAMETERSETTINGS_SETQUICKLAUNCHBARMENUS ISysParameterSettings_SetQuickLaunchBarMenus;
 	PFSYSPARAMETERSETTINGS_GETFONTS ISysParameterSettings_GetFonts;
 	PFSYSPARAMETERSETTINGS_GETFONTSFAMILIES ISysParameterSettings_GetFontsFamilies;
 	PFSYSPARAMETERSETTINGS_DELETEFONT ISysParameterSettings_DeleteFont;
 	PFSYSPARAMETERSETTINGS_SUBSTITUTEFONT ISysParameterSettings_SubstituteFont;
 	PFSYSPARAMETERSETTINGS_GETFONTSSUBST ISysParameterSettings_GetFontsSubst;
 	PFSYSPARAMETERSETTINGS_SETFONTSSUBST ISysParameterSettings_SetFontsSubst;
 	PFSYSPARAMETERSETTINGS_UPLOADFONTS ISysParameterSettings_uploadFonts;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYRESOLUTION ISysParameterSettings_GetDisplayResolution;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYORIENTATION ISysParameterSettings_GetDisplayOrientation;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYORIENTATION ISysParameterSettings_SetDisplayOrientation;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYBRIGHTNESS ISysParameterSettings_GetDisplayBrightness;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYBRIGHTNESS ISysParameterSettings_SetDisplayBrightness;
 	PFSYSPARAMETERSETTINGS_CHANGEBRIGHTNESS ISysParameterSettings_changeBrightness;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYCLEANTIME ISysParameterSettings_GetDisplayCleanTime;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYCLEANTIME ISysParameterSettings_SetDisplayCleanTime;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYSSENABLE ISysParameterSettings_GetDisplaySSEnable;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYSSENABLE ISysParameterSettings_SetDisplaySSEnable;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYSSTIME ISysParameterSettings_GetDisplaySSTime;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYSSTIME ISysParameterSettings_SetDisplaySSTime;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYSSTHEME ISysParameterSettings_GetDisplaySSTheme;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYSSTHEME ISysParameterSettings_SetDisplaySSTheme;
 	PFSYSPARAMETERSETTINGS_GETDISPLAYSSTEXT ISysParameterSettings_GetDisplaySSText;
 	PFSYSPARAMETERSETTINGS_SETDISPLAYSSTEXT ISysParameterSettings_SetDisplaySSText;
 	PFSYSPARAMETERSETTINGS_TURNSCREENSAVER ISysParameterSettings_turnScreensaver;
 	PFSYSPARAMETERSETTINGS_ROTATEDISPLAY ISysParameterSettings_rotateDisplay;
 	PFSYSPARAMETERSETTINGS_CLEARROUTINGCACHE ISysParameterSettings_ClearRoutingCache;
 	PFSYSPARAMETERSETTINGS_GETBROWSERTABABLE ISysParameterSettings_GetBrowserTabable;
 	PFSYSPARAMETERSETTINGS_SETBROWSERTABABLE ISysParameterSettings_SetBrowserTabable;
 	PFSYSPARAMETERSETTINGS_GETBROWSERADDRESSBAR ISysParameterSettings_GetBrowserAddressBar;
 	PFSYSPARAMETERSETTINGS_SETBROWSERADDRESSBAR ISysParameterSettings_SetBrowserAddressBar;
 	PFSYSPARAMETERSETTINGS_GETBROWSERFAVOURITEBAR ISysParameterSettings_GetBrowserFavouriteBar;
 	PFSYSPARAMETERSETTINGS_SETBROWSERFAVOURITEBAR ISysParameterSettings_SetBrowserFavouriteBar;
 	PFSYSPARAMETERSETTINGS_GETBROWSERZOOMABLE ISysParameterSettings_GetBrowserZoomable;
 	PFSYSPARAMETERSETTINGS_SETBROWSERZOOMABLE ISysParameterSettings_SetBrowserZoomable;
 	PFSYSPARAMETERSETTINGS_GETBROWSERURLS ISysParameterSettings_GetBrowserURLs;
 	PFSYSPARAMETERSETTINGS_SETBROWSERURLS ISysParameterSettings_SetBrowserURLs;
 	PFSYSPARAMETERSETTINGS_GETSSIMAGE ISysParameterSettings_getSSImage;
 	PFSYSPARAMETERSETTINGS_GETSTARTCOUNTDOWN ISysParameterSettings_GetStartCountdown;
 	PFSYSPARAMETERSETTINGS_SETSTARTCOUNTDOWN ISysParameterSettings_SetStartCountdown;
 	PFSYSPARAMETERSETTINGS_GETBROWSERSECURITY ISysParameterSettings_GetBrowserSecurity;
 	PFSYSPARAMETERSETTINGS_SETBROWSERSECURITY ISysParameterSettings_SetBrowserSecurity;
 	PFSYSPARAMETERSETTINGS_GETUSEPASSWORDVNC ISysParameterSettings_GetUsePasswordVnc;
 	PFSYSPARAMETERSETTINGS_SETUSEPASSWORDVNC ISysParameterSettings_SetUsePasswordVnc;
 	PFSYSPARAMETERSETTINGS_GETPASSWORDVNC ISysParameterSettings_GetPasswordVnc;
 	PFSYSPARAMETERSETTINGS_SETPASSWORDVNC ISysParameterSettings_SetPasswordVnc;
 	PFSYSPARAMETERSETTINGS_GETVNCSERVER ISysParameterSettings_GetVncServer;
 	PFSYSPARAMETERSETTINGS_SETVNCSERVER ISysParameterSettings_SetVncServer;
 	PFSYSPARAMETERSETTINGS_GETAUTOSTART ISysParameterSettings_GetAutostart;
 	PFSYSPARAMETERSETTINGS_SETAUTOSTART ISysParameterSettings_SetAutostart;
 	PFSYSPARAMETERSETTINGS_GETSUBNETMASK1 ISysParameterSettings_GetSubnetMask1;
 	PFSYSPARAMETERSETTINGS_GETSUBNETMASK2 ISysParameterSettings_GetSubnetMask2;
 	PFSYSPARAMETERSETTINGS_ISUNMOUNTSUPPORTTED ISysParameterSettings_IsUnmountSupportted;
 	PFSYSPARAMETERSETTINGS_ISCLEARROUTINGCACHESUPPORTTED ISysParameterSettings_IsClearRoutingCacheSupportted;
 	PFSYSPARAMETERSETTINGS_ISDELETEFONTSUPPORTTED ISysParameterSettings_IsdeleteFontSupportted;
 	PFSYSPARAMETERSETTINGS_ISSUBSTITUTEFONTSUPPORTTED ISysParameterSettings_IssubstituteFontSupportted;
 	PFSYSPARAMETERSETTINGS_ISUPLOADFONTSSUPPORTTED ISysParameterSettings_IsuploadFontsSupportted;
 	PFSYSPARAMETERSETTINGS_ISCREATEUSERSUPPORTTED ISysParameterSettings_IsCreateUserSupportted;
 	PFSYSPARAMETERSETTINGS_ISDELETEUSERSUPPORTTED ISysParameterSettings_IsDeleteUserSupportted;
 	PFSYSPARAMETERSETTINGS_ISCHANGEBRIGHTNESSSUPPORTTED ISysParameterSettings_IschangeBrightnessSupportted;
 	PFSYSPARAMETERSETTINGS_ISTURNSCREENSAVERSUPPORTTED ISysParameterSettings_IsturnScreensaverSupportted;
 	PFSYSPARAMETERSETTINGS_ISGETSSIMAGESUPPORTTED ISysParameterSettings_IsgetSSImageSupportted;
 	PFSYSPARAMETERSETTINGS_GETNETROUTES ISysParameterSettings_GetNETRoutes;
 	PFSYSPARAMETERSETTINGS_SETNETROUTES ISysParameterSettings_SetNETRoutes;
 	PFSYSPARAMETERSETTINGS_GETRS485TERM ISysParameterSettings_GetRS485Term;
 	PFSYSPARAMETERSETTINGS_SETRS485TERM ISysParameterSettings_SetRS485Term;
 	PFSYSPARAMETERSETTINGS_GETRIGHTCAN0TERM ISysParameterSettings_GetRightCAN0Term;
 	PFSYSPARAMETERSETTINGS_GETCAN0TERM ISysParameterSettings_GetCAN0Term;
 	PFSYSPARAMETERSETTINGS_SETCAN0TERM ISysParameterSettings_SetCAN0Term;
 	PFSYSPARAMETERSETTINGS_GETRIGHTCAN1TERM ISysParameterSettings_GetRightCAN1Term;
 	PFSYSPARAMETERSETTINGS_GETCAN1TERM ISysParameterSettings_GetCAN1Term;
 	PFSYSPARAMETERSETTINGS_SETCAN1TERM ISysParameterSettings_SetCAN1Term;
 	PFSYSPARAMETERSETTINGS_GETSDENABLE ISysParameterSettings_GetSDEnable;
 	PFSYSPARAMETERSETTINGS_SETSDENABLE ISysParameterSettings_SetSDEnable;
 	PFSYSPARAMETERSETTINGS_GETACCESSPOINT ISysParameterSettings_GetAccessPoint;
 	PFSYSPARAMETERSETTINGS_SETACCESSPOINT ISysParameterSettings_SetAccessPoint;
 	PFSYSPARAMETERSETTINGS_GETSSID ISysParameterSettings_GetSSID;
 	PFSYSPARAMETERSETTINGS_SETSSID ISysParameterSettings_SetSSID;
 	PFSYSPARAMETERSETTINGS_GETWLANAPCHANNEL ISysParameterSettings_GetWLANAPChannel;
 	PFSYSPARAMETERSETTINGS_SETWLANAPCHANNEL ISysParameterSettings_SetWLANAPChannel;
 	PFSYSPARAMETERSETTINGS_GETWLANAPAUTHTYPE ISysParameterSettings_GetWLANAPAuthType;
 	PFSYSPARAMETERSETTINGS_GETWLANAPWPATYPE ISysParameterSettings_GetWLANAPWPAType;
 	PFSYSPARAMETERSETTINGS_GETWLANAPHWMODE ISysParameterSettings_GetWLANAPHWMode;
 	PFSYSPARAMETERSETTINGS_WLANRESTART ISysParameterSettings_WLANRestart;
 	PFSYSPARAMETERSETTINGS_WLANWPACHANGEPASSWD ISysParameterSettings_WLANWPAChangePasswd;
 	PFSYSPARAMETERSETTINGS_WLANSCAN ISysParameterSettings_WLANScan;
 	PFSYSPARAMETERSETTINGS_WLANCONNECTTOAP ISysParameterSettings_WLANConnectToAP;
 	PFSYSPARAMETERSETTINGS_GETWLANCLIENTSSID ISysParameterSettings_GetWLANClientSSID;
 	PFSYSPARAMETERSETTINGS_SETWLANCLIENTSSID ISysParameterSettings_SetWLANClientSSID;
 	PFSYSPARAMETERSETTINGS_GETWLANCLIENTAUTHTYPE ISysParameterSettings_GetWLANClientAuthType;
 	PFSYSPARAMETERSETTINGS_SETWLANCLIENTAUTHTYPE ISysParameterSettings_SetWLANClientAuthType;
 	PFSYSPARAMETERSETTINGS_WLANCLIENTCHANGEPASSWD ISysParameterSettings_WLANClientChangePasswd;
 	PFSYSPARAMETERSETTINGS_GETWLANS ISysParameterSettings_GetWLANs;
 	PFSYSPARAMETERSETTINGS_IS3SWEBSERVERSUPPORTTED ISysParameterSettings_Is3SWebServerSupportted;
 } ISysParameterSettings_C;

#ifdef CPLUSPLUS
class ISysParameterSettings : public IBase
{
	public:
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDomainName1(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDomainName2(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetNameservers1(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetNameservers2(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetAdapterInfo1(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetAdapterInfo2(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetStaticGateway1(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetStaticGateway2(AdapterNetworkV4Settings * pAdapter) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetFtpStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetFtpStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetNtpStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetNtpStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetNtpServer(char * pszNtpServer, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetNtpServer(char * pszNtpServer) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetTimezone(char * pszTimezone, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetTimezone(char * pszTimezone) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDate(char * pszDate, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDate(char * pszDate) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetTime(char * pszTime, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetTime(char * pszTime) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDhcpStatus1(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDhcpStatus2(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_Reboot(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMemTotal(RTS_UI32 * pMemory) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMemAvailable(RTS_UI32 * pMemory) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMemFlashTotal(RTS_UI32 * pMemory) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMemFlashAvailable(RTS_UI32 * pMemory) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_CreateDefaultUsers(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_CreateUser(char * szUsername, char * szPasswd, char * szGroupname) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_ChangePasswd(char * szUsername, char * szPasswd) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetUsersGroupList(char * szUsername, char * szOutGroupList, int maxlen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_AddUserToGroup(char * szUsername, char * szGroupname) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_RemoveUserFromGroup(char * szUsername, char * szGroupname) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_VerifyPassword(char * szUsername, char * szPasswd) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetGroupMembers(char * szGroupname, char * szOutput, int maxlen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetVersions(char * szOutput, int buflen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMysqlStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetMysqlStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetLighttpdStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetLighttpdStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetLighttpdPort(RTS_UI32 *pport) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetLighttpdPort(RTS_UI32 port) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMysqlDbDir(char * pszDir, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetMysqlDbDir(char * pszDir) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetTelnetStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetTelnetStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetSSHStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetSSHStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWatchdogStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWatchdogStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWatchdogTime(RTS_UI32 *ptimeout) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWatchdogTime(RTS_UI32 timeout) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWatchdogTimeMs(RTS_I32 *pStatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWatchdogTimeMinMax(RTS_UI32 *pMin, RTS_UI32 *pMax) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetCanBridge(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetCanBridge(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetUart0Baudrate(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetUart0Baudrate(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetUart0Parity(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetUart0Parity(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetUart0Stopbits(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetUart0Stopbits(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetRightsForParameter(char * pszUserName, RTS_UI32 bcReadAccess, RTS_UI32 bcWriteAccess) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_DeleteUser(char * szUsername) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetSoftware_version(char * szOutput, int buflen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDeviceTemperature(RTS_REAL32 * pTemperature) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetPromisc1(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetPromisc1(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetPromisc2(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetPromisc2(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMulticast1(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetMulticast1(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMulticast2(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetMulticast2(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMountsJSON(char * szOutput, int maxlen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_Unmount(char * pszDirectory) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetProfinetName(char * pszName, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetProfinetName(char * pszName) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetMysqlBindAddress(char * pszBindAddress, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetMysqlBindAddress(char * pszBindAddress) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWebServerStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWebServerStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWebServerHTTP(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWebServerHTTP(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWebServerHTTPPort(RTS_UI32 *pport) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWebServerHTTPPort(RTS_UI32 port) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWebServerHTTPS(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWebServerHTTPS(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWebServerHTTPSPort(RTS_UI32 *pport) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWebServerHTTPSPort(RTS_UI32 port) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetLanguage(char * szLanguage, int buflen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetLanguage(char * szLanguage) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetQuickLaunchBarStatus(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetQuickLaunchBarStatus(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetQuickLaunchBarMenus(char * szMenus, int buflen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetQuickLaunchBarMenus(char * szMenus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetFonts(char * szFonts, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetFontsFamilies(char * szFonts, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_DeleteFont(char * szFont) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SubstituteFont(char * szFontToSubstitute, char* szFont) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetFontsSubst(char * szFontsSubst, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetFontsSubst(char * szFontsSubst, RTS_IEC_DWORD siSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_uploadFonts(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplayResolution(RTS_UI16 * pX, RTS_UI16* pY) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplayOrientation(RTS_UI16* pOrientation) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplayOrientation(RTS_UI16 nOrientation) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplayBrightness(RTS_UI8 * pBrightness) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplayBrightness(RTS_UI8 nBrightness) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_changeBrightness(RTS_UI8 nBrightness) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplayCleanTime(RTS_UI32* pCleanTime) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplayCleanTime(RTS_UI32 nCleanTime) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplaySSEnable(RTS_BOOL* pEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplaySSEnable(RTS_BOOL bEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplaySSTime(RTS_UI32* pSSTime) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplaySSTime(RTS_UI32 nSSTime) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplaySSTheme(RTS_UI8 * pValue) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplaySSTheme(RTS_UI8 nValue) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetDisplaySSText(char * pszText, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetDisplaySSText(char * pszText) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_turnScreensaver(RTS_BOOL bON) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_rotateDisplay(RTS_UI8 nRotate) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_ClearRoutingCache(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetBrowserTabable(RTS_BOOL* pEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetBrowserTabable(RTS_BOOL bEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetBrowserAddressBar(RTS_BOOL* pEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetBrowserAddressBar(RTS_BOOL bEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetBrowserFavouriteBar(RTS_BOOL* pEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetBrowserFavouriteBar(RTS_BOOL bEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetBrowserZoomable(RTS_BOOL* pEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetBrowserZoomable(RTS_BOOL bEnable) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetBrowserURLs(char * szURLs, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetBrowserURLs(char * szURLs, RTS_IEC_DWORD siSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_getSSImage(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetStartCountdown(RTS_UI16* pStartCountdown) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetStartCountdown(RTS_UI16 nStartCountdown) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetBrowserSecurity(char * szSecurity, int buflen) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetBrowserSecurity(char * szSecurity) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetUsePasswordVnc(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetUsePasswordVnc(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetPasswordVnc(char * pszValue, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetPasswordVnc(char * pszValue) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetVncServer(char * pszText, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetVncServer(char * pszText) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetAutostart(char * pszText, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetAutostart(char * pszText) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetSubnetMask1(char * pszOut, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetSubnetMask2(char * pszOut, RTS_I32 buffersize) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsUnmountSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsClearRoutingCacheSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsdeleteFontSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IssubstituteFontSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsuploadFontsSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsCreateUserSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsDeleteUserSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IschangeBrightnessSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsturnScreensaverSupportted(void) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_IsgetSSImageSupportted(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetNETRoutes(char * szRoutes, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetNETRoutes(char * szRoutes, RTS_IEC_DWORD siSize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetRS485Term(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetRS485Term(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetRightCAN0Term(char * pszUserName) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetCAN0Term(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetCAN0Term(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetRightCAN1Term(char * pszUserName) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetCAN1Term(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetCAN1Term(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetSDEnable(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetSDEnable(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetAccessPoint(RTS_I32 *pstatus) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetAccessPoint(RTS_I32 status) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetSSID(char * pszName, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetSSID(char * pszName) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANAPChannel(RTS_UI8* pChannel) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWLANAPChannel(RTS_UI8 nChannel) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANAPAuthType(RTS_UI8* pAuthType) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANAPWPAType(RTS_UI8* pWPAType) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANAPHWMode(char * pszName, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_WLANRestart(void) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_WLANWPAChangePasswd(char * pszPwd) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_WLANScan(char * sWLANInterface, dynamic_list* pOutput) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_WLANConnectToAP(char* sInterface, char * sSSID, char* pszPwd, char* sAuthType) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANClientSSID(char * pszName, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWLANClientSSID(char * pszName) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANClientAuthType(char * pszName, RTS_I32 buffersize) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_SetWLANClientAuthType(char * pszName) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_WLANClientChangePasswd(char * pszPwd) =0;
		virtual RTS_RESULT CDECL ISysParameterSettings_GetWLANs(char * szWLANs, RTS_IEC_DWORD* pSize) =0;
		virtual RTS_IEC_BOOL CDECL ISysParameterSettings_Is3SWebServerSupportted(void) =0;
};
	#ifndef ITF_SysParameterSettings
		#define ITF_SysParameterSettings static ISysParameterSettings *pISysParameterSettings = NULL;
	#endif
	#define EXTITF_SysParameterSettings
#else	/*CPLUSPLUS*/
	typedef ISysParameterSettings_C		ISysParameterSettings;
	#ifndef ITF_SysParameterSettings
		#define ITF_SysParameterSettings
	#endif
	#define EXTITF_SysParameterSettings
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_SYSPARAMETERSETTINGSITF_H_*/
