 /**
 * <interfacename>SysError</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _SYSERRORITF_H_
#define _SYSERRORITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: ERR</description>
 */
#define ERR_OK    RTS_IEC_DWORD_C(0x0)	/* Fehlerfrei */
#define ERR_NOK    RTS_IEC_DWORD_C(0x1)	/* Allgemeiner Fehler */
#define ERR_PARA_NOK    RTS_IEC_DWORD_C(0x8000)	/* Allgemeiner Parameterfehler */
#define ERR_PARA_UNKNOWN    RTS_IEC_DWORD_C(0x8100)	/* Parameter unbekannt */
#define ERR_PARA_NOTSUPPORTED    RTS_IEC_DWORD_C(0x8200)	/* Parameter wird nicht unterstützt */
#define ERR_VALUE_NOK    RTS_IEC_DWORD_C(0x8300)	/* Allgemeiner Wertefehler */
#define ERR_VALUE_WRONG    RTS_IEC_DWORD_C(0x8301)	/* Wert nicht gültig */
#define ERR_CHANNEL_NOK    RTS_IEC_DWORD_C(0x8400)	/* Allgemeiner Kanalfehler */
#define ERR_CHANNEL_NUMBER_WRONG    RTS_IEC_DWORD_C(0x8401)	/* Kanalnummer nicht gültig */
#define ERR_CHANNEL_TYP_WRONG    RTS_IEC_DWORD_C(0x8402)	/* Kanaltyp nicht gültig */
#define ERR_APP_NOK    RTS_IEC_DWORD_C(0x8500)	/* Allgemeiner Applikationsfehler */
#define ERR_WS_NEWSTART_NEED    RTS_IEC_DWORD_C(0x8600)	/* Bereich für WebSocket */
#define ERR_WS_FUNCTIONPARAMERT_INVALID    RTS_IEC_DWORD_C(0x8601)	
#define ERR_FTP_LOGIN_DENIED    RTS_IEC_DWORD_C(0x8640)	/* The remote server denied to login. */
#define ERR_FTP_ACCEPT_TIMEOUT    RTS_IEC_DWORD_C(0x8641)	/* While waiting for the server to connect, the timeout expired. */
#define ERR_FTP_COULDNT_CONNECT    RTS_IEC_DWORD_C(0x8642)	/* Failed to establish a FTP connection to host or proxy. */
#define ERR_FTP_REMOTE_FILE_NOT_FOUND    RTS_IEC_DWORD_C(0x8643)	/* The resource referenced in the URL does not exist. */
#define ERR_FTP_SOURCE_FILE_NOT_FOUND    RTS_IEC_DWORD_C(0x8644)	/* Source File to upload/download is not found. */
#define ERR_RTH    RTS_IEC_DWORD_C(0x8700)	/* Bereich */
#define ERR_MYSQL_ERROR_FIRST    RTS_IEC_DWORD_C(0x8800)	/* MYSQL Bereich: ca. 2000 Server Error Codes + ca. 100 Client Error codes */
#define ERR_MYSQL_SERVER_DB_CREATE_EXISTS    RTS_IEC_DWORD_C(0x8807)	/* Can't create database '%s'; database exists */
#define ERR_MYSQL_SERVER_TABLE_EXISTS_ERROR    RTS_IEC_DWORD_C(0x8832)	/* Table '%s' already exists. */
#define ERR_MYSQL_SERVER_LAST_ERROR    RTS_IEC_DWORD_C(0x8FCF)	/* MYSQL_SERVER_FIRST_ERROR+1999 */
#define ERR_MYSQL_CLIENT_UNKNOWN_ERROR    RTS_IEC_DWORD_C(0x8FD0)	/* MYSQL_CLIENT_FIRST_ERROR:=16#8FD0(*ca. 100 Client Error Codes; for details look for (ErrorCode-MYSQL_CLIENT_FIRST_ERROR+2000) here: https://dev.mysql.com/doc/refman/5.5/en/error-messages-client.html *),
 MYSQL_ERROR_FIRST+2000(7D0) */
#define ERR_MYSQL_CLIENT_SOCKET_CREATE_ERROR    RTS_IEC_DWORD_C(0x8FD1)	
#define ERR_MYSQL_CLIENT_CONNECTION_ERROR    RTS_IEC_DWORD_C(0x8FD2)	
#define ERR_MYSQL_CLIENT_CONN_HOST_ERROR    RTS_IEC_DWORD_C(0x8FD3)	
#define ERR_MYSQL_CLIENT_IPSOCK_ERROR    RTS_IEC_DWORD_C(0x8FD4)	
#define ERR_MYSQL_CLIENT_UNKNOWN_HOST    RTS_IEC_DWORD_C(0x8FD5)	
#define ERR_MYSQL_CLIENT_SERVER_GONE_ERROR    RTS_IEC_DWORD_C(0x8FD6)	
#define ERR_MYSQL_CLIENT_VERSION_ERROR    RTS_IEC_DWORD_C(0x8FD7)	
#define ERR_MYSQL_CLIENT_OUT_OF_MEMORY    RTS_IEC_DWORD_C(0x8FD8)	
#define ERR_MYSQL_CLIENT_WRONG_HOST_INFO    RTS_IEC_DWORD_C(0x8FD9)	
#define ERR_MYSQL_CLIENT_LOCALHOST_CONNECTION    RTS_IEC_DWORD_C(0x8FDA)	
#define ERR_MYSQL_CLIENT_TCP_CONNECTION    RTS_IEC_DWORD_C(0x8FDB)	
#define ERR_MYSQL_CLIENT_SERVER_HANDSHAKE_ERR    RTS_IEC_DWORD_C(0x8FDC)	
#define ERR_MYSQL_CLIENT_SERVER_LOST    RTS_IEC_DWORD_C(0x8FDD)	
#define ERR_MYSQL_CLIENT_COMMANDS_OUT_OF_SYNC    RTS_IEC_DWORD_C(0x8FDE)	
#define ERR_MYSQL_CLIENT_NAMEDPIPE_CONNECTION    RTS_IEC_DWORD_C(0x8FDF)	
#define ERR_MYSQL_CLIENT_NAMEDPIPEWAIT_ERROR    RTS_IEC_DWORD_C(0x8FE0)	
#define ERR_MYSQL_CLIENT_NAMEDPIPEOPEN_ERROR    RTS_IEC_DWORD_C(0x8FE1)	
#define ERR_MYSQL_CLIENT_NAMEDPIPESETSTATE_ERROR    RTS_IEC_DWORD_C(0x8FE2)	
#define ERR_MYSQL_CLIENT_CANT_READ_CHARSET    RTS_IEC_DWORD_C(0x8FE3)	
#define ERR_MYSQL_CLIENT_NET_PACKET_TOO_LARGE    RTS_IEC_DWORD_C(0x8FE4)	
#define ERR_MYSQL_CLIENT_EMBEDDED_CONNECTION    RTS_IEC_DWORD_C(0x8FE5)	
#define ERR_MYSQL_CLIENT_PROBE_SLAVE_STATUS    RTS_IEC_DWORD_C(0x8FE6)	
#define ERR_MYSQL_CLIENT_PROBE_SLAVE_HOSTS    RTS_IEC_DWORD_C(0x8FE7)	
#define ERR_MYSQL_CLIENT_PROBE_SLAVE_CONNECT    RTS_IEC_DWORD_C(0x8FE8)	
#define ERR_MYSQL_CLIENT_PROBE_MASTER_CONNECT    RTS_IEC_DWORD_C(0x8FE9)	
#define ERR_MYSQL_CLIENT_SSL_CONNECTION_ERROR    RTS_IEC_DWORD_C(0x8FEA)	
#define ERR_MYSQL_CLIENT_MALFORMED_PACKET    RTS_IEC_DWORD_C(0x8FEB)	
#define ERR_MYSQL_CLIENT_WRONG_LICENSE    RTS_IEC_DWORD_C(0x8FEC)	
#define ERR_MYSQL_CLIENT_NULL_POINTER    RTS_IEC_DWORD_C(0x8FED)	
#define ERR_MYSQL_CLIENT_NO_PREPARE_STMT    RTS_IEC_DWORD_C(0x8FEE)	
#define ERR_MYSQL_CLIENT_PARAMS_NOT_BOUND    RTS_IEC_DWORD_C(0x8FEF)	
#define ERR_MYSQL_CLIENT_DATA_TRUNCATED    RTS_IEC_DWORD_C(0x8FF0)	
#define ERR_MYSQL_CLIENT_NO_PARAMETERS_EXISTS    RTS_IEC_DWORD_C(0x8FF1)	
#define ERR_MYSQL_CLIENT_INVALID_PARAMETER_NO    RTS_IEC_DWORD_C(0x8FF2)	
#define ERR_MYSQL_CLIENT_INVALID_BUFFER_USE    RTS_IEC_DWORD_C(0x8FF3)	
#define ERR_MYSQL_CLIENT_UNSUPPORTED_PARAM_TYPE    RTS_IEC_DWORD_C(0x8FF4)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECTION    RTS_IEC_DWORD_C(0x8FF5)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECT_REQUEST_ERROR    RTS_IEC_DWORD_C(0x8FF6)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECT_ANSWER_ERROR    RTS_IEC_DWORD_C(0x8FF7)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECT_FILE_MAP_ERROR    RTS_IEC_DWORD_C(0x8FF8)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECT_MAP_ERROR    RTS_IEC_DWORD_C(0x8FF9)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_FILE_MAP_ERROR    RTS_IEC_DWORD_C(0x8FFA)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_MAP_ERROR    RTS_IEC_DWORD_C(0x8FFB)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_EVENT_ERROR    RTS_IEC_DWORD_C(0x8FFC)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECT_ABANDONED_ERROR    RTS_IEC_DWORD_C(0x8FFD)	
#define ERR_MYSQL_CLIENT_SHARED_MEMORY_CONNECT_SET_ERROR    RTS_IEC_DWORD_C(0x8FFE)	
#define ERR_MYSQL_CLIENT_CONN_UNKNOW_PROTOCOL    RTS_IEC_DWORD_C(0x8FFF)	
#define ERR_MYSQL_CLIENT_INVALID_CONN_HANDLE    RTS_IEC_DWORD_C(0x9000)	
#define ERR_MYSQL_CLIENT_SECURE_AUTH    RTS_IEC_DWORD_C(0x9001)	
#define ERR_MYSQL_CLIENT_FETCH_CANCELED    RTS_IEC_DWORD_C(0x9002)	
#define ERR_MYSQL_CLIENT_NO_DATA    RTS_IEC_DWORD_C(0x9003)	
#define ERR_MYSQL_CLIENT_NO_STMT_METADATA    RTS_IEC_DWORD_C(0x9004)	
#define ERR_MYSQL_CLIENT_NO_RESULT_SET    RTS_IEC_DWORD_C(0x9005)	
#define ERR_MYSQL_CLIENT_NOT_IMPLEMENTED    RTS_IEC_DWORD_C(0x9006)	
#define ERR_MYSQL_CLIENT_SERVER_LOST_EXTENDED    RTS_IEC_DWORD_C(0x9007)	
#define ERR_MYSQL_CLIENT_STMT_CLOSED    RTS_IEC_DWORD_C(0x9008)	
#define ERR_MYSQL_CLIENT_NEW_STMT_METADATA    RTS_IEC_DWORD_C(0x9009)	
#define ERR_MYSQL_CLIENT_ALREADY_CONNECTED    RTS_IEC_DWORD_C(0x900A)	
#define ERR_MYSQL_CLIENT_AUTH_PLUGIN_CANNOT_LOAD    RTS_IEC_DWORD_C(0x900B)	
#define ERR_MYSQL_CLIENT_DUPLICATE_CONNECTION_ATTR    RTS_IEC_DWORD_C(0x900C)	
#define ERR_MYSQL_CLIENT_AUTH_PLUGIN_ERR    RTS_IEC_DWORD_C(0x900D)	
#define ERR_MYSQL_ERROR_LAST    RTS_IEC_DWORD_C(0x9034)	/* MYSQL_ERROR_FIRST+2100 */
#define ERR_SQLITE_ERROR_FIRST    RTS_IEC_DWORD_C(0x9035)	/* SQLITE Bereich */
#define ERR_SQLITE_ERROR    RTS_IEC_DWORD_C(0x9036)	/* generic error */
#define ERR_SQLITE_INTERNAL    RTS_IEC_DWORD_C(0x9037)	/* Internal logic error in SQLite */
#define ERR_SQLITE_PERM    RTS_IEC_DWORD_C(0x9038)	/* Access permission denied */
#define ERR_SQLITE_ABORT    RTS_IEC_DWORD_C(0x9039)	/* Callback routine requested an abort */
#define ERR_SQLITE_BUSY    RTS_IEC_DWORD_C(0x903A)	/* The database file is locked */
#define ERR_SQLITE_LOCKED    RTS_IEC_DWORD_C(0x903B)	/* A table in the database is locked */
#define ERR_SQLITE_NOMEM    RTS_IEC_DWORD_C(0x903C)	/* A malloc() failed */
#define ERR_SQLITE_READONLY    RTS_IEC_DWORD_C(0x903D)	/* Attempt to write a readonly database */
#define ERR_SQLITE_INTERRUPT    RTS_IEC_DWORD_C(0x903E)	/* Operation terminated by sqlite3_interrupt() */
#define ERR_SQLITE_IOERR    RTS_IEC_DWORD_C(0x903F)	/* Some kind of disk I/O error occurred */
#define ERR_SQLITE_CORRUPT    RTS_IEC_DWORD_C(0x9040)	/* The database disk image is malformed */
#define ERR_SQLITE_NOTFOUND    RTS_IEC_DWORD_C(0x9041)	/* Unknown opcode in sqlite3_file_control() */
#define ERR_SQLITE_FULL    RTS_IEC_DWORD_C(0x9042)	/* Insertion failed because database is full */
#define ERR_SQLITE_CANTOPEN    RTS_IEC_DWORD_C(0x9043)	/* Insertion failed because database is full */
#define ERR_SQLITE_PROTOCOL    RTS_IEC_DWORD_C(0x9044)	/* Database lock protocol error */
#define ERR_SQLITE_EMPTY    RTS_IEC_DWORD_C(0x9045)	/* Internal use only */
#define ERR_SQLITE_SCHEMA    RTS_IEC_DWORD_C(0x9046)	/* The database schema changed */
#define ERR_SQLITE_TOOBIG    RTS_IEC_DWORD_C(0x9047)	/* String or BLOB exceeds size limit */
#define ERR_SQLITE_CONSTRAINT    RTS_IEC_DWORD_C(0x9048)	/* Abort due to constraint violation */
#define ERR_SQLITE_MISMATCH    RTS_IEC_DWORD_C(0x9049)	/* Data type mismatch */
#define ERR_SQLITE_MISUSE    RTS_IEC_DWORD_C(0x904A)	/* Library used incorrectly */
#define ERR_SQLITE_NOLFS    RTS_IEC_DWORD_C(0x904B)	/* Uses OS features not supported on host */
#define ERR_SQLITE_AUTH    RTS_IEC_DWORD_C(0x904C)	/* Authorization denied */
#define ERR_SQLITE_FORMAT    RTS_IEC_DWORD_C(0x904D)	/* ANot used */
#define ERR_SQLITE_RANGE    RTS_IEC_DWORD_C(0x904E)	/* 2nd parameter to sqlite3_bind out of range */
#define ERR_SQLITE_NOTADB    RTS_IEC_DWORD_C(0x904F)	/* File opened that is not a database file */
#define ERR_SQLITE_NOTICE    RTS_IEC_DWORD_C(0x9050)	/* Notifications from sqlite3_log() */
#define ERR_SQLITE_WARNING    RTS_IEC_DWORD_C(0x9051)	/* Warnings from sqlite3_log() */
#define ERR_SQLITE_ROW    RTS_IEC_DWORD_C(0x9098)	/* sqlite3_step() has another row ready */
#define ERR_SQLITE_DONE    RTS_IEC_DWORD_C(0x9099)	/* sqlite3_step() has finished executing */
#define ERR_SQLITE_ERROR_LAST    RTS_IEC_DWORD_C(0x90A0)	/* end-of-error-codes 
SQLITE_ERROR_FIRST+108(16#6C) */
/* Typed enum definition */
#define ERR    RTS_IEC_DWORD

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ISysError_C;

#ifdef CPLUSPLUS
class ISysError : public IBase
{
	public:
};
	#ifndef ITF_SysError
		#define ITF_SysError static ISysError *pISysError = NULL;
	#endif
	#define EXTITF_SysError
#else	/*CPLUSPLUS*/
	typedef ISysError_C		ISysError;
	#ifndef ITF_SysError
		#define ITF_SysError
	#endif
	#define EXTITF_SysError
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_SYSERRORITF_H_*/
