 /**
 * <interfacename>WSServer</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WSSERVERITF_H_
#define _WSSERVERITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Constants
 */
#define MAX_CLIENTS		RTS_IEC_DWORD_C(0x1E)	/* Maximum number of clients allowed to be simultanly connected to the server. */

/**
 * <description>
 * The backend (IEC-Application) can specify via the RegisterCallback function a callback function to be called by the WS-Server, in one of the following cases:
 * </description>
 * <element name="CALLBACKTYPEENUM_VALIDATE_LOGIN" type=OUT>The backend can validate if an user is allowed to login. The callback must have the following prototype:
	
 .. code-block:: codesys

	FUNCTION ValidateLoginCallbackFun : RTS_IEC_RESULT
	VAR_IN_OUT
		inoutParam : ValidateLoginStruct;
	END_VAR 
</element>
 * <element name="CALLBACKTYPEENUM_VALIDATE_SET" type=OUT>The backend can validate if an user is allowed to change a data point / parameter value. The callback must have the following prototype:
	
 .. code-block:: codesys

	FUNCTION ValidateSetCallbackFun : RTS_IEC_RESULT
	VAR_IN_OUT
		inoutParam : ValidateSetStruct;
	END_VAR
</element>
 * <element name="CALLBACKTYPEENUM_VALIDATE_LOGIN2" type=OUT>The backend checks if an authentication token is valid to login. 
 inAuthToken is a valid pointer only during this call. Please save it to use it later, if needed.
 The callback must have the following prototype:

 .. code-block:: codesys

	FUNCTION ValidateLogin2CallbackFun : RTS_IEC_RESULT
	VAR_INPUT
		inAuthToken : POINTER TO BYTE;
	END_VAR
 VAR_OUTPUT
 	outUserName: STRING;
	END_VAR
</element>
 * <element name="CALLBACKTYPEENUM_VALIDATE_GET" type=OUT>The backend can validate if an user is allowed to read a data point / parameter value. The callback must have the following prototype:
	
 .. code-block:: codesys

	FUNCTION ValidateGetCallbackFun : RTS_IEC_RESULT
	VAR_IN_OUT
		inoutParam : ValidateGetStruct;
	END_VAR

 The WSServer will call it by each of the following clients requests: get, getinfo, reg.
</element>
*/
#define CALLBACKTYPEENUM_VALIDATE_LOGIN    RTS_IEC_INT_C(0x0)
#define CALLBACKTYPEENUM_VALIDATE_SET    RTS_IEC_INT_C(0x1)
#define CALLBACKTYPEENUM_VALIDATE_LOGIN2    RTS_IEC_INT_C(0x2)
#define CALLBACKTYPEENUM_VALIDATE_GET    RTS_IEC_INT_C(0x3)
/* Typed enum definition */
#define CALLBACKTYPEENUM    RTS_IEC_INT

/**
 * <description>
 * Enumeration: ConnectionTypeEnum
 * </description>
 * <element name="CONNECTIONTYPEENUM_WS_ONLY" type=OUT>WebSocket connection</element>
 * <element name="CONNECTIONTYPEENUM_WSS_ONLY" type=OUT>secure WebSocket connection</element>
*/
#define CONNECTIONTYPEENUM_WS_ONLY    RTS_IEC_INT_C(0x0)
#define CONNECTIONTYPEENUM_WSS_ONLY    RTS_IEC_INT_C(0x1)
/* Typed enum definition */
#define CONNECTIONTYPEENUM    RTS_IEC_INT

/**
 * <description>
 * The server parameters can be set either via:
 * 
 * * the configuration file (CoDeSys Ctrl.cfg) of the CoDeSys runtime system
 * * or via this CoDeSys external library, function SetParameter
 * </description>
 * <element name="PARAMETERENUM_PORT" type=OUT>'PortNr': defines the MotanWS-Server Port; default: the 3S-WebServerPortNr; Any change needs a new start des Runtimes. It can be changed only in the CFG file.</element>
 * <element name="PARAMETERENUM_MAXCLIENTS" type=OUT>'MaxClients': defines the maximum number of simultaneous connections. Any change has live effect. The actual connections are still valid.</element>
 * <element name="PARAMETERENUM_REFRESH_TIME" type=OUT>'RefreshTime': defines the minimum time (in milliseconds) in which the client will be informed about value changes of the registered data points. Default: 0. A value of 0 means that the server informs the client as soon as possible about value change.	Priority has any entered 'RefreshTime' per data point or any 'refresh' request per client. Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_PING_TIME" type=OUT>'PingTime': defines the timeout in milliseconds without client activity - the server receives no request from clients - until the server sends the first PING request. A value of 0 disables the PING / PONG mechanism. Default: 5000 (5 seconds).  Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_PING_INTERVAL" type=OUT>'PingInterval': defines the interval in milliseconds between successive ping requests if no response was received. Default: 1000 (1 second). 0 or negative values are not allowed. If PingRetry is 0, the PingInterval setting has no meaning.  Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_PING_RETRY" type=OUT>'PingRetry': defines how many times the server will try to send a ping request before the connection is closed. Default:. 3. A value of 0 has no meaning. Only positive values are allowed, including 0.  Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_KA_TIME" type=OUT>'KaTime': defines the timeout in milliseconds with no activity until the server sends the first TCP keepalive request.A value of 0 disables the TCP keep alive mechanism. Default: 0. (disabled).  Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_KA_INTERVAL" type=OUT>'KaInterval': defines the interval in milliseconds between successive TCP keepalive requests if no response is received. Default: 0. (disabled).  Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_KA_RETRY" type=OUT>'KaRetry': defines how often the TCP stack attempts to send a TCP keepalive request before the connection is closed. Default: 0 (disabled). Only positive values are allowed, including 0. Often KARetry is not supported. In this case in the log-file is displayed the message: "KARetry not supported.". Under Windows CE the following registry entries must exist:

* HKLM \ Comm \ Tcpip \ Parms \ KeepAliveTime
* HKLM \ Comm \ Tcpip \ Parms \ KeepAliveInterval

The server checks if these entries exist and eventuelly creates it. In this case, the CoDeSysControl.exe must be restarted.
Any change has effect only for the new connections and not for the actual ones.</element>
 * <element name="PARAMETERENUM_CONNECTION_TYPE" type=OUT>'ConnectionType': defines the connection type; default: WS_ONLY; see enum ConnectionTypeEnum. Any change needs a new start des Runtimes. It can be changed only in the CFG file.</element>
 * <element name="PARAMETERENUM_TASK_PRIORITY" type=OUT>'TaskPriority':  Task Priority; Can be 0..256 see SysTask.TaskPriorities; default: 256 (Idle)</element>
 * <element name="PARAMETERENUM_TASK_INTERVAL" type=OUT>'TaskInterval':  Task Interval in microseconds; default: 1000 = 1ms</element>
 * <element name="PARAMETERENUM_BUFFERSIZE" type=OUT>''BufferSize': Buffer size in kb; default: 200 (kb)'</element>
*/
#define PARAMETERENUM_PORT    RTS_IEC_INT_C(0x0)
#define PARAMETERENUM_MAXCLIENTS    RTS_IEC_INT_C(0x1)
#define PARAMETERENUM_REFRESH_TIME    RTS_IEC_INT_C(0x2)
#define PARAMETERENUM_PING_TIME    RTS_IEC_INT_C(0x3)
#define PARAMETERENUM_PING_INTERVAL    RTS_IEC_INT_C(0x4)
#define PARAMETERENUM_PING_RETRY    RTS_IEC_INT_C(0x5)
#define PARAMETERENUM_KA_TIME    RTS_IEC_INT_C(0x6)
#define PARAMETERENUM_KA_INTERVAL    RTS_IEC_INT_C(0x7)
#define PARAMETERENUM_KA_RETRY    RTS_IEC_INT_C(0x8)
#define PARAMETERENUM_CONNECTION_TYPE    RTS_IEC_INT_C(0x9)
#define PARAMETERENUM_TASK_PRIORITY    RTS_IEC_INT_C(0xA)
#define PARAMETERENUM_TASK_INTERVAL    RTS_IEC_INT_C(0xB)
#define PARAMETERENUM_BUFFERSIZE    RTS_IEC_INT_C(0xC)
/* Typed enum definition */
#define PARAMETERENUM    RTS_IEC_INT

/**
 * <description>
 * 	"call":{
 * 			"proc":"RPCTestFun",
 * 			"authtoken":"M2IxMjhmZjEtNDc1MS00Nz",
 * 			"parameter":{
 * 				"inBOOL":true,
 * 				"inDWORD":2000,
 * 				"inREAL":0.4,
 * 				"inSTRING":"adbc"
 * 			}
 * 		},
 * 		"uuid":"Lcl8cXTqQ8qP28InaM0KWQ=="
 * 	}
 * </description>
 * <element name="RPCTYPEENUM_RPCTYPE_STRING" type=OUT>RPCTYPE_STRING: The paramters are represented as an array of RPParaStruct (STRING, STRING).
 The RPC function prototype:

 FUNCTION RPCTestFun : RTS_IEC_RESULT
	VAR_INPUT
		User : STRING;						// current user name
		Local : BOOL;						// TRUE if the user is connected locally
		ParaCount : WORD;					// count of input parameter
		ParaList : POINTER TO RPParaStruct;	// parameter list as array of objects of type RPParaStruct
		ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
	END_VAR
	VAR_OUTPUT
		ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
											// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
	END_VAR</element>
 * <element name="RPCTYPEENUM_RPCTYPE_POINTER" type=OUT>RPCTYPE_POINTER: The paramters are represented as POINTER TO BYTE
 The RPC function prototype:

 FUNCTION RPCTest2Fun : RTS_IEC_RESULT
	VAR_INPUT
		User : STRING;						// current user name
		Local : BOOL;						// TRUE if the user is connected locally
		ParaSize : DWORD;					// size of the Parameter
		Parameter : POINTER TO BYTE;		// parameter as POINTER TO BYTE (UTF8)
		Value : POINTER TO BYTE;			// parameter as POINTER TO BYTE (UTF8)
	END_VAR
	VAR_OUTPUT
		ValueSize : DWORD;					// Size of the Value
											// Not greater as the ValueSize parameter of the RegisterRP2Fun functionn.!!
	END_VAR</element>
*/
#define RPCTYPEENUM_RPCTYPE_STRING    RTS_IEC_INT_C(0x0)
#define RPCTYPEENUM_RPCTYPE_POINTER    RTS_IEC_INT_C(0x1)
/* Typed enum definition */
#define RPCTYPEENUM    RTS_IEC_INT

/**
 * <description>
 * Structure: RPParaStruct
 * </description>
 * <element name="ParaName" type=INOUT>Parameter Name</element>
 * <element name="ParaValue" type=INOUT>Parameter Value</element>
*/
typedef struct tagRPParaStruct
{
	RTS_IEC_STRING ParaName[81];
	RTS_IEC_STRING ParaValue[81];
} RPParaStruct;

/**
 * <description>
 * Defines the callback function/FB-method to be called from the WS-WebService
 * by a defined action.
 * </description>
 * <element name="pThis" type=INOUT>Pointer to the function block instance. NULL when the callback is not part of a function block.</element>
 * <element name="pCB" type=INOUT>Pointer to the callback function to be called.</element>
*/
typedef struct tagCallbackStruct
{
	RTS_IEC_BYTE *pThis;
	RTS_IEC_BYTE *pCB;
} CallbackStruct;

/**
 * <description>
 * Part of the ServerStateStruct structure which defines the server state.
 * Defines the information that can be get about a connected client.
 * </description>
 * <element name="IpAddress" type=INOUT>The ip address of the client connected to the server.</element>
 * <element name="RefreshTime" type=INOUT>The RefreshTime property set by the client via a 'refresh'-request.</element>
 * <element name="OPCUAServerURL" type=INOUT>The OPCURL when available</element>
*/
typedef struct tagClientConnectionStruct
{
	RTS_IEC_STRING IpAddress[17];
	RTS_IEC_DWORD RefreshTime;
	RTS_IEC_STRING OPCUAServerURL[256];
} ClientConnectionStruct;

/**
 * <description>
 * Defines the information that can be get about the server at a moment.
 * </description>
 * <element name="CountOfClients" type=INOUT>Number of connected clients.</element>
 * <element name="ClientConnections" type=INOUT>The information for each connected client.</element>
*/
typedef struct tagServerStateStruct
{
	RTS_IEC_DWORD CountOfClients;
	ClientConnectionStruct ClientConnections[MAX_CLIENTS - 0];
} ServerStateStruct;

/**
 * <description>
 * Defines the input parameters for the callback function to be called by the server to validate a client for get.
 * RegisterCallback(VALIDATE_GET, ValidateGetCallbackStructInst).
 * </description>
 * <element name="Path" type=INOUT>Data point/parameter path.</element>
 * <element name="User" type=INOUT>User name.</element>
 * <element name="Local" type=INOUT>TRUE if the user is logged in at a local client.</element>
*/
typedef struct tagValidateGetStruct
{
	RTS_IEC_STRING Path[256];
	RTS_IEC_STRING User[81];
	RTS_IEC_BOOL Local;
} ValidateGetStruct;

/**
 * <description>
 * Defines the input parameters for the callback function to be called by the server to validate a client for login.
 * RegisterCallback(VALIDATE_LOGIN, ValidateLoginCallbackStructInst).
 * </description>
 * <element name="UserName" type=INOUT>User name.</element>
 * <element name="Pwd" type=INOUT>User password.</element>
*/
typedef struct tagValidateLoginStruct
{
	RTS_IEC_STRING UserName[81];
	RTS_IEC_STRING Pwd[81];
} ValidateLoginStruct;

/**
 * <description>
 * Defines the input parameters for the callback function to be called by the server to validate a client for set.
 * RegisterCallback(VALIDATE_SET, ValidateSetCallbackStructInst).
 * </description>
 * <element name="Path" type=INOUT>Data point/parameter path.</element>
 * <element name="User" type=INOUT>User name.</element>
 * <element name="Local" type=INOUT>TRUE if the user is logged in at a local client.</element>
*/
typedef struct tagValidateSetStruct
{
	RTS_IEC_STRING Path[256];
	RTS_IEC_STRING User[81];
	RTS_IEC_BOOL Local;
} ValidateSetStruct;

/**
 * <description>
 * 	Adds an IP address as local client to the CFG file. Entry 'LocalClient.X=IP'.
 * 	:return: see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success; the IP was already in the CFG; the server must not be restarted.
 * 	+ ERR_WS_NEWSTART_NEED: the CoDeSys runtime must be restarted.
 * 	+ ERR_PARAMETER: invalid IP. Broadcast IP is not allowed.
 * </description>
 * <element name="AddLocalClientFun" type=OUT></element>
 * <element name="sIP" type=IN>IPV4 Address in String Format</element>
*/
typedef struct tagaddlocalclientfun_struct
{
	RTS_IEC_STRING sIP[81];
	RTS_IEC_RESULT AddLocalClientFun;
} addlocalclientfun_struct;

void CDECL CDECL_EXT addlocalclientfun(addlocalclientfun_struct *p);
typedef void (CDECL CDECL_EXT* PFADDLOCALCLIENTFUN_IEC) (addlocalclientfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(ADDLOCALCLIENTFUN_NOTIMPLEMENTED)
	#define USE_addlocalclientfun
	#define EXT_addlocalclientfun
	#define GET_addlocalclientfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_addlocalclientfun(p0) 
	#define CHK_addlocalclientfun  FALSE
	#define EXP_addlocalclientfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_addlocalclientfun
	#define EXT_addlocalclientfun
	#define GET_addlocalclientfun(fl)  CAL_CMGETAPI( "addlocalclientfun" ) 
	#define CAL_addlocalclientfun  addlocalclientfun
	#define CHK_addlocalclientfun  TRUE
	#define EXP_addlocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"addlocalclientfun", (RTS_UINTPTR)addlocalclientfun, 1, 0xA29BCA1B, 0x03051314) 
	#define EXTREF_ITF_addlocalclientfun {(RTS_VOID_FCTPTR)addlocalclientfun, "addlocalclientfun", 0xA29BCA1B, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_addlocalclientfun
	#define EXT_addlocalclientfun
	#define GET_addlocalclientfun(fl)  CAL_CMGETAPI( "addlocalclientfun" ) 
	#define CAL_addlocalclientfun  addlocalclientfun
	#define CHK_addlocalclientfun  TRUE
	#define EXP_addlocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"addlocalclientfun", (RTS_UINTPTR)addlocalclientfun, 1, 0xA29BCA1B, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServeraddlocalclientfun
	#define EXT_WSServeraddlocalclientfun
	#define GET_WSServeraddlocalclientfun  ERR_OK
	#define CAL_WSServeraddlocalclientfun  addlocalclientfun
	#define CHK_WSServeraddlocalclientfun  TRUE
	#define EXP_WSServeraddlocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"addlocalclientfun", (RTS_UINTPTR)addlocalclientfun, 1, 0xA29BCA1B, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_addlocalclientfun
	#define EXT_addlocalclientfun
	#define GET_addlocalclientfun(fl)  CAL_CMGETAPI( "addlocalclientfun" ) 
	#define CAL_addlocalclientfun  addlocalclientfun
	#define CHK_addlocalclientfun  TRUE
	#define EXP_addlocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"addlocalclientfun", (RTS_UINTPTR)addlocalclientfun, 1, 0xA29BCA1B, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_addlocalclientfun  PFADDLOCALCLIENTFUN_IEC pfaddlocalclientfun;
	#define EXT_addlocalclientfun  extern PFADDLOCALCLIENTFUN_IEC pfaddlocalclientfun;
	#define GET_addlocalclientfun(fl)  s_pfCMGetAPI2( "addlocalclientfun", (RTS_VOID_FCTPTR *)&pfaddlocalclientfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA29BCA1B, 0x03051314)
	#define CAL_addlocalclientfun  pfaddlocalclientfun
	#define CHK_addlocalclientfun  (pfaddlocalclientfun != NULL)
	#define EXP_addlocalclientfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"addlocalclientfun", (RTS_UINTPTR)addlocalclientfun, 1, 0xA29BCA1B, 0x03051314) 
#endif


/**
 * <description>
 * It calls a RPC (Remote Procedure Call) which is registered to the server (RPCTYPE_STRING), either via IEC or inside of an elrest component.
 * When ValueCount is not null and ValueList is null, then the function returns to the ValueCount the count of output parameters.
 * 
 * 	:return: see SysError.library and CmpErrors.library
 * 	+ Return code of the function entered by Name
 * 	+ ERR_OK: success;
 * 	+ ERR_NO_OBJECT: function name not found
 * 	+ ERR_PARA_NOK: if ParaCount>0 and ParaList is null
 * </description>
 * <element name="Call" type=OUT></element>
 * <element name="Name" type=IN>function name to call it; not casesensitive</element>
 * <element name="ParaCount" type=IN>count of input parameter</element>
 * <element name="ParaList" type=IN>parameter list as array of objects of type RPParaStruct</element>
 * <element name="ValueCount" type=IN>in/out-put Count of values which are retuned to the ValueList parameter.</element>
 * <element name="ValueList" type=IN>in/out-put values list as array of objects of type RPParaStruct</element>
*/
typedef struct tagcall_struct
{
	RTS_IEC_STRING Name[81];
	RTS_IEC_WORD ParaCount;
	RPParaStruct *ParaList;
	RTS_IEC_WORD *ValueCount;
	RPParaStruct *ValueList;
	RTS_IEC_RESULT Call;
} call_struct;

void CDECL CDECL_EXT call(call_struct *p);
typedef void (CDECL CDECL_EXT* PFCALL_IEC) (call_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(CALL_NOTIMPLEMENTED)
	#define USE_call
	#define EXT_call
	#define GET_call(fl)  ERR_NOTIMPLEMENTED
	#define CAL_call(p0) 
	#define CHK_call  FALSE
	#define EXP_call  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_call
	#define EXT_call
	#define GET_call(fl)  CAL_CMGETAPI( "call" ) 
	#define CAL_call  call
	#define CHK_call  TRUE
	#define EXP_call  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call", (RTS_UINTPTR)call, 1, 0x1DAEFC73, 0x03051314) 
	#define EXTREF_ITF_call {(RTS_VOID_FCTPTR)call, "call", 0x1DAEFC73, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_call
	#define EXT_call
	#define GET_call(fl)  CAL_CMGETAPI( "call" ) 
	#define CAL_call  call
	#define CHK_call  TRUE
	#define EXP_call  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call", (RTS_UINTPTR)call, 1, 0x1DAEFC73, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServercall
	#define EXT_WSServercall
	#define GET_WSServercall  ERR_OK
	#define CAL_WSServercall  call
	#define CHK_WSServercall  TRUE
	#define EXP_WSServercall  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call", (RTS_UINTPTR)call, 1, 0x1DAEFC73, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_call
	#define EXT_call
	#define GET_call(fl)  CAL_CMGETAPI( "call" ) 
	#define CAL_call  call
	#define CHK_call  TRUE
	#define EXP_call  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call", (RTS_UINTPTR)call, 1, 0x1DAEFC73, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_call  PFCALL_IEC pfcall;
	#define EXT_call  extern PFCALL_IEC pfcall;
	#define GET_call(fl)  s_pfCMGetAPI2( "call", (RTS_VOID_FCTPTR *)&pfcall, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1DAEFC73, 0x03051314)
	#define CAL_call  pfcall
	#define CHK_call  (pfcall != NULL)
	#define EXP_call   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call", (RTS_UINTPTR)call, 1, 0x1DAEFC73, 0x03051314) 
#endif

/**
 * <description>
 * It calls a RPC (Remote Procedure Call) which is registered to the server(RPCTYPE_POINTER), either via IEC or inside of an elrest component.
 * When ValueCount is not null and ValueList is null, then the function returns to the ValueCount the count of output parameters.
 * 
 * 	:return: see SysError.library and CmpErrors.library
 * 	+ Return code of the function entered by Name
 * 	+ ERR_OK: success;
 * 	+ ERR_NO_OBJECT: function name not found
 * 	+ ERR_PARA_NOK: if ParaCount>0 and ParaList is null
 * </description>
 * <element name="Call2" type=OUT></element>
 * <element name="Name" type=IN>function name to call it; not casesensitive</element>
 * <element name="ParaSize" type=IN>size of the buffer Parameter</element>
 * <element name="Parameter" type=IN>parameter buffer</element>
 * <element name="ValueSize" type=IN>in/out-put Size of Value buffer which are retuned to the Value parameter.</element>
 * <element name="Value" type=IN>in/out-put values</element>
*/
typedef struct tagcall2_struct
{
	RTS_IEC_STRING Name[81];
	RTS_IEC_DWORD ParaSize;
	RTS_IEC_BYTE *Parameter;
	RTS_IEC_DWORD *ValueSize;
	RTS_IEC_BYTE *Value;
	RTS_IEC_RESULT Call2;
} call2_struct;

void CDECL CDECL_EXT call2(call2_struct *p);
typedef void (CDECL CDECL_EXT* PFCALL2_IEC) (call2_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(CALL2_NOTIMPLEMENTED)
	#define USE_call2
	#define EXT_call2
	#define GET_call2(fl)  ERR_NOTIMPLEMENTED
	#define CAL_call2(p0) 
	#define CHK_call2  FALSE
	#define EXP_call2  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_call2
	#define EXT_call2
	#define GET_call2(fl)  CAL_CMGETAPI( "call2" ) 
	#define CAL_call2  call2
	#define CHK_call2  TRUE
	#define EXP_call2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call2", (RTS_UINTPTR)call2, 1, 0x6C3EAAEF, 0x03051314) 
	#define EXTREF_ITF_call2 {(RTS_VOID_FCTPTR)call2, "call2", 0x6C3EAAEF, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_call2
	#define EXT_call2
	#define GET_call2(fl)  CAL_CMGETAPI( "call2" ) 
	#define CAL_call2  call2
	#define CHK_call2  TRUE
	#define EXP_call2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call2", (RTS_UINTPTR)call2, 1, 0x6C3EAAEF, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServercall2
	#define EXT_WSServercall2
	#define GET_WSServercall2  ERR_OK
	#define CAL_WSServercall2  call2
	#define CHK_WSServercall2  TRUE
	#define EXP_WSServercall2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call2", (RTS_UINTPTR)call2, 1, 0x6C3EAAEF, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_call2
	#define EXT_call2
	#define GET_call2(fl)  CAL_CMGETAPI( "call2" ) 
	#define CAL_call2  call2
	#define CHK_call2  TRUE
	#define EXP_call2  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call2", (RTS_UINTPTR)call2, 1, 0x6C3EAAEF, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_call2  PFCALL2_IEC pfcall2;
	#define EXT_call2  extern PFCALL2_IEC pfcall2;
	#define GET_call2(fl)  s_pfCMGetAPI2( "call2", (RTS_VOID_FCTPTR *)&pfcall2, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6C3EAAEF, 0x03051314)
	#define CAL_call2  pfcall2
	#define CHK_call2  (pfcall2 != NULL)
	#define EXP_call2   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"call2", (RTS_UINTPTR)call2, 1, 0x6C3EAAEF, 0x03051314) 
#endif


/**
 * <description>
 * 	Gets the local clients to a string array.
 * 	
 * | When the function parameter inoutLocalClients is NULL, then the count of local clients will be returned to the in/out parameter inoutCountOfLocalClients and the size of one client will be returned to the in/out parameter inoutSizeOfOneClient.
 * | Otherwise, when the buffer size is enough, then the actual number of local clients is returned to the inoutCountOfLocalClients function parameter and the local clients are returned to the inoutLocalClients function parameter as an array of IPv4 Addresses in string format.
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success.
 * 	+ ERR_PARAMETER: inoutLocalClients is NULL or (inoutLocalClients <> NULL and inoutCountOfLocalClients <> 0 and inoutLocalClients = NULL).
 * 	+ ERR_BUFFERSIZE: buffer size is too small; in this case,  the necessary size is returned to the inoutSizeOfOneClient and the inoutCountOfLocalClients function parameters.
 * 	+ ERR_FAILED: internal error.
 * </description>
 * <element name="GetAllLocalClientsFun" type=OUT></element>
 * <element name="bFromCFG" type=IN>|	**TRUE**, when the values will be read from the CFG file.
|	**FALSE**, when the values will be read FROM the server side.
|	The WS Server reads only once the CFG-file, by starting. All other changes to the CFG-file have effect only by next start of the WS Server.</element>
 * <element name="pLocalClients" type=IN>Buffer for the string array of configured local clients. The buffer size is inoutCountOfLocalClients*inoutSizeOfOneClient.</element>
 * <element name="nSizeOfOneClient" type=INOUT>Size of one client. sizeof(STRING)</element>
 * <element name="nCountOfLocalClients" type=INOUT>Count of array elements of type STRING.</element>
*/
typedef struct taggetalllocalclientsfun_struct
{
	RTS_IEC_BOOL bFromCFG;
	RTS_IEC_STRING *pLocalClients;
	RTS_IEC_DWORD *nSizeOfOneClient;
	RTS_IEC_DWORD *nCountOfLocalClients;
	RTS_IEC_RESULT GetAllLocalClientsFun;
} getalllocalclientsfun_struct;

void CDECL CDECL_EXT getalllocalclientsfun(getalllocalclientsfun_struct *p);
typedef void (CDECL CDECL_EXT* PFGETALLLOCALCLIENTSFUN_IEC) (getalllocalclientsfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(GETALLLOCALCLIENTSFUN_NOTIMPLEMENTED)
	#define USE_getalllocalclientsfun
	#define EXT_getalllocalclientsfun
	#define GET_getalllocalclientsfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_getalllocalclientsfun(p0) 
	#define CHK_getalllocalclientsfun  FALSE
	#define EXP_getalllocalclientsfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_getalllocalclientsfun
	#define EXT_getalllocalclientsfun
	#define GET_getalllocalclientsfun(fl)  CAL_CMGETAPI( "getalllocalclientsfun" ) 
	#define CAL_getalllocalclientsfun  getalllocalclientsfun
	#define CHK_getalllocalclientsfun  TRUE
	#define EXP_getalllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getalllocalclientsfun", (RTS_UINTPTR)getalllocalclientsfun, 1, 0xD2A04FD2, 0x03051314) 
	#define EXTREF_ITF_getalllocalclientsfun {(RTS_VOID_FCTPTR)getalllocalclientsfun, "getalllocalclientsfun", 0xD2A04FD2, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_getalllocalclientsfun
	#define EXT_getalllocalclientsfun
	#define GET_getalllocalclientsfun(fl)  CAL_CMGETAPI( "getalllocalclientsfun" ) 
	#define CAL_getalllocalclientsfun  getalllocalclientsfun
	#define CHK_getalllocalclientsfun  TRUE
	#define EXP_getalllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getalllocalclientsfun", (RTS_UINTPTR)getalllocalclientsfun, 1, 0xD2A04FD2, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServergetalllocalclientsfun
	#define EXT_WSServergetalllocalclientsfun
	#define GET_WSServergetalllocalclientsfun  ERR_OK
	#define CAL_WSServergetalllocalclientsfun  getalllocalclientsfun
	#define CHK_WSServergetalllocalclientsfun  TRUE
	#define EXP_WSServergetalllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getalllocalclientsfun", (RTS_UINTPTR)getalllocalclientsfun, 1, 0xD2A04FD2, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_getalllocalclientsfun
	#define EXT_getalllocalclientsfun
	#define GET_getalllocalclientsfun(fl)  CAL_CMGETAPI( "getalllocalclientsfun" ) 
	#define CAL_getalllocalclientsfun  getalllocalclientsfun
	#define CHK_getalllocalclientsfun  TRUE
	#define EXP_getalllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getalllocalclientsfun", (RTS_UINTPTR)getalllocalclientsfun, 1, 0xD2A04FD2, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_getalllocalclientsfun  PFGETALLLOCALCLIENTSFUN_IEC pfgetalllocalclientsfun;
	#define EXT_getalllocalclientsfun  extern PFGETALLLOCALCLIENTSFUN_IEC pfgetalllocalclientsfun;
	#define GET_getalllocalclientsfun(fl)  s_pfCMGetAPI2( "getalllocalclientsfun", (RTS_VOID_FCTPTR *)&pfgetalllocalclientsfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD2A04FD2, 0x03051314)
	#define CAL_getalllocalclientsfun  pfgetalllocalclientsfun
	#define CHK_getalllocalclientsfun  (pfgetalllocalclientsfun != NULL)
	#define EXP_getalllocalclientsfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getalllocalclientsfun", (RTS_UINTPTR)getalllocalclientsfun, 1, 0xD2A04FD2, 0x03051314) 
#endif


/**
 * <description>
 * 	Gets a server parameter specified by enParameter.
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success;
 * 	+ ERR_FAILED: internal error; server is not initialised;or key not found in CFG when inCFG is TRUE.
 * 	+ ERR_PARAMETER: unknown parameter or inoutValue is NULL;
 * </description>
 * <element name="GetParameterFun" type=OUT></element>
 * <element name="enParameter" type=IN>Parameter to get.</element>
 * <element name="pValue" type=IN>Buffer for the parameter value.</element>
 * <element name="bCFG" type=IN>TRUE to get the value from CFG file, FALSE to get the value which the Server actually uses.</element>
*/
typedef struct taggetparameterfun_struct
{
	RTS_IEC_INT enParameter;
	RTS_IEC_DWORD *pValue;
	RTS_IEC_BOOL bCFG;
	RTS_IEC_RESULT GetParameterFun;
} getparameterfun_struct;

void CDECL CDECL_EXT getparameterfun(getparameterfun_struct *p);
typedef void (CDECL CDECL_EXT* PFGETPARAMETERFUN_IEC) (getparameterfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(GETPARAMETERFUN_NOTIMPLEMENTED)
	#define USE_getparameterfun
	#define EXT_getparameterfun
	#define GET_getparameterfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_getparameterfun(p0) 
	#define CHK_getparameterfun  FALSE
	#define EXP_getparameterfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_getparameterfun
	#define EXT_getparameterfun
	#define GET_getparameterfun(fl)  CAL_CMGETAPI( "getparameterfun" ) 
	#define CAL_getparameterfun  getparameterfun
	#define CHK_getparameterfun  TRUE
	#define EXP_getparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getparameterfun", (RTS_UINTPTR)getparameterfun, 1, 0x631D455F, 0x03051314) 
	#define EXTREF_ITF_getparameterfun {(RTS_VOID_FCTPTR)getparameterfun, "getparameterfun", 0x631D455F, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_getparameterfun
	#define EXT_getparameterfun
	#define GET_getparameterfun(fl)  CAL_CMGETAPI( "getparameterfun" ) 
	#define CAL_getparameterfun  getparameterfun
	#define CHK_getparameterfun  TRUE
	#define EXP_getparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getparameterfun", (RTS_UINTPTR)getparameterfun, 1, 0x631D455F, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServergetparameterfun
	#define EXT_WSServergetparameterfun
	#define GET_WSServergetparameterfun  ERR_OK
	#define CAL_WSServergetparameterfun  getparameterfun
	#define CHK_WSServergetparameterfun  TRUE
	#define EXP_WSServergetparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getparameterfun", (RTS_UINTPTR)getparameterfun, 1, 0x631D455F, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_getparameterfun
	#define EXT_getparameterfun
	#define GET_getparameterfun(fl)  CAL_CMGETAPI( "getparameterfun" ) 
	#define CAL_getparameterfun  getparameterfun
	#define CHK_getparameterfun  TRUE
	#define EXP_getparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getparameterfun", (RTS_UINTPTR)getparameterfun, 1, 0x631D455F, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_getparameterfun  PFGETPARAMETERFUN_IEC pfgetparameterfun;
	#define EXT_getparameterfun  extern PFGETPARAMETERFUN_IEC pfgetparameterfun;
	#define GET_getparameterfun(fl)  s_pfCMGetAPI2( "getparameterfun", (RTS_VOID_FCTPTR *)&pfgetparameterfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x631D455F, 0x03051314)
	#define CAL_getparameterfun  pfgetparameterfun
	#define CHK_getparameterfun  (pfgetparameterfun != NULL)
	#define EXP_getparameterfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getparameterfun", (RTS_UINTPTR)getparameterfun, 1, 0x631D455F, 0x03051314) 
#endif


/**
 * <description>
 * 	Gets the server state.
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success;
 * 	+ ERR_VERSION_MISMATCH: incompatibility between  IEC and the server; nSize is different than sizeof(ServerStateStruct) on the server side;
 * 	+ ERR_FAILED: internal error; the server is not initialised;
 * 	+ ERR_PARAMETER: pState is NULL;
 * </description>
 * <element name="GetStateFun" type=OUT></element>
 * <element name="pState" type=IN>Buffer for the server state.</element>
 * <element name="nSize" type=IN>sizeof(ServerStateStruct) on the IEC side.</element>
*/
typedef struct taggetstatefun_struct
{
	ServerStateStruct *pState;
	RTS_IEC_DWORD nSize;
	RTS_IEC_RESULT GetStateFun;
} getstatefun_struct;

void CDECL CDECL_EXT getstatefun(getstatefun_struct *p);
typedef void (CDECL CDECL_EXT* PFGETSTATEFUN_IEC) (getstatefun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(GETSTATEFUN_NOTIMPLEMENTED)
	#define USE_getstatefun
	#define EXT_getstatefun
	#define GET_getstatefun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_getstatefun(p0) 
	#define CHK_getstatefun  FALSE
	#define EXP_getstatefun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_getstatefun
	#define EXT_getstatefun
	#define GET_getstatefun(fl)  CAL_CMGETAPI( "getstatefun" ) 
	#define CAL_getstatefun  getstatefun
	#define CHK_getstatefun  TRUE
	#define EXP_getstatefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getstatefun", (RTS_UINTPTR)getstatefun, 1, 0x2E45D36A, 0x03051314) 
	#define EXTREF_ITF_getstatefun {(RTS_VOID_FCTPTR)getstatefun, "getstatefun", 0x2E45D36A, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_getstatefun
	#define EXT_getstatefun
	#define GET_getstatefun(fl)  CAL_CMGETAPI( "getstatefun" ) 
	#define CAL_getstatefun  getstatefun
	#define CHK_getstatefun  TRUE
	#define EXP_getstatefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getstatefun", (RTS_UINTPTR)getstatefun, 1, 0x2E45D36A, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServergetstatefun
	#define EXT_WSServergetstatefun
	#define GET_WSServergetstatefun  ERR_OK
	#define CAL_WSServergetstatefun  getstatefun
	#define CHK_WSServergetstatefun  TRUE
	#define EXP_WSServergetstatefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getstatefun", (RTS_UINTPTR)getstatefun, 1, 0x2E45D36A, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_getstatefun
	#define EXT_getstatefun
	#define GET_getstatefun(fl)  CAL_CMGETAPI( "getstatefun" ) 
	#define CAL_getstatefun  getstatefun
	#define CHK_getstatefun  TRUE
	#define EXP_getstatefun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getstatefun", (RTS_UINTPTR)getstatefun, 1, 0x2E45D36A, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_getstatefun  PFGETSTATEFUN_IEC pfgetstatefun;
	#define EXT_getstatefun  extern PFGETSTATEFUN_IEC pfgetstatefun;
	#define GET_getstatefun(fl)  s_pfCMGetAPI2( "getstatefun", (RTS_VOID_FCTPTR *)&pfgetstatefun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x2E45D36A, 0x03051314)
	#define CAL_getstatefun  pfgetstatefun
	#define CHK_getstatefun  (pfgetstatefun != NULL)
	#define EXP_getstatefun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"getstatefun", (RTS_UINTPTR)getstatefun, 1, 0x2E45D36A, 0x03051314) 
#endif


/**
 * <description>
 * 	Specifies a callback function to be called by the WS-Server depending on the inType.
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success;
 * 	+ ERR_NOT_SUPPORTED: type of callback not implemented;
 * </description>
 * <element name="RegisterCallbackFun" type=OUT></element>
 * <element name="inType" type=IN>Callback type.</element>
 * <element name="inCallbackStructInst" type=IN>Pointer to the callback function to be called by the server.</element>
*/
typedef struct tagregistercallbackfun_struct
{
	RTS_IEC_INT inType;
	CallbackStruct inCallbackStructInst;
	RTS_IEC_RESULT RegisterCallbackFun;
} registercallbackfun_struct;

void CDECL CDECL_EXT registercallbackfun(registercallbackfun_struct *p);
typedef void (CDECL CDECL_EXT* PFREGISTERCALLBACKFUN_IEC) (registercallbackfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(REGISTERCALLBACKFUN_NOTIMPLEMENTED)
	#define USE_registercallbackfun
	#define EXT_registercallbackfun
	#define GET_registercallbackfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_registercallbackfun(p0) 
	#define CHK_registercallbackfun  FALSE
	#define EXP_registercallbackfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_registercallbackfun
	#define EXT_registercallbackfun
	#define GET_registercallbackfun(fl)  CAL_CMGETAPI( "registercallbackfun" ) 
	#define CAL_registercallbackfun  registercallbackfun
	#define CHK_registercallbackfun  TRUE
	#define EXP_registercallbackfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registercallbackfun", (RTS_UINTPTR)registercallbackfun, 1, 0xCF0A2177, 0x03051314) 
	#define EXTREF_ITF_registercallbackfun {(RTS_VOID_FCTPTR)registercallbackfun, "registercallbackfun", 0xCF0A2177, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_registercallbackfun
	#define EXT_registercallbackfun
	#define GET_registercallbackfun(fl)  CAL_CMGETAPI( "registercallbackfun" ) 
	#define CAL_registercallbackfun  registercallbackfun
	#define CHK_registercallbackfun  TRUE
	#define EXP_registercallbackfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registercallbackfun", (RTS_UINTPTR)registercallbackfun, 1, 0xCF0A2177, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServerregistercallbackfun
	#define EXT_WSServerregistercallbackfun
	#define GET_WSServerregistercallbackfun  ERR_OK
	#define CAL_WSServerregistercallbackfun  registercallbackfun
	#define CHK_WSServerregistercallbackfun  TRUE
	#define EXP_WSServerregistercallbackfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registercallbackfun", (RTS_UINTPTR)registercallbackfun, 1, 0xCF0A2177, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_registercallbackfun
	#define EXT_registercallbackfun
	#define GET_registercallbackfun(fl)  CAL_CMGETAPI( "registercallbackfun" ) 
	#define CAL_registercallbackfun  registercallbackfun
	#define CHK_registercallbackfun  TRUE
	#define EXP_registercallbackfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registercallbackfun", (RTS_UINTPTR)registercallbackfun, 1, 0xCF0A2177, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_registercallbackfun  PFREGISTERCALLBACKFUN_IEC pfregistercallbackfun;
	#define EXT_registercallbackfun  extern PFREGISTERCALLBACKFUN_IEC pfregistercallbackfun;
	#define GET_registercallbackfun(fl)  s_pfCMGetAPI2( "registercallbackfun", (RTS_VOID_FCTPTR *)&pfregistercallbackfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCF0A2177, 0x03051314)
	#define CAL_registercallbackfun  pfregistercallbackfun
	#define CHK_registercallbackfun  (pfregistercallbackfun != NULL)
	#define EXP_registercallbackfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registercallbackfun", (RTS_UINTPTR)registercallbackfun, 1, 0xCF0A2177, 0x03051314) 
#endif

/**
 * <description>
 * Register a RPC (Remote Procedure Call) by the server.
 * The frontend (HMI-Client) can than any IEC function/FB-method call without having to change the middleware (server).
 * The client request to call a RPC looks like:
 * 
 * .. code-block:: json
 * 
 * 		{
 * 			"uuid":"zJyM1jBCSTuJxgI2Aktlew",
 * 			"call":{
 * 				"proc":"Function/Method name",
 * 				"authToken": "34gt",
 * 				"parameter":{
 * 					"<Parametername 1>": "Parameterwert 1",
 * 					"<Parametername n>": "Parameterwert n"
 * 				}
 * 			}
 * 		}
 * 
 * TypeOfRPC: **RPCTYPE_POINTER**
 * 
 * .. code-block:: codesys
 * 
 * 		FUNCTION RPCallbackFun : RTS_IEC_RESULT
 * 		VAR_INPUT
 * 			User : STRING;						// current user name
 * 			Local : BOOL;						// TRUE if the user is connected locally
 * 			ParaSize : DWORD;					// Size of Parameter
 * 			Parameter : POINTER TO BYTE;		// parameter as pointer of type BYTE (UTF8) (the value of the "parameter" key in the call-request)
 * 			Value : POINTER TO BYTE;			// value as pointer to byte (UTF8)
 * 		END_VAR
 * 		VAR_OUTPUT
 * 			ValueSize : DWORD;					// Size of the returned Value buffer
 * 												// Not greater as the ValueCount parameter of the RegisterRP2Fun functionn.!!
 * 		END_VAR
 * 
 * TypeOfRPC: **RPCTYPE_STRING** (same like **RegisterRPFun**)
 * 
 * .. code-block:: codesys
 * 
 * 		FUNCTION RPCallbackFun : RTS_IEC_RESULT
 * 		VAR_INPUT
 * 			User : STRING;						// current user name
 * 			Local : BOOL;						// TRUE if the user is connected locally
 * 			ParaCount : WORD;					// count of input parameter
 * 			ParaList : POINTER TO RPParaStruct;	// parameter list as array of objects of type RPParaStruct
 * 			ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
 * 		END_VAR
 * 		VAR_OUTPUT
 * 			ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
 * 												// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
 * 		END_VAR
 * **Example** for an RPC call which has 4 parameters (BOOL, DWORD, REAL and STRING) und returns as values the input parameters with a little change: the fourth parameter, a string, will be changed to 'def':
 * 
 * **Frontend**:
 * 
 * .. code-block:: json
 * 	
 * 	{
 * 		"call":{
 * 			"proc":"RPCTestFun",
 * 			"authtoken":"M2IxMjhmZjEtNDc1MS00Nz",
 * 			"parameter":{
 * 				"inBOOL":true,
 * 				"inDWORD":2000,
 * 				"inREAL":0.4,
 * 				"inSTRING":"adbc"
 * 			}
 * 		},
 * 		"uuid":"Lcl8cXTqQ8qP28InaM0KWQ=="
 * 	}
 * 
 * **Backend Example for RPCTYPE_STRING**:
 * 
 * .. code-block:: codesys
 * 
 * 	g_tRPCCall:TCallback;	
 * 	g_tRPCCall.pCB :=ADR(RPCTestFun);
 * 	g_tRPCCall.pThis:=NULL;
 * 	RegisterRP2Fun('RPCTestFun', 4, g_tRPCCall, RPCTYPE_STRING);
 * 	FUNCTION RPCTestFun : RTS_IEC_RESULT
 * 	VAR_INPUT
 * 		User : STRING;						// current user name
 * 		Local : BOOL;						// TRUE if the user is connected locally
 * 		ParaCount : WORD;					// count of input parameter
 * 		ParaList : POINTER TO RPParaStruct;	// parameter list as array of objects of type RPParaStruct
 * 		ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
 * 	END_VAR
 * 	VAR_OUTPUT
 * 		ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
 * 											// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
 * 	END_VAR
 * 	IF (ValueList=NULL) THEN
 * 		RPCTestFun:=700;
 * 		ValueCount:=0;
 * 		RETURN;
 * 	END_IF
 * 	IF (ParaCount>4) THEN
 * 		RPCTestFun:=400;
 * 		ValueCount:=0;
 * 		RETURN;
 * 	ELSE
 * 		SysMemCpy(ValueList, ParaList, ParaCount*SIZEOF(RPParaStruct));
 * 		ValueList[3].ParaValue:='"def"';
 * 		ValueCount:=ParaCount;
 * 		RPCTestFun:=0;		
 * 	END_IF
 * 
 * **Backend Example for RPCTYPE_POINTER**:
 * 
 * .. code-block:: codesys
 * 
 * 	g_tRPCCall:TCallback;	
 * 	g_tRPCCall.pCB :=ADR(RPCTest2Fun);
 * 	g_tRPCCall.pThis:=NULL;
 * 	RegisterRP2Fun('RPCTestFun', 200, g_tRPCCall, RPCTYPE_POINTER);
 * 	FUNCTION RPCTest2Fun : RTS_IEC_RESULT
 * 	VAR_INPUT
 * 		User : STRING;						// current user name
 * 		Local : BOOL;						// TRUE if the user is connected locally
 * 		ParaSize : DWORD;					// size of the Parameter buffer
 * 		Parameter : POINTER TO BYTE;		// parameter as pointer of type BYTE (UTF8) (the value of the "parameter" key in the call-request)
 * 		Value : POINTER TO BYTE;			// value as pointer to byte (UTF8)
 * 	END_VAR
 * 	VAR_OUTPUT
 * 		ValueSize : DWORD;					// Size of the returned Value buffer
 * 											// Not greater as the ValueCount parameter of the RegisterRP2Fun functionn.!!
 * 	END_VAR
 * 	IF (Value=NULL) THEN
 * 		RPCTest2Fun:=700;
 * 		ValueSize:=0;
 * 		RETURN;
 * 	END_IF
 * 	IF (ParaSize>ValueSize) THEN
 * 		RPCTest2Fun:=400;
 * 		ValueSize:=0;
 * 		RETURN;
 * 	ELSE
 * 		SysMemCpy(Value, Parameter, ParaSize);
 * 		ValueSize:=ParaSize;
 * 		RPCTest2Fun:=0;		
 * 	END_IF
 * 
 * **Middleware (server)**:
 * 
 * .. code-block:: json: RPCTYPE_STRING
 * 	
 * 	{
 * 		"uuid":"Lcl8cXTqQ8qP28InaM0KWQ==",
 * 		"call":{
 * 			"proc":"RPCTestFun",
 * 			"result":0,
 * 			"values":{
 * 				"inBOOL":true,
 * 				"inDWORD":2000,
 * 				"inREAL":0.4,
 * 				"inSTRING":"def"
 * 			}
 * 		}
 * 	}
 * 
 * .. code-block:: json: RPCTYPE_POINTER
 * 	
 * 	{
 * 		"uuid":"Lcl8cXTqQ8qP28InaM0KWQ==",
 * 		"call":{
 * 			"proc":"RPCTestFun",
 * 			"result":0,
 * 			"values":{
 * 				"inBOOL":true,
 * 				"inDWORD":2000,
 * 				"inREAL":0.4,
 * 				"inSTRING":"adbc"
 * 			}
 * 		}
 * 	}
 * 
 * Beginning with the Version **3.5.15.28** / **3.5.16.32** / **3.5.16.42** (depending on the device and the CoDeSys Runtime Version) of **CmpWSServer**, for each RPC can be registered another RPC to get Information like Rights and other custom infos about the first RPC.
 * The callback function/FB-method to get info must:
 * 
 * * the prototype depends on the parameter TypeOfRPC
 * * be called RPCNameInfo
 * * return **ELA_SYSERROR.ERR.OK** if the current user has right to call it, otherwise **CmpErrors.Errors.ERR_NO_ACCESS_RIGHTS**
 * 
 * Optionally, can be returned more Infos, custom Infos. See the example below(type, CountOfInputs). In this case, please register the INFO callback with the right **ValueCount**.
 * 
 * TypeOfRPC: **RPCTYPE_STRING**
 * 
 * **Example** of returning information about the RPCTestFun RPC. Only the user 'Administrator' is allowed to call it and in that case, it returns additionally the infos: the RPC return type and the count of input parameters.
 * 
 * .. code-block:: codesys
 * 
 * 		FUNCTION RPTestFunInfo : RTS_IEC_RESULT
 * 		VAR_INPUT
 * 			User : STRING;						// current user name
 * 			Local : BOOL;						// TRUE if the user is connected locally
 * 			ParaCount : WORD;					// 0
 * 			ParaList : POINTER TO RPParaStruct;	// NULL
 * 			ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
 * 		END_VAR
 * 		VAR_OUTPUT
 * 			ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
 * 												// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
 * 		END_VAR
 * 		IF (User='Administrator') THEN
 * 			IF(ValueCount>=2) THEN
 * 				ValueCount:=2;
 * 				IF (ValueList<>0) THEN
 * 					ValueList[0].ParaName:='type';
 * 					ValueList[0].ParaValue:='"RTS_IEC_RESULT"';
 * 					ValueList[1].ParaName:='CountOfInputs';
 * 					ValueList[1].ParaValue:='4';
 * 				END_IF
 * 			ELSE
 * 				ValueCount:=0;
 * 			END_IF
 * 			RPCTestInfo:=ELA_SYSERROR.ERR.OK;
 * 		ELSE
 * 			ValueCount:=0;
 * 			RPCTestInfo:=CmpErrors.Errors.ERR_NO_ACCESS_RIGHTS;
 * 		END_IF
 * 
 * TypeOfRPC: **RPCTYPE_POINTER**
 * 
 * **Example** of returning information about the RPCTest2Fun RPC. Only the user 'Administrator' is allowed to call it and in that case, it returns additionally the infos: the RPC return type and the count of input parameters.
 * 
 * .. code-block:: codesys
 * 
 * 		FUNCTION RPCTest2FunInfo : RTS_IEC_RESULT
 * 		VAR_INPUT
 * 			User : STRING;						// current user name
 * 			Local : BOOL;						// TRUE if the user is connected locally
 * 			ParaSize : DWORD;					// 0
 * 			Parameter : POINTER TO BYTE;		// NULL
 * 			Value : POINTER TO BYTE;			// value as pointer to byte (UTF8)
 * 		END_VAR
 * 		VAR_OUTPUT
 * 			ValueSize : DWORD;					// Size of the returned Value buffer
 * 												// Not greater as the ValueCount parameter of the RegisterRP2Fun functionn.!!
 * 		END_VAR
 * 		VAR
 * 			sValue:STRING(200):='"type":"RTS_IEC_RESULT";"CountOfInputs":4';
 * 		END_VAR
 * 		IF (User='Administrator') THEN
 * 			IF(ValueSize>=200) THEN
 * 				ValueSize:=	LEN(sValue)+1;			
 * 				SysMemCpy(Value, ADR(sValue), ValueSize);
 * 			ELSE
 * 				ValueSize:=0;
 * 			END_IF
 * 			RPCTest2FunInfo:=ELA_SYSERROR.ERR.OK;
 * 		ELSE
 * 			ValueSize:=0;
 * 			RPCTest2FunInfo:=CmpErrors.Errors.ERR_NO_ACCESS_RIGHTS;
 * 		END_IF
 * 
 * :return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success;
 * 	+ ERR_NOMEMORY: not enough memory;
 * </description>
 * <element name="RegisterRP2Fun" type=OUT></element>
 * <element name="ProcName" type=IN>function/FB-method name</element>
 * <element name="ValueCount" type=IN>RPCTYPE_STRING: Maximum number of output values will be returned from the calbback function/FB-method.</element>
 * <element name="CallbackStructInst" type=IN>pointer to a structure which defines the function to be called</element>
 * <element name="TypeOfRPC" type=IN></element>
*/
typedef struct tagregisterrp2fun_struct
{
	RTS_IEC_STRING ProcName[81];
	RTS_IEC_DWORD ValueCount;
	CallbackStruct CallbackStructInst;
	RTS_IEC_INT TypeOfRPC;
	RTS_IEC_RESULT RegisterRP2Fun;
} registerrp2fun_struct;

void CDECL CDECL_EXT registerrp2fun(registerrp2fun_struct *p);
typedef void (CDECL CDECL_EXT* PFREGISTERRP2FUN_IEC) (registerrp2fun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(REGISTERRP2FUN_NOTIMPLEMENTED)
	#define USE_registerrp2fun
	#define EXT_registerrp2fun
	#define GET_registerrp2fun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_registerrp2fun(p0) 
	#define CHK_registerrp2fun  FALSE
	#define EXP_registerrp2fun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_registerrp2fun
	#define EXT_registerrp2fun
	#define GET_registerrp2fun(fl)  CAL_CMGETAPI( "registerrp2fun" ) 
	#define CAL_registerrp2fun  registerrp2fun
	#define CHK_registerrp2fun  TRUE
	#define EXP_registerrp2fun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrp2fun", (RTS_UINTPTR)registerrp2fun, 1, 0x0BA96B93, 0x03051315) 
	#define EXTREF_ITF_registerrp2fun {(RTS_VOID_FCTPTR)registerrp2fun, "registerrp2fun", 0x0BA96B93, 0x03051315}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_registerrp2fun
	#define EXT_registerrp2fun
	#define GET_registerrp2fun(fl)  CAL_CMGETAPI( "registerrp2fun" ) 
	#define CAL_registerrp2fun  registerrp2fun
	#define CHK_registerrp2fun  TRUE
	#define EXP_registerrp2fun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrp2fun", (RTS_UINTPTR)registerrp2fun, 1, 0x0BA96B93, 0x03051315) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServerregisterrp2fun
	#define EXT_WSServerregisterrp2fun
	#define GET_WSServerregisterrp2fun  ERR_OK
	#define CAL_WSServerregisterrp2fun  registerrp2fun
	#define CHK_WSServerregisterrp2fun  TRUE
	#define EXP_WSServerregisterrp2fun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrp2fun", (RTS_UINTPTR)registerrp2fun, 1, 0x0BA96B93, 0x03051315) 
#elif defined(CPLUSPLUS)
	#define USE_registerrp2fun
	#define EXT_registerrp2fun
	#define GET_registerrp2fun(fl)  CAL_CMGETAPI( "registerrp2fun" ) 
	#define CAL_registerrp2fun  registerrp2fun
	#define CHK_registerrp2fun  TRUE
	#define EXP_registerrp2fun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrp2fun", (RTS_UINTPTR)registerrp2fun, 1, 0x0BA96B93, 0x03051315) 
#else /* DYNAMIC_LINK */
	#define USE_registerrp2fun  PFREGISTERRP2FUN_IEC pfregisterrp2fun;
	#define EXT_registerrp2fun  extern PFREGISTERRP2FUN_IEC pfregisterrp2fun;
	#define GET_registerrp2fun(fl)  s_pfCMGetAPI2( "registerrp2fun", (RTS_VOID_FCTPTR *)&pfregisterrp2fun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0BA96B93, 0x03051315)
	#define CAL_registerrp2fun  pfregisterrp2fun
	#define CHK_registerrp2fun  (pfregisterrp2fun != NULL)
	#define EXP_registerrp2fun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrp2fun", (RTS_UINTPTR)registerrp2fun, 1, 0x0BA96B93, 0x03051315) 
#endif


/**
 * <description>
 * Register a RPC (Remote Procedure Call) by the server.
 * The frontend (HMI-Client) can than any IEC function/FB-method call without having to change the middleware (server).
 * The client request to call a RPC looks like:
 * 
 * .. code-block:: json
 * 
 * 		{
 * 			"uuid":"zJyM1jBCSTuJxgI2Aktlew",
 * 			"call":{
 * 				"proc":"Function/Method name",
 * 				"authToken": "34gt",
 * 				"parameter":{
 * 					"<Parametername 1>": "Parameterwert 1",
 * 					"<Parametername n>": "Parameterwert n"
 * 				}
 * 			}
 * 		}
 * 
 * The callback function/FB-method must have the following prototype:
 * 
 * .. code-block:: codesys
 * 
 * 		FUNCTION RPCallbackFun : RTS_IEC_RESULT
 * 		VAR_INPUT
 * 			User : STRING;						// current user name
 * 			Local : BOOL;						// TRUE if the user is connected locally
 * 			ParaCount : WORD;					// count of input parameter
 * 			ParaList : POINTER TO RPParaStruct;	// parameter list as array of objects of type RPParaStruct
 * 			ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
 * 		END_VAR
 * 		VAR_OUTPUT
 * 			ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
 * 												// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
 * 		END_VAR
 * 
 * **Example** for an RPC call which has 4 parameters (BOOL, DWORD, REAL and STRING) und returns as values the input parameters with a little change: the fourth parameter, a string, will be changed to 'def':
 * 
 * **Frontend**:
 * 
 * .. code-block:: json
 * 	
 * 	{
 * 		"call":{
 * 			"proc":"RPCTestFun",
 * 			"authtoken":"M2IxMjhmZjEtNDc1MS00Nz",
 * 			"parameter":{
 * 				"inBOOL":true,
 * 				"inDWORD":2000,
 * 				"inREAL":0.4,
 * 				"inSTRING":"adbc"
 * 			}
 * 		},
 * 		"uuid":"Lcl8cXTqQ8qP28InaM0KWQ=="
 * 	}
 * 
 * **Backend**:
 * 
 * .. code-block:: codesys
 * 
 * 	g_tRPCCall:TCallback;	
 * 	g_tRPCCall.pCB :=ADR(FC_RPCTest);
 * 	g_tRPCCall.pThis:=NULL;
 * 	RegisterRP('RPCTestFun', 4, g_tRPCCall);
 * 	FUNCTION RPCTestFun : RTS_IEC_RESULT
 * 	VAR_INPUT
 * 		User : STRING;						// current user name
 * 		Local : BOOL;						// TRUE if the user is connected locally
 * 		ParaCount : WORD;					// count of input parameter
 * 		ParaList : POINTER TO RPParaStruct;	// parameter list as array of objects of type RPParaStruct
 * 		ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
 * 	END_VAR
 * 	VAR_OUTPUT
 * 		ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
 * 											// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
 * 	END_VAR
 * 	IF (ValueList=NULL) THEN
 * 		RPCTestFun:=700;
 * 		ValueCount:=0;
 * 		RETURN;
 * 	END_IF
 * 	IF (ParaCount>4) THEN
 * 		RPCTestFun:=400;
 * 		ValueCount:=0;
 * 		RETURN;
 * 	ELSE
 * 		SysMemCpy(ValueList, ParaList, ParaCount*SIZEOF(RPParaStruct));
 * 		ValueList[3].ParaValue:='"def"';
 * 		ValueCount:=ParaCount;
 * 		RPCTestFun:=0;		
 * 	END_IF
 * 
 * **Middleware (server)**:
 * 
 * .. code-block:: json
 * 	
 * 	{
 * 		"uuid":"Lcl8cXTqQ8qP28InaM0KWQ==",
 * 		"call":{
 * 			"proc":"RPCTestFun",
 * 			"result":0,
 * 			"values":{
 * 				"inBOOL":true,
 * 				"inDWORD":2000,
 * 				"inREAL":0.4,
 * 				"inSTRING":"def"
 * 			}
 * 		}
 * 	}
 * 
 * Beginning with the Version **3.5.15.28** / **3.5.16.32** / **3.5.16.42** (depending on the device and the CoDeSys Runtime Version) of **CmpWSServer**, for each RPC can be registered another RPC to get Information like Rights and other custom infos about the first RPC.
 * The callback function/FB-method to get info must:
 * 
 * * have the same prototype like the RPC
 * * be called RPCNameInfo
 * * return **ELA_SYSERROR.ERR.OK** if the current user has right to call it, otherwise **CmpErrors.Errors.ERR_NO_ACCESS_RIGHTS**
 * 
 * Optionally, can be returned more Infos, custom Infos. See the example below(type, CountOfInputs). In this case, please register the INFO callback with the right **ValueCount**.
 * 
 * **Example** of returning information about the RPCTestFun RPC. Only the user 'Administrator' is allowed to call it and in that case, it returns additionally the infos: the RPC return type and the count of input parameters.
 * 
 * .. code-block:: codesys
 * 
 * 		FUNCTION RPTestFunInfo : RTS_IEC_RESULT
 * 		VAR_INPUT
 * 			User : STRING;						// current user name
 * 			Local : BOOL;						// TRUE if the user is connected locally
 * 			ParaCount : WORD;					// count of input parameter
 * 			ParaList : POINTER TO RPParaStruct;	// parameter list as array of objects of type RPParaStruct
 * 			ValueList : POINTER TO RPParaStruct;// values list as array of objects of type RPParaStruct
 * 		END_VAR
 * 		VAR_OUTPUT
 * 			ValueCount : WORD;					// Count of values which are retuned to the ValueList parameter.
 * 												// Not greater as the ValueCount parameter of the RegisterRPFun functionn.!!
 * 		END_VAR
 * 		IF (User='Administrator') THEN
 * 			IF(ValueCount>=2) THEN
 * 				ValueCount:=2;
 * 				IF (ValueList<>0) THEN
 * 					ValueList[0].ParaName:='type';
 * 					ValueList[0].ParaValue:='"RTS_IEC_RESULT"';
 * 					ValueList[1].ParaName:='CountOfInputs';
 * 					ValueList[1].ParaValue:='4';
 * 				END_IF
 * 			ELSE
 * 				ValueCount:=0;
 * 			END_IF
 * 			RPCTestInfo:=ELA_SYSERROR.ERR.OK;
 * 		ELSE
 * 			ValueCount:=0;
 * 			RPCTestInfo:=CmpErrors.Errors.ERR_NO_ACCESS_RIGHTS;
 * 		END_IF
 * 
 * :return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success;
 * 	+ ERR_NOMEMORY: not enough memory;
 * </description>
 * <element name="RegisterRPFun" type=OUT></element>
 * <element name="ProcName" type=IN>function/FB-method name</element>
 * <element name="ValueCount" type=IN>Maximum number of output values will be returned from the calbback function/FB-method.</element>
 * <element name="CallbackStructInst" type=IN>pointer to a structure which defines the function to be called</element>
*/
typedef struct tagregisterrpfun_struct
{
	RTS_IEC_STRING ProcName[81];
	RTS_IEC_WORD ValueCount;
	CallbackStruct CallbackStructInst;
	RTS_IEC_RESULT RegisterRPFun;
} registerrpfun_struct;

void CDECL CDECL_EXT registerrpfun(registerrpfun_struct *p);
typedef void (CDECL CDECL_EXT* PFREGISTERRPFUN_IEC) (registerrpfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(REGISTERRPFUN_NOTIMPLEMENTED)
	#define USE_registerrpfun
	#define EXT_registerrpfun
	#define GET_registerrpfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_registerrpfun(p0) 
	#define CHK_registerrpfun  FALSE
	#define EXP_registerrpfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_registerrpfun
	#define EXT_registerrpfun
	#define GET_registerrpfun(fl)  CAL_CMGETAPI( "registerrpfun" ) 
	#define CAL_registerrpfun  registerrpfun
	#define CHK_registerrpfun  TRUE
	#define EXP_registerrpfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrpfun", (RTS_UINTPTR)registerrpfun, 1, 0xE95228FB, 0x03051314) 
	#define EXTREF_ITF_registerrpfun {(RTS_VOID_FCTPTR)registerrpfun, "registerrpfun", 0xE95228FB, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_registerrpfun
	#define EXT_registerrpfun
	#define GET_registerrpfun(fl)  CAL_CMGETAPI( "registerrpfun" ) 
	#define CAL_registerrpfun  registerrpfun
	#define CHK_registerrpfun  TRUE
	#define EXP_registerrpfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrpfun", (RTS_UINTPTR)registerrpfun, 1, 0xE95228FB, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServerregisterrpfun
	#define EXT_WSServerregisterrpfun
	#define GET_WSServerregisterrpfun  ERR_OK
	#define CAL_WSServerregisterrpfun  registerrpfun
	#define CHK_WSServerregisterrpfun  TRUE
	#define EXP_WSServerregisterrpfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrpfun", (RTS_UINTPTR)registerrpfun, 1, 0xE95228FB, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_registerrpfun
	#define EXT_registerrpfun
	#define GET_registerrpfun(fl)  CAL_CMGETAPI( "registerrpfun" ) 
	#define CAL_registerrpfun  registerrpfun
	#define CHK_registerrpfun  TRUE
	#define EXP_registerrpfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrpfun", (RTS_UINTPTR)registerrpfun, 1, 0xE95228FB, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_registerrpfun  PFREGISTERRPFUN_IEC pfregisterrpfun;
	#define EXT_registerrpfun  extern PFREGISTERRPFUN_IEC pfregisterrpfun;
	#define GET_registerrpfun(fl)  s_pfCMGetAPI2( "registerrpfun", (RTS_VOID_FCTPTR *)&pfregisterrpfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xE95228FB, 0x03051314)
	#define CAL_registerrpfun  pfregisterrpfun
	#define CHK_registerrpfun  (pfregisterrpfun != NULL)
	#define EXP_registerrpfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"registerrpfun", (RTS_UINTPTR)registerrpfun, 1, 0xE95228FB, 0x03051314) 
#endif


/**
 * <description>
 * 	Removes all local clients from the CFG file.
 * 	
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success. No local client to remove.
 * 	+ ERR_WS_NEWSTART_NEED: Success and the CoDeSys runtime must be restarted.
 * </description>
 * <element name="RemoveAllLocalClientsFun" type=OUT></element>
*/
typedef struct tagremovealllocalclientsfun_struct
{
	RTS_IEC_RESULT RemoveAllLocalClientsFun;
} removealllocalclientsfun_struct;

void CDECL CDECL_EXT removealllocalclientsfun(removealllocalclientsfun_struct *p);
typedef void (CDECL CDECL_EXT* PFREMOVEALLLOCALCLIENTSFUN_IEC) (removealllocalclientsfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(REMOVEALLLOCALCLIENTSFUN_NOTIMPLEMENTED)
	#define USE_removealllocalclientsfun
	#define EXT_removealllocalclientsfun
	#define GET_removealllocalclientsfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_removealllocalclientsfun(p0) 
	#define CHK_removealllocalclientsfun  FALSE
	#define EXP_removealllocalclientsfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_removealllocalclientsfun
	#define EXT_removealllocalclientsfun
	#define GET_removealllocalclientsfun(fl)  CAL_CMGETAPI( "removealllocalclientsfun" ) 
	#define CAL_removealllocalclientsfun  removealllocalclientsfun
	#define CHK_removealllocalclientsfun  TRUE
	#define EXP_removealllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removealllocalclientsfun", (RTS_UINTPTR)removealllocalclientsfun, 1, 0xCD35F1BD, 0x03051314) 
	#define EXTREF_ITF_removealllocalclientsfun {(RTS_VOID_FCTPTR)removealllocalclientsfun, "removealllocalclientsfun", 0xCD35F1BD, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_removealllocalclientsfun
	#define EXT_removealllocalclientsfun
	#define GET_removealllocalclientsfun(fl)  CAL_CMGETAPI( "removealllocalclientsfun" ) 
	#define CAL_removealllocalclientsfun  removealllocalclientsfun
	#define CHK_removealllocalclientsfun  TRUE
	#define EXP_removealllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removealllocalclientsfun", (RTS_UINTPTR)removealllocalclientsfun, 1, 0xCD35F1BD, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServerremovealllocalclientsfun
	#define EXT_WSServerremovealllocalclientsfun
	#define GET_WSServerremovealllocalclientsfun  ERR_OK
	#define CAL_WSServerremovealllocalclientsfun  removealllocalclientsfun
	#define CHK_WSServerremovealllocalclientsfun  TRUE
	#define EXP_WSServerremovealllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removealllocalclientsfun", (RTS_UINTPTR)removealllocalclientsfun, 1, 0xCD35F1BD, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_removealllocalclientsfun
	#define EXT_removealllocalclientsfun
	#define GET_removealllocalclientsfun(fl)  CAL_CMGETAPI( "removealllocalclientsfun" ) 
	#define CAL_removealllocalclientsfun  removealllocalclientsfun
	#define CHK_removealllocalclientsfun  TRUE
	#define EXP_removealllocalclientsfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removealllocalclientsfun", (RTS_UINTPTR)removealllocalclientsfun, 1, 0xCD35F1BD, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_removealllocalclientsfun  PFREMOVEALLLOCALCLIENTSFUN_IEC pfremovealllocalclientsfun;
	#define EXT_removealllocalclientsfun  extern PFREMOVEALLLOCALCLIENTSFUN_IEC pfremovealllocalclientsfun;
	#define GET_removealllocalclientsfun(fl)  s_pfCMGetAPI2( "removealllocalclientsfun", (RTS_VOID_FCTPTR *)&pfremovealllocalclientsfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCD35F1BD, 0x03051314)
	#define CAL_removealllocalclientsfun  pfremovealllocalclientsfun
	#define CHK_removealllocalclientsfun  (pfremovealllocalclientsfun != NULL)
	#define EXP_removealllocalclientsfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removealllocalclientsfun", (RTS_UINTPTR)removealllocalclientsfun, 1, 0xCD35F1BD, 0x03051314) 
#endif


/**
 * <description>
 * Removes a local client from the CFG file.
 * 	
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success; no need to remove it; the IP wasn't in the CFG.
 * 	+ ERR_WS_NEWSTART_NEED: the local client was successfully removed; the CoDeSys runtime must be restarted.
 * </description>
 * <element name="RemoveLocalClientFun" type=OUT></element>
 * <element name="sIP" type=IN>IPV4 Address in String Format</element>
*/
typedef struct tagremovelocalclientfun_struct
{
	RTS_IEC_STRING sIP[81];
	RTS_IEC_RESULT RemoveLocalClientFun;
} removelocalclientfun_struct;

void CDECL CDECL_EXT removelocalclientfun(removelocalclientfun_struct *p);
typedef void (CDECL CDECL_EXT* PFREMOVELOCALCLIENTFUN_IEC) (removelocalclientfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(REMOVELOCALCLIENTFUN_NOTIMPLEMENTED)
	#define USE_removelocalclientfun
	#define EXT_removelocalclientfun
	#define GET_removelocalclientfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_removelocalclientfun(p0) 
	#define CHK_removelocalclientfun  FALSE
	#define EXP_removelocalclientfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_removelocalclientfun
	#define EXT_removelocalclientfun
	#define GET_removelocalclientfun(fl)  CAL_CMGETAPI( "removelocalclientfun" ) 
	#define CAL_removelocalclientfun  removelocalclientfun
	#define CHK_removelocalclientfun  TRUE
	#define EXP_removelocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removelocalclientfun", (RTS_UINTPTR)removelocalclientfun, 1, 0xDE3B14FB, 0x03051314) 
	#define EXTREF_ITF_removelocalclientfun {(RTS_VOID_FCTPTR)removelocalclientfun, "removelocalclientfun", 0xDE3B14FB, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_removelocalclientfun
	#define EXT_removelocalclientfun
	#define GET_removelocalclientfun(fl)  CAL_CMGETAPI( "removelocalclientfun" ) 
	#define CAL_removelocalclientfun  removelocalclientfun
	#define CHK_removelocalclientfun  TRUE
	#define EXP_removelocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removelocalclientfun", (RTS_UINTPTR)removelocalclientfun, 1, 0xDE3B14FB, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServerremovelocalclientfun
	#define EXT_WSServerremovelocalclientfun
	#define GET_WSServerremovelocalclientfun  ERR_OK
	#define CAL_WSServerremovelocalclientfun  removelocalclientfun
	#define CHK_WSServerremovelocalclientfun  TRUE
	#define EXP_WSServerremovelocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removelocalclientfun", (RTS_UINTPTR)removelocalclientfun, 1, 0xDE3B14FB, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_removelocalclientfun
	#define EXT_removelocalclientfun
	#define GET_removelocalclientfun(fl)  CAL_CMGETAPI( "removelocalclientfun" ) 
	#define CAL_removelocalclientfun  removelocalclientfun
	#define CHK_removelocalclientfun  TRUE
	#define EXP_removelocalclientfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removelocalclientfun", (RTS_UINTPTR)removelocalclientfun, 1, 0xDE3B14FB, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_removelocalclientfun  PFREMOVELOCALCLIENTFUN_IEC pfremovelocalclientfun;
	#define EXT_removelocalclientfun  extern PFREMOVELOCALCLIENTFUN_IEC pfremovelocalclientfun;
	#define GET_removelocalclientfun(fl)  s_pfCMGetAPI2( "removelocalclientfun", (RTS_VOID_FCTPTR *)&pfremovelocalclientfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDE3B14FB, 0x03051314)
	#define CAL_removelocalclientfun  pfremovelocalclientfun
	#define CHK_removelocalclientfun  (pfremovelocalclientfun != NULL)
	#define EXP_removelocalclientfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"removelocalclientfun", (RTS_UINTPTR)removelocalclientfun, 1, 0xDE3B14FB, 0x03051314) 
#endif


/**
 * <description>
 * setlasterrorfun
 * </description>
 * <element name="SetLastErrorFun" type=OUT></element>
 * <element name="LastError" type=IN></element>
*/
typedef struct tagsetlasterrorfun_struct
{
	RTS_IEC_RESULT LastError;
	RTS_IEC_RESULT SetLastErrorFun;
} setlasterrorfun_struct;

void CDECL CDECL_EXT setlasterrorfun(setlasterrorfun_struct *p);
typedef void (CDECL CDECL_EXT* PFSETLASTERRORFUN_IEC) (setlasterrorfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(SETLASTERRORFUN_NOTIMPLEMENTED)
	#define USE_setlasterrorfun
	#define EXT_setlasterrorfun
	#define GET_setlasterrorfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_setlasterrorfun(p0) 
	#define CHK_setlasterrorfun  FALSE
	#define EXP_setlasterrorfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_setlasterrorfun
	#define EXT_setlasterrorfun
	#define GET_setlasterrorfun(fl)  CAL_CMGETAPI( "setlasterrorfun" ) 
	#define CAL_setlasterrorfun  setlasterrorfun
	#define CHK_setlasterrorfun  TRUE
	#define EXP_setlasterrorfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setlasterrorfun", (RTS_UINTPTR)setlasterrorfun, 1, 0x70D134D5, 0x03051314) 
	#define EXTREF_ITF_setlasterrorfun {(RTS_VOID_FCTPTR)setlasterrorfun, "setlasterrorfun", 0x70D134D5, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_setlasterrorfun
	#define EXT_setlasterrorfun
	#define GET_setlasterrorfun(fl)  CAL_CMGETAPI( "setlasterrorfun" ) 
	#define CAL_setlasterrorfun  setlasterrorfun
	#define CHK_setlasterrorfun  TRUE
	#define EXP_setlasterrorfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setlasterrorfun", (RTS_UINTPTR)setlasterrorfun, 1, 0x70D134D5, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServersetlasterrorfun
	#define EXT_WSServersetlasterrorfun
	#define GET_WSServersetlasterrorfun  ERR_OK
	#define CAL_WSServersetlasterrorfun  setlasterrorfun
	#define CHK_WSServersetlasterrorfun  TRUE
	#define EXP_WSServersetlasterrorfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setlasterrorfun", (RTS_UINTPTR)setlasterrorfun, 1, 0x70D134D5, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_setlasterrorfun
	#define EXT_setlasterrorfun
	#define GET_setlasterrorfun(fl)  CAL_CMGETAPI( "setlasterrorfun" ) 
	#define CAL_setlasterrorfun  setlasterrorfun
	#define CHK_setlasterrorfun  TRUE
	#define EXP_setlasterrorfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setlasterrorfun", (RTS_UINTPTR)setlasterrorfun, 1, 0x70D134D5, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_setlasterrorfun  PFSETLASTERRORFUN_IEC pfsetlasterrorfun;
	#define EXT_setlasterrorfun  extern PFSETLASTERRORFUN_IEC pfsetlasterrorfun;
	#define GET_setlasterrorfun(fl)  s_pfCMGetAPI2( "setlasterrorfun", (RTS_VOID_FCTPTR *)&pfsetlasterrorfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x70D134D5, 0x03051314)
	#define CAL_setlasterrorfun  pfsetlasterrorfun
	#define CHK_setlasterrorfun  (pfsetlasterrorfun != NULL)
	#define EXP_setlasterrorfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setlasterrorfun", (RTS_UINTPTR)setlasterrorfun, 1, 0x70D134D5, 0x03051314) 
#endif


/**
 * <description>
 * 	:return:  see SysError.library and CmpErrors.library
 * 	+ ERR_OK: success;
 * 	+ ERR_WS_NEWSTART_NEED: in the case of changing the PORT parameter, the CoDeSys runtime must be restarted;
 * 	+ ERR_VALUE_WRONG: invalid value to set; by example for the MaxClients parameter, the valid range for the value is [1, MAX_CLIENTS];
 * 	+ ERR_FAILED: internal error; server is not initialised;
 * 	+ ERR_PARAMETER: unknown parameter;
 * </description>
 * <element name="SetParameterFun" type=OUT></element>
 * <element name="enParameter" type=IN>Parameter to set.</element>
 * <element name="Value" type=IN>Parameter value.</element>
*/
typedef struct tagsetparameterfun_struct
{
	RTS_IEC_INT enParameter;
	RTS_IEC_DWORD Value;
	RTS_IEC_RESULT SetParameterFun;
} setparameterfun_struct;

void CDECL CDECL_EXT setparameterfun(setparameterfun_struct *p);
typedef void (CDECL CDECL_EXT* PFSETPARAMETERFUN_IEC) (setparameterfun_struct *p);
#if defined(WSSERVER_NOTIMPLEMENTED) || defined(SETPARAMETERFUN_NOTIMPLEMENTED)
	#define USE_setparameterfun
	#define EXT_setparameterfun
	#define GET_setparameterfun(fl)  ERR_NOTIMPLEMENTED
	#define CAL_setparameterfun(p0) 
	#define CHK_setparameterfun  FALSE
	#define EXP_setparameterfun  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_setparameterfun
	#define EXT_setparameterfun
	#define GET_setparameterfun(fl)  CAL_CMGETAPI( "setparameterfun" ) 
	#define CAL_setparameterfun  setparameterfun
	#define CHK_setparameterfun  TRUE
	#define EXP_setparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setparameterfun", (RTS_UINTPTR)setparameterfun, 1, 0xDF3B0F24, 0x03051314) 
	#define EXTREF_ITF_setparameterfun {(RTS_VOID_FCTPTR)setparameterfun, "setparameterfun", 0xDF3B0F24, 0x03051314}
#elif defined(MIXED_LINK) && !defined(WSSERVER_EXTERNAL)
	#define USE_setparameterfun
	#define EXT_setparameterfun
	#define GET_setparameterfun(fl)  CAL_CMGETAPI( "setparameterfun" ) 
	#define CAL_setparameterfun  setparameterfun
	#define CHK_setparameterfun  TRUE
	#define EXP_setparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setparameterfun", (RTS_UINTPTR)setparameterfun, 1, 0xDF3B0F24, 0x03051314) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WSServersetparameterfun
	#define EXT_WSServersetparameterfun
	#define GET_WSServersetparameterfun  ERR_OK
	#define CAL_WSServersetparameterfun  setparameterfun
	#define CHK_WSServersetparameterfun  TRUE
	#define EXP_WSServersetparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setparameterfun", (RTS_UINTPTR)setparameterfun, 1, 0xDF3B0F24, 0x03051314) 
#elif defined(CPLUSPLUS)
	#define USE_setparameterfun
	#define EXT_setparameterfun
	#define GET_setparameterfun(fl)  CAL_CMGETAPI( "setparameterfun" ) 
	#define CAL_setparameterfun  setparameterfun
	#define CHK_setparameterfun  TRUE
	#define EXP_setparameterfun  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setparameterfun", (RTS_UINTPTR)setparameterfun, 1, 0xDF3B0F24, 0x03051314) 
#else /* DYNAMIC_LINK */
	#define USE_setparameterfun  PFSETPARAMETERFUN_IEC pfsetparameterfun;
	#define EXT_setparameterfun  extern PFSETPARAMETERFUN_IEC pfsetparameterfun;
	#define GET_setparameterfun(fl)  s_pfCMGetAPI2( "setparameterfun", (RTS_VOID_FCTPTR *)&pfsetparameterfun, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDF3B0F24, 0x03051314)
	#define CAL_setparameterfun  pfsetparameterfun
	#define CHK_setparameterfun  (pfsetparameterfun != NULL)
	#define EXP_setparameterfun   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"setparameterfun", (RTS_UINTPTR)setparameterfun, 1, 0xDF3B0F24, 0x03051314) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWSServer_C;

#ifdef CPLUSPLUS
class IWSServer : public IBase
{
	public:
};
	#ifndef ITF_WSServer
		#define ITF_WSServer static IWSServer *pIWSServer = NULL;
	#endif
	#define EXTITF_WSServer
#else	/*CPLUSPLUS*/
	typedef IWSServer_C		IWSServer;
	#ifndef ITF_WSServer
		#define ITF_WSServer
	#endif
	#define EXTITF_WSServer
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WSSERVERITF_H_*/
