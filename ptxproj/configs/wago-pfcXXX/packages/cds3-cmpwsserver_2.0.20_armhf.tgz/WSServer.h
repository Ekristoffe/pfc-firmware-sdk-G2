/** WSServer.h

	@author	: Nicoleta Nething
   company	: elrest
	@date	   : 28.08.2015

	Descrption:
	WebSocket(s) Server um CoDeSys-Symbolwerten mit Web-Clients auszutauschen

	Change history:
	#01 Ng		Datum: 28.08.2015
*/
#include "ws_errors.h"
#include "ws_users.h"

#define LOCAL_RESOURCE_PATH "websockets-server"
#define LOG_MEMORY   UINT32_C(0x00100000)
#define LOG_QUERIES  UINT32_C(0x00200000)
#define LOG_THREADWS   UINT32_C(0x00400000)

#define max(a,b)    (((a) > (b)) ? (a) : (b))
#define min(a,b)    (((a) < (b)) ? (a) : (b))

/*#define LOG_MEMORY_FAILED		UINT32_C(0x00010000)
#define LOG_MEMORY_REUSEABLE	UINT32_C(0x00020000)	// Memory output for reusable memory blocks 
#define LOG_MEMORY_POOL			UINT32_C(0x00040000)	// Memory output for sockets and requests	
#define LOG_MEMORY_ALL			UINT32_C(0x000f0000)
#define LOG_SOCKET_GENERAL		UINT32_C(0x00100000)
#define LOG_SOCKET_ERROR		UINT32_C(0x00200000)
#define LOG_SOCKET_SPECIAL		UINT32_C(0x00400000)
#define LOG_SOCKET_ALL			UINT32_C(0x00f00000)*/

#define WS_EXCEPTION_STRING_SIZE 256
#define RTS_CATCH_REQ(sRequest) \
   rts_catch \
   {\
      char exceptionString[WS_EXCEPTION_STRING_SIZE];\
      RTS_UI32 exceptionCode = EXCPT_GET_CODE();\
      int n;\
      exceptionString[0]='\0';\
      CAL_SysExceptConvertToString(exceptionCode, exceptionString, sizeof(exceptionString)-1);\
      CAL_LogAdd(STD_LOGGER, COMPONENT_ID, LOG_EXCEPTION, 0, 0, "Exception: %u(0x%X) (%s)", exceptionCode, exceptionCode, exceptionString);\
      CAL_LogAdd(STD_LOGGER, COMPONENT_ID, LOG_EXCEPTION, 0, 0, "Exception: LastRequest: %s. Last Parameter: %s.", gLastRequest, gLastReqPar);\
      result = WS_ERROR_EXCEPTION;\
      n=sprintf_s(pAnswerBuffer, nMaxBufferLength, "{\"uuid\":\"%.*s\",\"%s\":{\"error\":{\"nr\":%d,\"msg\":\"%s\",\"ext\":%u}}}", pTokens[iUUID].end-pTokens[iUUID].start, in_json+pTokens[iUUID].start, sRequest, result, exceptionString, exceptionCode);\
      pAnswerBuffer[n] = '\0';\
      bWSThreadException=TRUE;\
   }\
   rts_try_end


union ws_value {
   RTS_UI8        byteVal;    // TYPE3_BOOL, TYPE3_BYTE, TYPE3_USINT
   RTS_UI16       wordVal;    // TYPE3_WORD, TYPE3_UINT
   RTS_UI32       dwordVal;   // TYPE3_DWORD, TYPE3_UDINT, TYPE3_TIME, TYPE3_DATE, TYPE3_DATEANDTIME, TYPE3_TIMEOFDAY
   RTS_I8         cVal;       // TYPE3_SINT
   RTS_I16        shortVal;   // TYPE3_INT
   RTS_I32        longVal;    // TYPE3_DINT
   RTS_REAL32     floatVal;   // TYPE3_REAL
   RTS_REAL64     doubleVal;  // TYPE3_LREAL
   RTS_CSTRING*   stringVal;  // TYPE3_STRING
   RTS_WCHAR*     wstringVal; // TYPE3_WSTRING
   void*          arrVal;     // TYPE3_ARRAY
   RTS_HANDLE     pointerVal; // TYPE3_POINTER
};

#define ELEMENTTYPE_SYMBOL       0
#define ELEMENTTYPE_PARAMETER    1
#define ELEMENTTYPE_MESSAGE      2
//#define ELEMENTTYPE_OPCUA        3

typedef struct
{
   RTS_IEC_STRING       szNamespace[81];
   ServiceParameterStruct*    pServiceParameters;
   RTS_IEC_DWORD        ui32NoOfServiceParameters;
} ParameterService;

/* all-codesys-symbols */

/*
 * one of these is auto-created for each connection and a pointer to the
 * appropriate instance is passed to the callback in the user parameter
 *
 * for this example protocol we use it to individualize the count for each
 * connection.
 */

typedef struct tagelement_symbol
{
   RTS_HANDLE                    hRTSNode;   
   RTS_HANDLE                    hRTSTypeNode;           // handle to the type node
   
   VariableInformationStructN    varInfo;
   
   TypeDescAsUnion               tTypeDesc;              // TYPE3_USERDEF, TYPE3_ARRAY of TYPE3_USERDEF

} element_symbol;


typedef struct tagelement_parameter
{
   ParameterService*             pService;
   RTS_UI32                      nIndexOfParamter;    

} element_parameter;

typedef union
{
	element_symbol          symbol;		
	element_parameter       parameter;	
} ElementUnion;

struct session_element {
   
   char*                         sName;

   RTS_UI8                       type;
   ElementUnion                  _union;  
   
   TypeClass3                    eRTSType;
   TypeClass3                    eRTSArrayType;          // TYPE3_ARRAY
   RTS_UI32                      lRTSSize;
   RTS_UI32                      lRTSArrayElementSize;   // TYPE3_ARRAY

   union ws_value                value_prev;
   union ws_value                value;
   union ws_value                delta;

   struct session_element*       pParentElement;
   struct session_element*       pStructMembers;         // nur f�r tTypeDesc._typeClass==TYPE3_USERDEF und TYPE3_ARRAY of TYPE3_USERDEF
                                                         // entsprechend tTypeDesc._union._struct._Components

   RTS_BOOL                      bRegistered;         
   RTS_BOOL                      bSubPath;
   RTS_BOOL                      bInSubPath;
   RTS_BOOL                      bWrite;
   RTS_BOOL                      bSubPathRegistered;     //  by example, important when at one time some member(s) of a structure (via subPath) are registered
                                                         //  and at another time another member (by subPath too) => the value for the 'regsiter' request should contains only the last requested value and not all registered

   RTS_UI32                      nRefreshMin;
   RTS_UI32                      nRefreshMax;
   RTS_UI32                      nLastUpdate;
};

typedef struct tagsubPath
{
	char*                         sSubPath;               // Path to Struct Member relative to the "address"
   struct session_element*       pElement;               // Pointer to RTSNode
} subPath;

struct session_elements{
   
   // Beispiel:
   // "Application1.PLC_PRG.C[5]" - Array index 5 of the array C in the main program PLC_PRG
   // "Application1.PLC_PRG.D.E"  - Element E of the structure D in main program PLC_PRG
   // "Application1.GVL.A"        - Variable A in the global variable list
   // "Application1.PLC_PRG.B"    - Variable B in the main program PLC_PRG
   // "NET:"                      - all paramters of the paramter service NET
   // "NET:Mac_Address1"          - parameter Mac_Address1 of the service NET
   char* address;

   subPath *subPaths;
   RTS_UI16  nCountOfSubPaths;

   struct session_element element;

   // verkettete Liste
	struct session_elements* pNext;
};

#define MAX_KIND_OF_MESSAGES  10
typedef struct {
   RTS_IEC_WORD   nIdxToMsg;
   RTS_IEC_BOOL   bOnChanged;
}session_message;

typedef struct {
   RTS_UI32 nRefreshTime;

   // Symbole/Parameter
   struct session_elements* pFirst;
   struct session_elements* pCurrent;
   RTS_UI16 nCurrentIndexToSubPath;

   RTS_IEC_WORD nStep;  // 0 - Datenpunkte/Symbole

   
} session_elrest;

typedef struct {
   RTS_UI32 nRefreshTime;

   // Symbole/Parameter
   struct session_elements* pFirst;
   struct session_elements* pCurrent;
   RTS_UI16 nCurrentIndexToSubPath;

   RTS_IEC_WORD nStep;  // 0 - Datenpunkte/Symbole
                        // 1 - Messages
      
   session_message message[MAX_KIND_OF_MESSAGES];
} session_motan;

typedef struct OPCUA_MonItem {
   RTS_UI32    nID;
   char*       sPath;
   void*       data;
   RTS_UI16    nType;
   RTS_BOOL    bToRegister;
   char        sRegUUID[24];

   struct OPCUA_MonItem* pNext;
} OPCUA_MonItem;

typedef struct {
   RTS_UI32 nRefreshTime;
   
   OPCUA_MonItem* pFirst;

   RTS_UI32 nOPCUASubscriptionId;   

} session_opcua;

typedef union {
	session_elrest elrest;		
	session_motan  motan;	
   session_opcua  opcua;
} SessionUnion;

// pro client
struct session_info{
   RTS_IEC_BYTE nType; // 0 - elrest 3S Symbole
                       // 1 - motan 3S Symbole & Messages
                       // 2 - OPCUA Items
   SessionUnion _union;
};

#define WSSERVER_NUM_OF_STATIC_RPCS 20
typedef struct
{
   RTS_IEC_STRING    sName[81];
   RTS_IEC_DWORD     nValueCount;
   CallbackStruct         cbFunction;
   RTS_IEC_INT       eTypeOfRPC; // siehe RPCTYPEENUM_RPCTYPE_
} STRUCT_RPCCALL;

/*typedef enum WSSERVER_CONNECTION_TYPEtag
{
	HTTP_ONLY,
	HTTPS_ONLY,
	HTTP_AND_HTTPS
} WSSERVER_CONNECTION_TYPE;*/

#ifdef _MOTANWSSERVERITF_H_
typedef struct
{
   RTS_IEC_WORD   nKind;

   RTS_IEC_WORD   nCountOfMsgMembers;
   TMsgMember*    pArrayOfMsgMembers;
   
   RTS_IEC_DWORD  nCountOfMsgs;
   void*          pListOfMessages;

   RTS_IEC_BOOL   bOnChanged;

} STRUCT_KIND_OF_MSG;
#endif

RTS_HANDLE GetLogWSServer(void);
RTS_RESULT SocketClose(RTS_HANDLE hSocket);
RTS_HANDLE SocketCreate(RTS_HANDLE hISysSocket, CLASSID ClassId, SysSock_Parameter *pParameter, RTS_RESULT *pResult);
RTS_HANDLE SocketAccept(RTS_HANDLE hISysSocket, CLASSID ClassId, RTS_HANDLE hSocket, SOCKADDRESS *pSockAddr, RTS_I32 *piSockAddrSize, RTS_RESULT *pResult);

void StartCommunicationThread(RTS_UI32 iTaskPriority, RTS_UI32 iTaskInterval, RTS_UI32 iTaskStackSize);
RTS_RESULT StopCommunicationThread();
void RestartCommunicationThread();
RTS_IEC_BOOL WSServerThreadIsRunning();

ParameterService *GetNewParameterService(RTS_RESULT *pResult);
ParameterService* GetServiceByName(char* szUserName, char* szService, RTS_RESULT* pResult);

STRUCT_RPCCALL* GetCallByName(RTS_IEC_STRING* sName);

extern RTS_HANDLE s_hLog;
