/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component CmpWSServer</name>
 *  <description> 
 *  An example on how to implement a component.
 *  This component does no usefull work and it exports no functions
 *  which are intended to be used for anything. Use at your own risk.
 *  </description>
 *  <copyright>
 *  (c) 2010 elrest Automationssysteme GmbH
 *  </copyright>
 */
#ifndef _CMPWSSERVERDEP_H_
#define _CMPWSSERVERDEP_H_

#define COMPONENT_NAME "CmpWSServer" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_CmpWSServer)
#define COMPONENT_NAME_UNQUOTED CmpWSServer





#define CMP_VERSION         UINT32_C(0x00020015)
#define CMP_VERSION_STRING "0.2.0.21"
#define CMP_VERSION_RC      0,2,0,21
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"			


/* elrest target defines for V3 components*/
#ifdef WAGO
#include <WagoSysdefines.h>
#define CLASSID_TscLED 	ADDVENDORID(CMP_VENDORID, TSCSYSWEBSOCKETSERVER_CLASSID_C)
#define CMPID_CmpWSServer  TSCSYSWEBSOCKETSERVER_CMPID
#define ITFID_TscLED    ADDVENDORID(CMP_VENDORID, TSCSYSWEBSOCKETSERVER_CLASSID_C)

#ifdef CODESYS_V3_5_5_10
#define VariableInformationStructN  VariableInformationStruct2
#define MyCAL_IecVarAccGetNodeN(pszPath, phInterface, pVariableInformation, pResult)      CAL_IecVarAccGetNode3(pszPath, phInterface, pVariableInformation, pResult)
#define MyCAL_IecVarAccInitVarInfo(pVariableInformation, nSizeOfVariableInformation)      memset(pVariableInformation, 0, nSizeOfVariableInformation)
#else
#define VariableInformationStructN VariableInformationStruct3
#define CAL_IecVarAccGetNodeN(pszPath, phInterface, pVariableInformation, pResult)       CAL_IecVarAccGetNode3(pszPath, phInterface, (VariableInformationStruct2*)pVariableInformation, pResult)
#define MyCAL_IecVarAccInitVarInfo(pVariableInformation, nSizeOfVariableInformation)     CAL_IecVarAccInitVarInfo((VariableInformationStruct2*)pVariableInformation, nSizeOfVariableInformation) //memset(pVariableInformation, 0, nSizeOfVariableInformation)
#define MyCAL_IecVarAccExitVarInfo(pVariableInformation)                                 CAL_IecVarAccExitVarInfo((VariableInformationStruct2*)pVariableInformation) 
#endif
#include <sys/socket.h>
#include <poll.h>

#define eWS_POLLIN   (POLLIN)
#define eWS_POLLOUT  (POLLOUT)
#define eWS_POLLHUP  (POLLHUP|POLLERR)

#define eWS_set_blocking_send(ews)
#define VENDOR_3S_ID				0x0000

#else
#include "SysTargetDefines.h"
#endif

#ifdef ERR_OK
#undef ERR_OK
#endif
#include "SysErrorItf.h"

#include "SysCpuHandlingItf.h"


#include "SysFileItf.h"


#include "SysMemItf.h"


#include "SysTimeItf.h"


#include "SysSocketItf.h"


#include "SysSocket2Itf.h"


#include "SysSemItf.h"


#include "SysFileItf.h"


#include "CMLockItf.h"


#include "CmpMemPoolItf.h"


#include "CmpIecVarAccessItf.h"


#include "CmpSettingsItf.h"


#include "CmpEventMgrItf.h"


#include "CmpAppItf.h"


#include "CmpWebServerItf.h"


#include "CMItf.h"


/*Obsolete include: CMUtilsItf.m4*/


#include "CmpParameterServerItf.h"


#include "SysUtilItf.h"


#include "SysTaskItf.h"


#include "CmpTlsItf.h"


#include "SysExceptItf.h"


/*Obsolete include: CmpLogItf.m4*/


#include "SysTaskItf.h"


#include "SysDirItf.h"


#include "SysProcessItf.h"


#include "CmpUserDBItf.h"


#include "SysParameterSettingsItf.h"


#include "CmpIecStringUtilsItf.h"


#include "TscDrmIecInterfaceItf.h"


#include "CmpElrestOPCUAClientItf.h"








/**
 * \file CmpWSServerItf.h
 */
#include "CmpWSServerItf.h"

/**
 * \file WSServerLibItf.h
 */
#include "WSServerLibItf.h"









/*USE_ITF(`CMLockItf.m4')*/
#include "SysTargetItf.h"



        































































































































     































































































































     



        































      































      





#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pISysTarget == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTarget, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTarget = (ISysTarget *)pIBase->QueryInterface(pIBase, ITFID_ISysTarget, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpElrestOPCUAClient == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpElrestOPCUAClient, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpElrestOPCUAClient = (ICmpElrestOPCUAClient *)pIBase->QueryInterface(pIBase, ITFID_ICmpElrestOPCUAClient, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pITscDrmIecInterface == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscDrmIecInterface, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscDrmIecInterface = (ITscDrmIecInterface *)pIBase->QueryInterface(pIBase, ITFID_ITscDrmIecInterface, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpIecStringUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpIecStringUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpIecStringUtils = (ICmpIecStringUtils *)pIBase->QueryInterface(pIBase, ITFID_ICmpIecStringUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysParameterSettings == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysParameterSettings, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysParameterSettings = (ISysParameterSettings *)pIBase->QueryInterface(pIBase, ITFID_ISysParameterSettings, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpUserDB == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpUserDB, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpUserDB = (ICmpUserDB *)pIBase->QueryInterface(pIBase, ITFID_ICmpUserDB, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysProcess == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysProcess, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysProcess = (ISysProcess *)pIBase->QueryInterface(pIBase, ITFID_ISysProcess, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysDir == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysDir, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysDir = (ISysDir *)pIBase->QueryInterface(pIBase, ITFID_ISysDir, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          /*Obsolete include CmpLog*/ \
		  if (pISysExcept == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysExcept, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysExcept = (ISysExcept *)pIBase->QueryInterface(pIBase, ITFID_ISysExcept, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpTls == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpTls, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpTls = (ICmpTls *)pIBase->QueryInterface(pIBase, ITFID_ICmpTls, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysUtil == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysUtil, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysUtil = (ISysUtil *)pIBase->QueryInterface(pIBase, ITFID_ISysUtil, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpParameterServer == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpParameterServer, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpParameterServer = (ICmpParameterServer *)pIBase->QueryInterface(pIBase, ITFID_ICmpParameterServer, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		  if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpWebServer == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpWebServer, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpWebServer = (ICmpWebServer *)pIBase->QueryInterface(pIBase, ITFID_ICmpWebServer, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpEventMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpEventMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpEventMgr = (ICmpEventMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpEventMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpSettings == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSettings, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSettings = (ICmpSettings *)pIBase->QueryInterface(pIBase, ITFID_ICmpSettings, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpIecVarAccess == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpIecVarAccess, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpIecVarAccess = (ICmpIecVarAccess *)pIBase->QueryInterface(pIBase, ITFID_ICmpIecVarAccess, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpMemPool == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpMemPool, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpMemPool = (ICmpMemPool *)pIBase->QueryInterface(pIBase, ITFID_ICmpMemPool, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICMLock == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMLock, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMLock = (ICMLock *)pIBase->QueryInterface(pIBase, ITFID_ICMLock, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysFile == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysFile, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysFile = (ISysFile *)pIBase->QueryInterface(pIBase, ITFID_ISysFile, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysSem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysSem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysSem = (ISysSem *)pIBase->QueryInterface(pIBase, ITFID_ISysSem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysSocket2 == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysSocket2, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysSocket2 = (ISysSocket2 *)pIBase->QueryInterface(pIBase, ITFID_ISysSocket2, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysSocket == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysSocket, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysSocket = (ISysSocket *)pIBase->QueryInterface(pIBase, ITFID_ISysSocket, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTime == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTime, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTime = (ISysTime *)pIBase->QueryInterface(pIBase, ITFID_ISysTime, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysMem == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysMem, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysMem = (ISysMem *)pIBase->QueryInterface(pIBase, ITFID_ISysMem, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysFile == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysFile, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysFile = (ISysFile *)pIBase->QueryInterface(pIBase, ITFID_ISysFile, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysCpuHandling == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysCpuHandling, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysCpuHandling = (ISysCpuHandling *)pIBase->QueryInterface(pIBase, ITFID_ISysCpuHandling, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pISysTarget = NULL; \
          pICmpElrestOPCUAClient = NULL; \
          pITscDrmIecInterface = NULL; \
          pICmpIecStringUtils = NULL; \
          pISysParameterSettings = NULL; \
          pICmpUserDB = NULL; \
          pISysProcess = NULL; \
          pISysDir = NULL; \
          pISysTask = NULL; \
          /*Obsolete include CmpLog*/ \
		  pISysExcept = NULL; \
          pICmpTls = NULL; \
          pISysTask = NULL; \
          pISysUtil = NULL; \
          pICmpParameterServer = NULL; \
          /*Obsolete include CMUtils*/ \
		  pICM = NULL; \
          pICmpWebServer = NULL; \
          pICmpApp = NULL; \
          pICmpEventMgr = NULL; \
          pICmpSettings = NULL; \
          pICmpIecVarAccess = NULL; \
          pICmpMemPool = NULL; \
          pICMLock = NULL; \
          pISysFile = NULL; \
          pISysSem = NULL; \
          pISysSocket2 = NULL; \
          pISysSocket = NULL; \
          pISysTime = NULL; \
          pISysMem = NULL; \
          pISysFile = NULL; \
          pISysCpuHandling = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pISysTarget != NULL) \
        { \
            pIBase = (IBase *)pISysTarget->QueryInterface(pISysTarget, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTarget = NULL; \
            } \
        } \
          if (pICmpElrestOPCUAClient != NULL) \
        { \
            pIBase = (IBase *)pICmpElrestOPCUAClient->QueryInterface(pICmpElrestOPCUAClient, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpElrestOPCUAClient = NULL; \
            } \
        } \
          if (pITscDrmIecInterface != NULL) \
        { \
            pIBase = (IBase *)pITscDrmIecInterface->QueryInterface(pITscDrmIecInterface, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscDrmIecInterface = NULL; \
            } \
        } \
          if (pICmpIecStringUtils != NULL) \
        { \
            pIBase = (IBase *)pICmpIecStringUtils->QueryInterface(pICmpIecStringUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpIecStringUtils = NULL; \
            } \
        } \
          if (pISysParameterSettings != NULL) \
        { \
            pIBase = (IBase *)pISysParameterSettings->QueryInterface(pISysParameterSettings, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysParameterSettings = NULL; \
            } \
        } \
          if (pICmpUserDB != NULL) \
        { \
            pIBase = (IBase *)pICmpUserDB->QueryInterface(pICmpUserDB, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpUserDB = NULL; \
            } \
        } \
          if (pISysProcess != NULL) \
        { \
            pIBase = (IBase *)pISysProcess->QueryInterface(pISysProcess, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysProcess = NULL; \
            } \
        } \
          if (pISysDir != NULL) \
        { \
            pIBase = (IBase *)pISysDir->QueryInterface(pISysDir, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysDir = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
          /*Obsolete include CmpLog*/ \
		  if (pISysExcept != NULL) \
        { \
            pIBase = (IBase *)pISysExcept->QueryInterface(pISysExcept, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysExcept = NULL; \
            } \
        } \
          if (pICmpTls != NULL) \
        { \
            pIBase = (IBase *)pICmpTls->QueryInterface(pICmpTls, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpTls = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
          if (pISysUtil != NULL) \
        { \
            pIBase = (IBase *)pISysUtil->QueryInterface(pISysUtil, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysUtil = NULL; \
            } \
        } \
          if (pICmpParameterServer != NULL) \
        { \
            pIBase = (IBase *)pICmpParameterServer->QueryInterface(pICmpParameterServer, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpParameterServer = NULL; \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		  if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
          if (pICmpWebServer != NULL) \
        { \
            pIBase = (IBase *)pICmpWebServer->QueryInterface(pICmpWebServer, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpWebServer = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pICmpEventMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpEventMgr->QueryInterface(pICmpEventMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpEventMgr = NULL; \
            } \
        } \
          if (pICmpSettings != NULL) \
        { \
            pIBase = (IBase *)pICmpSettings->QueryInterface(pICmpSettings, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSettings = NULL; \
            } \
        } \
          if (pICmpIecVarAccess != NULL) \
        { \
            pIBase = (IBase *)pICmpIecVarAccess->QueryInterface(pICmpIecVarAccess, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpIecVarAccess = NULL; \
            } \
        } \
          if (pICmpMemPool != NULL) \
        { \
            pIBase = (IBase *)pICmpMemPool->QueryInterface(pICmpMemPool, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpMemPool = NULL; \
            } \
        } \
          if (pICMLock != NULL) \
        { \
            pIBase = (IBase *)pICMLock->QueryInterface(pICMLock, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMLock = NULL; \
            } \
        } \
          if (pISysFile != NULL) \
        { \
            pIBase = (IBase *)pISysFile->QueryInterface(pISysFile, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysFile = NULL; \
            } \
        } \
          if (pISysSem != NULL) \
        { \
            pIBase = (IBase *)pISysSem->QueryInterface(pISysSem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysSem = NULL; \
            } \
        } \
          if (pISysSocket2 != NULL) \
        { \
            pIBase = (IBase *)pISysSocket2->QueryInterface(pISysSocket2, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysSocket2 = NULL; \
            } \
        } \
          if (pISysSocket != NULL) \
        { \
            pIBase = (IBase *)pISysSocket->QueryInterface(pISysSocket, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysSocket = NULL; \
            } \
        } \
          if (pISysTime != NULL) \
        { \
            pIBase = (IBase *)pISysTime->QueryInterface(pISysTime, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTime = NULL; \
            } \
        } \
          if (pISysMem != NULL) \
        { \
            pIBase = (IBase *)pISysMem->QueryInterface(pISysMem, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysMem = NULL; \
            } \
        } \
          if (pISysFile != NULL) \
        { \
            pIBase = (IBase *)pISysFile->QueryInterface(pISysFile, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysFile = NULL; \
            } \
        } \
          if (pISysCpuHandling != NULL) \
        { \
            pIBase = (IBase *)pISysCpuHandling->QueryInterface(pISysCpuHandling, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysCpuHandling = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) TempResult = GET_fureleaseexplicitlicense(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_fugetlicensestate(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_fucheckexplicitlicense(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_WebServerRequestRunning(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_ParameterServerGetNamespace(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_ParameterServerGetCountOfNamespaces(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_DateTime_toUnixTime(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_Browse(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_Log(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_UnregValue(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_GetValueAndTypeFromHandle(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_Client_run_iterate(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_RegValueChange(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_RegValue(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_CreateSubscription(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_Disconnect(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_ClearValue(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_SetValue(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_GetValue(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_eUA_Connect(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysParameterSettings_VerifyPassword(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_TlsFreeContext(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_TlsCreateContext(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_ParameterServerCall(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_ParameterServerGetInfo(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_ParameterServerSet(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_ParameterServerGet(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogUnregisterBackend(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogRegisterBackend(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogDelete(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_LogCreate(CM_IMPORT_OPTIONAL_FUNCTION);\
          /*Obsolete optional include LogAdd*/ \
		  if (ERR_OK == importResult ) importResult = GET_SysProcessExecuteCommand2(0);\
          if (ERR_OK == importResult ) importResult = GET_SysExceptConvertToString(0);\
          if (ERR_OK == importResult ) importResult = GET_SysExceptTry(0);\
          if (ERR_OK == importResult ) importResult = GET_SysExceptCatch(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccBrowseUp(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SysDirCreate2(0);\
          if (ERR_OK == importResult ) importResult = GET_stusprintf(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskSetExit(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskGetInfo(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnter(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskWaitSleep(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnd(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskLeave(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskResume(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskExit(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskGetCurrent(0);\
          if (ERR_OK == importResult ) importResult = GET_SysUtilCreateUUID(0);\
          if (ERR_OK == importResult ) importResult = GET_SysUtilConvStringToUTF83(0);\
          if (ERR_OK == importResult ) importResult = GET_SysUtilConvUTF8ToString4(0);\
          if (ERR_OK == importResult ) importResult = GET_SysUtilConvUTF8ToWString(0);\
          if (ERR_OK == importResult ) importResult = GET_SysUtilConvWStringToUTF8(0);\
          if (ERR_OK == importResult ) importResult = GET_SysCpuCallIecFuncWithParams(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolUnlockBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolLockBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolGetBlock2(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolUnlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolLock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolIsValidBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolRemoveUsedBlockFromPool(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolAddUsedBlockToPool(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolRemoveUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolAddUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolPutBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolExtendDynamic(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolGetBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolCreateStatic(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlsnprintf(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeMemCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlwstrncmp(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlwstrcmp(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlStrIStr(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCat(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlwstrlen(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrNCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlwstrcpy(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlStrICmp(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlStrLen(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlStrNICmp(0);\
          if (ERR_OK == importResult ) importResult = GET_CMDeleteInstance(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemReallocData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemFreeData(0);\
          if (ERR_OK == importResult ) importResult = GET_SysMemAllocData(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgRemoveKey(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgSetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgSetIntValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetIntValue(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventGetEvent(0);\
          if (ERR_OK == importResult ) importResult = GET_EventCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetEnumValues(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeClassFromType(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeNodeByIndex(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNumOfTypes(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNodeType(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNodeFullPath3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNodeFullPath(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeName(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccBrowseGetNext(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccBrowseDown(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccBrowseGetRoot(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccExitVarInfo(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccInitVarInfo(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetClientOffset(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetAccessRights(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNodeName(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeDesc(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeNode(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeNode3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccSetValue3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetValue3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeClass3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetSize3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNode4(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNode3(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetNode(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetTypeClass(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetSize(0);\
          if (ERR_OK == importResult ) importResult = GET_IecVarAccGetFirstInterface(0);\
          if (ERR_OK == importResult ) importResult = GET_SysDirClose(0);\
          if (ERR_OK == importResult ) importResult = GET_SysDirOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileFlush(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileWrite(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileGetSize(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileGetPath2(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileGetPath(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileClose(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileSetPos(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileGetPos(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileRead(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileGetSizeByHandle(0);\
          if (ERR_OK == importResult ) importResult = GET_SysFileOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemLeave(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemEnter(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSemCreate(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTimeGetMs(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockInetNtoa(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSock2FdIsset(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockGetHostName(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockFdZero(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockNtohs(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockNtohl(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockHtonl(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockInetAddr(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockGetHostByName(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSockHtons(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSock2Close(0);\
          if (ERR_OK == importResult ) importResult = GET_SysSock2Create(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTargetGetVersion(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTargetGetId(0);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef CMPWSSERVER_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
            { (RTS_VOID_FCTPTR)setparameterfun, "setparameterfun", 0xDF3B0F24, 0x03051314 },\
          { (RTS_VOID_FCTPTR)setlasterrorfun, "setlasterrorfun", 0x70D134D5, 0x03051314 },\
          { (RTS_VOID_FCTPTR)removelocalclientfun, "removelocalclientfun", 0xDE3B14FB, 0x03051314 },\
          { (RTS_VOID_FCTPTR)removealllocalclientsfun, "removealllocalclientsfun", 0xCD35F1BD, 0x03051314 },\
          { (RTS_VOID_FCTPTR)registerrpfun, "registerrpfun", 0xE95228FB, 0x03051314 },\
          { (RTS_VOID_FCTPTR)registerrp2fun, "registerrp2fun", 0x0BA96B93, 0x03051315 },\
          { (RTS_VOID_FCTPTR)registercallbackfun, "registercallbackfun", 0xCF0A2177, 0x03051314 },\
          { (RTS_VOID_FCTPTR)getstatefun, "getstatefun", 0x2E45D36A, 0x03051314 },\
          { (RTS_VOID_FCTPTR)getparameterfun, "getparameterfun", 0x631D455F, 0x03051314 },\
          { (RTS_VOID_FCTPTR)getalllocalclientsfun, "getalllocalclientsfun", 0xD2A04FD2, 0x03051314 },\
          { (RTS_VOID_FCTPTR)call2, "call2", 0x6C3EAAEF, 0x03051314 },\
          { (RTS_VOID_FCTPTR)call, "call", 0x1DAEFC73, 0x03051314 },\
          { (RTS_VOID_FCTPTR)addlocalclientfun, "addlocalclientfun", 0xA29BCA1B, 0x03051314 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef CMPWSSERVER_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                      
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(CMPWSSERVER_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
        { (RTS_VOID_FCTPTR)MotanWSServerHandlerV3, "MotanWSServerHandlerV3", 0, 0 },\
          { (RTS_VOID_FCTPTR)WSServerHandlerV3, "WSServerHandlerV3", 0, 0 },\
                                    \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysCpuHandling     \
	ITF_SysFile     \
	ITF_SysMem     \
	ITF_SysTime     \
	ITF_SysSocket     \
	ITF_SysSocket2     \
	ITF_SysSem     \
	ITF_SysFile     \
	ITF_CMLock     \
	ITF_CmpMemPool     \
	ITF_CmpIecVarAccess     \
	ITF_CmpSettings     \
	ITF_CmpEventMgr     \
	ITF_CmpApp     \
	ITF_CmpWebServer     \
	ITF_CM     \
	/*obsolete entry ITF_CMUtils*/      \
	ITF_CmpParameterServer     \
	ITF_SysUtil     \
	ITF_SysTask     \
	ITF_CmpTls     \
	ITF_SysExcept     \
	/*obsolete entry ITF_CmpLog*/      \
	ITF_SysTask     \
	ITF_SysDir     \
	ITF_SysProcess     \
	ITF_CmpUserDB     \
	ITF_SysParameterSettings     \
	ITF_CmpIecStringUtils     \
	ITF_TscDrmIecInterface     \
	ITF_CmpElrestOPCUAClient     \
	ITF_SysTarget      \
    USE_SysTargetGetId      \
    USE_SysTargetGetVersion      \
    USE_SysSock2Create      \
    USE_SysSock2Close      \
    USE_SysSockHtons      \
    USE_SysSockGetHostByName      \
    USE_SysSockInetAddr      \
    USE_SysSockHtonl      \
    USE_SysSockNtohl      \
    USE_SysSockNtohs      \
    USE_SysSockFdZero      \
    USE_SysSockGetHostName      \
    USE_SysSock2FdIsset      \
    USE_SysSockInetNtoa      \
    USE_SysTimeGetMs      \
    USE_SysSemCreate      \
    USE_SysSemDelete      \
    USE_SysSemEnter      \
    USE_SysSemLeave      \
    USE_SysFileOpen      \
    USE_SysFileGetSizeByHandle      \
    USE_SysFileRead      \
    USE_SysFileGetPos      \
    USE_SysFileSetPos      \
    USE_SysFileClose      \
    USE_SysFileGetPath      \
    USE_SysFileGetPath2      \
    USE_SysFileGetSize      \
    USE_SysFileWrite      \
    USE_SysFileFlush      \
    USE_SysDirOpen      \
    USE_SysDirClose      \
    USE_IecVarAccGetFirstInterface      \
    USE_IecVarAccGetSize      \
    USE_IecVarAccGetTypeClass      \
    USE_IecVarAccGetNode      \
    USE_IecVarAccGetNode3      \
    USE_IecVarAccGetNode4      \
    USE_IecVarAccGetSize3      \
    USE_IecVarAccGetTypeClass3      \
    USE_IecVarAccGetValue3      \
    USE_IecVarAccSetValue3      \
    USE_IecVarAccGetTypeNode3      \
    USE_IecVarAccGetTypeNode      \
    USE_IecVarAccGetTypeDesc      \
    USE_IecVarAccGetNodeName      \
    USE_IecVarAccGetAccessRights      \
    USE_IecVarAccGetClientOffset      \
    USE_IecVarAccInitVarInfo      \
    USE_IecVarAccExitVarInfo      \
    USE_IecVarAccBrowseGetRoot      \
    USE_IecVarAccBrowseDown      \
    USE_IecVarAccBrowseGetNext      \
    USE_IecVarAccGetTypeName      \
    USE_IecVarAccGetNodeFullPath      \
    USE_IecVarAccGetNodeFullPath3      \
    USE_IecVarAccGetNodeType      \
    USE_IecVarAccGetNumOfTypes      \
    USE_IecVarAccGetTypeNodeByIndex      \
    USE_IecVarAccGetTypeClassFromType      \
    USE_IecVarAccGetEnumValues      \
    USE_EventOpen      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventCreate      \
    USE_EventGetEvent      \
    USE_EventClose      \
    USE_SettgGetIntValue      \
    USE_SettgSetIntValue      \
    USE_SettgGetStringValue      \
    USE_SettgSetStringValue      \
    USE_SettgRemoveKey      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_SysMemReallocData      \
    USE_CMDeleteInstance      \
    USE_CMUtlStrNICmp      \
    USE_CMUtlSafeStrCpy      \
    USE_CMUtlStrLen      \
    USE_CMUtlStrICmp      \
    USE_CMUtlwstrcpy      \
    USE_CMUtlSafeStrNCpy      \
    USE_CMUtlwstrlen      \
    USE_CMUtlSafeStrCat      \
    USE_CMUtlStrIStr      \
    USE_CMUtlwstrcmp      \
    USE_CMUtlwstrncmp      \
    USE_CMUtlSafeMemCpy      \
    USE_CMUtlsnprintf      \
    USE_MemPoolCreateStatic      \
    USE_MemPoolDelete      \
    USE_MemPoolGetBlock      \
    USE_MemPoolExtendDynamic      \
    USE_MemPoolPutBlock      \
    USE_MemPoolAddUsedBlock      \
    USE_MemPoolRemoveUsedBlock      \
    USE_MemPoolAddUsedBlockToPool      \
    USE_MemPoolRemoveUsedBlockFromPool      \
    USE_MemPoolIsValidBlock      \
    USE_MemPoolLock      \
    USE_MemPoolUnlock      \
    USE_MemPoolGetBlock2      \
    USE_MemPoolLockBlock      \
    USE_MemPoolUnlockBlock      \
    USE_SysCpuCallIecFuncWithParams      \
    USE_SysUtilConvWStringToUTF8      \
    USE_SysUtilConvUTF8ToWString      \
    USE_SysUtilConvUTF8ToString4      \
    USE_SysUtilConvStringToUTF83      \
    USE_SysUtilCreateUUID      \
    USE_SysTaskGetCurrent      \
    USE_SysTaskCreate      \
    USE_SysTaskExit      \
    USE_SysTaskResume      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskWaitSleep      \
    USE_SysTaskEnter      \
    USE_SysTaskGetInfo      \
    USE_SysTaskSetExit      \
    USE_stusprintf      \
    USE_SysDirCreate2      \
    USE_IecVarAccGetValue      \
    USE_IecVarAccBrowseUp      \
    USE_SysExceptCatch      \
    USE_SysExceptTry      \
    USE_SysExceptConvertToString      \
    USE_SysProcessExecuteCommand2      \
    /*obsolete USE_LogAdd*/      \
    USE_LogCreate      \
    USE_LogDelete      \
    USE_LogRegisterBackend      \
    USE_LogUnregisterBackend      \
    USE_ParameterServerGet      \
    USE_ParameterServerSet      \
    USE_ParameterServerGetInfo      \
    USE_ParameterServerCall      \
    USE_TlsCreateContext      \
    USE_TlsFreeContext      \
    USE_SysParameterSettings_VerifyPassword      \
    USE_eUA_Connect      \
    USE_eUA_GetValue      \
    USE_eUA_SetValue      \
    USE_eUA_ClearValue      \
    USE_eUA_Disconnect      \
    USE_eUA_CreateSubscription      \
    USE_eUA_RegValue      \
    USE_eUA_RegValueChange      \
    USE_eUA_Client_run_iterate      \
    USE_eUA_GetValueAndTypeFromHandle      \
    USE_eUA_UnregValue      \
    USE_eUA_Log      \
    USE_eUA_Browse      \
    USE_eUA_DateTime_toUnixTime      \
    USE_ParameterServerGetCountOfNamespaces      \
    USE_ParameterServerGetNamespace      \
    USE_WebServerRequestRunning      \
    USE_fucheckexplicitlicense      \
    USE_fugetlicensestate      \
    USE_fureleaseexplicitlicense     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysCpuHandling    \
	ITF_SysFile    \
	ITF_SysMem    \
	ITF_SysTime    \
	ITF_SysSocket    \
	ITF_SysSocket2    \
	ITF_SysSem    \
	ITF_SysFile    \
	ITF_CMLock    \
	ITF_CmpMemPool    \
	ITF_CmpIecVarAccess    \
	ITF_CmpSettings    \
	ITF_CmpEventMgr    \
	ITF_CmpApp    \
	ITF_CmpWebServer    \
	ITF_CM    \
	/*obsolete entry ITF_CMUtils*/     \
	ITF_CmpParameterServer    \
	ITF_SysUtil    \
	ITF_SysTask    \
	ITF_CmpTls    \
	ITF_SysExcept    \
	/*obsolete entry ITF_CmpLog*/     \
	ITF_SysTask    \
	ITF_SysDir    \
	ITF_SysProcess    \
	ITF_CmpUserDB    \
	ITF_SysParameterSettings    \
	ITF_CmpIecStringUtils    \
	ITF_TscDrmIecInterface    \
	ITF_CmpElrestOPCUAClient    \
	ITF_SysTarget     \
    USE_SysTargetGetId      \
    USE_SysTargetGetVersion      \
    USE_SysSock2Create      \
    USE_SysSock2Close      \
    USE_SysSockHtons      \
    USE_SysSockGetHostByName      \
    USE_SysSockInetAddr      \
    USE_SysSockHtonl      \
    USE_SysSockNtohl      \
    USE_SysSockNtohs      \
    USE_SysSockFdZero      \
    USE_SysSockGetHostName      \
    USE_SysSock2FdIsset      \
    USE_SysSockInetNtoa      \
    USE_SysTimeGetMs      \
    USE_SysSemCreate      \
    USE_SysSemDelete      \
    USE_SysSemEnter      \
    USE_SysSemLeave      \
    USE_SysFileOpen      \
    USE_SysFileGetSizeByHandle      \
    USE_SysFileRead      \
    USE_SysFileGetPos      \
    USE_SysFileSetPos      \
    USE_SysFileClose      \
    USE_SysFileGetPath      \
    USE_SysFileGetPath2      \
    USE_SysFileGetSize      \
    USE_SysFileWrite      \
    USE_SysFileFlush      \
    USE_SysDirOpen      \
    USE_SysDirClose      \
    USE_IecVarAccGetFirstInterface      \
    USE_IecVarAccGetSize      \
    USE_IecVarAccGetTypeClass      \
    USE_IecVarAccGetNode      \
    USE_IecVarAccGetNode3      \
    USE_IecVarAccGetNode4      \
    USE_IecVarAccGetSize3      \
    USE_IecVarAccGetTypeClass3      \
    USE_IecVarAccGetValue3      \
    USE_IecVarAccSetValue3      \
    USE_IecVarAccGetTypeNode3      \
    USE_IecVarAccGetTypeNode      \
    USE_IecVarAccGetTypeDesc      \
    USE_IecVarAccGetNodeName      \
    USE_IecVarAccGetAccessRights      \
    USE_IecVarAccGetClientOffset      \
    USE_IecVarAccInitVarInfo      \
    USE_IecVarAccExitVarInfo      \
    USE_IecVarAccBrowseGetRoot      \
    USE_IecVarAccBrowseDown      \
    USE_IecVarAccBrowseGetNext      \
    USE_IecVarAccGetTypeName      \
    USE_IecVarAccGetNodeFullPath      \
    USE_IecVarAccGetNodeFullPath3      \
    USE_IecVarAccGetNodeType      \
    USE_IecVarAccGetNumOfTypes      \
    USE_IecVarAccGetTypeNodeByIndex      \
    USE_IecVarAccGetTypeClassFromType      \
    USE_IecVarAccGetEnumValues      \
    USE_EventOpen      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventCreate      \
    USE_EventGetEvent      \
    USE_EventClose      \
    USE_SettgGetIntValue      \
    USE_SettgSetIntValue      \
    USE_SettgGetStringValue      \
    USE_SettgSetStringValue      \
    USE_SettgRemoveKey      \
    USE_SysMemAllocData      \
    USE_SysMemFreeData      \
    USE_SysMemReallocData      \
    USE_CMDeleteInstance      \
    USE_CMUtlStrNICmp      \
    USE_CMUtlSafeStrCpy      \
    USE_CMUtlStrLen      \
    USE_CMUtlStrICmp      \
    USE_CMUtlwstrcpy      \
    USE_CMUtlSafeStrNCpy      \
    USE_CMUtlwstrlen      \
    USE_CMUtlSafeStrCat      \
    USE_CMUtlStrIStr      \
    USE_CMUtlwstrcmp      \
    USE_CMUtlwstrncmp      \
    USE_CMUtlSafeMemCpy      \
    USE_CMUtlsnprintf      \
    USE_MemPoolCreateStatic      \
    USE_MemPoolDelete      \
    USE_MemPoolGetBlock      \
    USE_MemPoolExtendDynamic      \
    USE_MemPoolPutBlock      \
    USE_MemPoolAddUsedBlock      \
    USE_MemPoolRemoveUsedBlock      \
    USE_MemPoolAddUsedBlockToPool      \
    USE_MemPoolRemoveUsedBlockFromPool      \
    USE_MemPoolIsValidBlock      \
    USE_MemPoolLock      \
    USE_MemPoolUnlock      \
    USE_MemPoolGetBlock2      \
    USE_MemPoolLockBlock      \
    USE_MemPoolUnlockBlock      \
    USE_SysCpuCallIecFuncWithParams      \
    USE_SysUtilConvWStringToUTF8      \
    USE_SysUtilConvUTF8ToWString      \
    USE_SysUtilConvUTF8ToString4      \
    USE_SysUtilConvStringToUTF83      \
    USE_SysUtilCreateUUID      \
    USE_SysTaskGetCurrent      \
    USE_SysTaskCreate      \
    USE_SysTaskExit      \
    USE_SysTaskResume      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskWaitSleep      \
    USE_SysTaskEnter      \
    USE_SysTaskGetInfo      \
    USE_SysTaskSetExit      \
    USE_stusprintf      \
    USE_SysDirCreate2      \
    USE_IecVarAccGetValue      \
    USE_IecVarAccBrowseUp      \
    USE_SysExceptCatch      \
    USE_SysExceptTry      \
    USE_SysExceptConvertToString      \
    USE_SysProcessExecuteCommand2      \
    /*obsolete USE_LogAdd*/      \
    USE_LogCreate      \
    USE_LogDelete      \
    USE_LogRegisterBackend      \
    USE_LogUnregisterBackend      \
    USE_ParameterServerGet      \
    USE_ParameterServerSet      \
    USE_ParameterServerGetInfo      \
    USE_ParameterServerCall      \
    USE_TlsCreateContext      \
    USE_TlsFreeContext      \
    USE_SysParameterSettings_VerifyPassword      \
    USE_eUA_Connect      \
    USE_eUA_GetValue      \
    USE_eUA_SetValue      \
    USE_eUA_ClearValue      \
    USE_eUA_Disconnect      \
    USE_eUA_CreateSubscription      \
    USE_eUA_RegValue      \
    USE_eUA_RegValueChange      \
    USE_eUA_Client_run_iterate      \
    USE_eUA_GetValueAndTypeFromHandle      \
    USE_eUA_UnregValue      \
    USE_eUA_Log      \
    USE_eUA_Browse      \
    USE_eUA_DateTime_toUnixTime      \
    USE_ParameterServerGetCountOfNamespaces      \
    USE_ParameterServerGetNamespace      \
    USE_WebServerRequestRunning      \
    USE_fucheckexplicitlicense      \
    USE_fugetlicensestate      \
    USE_fureleaseexplicitlicense     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysCpuHandling    \
	EXTITF_SysFile    \
	EXTITF_SysMem    \
	EXTITF_SysTime    \
	EXTITF_SysSocket    \
	EXTITF_SysSocket2    \
	EXTITF_SysSem    \
	EXTITF_SysFile    \
	EXTITF_CMLock    \
	EXTITF_CmpMemPool    \
	EXTITF_CmpIecVarAccess    \
	EXTITF_CmpSettings    \
	EXTITF_CmpEventMgr    \
	EXTITF_CmpApp    \
	EXTITF_CmpWebServer    \
	EXTITF_CM    \
	/*obsolete entry EXTITF_CMUtils*/     \
	EXTITF_CmpParameterServer    \
	EXTITF_SysUtil    \
	EXTITF_SysTask    \
	EXTITF_CmpTls    \
	EXTITF_SysExcept    \
	/*obsolete entry EXTITF_CmpLog*/     \
	EXTITF_SysTask    \
	EXTITF_SysDir    \
	EXTITF_SysProcess    \
	EXTITF_CmpUserDB    \
	EXTITF_SysParameterSettings    \
	EXTITF_CmpIecStringUtils    \
	EXTITF_TscDrmIecInterface    \
	EXTITF_CmpElrestOPCUAClient    \
	EXTITF_SysTarget     \
    EXT_SysTargetGetId  \
    EXT_SysTargetGetVersion  \
    EXT_SysSock2Create  \
    EXT_SysSock2Close  \
    EXT_SysSockHtons  \
    EXT_SysSockGetHostByName  \
    EXT_SysSockInetAddr  \
    EXT_SysSockHtonl  \
    EXT_SysSockNtohl  \
    EXT_SysSockNtohs  \
    EXT_SysSockFdZero  \
    EXT_SysSockGetHostName  \
    EXT_SysSock2FdIsset  \
    EXT_SysSockInetNtoa  \
    EXT_SysTimeGetMs  \
    EXT_SysSemCreate  \
    EXT_SysSemDelete  \
    EXT_SysSemEnter  \
    EXT_SysSemLeave  \
    EXT_SysFileOpen  \
    EXT_SysFileGetSizeByHandle  \
    EXT_SysFileRead  \
    EXT_SysFileGetPos  \
    EXT_SysFileSetPos  \
    EXT_SysFileClose  \
    EXT_SysFileGetPath  \
    EXT_SysFileGetPath2  \
    EXT_SysFileGetSize  \
    EXT_SysFileWrite  \
    EXT_SysFileFlush  \
    EXT_SysDirOpen  \
    EXT_SysDirClose  \
    EXT_IecVarAccGetFirstInterface  \
    EXT_IecVarAccGetSize  \
    EXT_IecVarAccGetTypeClass  \
    EXT_IecVarAccGetNode  \
    EXT_IecVarAccGetNode3  \
    EXT_IecVarAccGetNode4  \
    EXT_IecVarAccGetSize3  \
    EXT_IecVarAccGetTypeClass3  \
    EXT_IecVarAccGetValue3  \
    EXT_IecVarAccSetValue3  \
    EXT_IecVarAccGetTypeNode3  \
    EXT_IecVarAccGetTypeNode  \
    EXT_IecVarAccGetTypeDesc  \
    EXT_IecVarAccGetNodeName  \
    EXT_IecVarAccGetAccessRights  \
    EXT_IecVarAccGetClientOffset  \
    EXT_IecVarAccInitVarInfo  \
    EXT_IecVarAccExitVarInfo  \
    EXT_IecVarAccBrowseGetRoot  \
    EXT_IecVarAccBrowseDown  \
    EXT_IecVarAccBrowseGetNext  \
    EXT_IecVarAccGetTypeName  \
    EXT_IecVarAccGetNodeFullPath  \
    EXT_IecVarAccGetNodeFullPath3  \
    EXT_IecVarAccGetNodeType  \
    EXT_IecVarAccGetNumOfTypes  \
    EXT_IecVarAccGetTypeNodeByIndex  \
    EXT_IecVarAccGetTypeClassFromType  \
    EXT_IecVarAccGetEnumValues  \
    EXT_EventOpen  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_EventCreate  \
    EXT_EventGetEvent  \
    EXT_EventClose  \
    EXT_SettgGetIntValue  \
    EXT_SettgSetIntValue  \
    EXT_SettgGetStringValue  \
    EXT_SettgSetStringValue  \
    EXT_SettgRemoveKey  \
    EXT_SysMemAllocData  \
    EXT_SysMemFreeData  \
    EXT_SysMemReallocData  \
    EXT_CMDeleteInstance  \
    EXT_CMUtlStrNICmp  \
    EXT_CMUtlSafeStrCpy  \
    EXT_CMUtlStrLen  \
    EXT_CMUtlStrICmp  \
    EXT_CMUtlwstrcpy  \
    EXT_CMUtlSafeStrNCpy  \
    EXT_CMUtlwstrlen  \
    EXT_CMUtlSafeStrCat  \
    EXT_CMUtlStrIStr  \
    EXT_CMUtlwstrcmp  \
    EXT_CMUtlwstrncmp  \
    EXT_CMUtlSafeMemCpy  \
    EXT_CMUtlsnprintf  \
    EXT_MemPoolCreateStatic  \
    EXT_MemPoolDelete  \
    EXT_MemPoolGetBlock  \
    EXT_MemPoolExtendDynamic  \
    EXT_MemPoolPutBlock  \
    EXT_MemPoolAddUsedBlock  \
    EXT_MemPoolRemoveUsedBlock  \
    EXT_MemPoolAddUsedBlockToPool  \
    EXT_MemPoolRemoveUsedBlockFromPool  \
    EXT_MemPoolIsValidBlock  \
    EXT_MemPoolLock  \
    EXT_MemPoolUnlock  \
    EXT_MemPoolGetBlock2  \
    EXT_MemPoolLockBlock  \
    EXT_MemPoolUnlockBlock  \
    EXT_SysCpuCallIecFuncWithParams  \
    EXT_SysUtilConvWStringToUTF8  \
    EXT_SysUtilConvUTF8ToWString  \
    EXT_SysUtilConvUTF8ToString4  \
    EXT_SysUtilConvStringToUTF83  \
    EXT_SysUtilCreateUUID  \
    EXT_SysTaskGetCurrent  \
    EXT_SysTaskCreate  \
    EXT_SysTaskExit  \
    EXT_SysTaskResume  \
    EXT_SysTaskLeave  \
    EXT_SysTaskEnd  \
    EXT_SysTaskWaitSleep  \
    EXT_SysTaskEnter  \
    EXT_SysTaskGetInfo  \
    EXT_SysTaskSetExit  \
    EXT_stusprintf  \
    EXT_SysDirCreate2  \
    EXT_IecVarAccGetValue  \
    EXT_IecVarAccBrowseUp  \
    EXT_SysExceptCatch  \
    EXT_SysExceptTry  \
    EXT_SysExceptConvertToString  \
    EXT_SysProcessExecuteCommand2  \
    /*obsolete EXT_LogAdd*/  \
    EXT_LogCreate  \
    EXT_LogDelete  \
    EXT_LogRegisterBackend  \
    EXT_LogUnregisterBackend  \
    EXT_ParameterServerGet  \
    EXT_ParameterServerSet  \
    EXT_ParameterServerGetInfo  \
    EXT_ParameterServerCall  \
    EXT_TlsCreateContext  \
    EXT_TlsFreeContext  \
    EXT_SysParameterSettings_VerifyPassword  \
    EXT_eUA_Connect  \
    EXT_eUA_GetValue  \
    EXT_eUA_SetValue  \
    EXT_eUA_ClearValue  \
    EXT_eUA_Disconnect  \
    EXT_eUA_CreateSubscription  \
    EXT_eUA_RegValue  \
    EXT_eUA_RegValueChange  \
    EXT_eUA_Client_run_iterate  \
    EXT_eUA_GetValueAndTypeFromHandle  \
    EXT_eUA_UnregValue  \
    EXT_eUA_Log  \
    EXT_eUA_Browse  \
    EXT_eUA_DateTime_toUnixTime  \
    EXT_ParameterServerGetCountOfNamespaces  \
    EXT_ParameterServerGetNamespace  \
    EXT_WebServerRequestRunning  \
    EXT_fucheckexplicitlicense  \
    EXT_fugetlicensestate  \
    EXT_fureleaseexplicitlicense 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry CmpWSServer__Entry
#endif


#ifdef CPLUSPLUS

class CCmpWSServer : public ICmpWSServer , public IWSServer 
{
    public:
        CCmpWSServer() : hCmpWSServer(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CCmpWSServer()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ICmpWSServer *)this);            
            else if (iid == ITFID_ICmpWSServer)
                pItf = dynamic_cast<ICmpWSServer *>(this); 
            else if (iid == ITFID_IWSServer)
                pItf = dynamic_cast<IWSServer *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hCmpWSServer;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
