/** WS_users.h

	@author	: Nicoleta Nething
   company	: elrest Automationssysteme GmbH
	@date	   : 28.08.2015

	Descrption:
	

	Change history:
	#01 Ng		Datum: 28.08.2015
*/

#define WS_MAX_USERPROFILES 50
#define WS_MAX_USERS        999
#define WS_USERNAME_MAX     32
#define WS_USERPWD_MAX      16