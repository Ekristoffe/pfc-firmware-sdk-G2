//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     MbConfig.h
///
///  \version  $Revision$
///
///  \brief    Modbus configuration library interface
///
///  \author   u015614 : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef MBCONFIG_H_
#define MBCONFIG_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <stdint.h>
#include <pthread.h>
#include <semaphore.h>

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
/// Status code type.
typedef uint32_t mbcfg_Status_type;
#define MBCFG_STATUS_OK                  ((mbcfg_Status_type)0u)
#define MBCFG_STATUS_FAILED              ((mbcfg_Status_type)1u) /* General error */
#define MBCFG_STATUS_NOT_IMPLEMENTED     ((mbcfg_Status_type)2u) /* The function is not yet implemented */
#define MBCFG_STATUS_INVALID_PARAMETER   ((mbcfg_Status_type)3u) /* Invalid function parameter */
#define MBCFG_STATUS_NO_MEMORY_RESOURCES ((mbcfg_Status_type)4u) /* Insufficient heap memory available */
#define MBCFG_STATUS_NO_THREAD_RESOURCES ((mbcfg_Status_type)5u) /* Insufficient thread resources available */
#define MBCFG_STATUS_NOT_STARTED         ((mbcfg_Status_type)6u) /* Asynchronous processing is not started */
#define MBCFG_STATUS_REQ_PARAM_UPDATE    ((mbcfg_Status_type)7u) /* Indicates if a Parameter is requested for update before the previous value was written to file */

/// Flag type.
typedef uint32_t mbcfg_Flag_type;
#define MBCFG_FLAG_DISABLED              ((mbcfg_Flag_type)0u)
#define MBCFG_FLAG_ENABLED               ((mbcfg_Flag_type)1u)

/// Service protocol type.
typedef uint32_t mbcfg_ServiceProtocol_type;
#define MBCFG_SERVICE_TCP                ((mbcfg_ServiceProtocol_type)0u)
#define MBCFG_SERVICE_UDP                ((mbcfg_ServiceProtocol_type)1u)

/// Service parameter set type.
typedef struct mbcfg_ServiceParameter_
{
  mbcfg_Flag_type enable;
  uint16_t        port;
} mbcfg_ServiceParameter_type;

/// Alternative watchdog parameter set type.
typedef struct mbcfg_AlternativeWatchdogParameter_
{
  mbcfg_Flag_type enabled;
  uint16_t        timeout;
  uint16_t        options;
} mbcfg_AlternativeWatchdogParameter_type;

/// Callback function type to report the result of an asynchronous operation
typedef void (*mbcfg_CallbackFn_type) (mbcfg_Status_type result, void *pUserData);

/// Context-Structure for each Task which uses this module
typedef struct mbcfg_Context 
{
  pthread_t       threadID;

  mbcfg_Flag_type threadActive;
  mbcfg_Flag_type stopRequest;
  pthread_mutex_t mutexWakeupThread;
  pthread_cond_t  eventWakeupThread;
  sem_t*          sem_file;
} mbcfg_Context_type;


//--------------------------------------------------------------------------------------------------
// macros
//--------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

//------------------------------------------------------------------------------
/// create an instance of configuration context object
/// 
/// \param[out]    ppCtx
///   configuration context object instance
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_CreateContext(mbcfg_Context_type ** const ppCtx);

//------------------------------------------------------------------------------
/// destroy an instance of configuration context object
/// 
/// \param[in]    pCtx
///   configuration context object instance
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_DestroyContext(mbcfg_Context_type * pCtx);

//------------------------------------------------------------------------------
/// start the processing thread for asynchronous write operations
/// 
/// \param[in]    pCtx
///   configuration context object instance
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_StartAsyncProcessing(mbcfg_Context_type * const pCtx);

//------------------------------------------------------------------------------
/// stop the processing thread for asynchronous write operations
/// 
/// \param[in]    pCtx
///   configuration context object instance
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_StopAsyncProcessing(mbcfg_Context_type * const pCtx);

//------------------------------------------------------------------------------
/// read service parameter set
/// 
/// \param[in]    pCtx
///   configuration context object instance
/// \param[in]    serviceProtocol
///   type of service
/// \param[out]   pParameter
///   set of all service parameter
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_ReadServiceParameter(mbcfg_Context_type * const pCtx,
                                             mbcfg_ServiceProtocol_type serviceProtocol,
                                             mbcfg_ServiceParameter_type * const pParameter);

//------------------------------------------------------------------------------
/// read alternative watchdog parameter set
/// 
/// \param[in]    pCtx
///   configuration context object instance
/// \param[out]   pParameter
///   set of all watchdog parameter
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_ReadAlternativeWatchdogParameter(mbcfg_Context_type * const pCtx,
                                                         mbcfg_AlternativeWatchdogParameter_type * const pParameter);

//------------------------------------------------------------------------------
/// write service 'enabled' parameter
/// 
/// \param[in]    pCtx
///   configuration context object instance
/// \param[in]    fWriteAsync
///   flag to write this parameter asynchronous (Note: Asynchronous processing must be started before).
/// \param[in]    postWriteCallbackFn
///   callback function to report the result of asynchronous write
/// \param[in]    pUserData
///   arguments for callback function
/// \param[in]    serviceProtocol
///   type of service
/// \param[in]    newValue
///   new parameter value to write
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_WriteServiceEnable(mbcfg_Context_type * const pCtx,
                                           mbcfg_Flag_type fWriteAsync,
                                           mbcfg_CallbackFn_type postWriteCallbackFn,
                                           void* pUserData,
                                           mbcfg_ServiceProtocol_type serviceProtocol,
                                           mbcfg_Flag_type newValue);

//------------------------------------------------------------------------------
/// write service 'port' parameter
/// 
/// \param[in]    pCtx
///   configuration context object instance
/// \param[in]    fWriteAsync
///   flag to write this parameter asynchronous (Note: Asynchronous processing must be started before).
/// \param[in]    postWriteCallbackFn
///   callback function to report the result of asynchronous write
/// \param[in]    pUserData
///   arguments for callback function
/// \param[in]    serviceProtocol
///   type of service
/// \param[in]    newValue
///   new parameter value to write
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_WriteServicePort(mbcfg_Context_type * const pCtx,
                                         mbcfg_Flag_type fWriteAsync,
                                         mbcfg_CallbackFn_type postWriteCallbackFn,
                                         void* pUserData,
                                         mbcfg_ServiceProtocol_type serviceProtocol,
                                         uint16_t newValue);

//------------------------------------------------------------------------------
/// write alternative watchdog 'enabled' parameter
/// 
/// \param[in]    pCtx
///   configuration context object instance
/// \param[in]    fWriteAsync
///   flag to write this parameter asynchronous (Note: Asynchronous processing must be started before).
/// \param[in]    postWriteCallbackFn
///   callback function to report the result of asynchronous write
/// \param[in]    pUserData
///   arguments for callback function
/// \param[in]    newValue
///   new parameter value to write
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_WriteAlternativeWatchdogEnabled(mbcfg_Context_type * const pCtx,
                                                        mbcfg_Flag_type fWriteAsync,
                                                        mbcfg_CallbackFn_type postWriteCallbackFn,
                                                        void* pUserData,
                                                        mbcfg_Flag_type newValue);

//------------------------------------------------------------------------------
/// write alternative watchdog 'timeout' parameter
/// 
/// \param[in]    pCtx
///   configuration context object instance
/// \param[in]    fWriteAsync
///   flag to write this parameter asynchronous (Note: Asynchronous processing must be started before).
/// \param[in]    postWriteCallbackFn
///   callback function to report the result of asynchronous write
/// \param[in]    pUserData
///   arguments for callback function
/// \param[in]    newValue
///   new parameter value to write
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_WriteAlternativeWatchdogTimeout(mbcfg_Context_type * const pCtx,
                                                        mbcfg_Flag_type fWriteAsync,
                                                        mbcfg_CallbackFn_type postWriteCallbackFn,
                                                        void* pUserData,
                                                        uint16_t newValue);

//------------------------------------------------------------------------------
/// write alternative watchdog 'options' parameter
///
/// \param[in]    pCtx
///   configuration context object instance
/// \param[in]    fWriteAsync
///   flag to write this parameter asynchronous (Note: Asynchronous processing must be started before).
/// \param[in]    postWriteCallbackFn
///   callback function to report the result of asynchronous write
/// \param[in]    pUserData
///   arguments for callback function
/// \param[in]    newValue
///   new parameter value to write
///
/// \retval
///   status code. Depends on operation success.
//------------------------------------------------------------------------------
mbcfg_Status_type mbcfg_WriteAlternativeWatchdogOptions(mbcfg_Context_type * const pCtx,
                                                        mbcfg_Flag_type fWriteAsync,
                                                        mbcfg_CallbackFn_type postWriteCallbackFn,
                                                        void* pUserData,
                                                        uint16_t newValue);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif /* MBCONFIG_H_ */
