//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co.\ KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     mbs_error.h
///
///  \version  $Revision$
///
///  \brief    <b>Modbus Slave - Error definitions interface.</b>
///
///  \author   M.Sopala: WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef MBS_ERROR_H_
#define MBS_ERROR_H_


//------------------------------------------------------------------------------
//  Defines
//------------------------------------------------------------------------------

/// Short macro to silence unused parameter compiler warnings
#define UNUSED( param )     ((void) (param))

enum {
    SUCCESS             = 0,    ///< Success
    DAL_ACCESS_DENIED      ,    ///< 0x8001 - Access to DAL function denied (wrong AMBS state)
    DAL_OPEN_FAILED        ,    ///< 0x8002 - MBS Open operation failed
    DAL_CLOSE_FAILED       ,    ///< 0x8003 - MBS Close operation failed
    TCP_CONFIG_FAILED      ,    ///< 0x8004 - MBS TCP configuration failed
    UDP_CONFIG_FAILED      ,    ///< 0x8005 - MBS UDP configuration failed
    RTU_CONFIG_FAILED      ,    ///< 0x8006 - MBS RTU configuration failed
    ALL_CONFIG_FAILED      ,    ///< 0x8007 - Common protocol stack configuration failed
    OBTAIN_SYSRES_FAILED   ,    ///< 0x8008 - Allocation of system resource failed
    ACCESS_SYSRES_FAILED   ,    ///< 0x8009 - Access to or handling of system resources failed
    OUT_OF_RANGE           ,    ///< 0x800A - Parameter out of range
    ARG_NULL               ,    ///< 0x800B - Argument is NULL
    INVALID_PARAMETER      ,    ///< 0x800C - Invalid parameter
    DAL_WDT_WRONG_STATE    ,    ///< 0x800D - DAL Watchdog in not allowed state
    UNKNOWN                ,    ///< 0x800E - Unknown error
    ERR_LAST_ENTRY  = UNKNOWN,  ///< Last possible MBS error
};


#define ERR_BASE                    0x8000

#define ERR_DAL_ACCESS_DENIED       (ERR_BASE + DAL_ACCESS_DENIED)
#define ERR_DAL_OPEN_FAILED         (ERR_BASE + DAL_OPEN_FAILED)
#define ERR_DAL_CLOSE_FAILED        (ERR_BASE + DAL_CLOSE_FAILED)
#define ERR_TCP_CONFIG_FAILED       (ERR_BASE + TCP_CONFIG_FAILED)
#define ERR_UDP_CONFIG_FAILED       (ERR_BASE + UDP_CONFIG_FAILED)
#define ERR_RTU_CONFIG_FAILED       (ERR_BASE + RTU_CONFIG_FAILED)
#define ERR_ALL_CONFIG_FAILED       (ERR_BASE + ALL_CONFIG_FAILED)
#define ERR_OBTAIN_SYSRES_FAILED    (ERR_BASE + OBTAIN_SYSRES_FAILED)
#define ERR_ACCESS_SYSRES_FAILED    (ERR_BASE + ACCESS_SYSRES_FAILED)
#define ERR_OUT_OF_RANGE            (ERR_BASE + OUT_OF_RANGE)
#define ERR_ARG_NULL                (ERR_BASE + ARG_NULL)
#define ERR_INVALID_PARAMETER       (ERR_BASE + INVALID_PARAMETER)
#define ERR_DAL_WDT_WRONG_STATE     (ERR_BASE + DAL_WDT_WRONG_STATE)
#define ERR_UNKNOWN                 (ERR_BASE + UNKNOWN)


//------------------------------------------------------------------------------
//  Constants
//------------------------------------------------------------------------------

/// MBS corresponding error text messages
extern const char* mbs_error_msg[];


#endif /* MBS_ERROR_H_ */
//---- End of source file ------------------------------------------------------
