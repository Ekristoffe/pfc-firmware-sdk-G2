//--------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co.\ KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
/// \file       mbs_API.h
///
/// \version    $Id$
///
/// \par        <b>Software Package</b>:
///             Modbus Slave Library (MBS, libmbs)
///
/// \brief      <b>Modbus Slave API.</b>
///
/// \details    This is the Application Programming Interface of Modbus Slave library (libmbs), MBS
///             for short. The MBS is a Modbus Slave shared object library which can work with
///             various Modbus Protocol Stacks, such as TCP, UDP and RTU, simultaneously. The MBS
///             package consist of following modules:\n
///             - \b mbs_dev - The module mbs_dev (\ref mbs_dev.h, \ref mbs_dev.c) acts as interface
///             to the various Modbus Protocol stack and implements the complete data exchange
///             between MBS and the Protocol stacks. Here are implemented the particular, supported
///             Modbus function code services, which are bind to Modbus Protocol Stack dispatcher.
///             This module also manages the reaction of MBS to different states of PLC (start,
///             stop, etc.)\n
///             - \b mbs_dal - The module mbs_dal (\ref mbs_dal.h, \ref mbs_dal.c) acts as interface
///             to the PLC and realizes and controls the data exchange between the PLC and the MBS.
///             The configuration for various MBS operations as well as MBS common parameters are
///             also passed to MBS over the interface of this module.\n
///             - \b mbs_wiregs - The module mbs_wiregs (\ref mbs_wiregs.h, \ref mbs_wiregs.c)

///             - \b mbs_config - The module mbs_config (\ref mbs_config.h, \ref mbs_config.c)
///             implements the configurable data and settings for the MBS. It contains functions for
///             verification and configuration of particular Modbus operations such as TCP, UDP or
///             RTU.\n
///             - \b mbs_timer - The module mbs_timer (\ref mbs_timer.h, \ref mbs_timer.c)
///             implements timer functionality adjusted to the needs of DAL and MBS.\n
///             - \b mbs_wd -  The module mbs_wd (\ref mbs_wd.h, \ref mbs_wd.c) implements the
///             Modbus Watchdog, which monitors the Modbus communication between Modbus Master and
///             Modbus Slave.\n
///             - \b mbs_log - The module mbs_log (\ref mbs_log.h, \ref mbs_log.c) implements the
///             logger. The MBS logger allows to trace on demand the activities of MBS and Protocol
///             Stacks. For each trace group exists a configurable trace mask allowing flexible
///             choice of required traced events or data.
///
/// \see        mbs_config.h, mbs_error.h, mbs_log.h
///
/// \author     M.Sopala : WAGO GmbH & Co. KG
//--------------------------------------------------------------------------------------------------
#ifndef MBS_API_H_
#define MBS_API_H_


//--------------------------------------------------------------------------------------------------
//  includes
//--------------------------------------------------------------------------------------------------

#include <modbus.h>
#include <modbusip.h>
#include <modbus_serial.h>

#include "mbs_error.h"
#include "mbs_config.h"
#include "mbs_log.h"


//--------------------------------------------------------------------------------------------------
//  Exported functions
//--------------------------------------------------------------------------------------------------

/**
 * @brief       Returns actual response delay for TCP/UDP requests in 1ms units
 * @retval      Delay value in 1ms units (e.g. 25 = 25ms)
 */
extern uint16_t mbs_GetIpResponseDelay (void);


/**
 * @brief       Sets the response delay for TCP/UDP requests.
 * @note        This function changes the delay value for new received TCP/UDP Modbus requests
 *              It does not store this parameter persistently!
 * @param[in]   delay         IP response delay in 1ms units (e.g. 25 = 25ms)
 * @return      Number of written bytes (always = 2)
 */
extern int mbs_SetIpResponseDelay (uint16_t delay);


/**
 * @brief       Returns actual timeout for a TCP socket in 100ms units
 * @retval      TCP timeout in 100ms units (e.g. 25 = 2500ms)
 */
extern uint16_t mbs_GetTcpTimeout (void);


/**
 * @brief       Sets the timeout for the TCP sockets.
 * @note        This function changes the timeout value for new, not yet established TCP
 *              connections. It does not store this parameter permanently! If the Modbus TCP is
 *              reconfigured by the PLC than the TCP timeout value stored previously by the call of
 *              this function will be overwritten by the new value from PLC configuration settings.
 * @param[in]   timeout         TCP timeout in 100ms units (e.g. 25 = 2500ms)
 * @return      Number of written bytes (always = 2)
 */
extern int mbs_SetTcpTimeout (uint16_t timeout);


/**
 * @brief       Provides number of actual established TCP connections
 * @return      Number of actual established TCP connections
 */
extern uint16_t mbs_GetTcpConnectionNumber (void);


/**
 * @brief       Initializes TCP socket with initial (default) settings.
 */
extern void mbs_InitTcpSocket (void);


/**
 * @brief       Initializes UDP socket with initial (default) settings
 */
extern void mbs_InitUdpSocket (void);


/**
 * @brief       Initializes RTU Serial Line structure with initial (default) settings
 */
extern void mbs_InitRtuSerialLine (void);


/**
 * @brief       Configures, starts and stops the TCP socket.
 * @details     This function configures and starts or stops the TCP socket successively depending
 *              on passed configuration for Modbus TCP.
 * @param[in]   pConfig         pointer TCP configuration
 * @param[in]   logMask         TCP logging mask, is not a formal configuration parameter
 * @param[in]   portState       TCP port state, either TCP_ENABLED or TCP_DISABLED
 * @retval      MBS_SUCCESS     Configuration accepted successfully, socket started or stopped
 * @retval      EINVAL          Configuration failed, at least one invalid parameter, also if
 *                              \config is a NULL pointer
 * @retval      EAGAIN          Insufficient resources to start (create) a new thread or a
 *                              system-imposed limit on the number of threads was encountered (only
 *                              for socket start configuration)
 * @retval      EPERM           No permission to set the scheduling policy and parameters passed
 *                              by the creation of new thread (only for socket start configuration)
 */
extern int mbs_ConfigTcpSocket (const tTcpCnf* pConfig, unsigned long logMask, unsigned int portState);


/**
 * @brief       Configures, starts and stops the only UDP socket.
 * @details     This function configures and starts or stops the UDP socket successively depending
 *              on passed configuration for Modbus UDP
 * @param[in]   pConfig         pointer UDP configuration
 * @param[in]   logMask         UDP logging mask
 * @param[in]   portState       UDP port state, either UDP_ENABLED or UDP_DISABLED
 * @retval      MBS_SUCCESS     Configuration successful accepted, socket started or stopped
 * @retval      EINVAL          Configuration failed, at least one invalid parameter, also if
 *                              \config is a NULL pointer
 * @retval      EAGAIN          Insufficient resources to start (create) a new thread or a
 *                              system-imposed limit on the number of threads was encountered (only
 *                              for socket start configuration)
 * @retval      EPERM           No permission to set the scheduling policy and parameters passed
 *                              by the creation of new thread (only for socket start configuration)
 */
extern int mbs_ConfigUdpSocket (const tUdpCnf* pConfig, unsigned long logMask, unsigned int portState);


/**
 * @brief       Configures, starts and stops the RTU connection.
 * @details     This function configures and starts or stops the RTU connection successively
 *              depending on passed configuration for Modbus RTU
 * @param[in]   pConfig         pointer RTU configuration
 * @param[in]   logMask         RTU logging mask
 * @retval      MBS_SUCCESS     Configuration successful accepted, connection established
 * @retval      EINVAL          Configuration failed, at least one invalid parameter, also if
 *                              \config is a NULL pointer
 * @retval      EAGAIN          Insufficient resources to start (create) a new thread or a
 *                              system-imposed limit on the number of threads was encountered (only
 *                              for socket start configuration)
 * @retval      EPERM           No permission to set the scheduling policy and parameters passed
 *                              by the creation of new thread (only for socket start configuration)
 */
extern int mbs_ConfigRtuLine (const tRtuCnf* pConfig, unsigned long logMask);


/**
 * @brief       Returns a pointer to Modbus TCP socket structure containing TCP socket configuration
 * @retval      Pointer to stack structure \c mb_socket for Modbus TCP
 */
extern struct mb_socket* mbs_GetTcpSocket (void);


/**
 * @brief       Returns a pointer to Modbus UDP socket structure containing TCP socket configuration
 * @retval      Pointer to stack structure \c mb_socket for Modbus UDP
 */
extern struct mb_socket* mbs_GetUdpSocket (void);


/**
 * @brief       Returns a pointer to stack RTU structure \c mb_serial containing Modbus RTU
 *              configuration
 * @retval      Pointer to stack structure \c mb_serial
 */
extern struct mb_serial* mbs_GetModbusRtu (void);


/**
 * @brief       Modifies the logging options for the TCP or UDP sockets
 * @param[out]  socket          required TCP or UDP socket
 * @param[in]   logMask         new logging mask
 */
extern void mbs_ModifySocketLogOptions (struct mb_socket* socket, unsigned long logMask);


/**
 * @brief       Modifies the logging options for Modbus RTU
 * @param[in]   logMask         new logging mask
 */
extern void mbs_ModifyRtuLogOptions (unsigned long logMask);


/**
 * @brief       Terminates and closes all opened Modbus protocol stacks.
 * @details
 * @note        Do not disable the socket structure passed to libModbus protocol stacks before this
 *              function is called
 */
extern void mbs_ModbusStop (void);


/**
 * @brief       Terminates all established TCP connections.
 * @details     TODO: All worker sockets will be terminated. The main socket stays in state listen
 */
extern int mbs_ResetTcpConnections (void);


#endif  // MBS_API_H_
//---- End of file ---------------------------------------------------------------------------------
