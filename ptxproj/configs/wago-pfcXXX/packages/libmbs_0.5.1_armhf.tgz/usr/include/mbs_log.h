//--------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co.\ KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
/// \file       mbs_log.h
///
/// \version    $Revision: 1 $
///
/// \par        <b>Software Package</b>:
///             Modbus Slave Library (MBS, libmbs)
///
/// \brief      <b>Logging Interface</b>
///
/// \details    This global interface provides all resources and functionalities
///             allowing logging in MBS as well as in the libModbus library
///
/// \author     M.Sopala : WAGO GmbH & Co. KG
///
/// \todo       Remove MBSLOG_PANIC - does not be needed!
//--------------------------------------------------------------------------------------------------
#ifndef MBS_LOG_H_
#define MBS_LOG_H_

#include <diagnostic/diagnostic_API.h>

//--------------------------------------------------------------------------------------------------
//  DEFINES
//--------------------------------------------------------------------------------------------------

/// System scope
#define SCOPE                   ("MBS")
/// Executed function
#define FUN                     (__FUNCTION__)

/**
 * @par         Default logging mask (0 = logging off) for libModbus library
 * @details     The Modbus protocol stacks uses following values for masking
 *              the logger:\n
 *              - MB_LOG_THREAD  = 0x01,    Thread logging
 *              - MB_LOG_CONNECT = 0x02,    Connectivity logging
 *              - MB_LOG_SOCKET  = 0x04,    Socket logging
 *              - MB_LOG_DATA    = 0x08,    Data logging
 *              - MB_LOG_SERIAL  = 0x10,    Serial Interface logging
 */

/// Modbus protocol stack logging off / on
#define MB_LOG_OFF              0x00
#define MB_LOG_ON               0x01

/// Modbus protocol stack default logging mask
#define MB_LOG_DEFAULT          MB_LOG_OFF

/// Modbus protocol stack full logging mask
#define MB_LOG_FULLMASK         (  MB_LOG_THREAD | MB_LOG_CONNECT | MB_LOG_SOCKET \
                                 | MB_LOG_DATA   | MB_LOG_SERIAL  )

/// Compiler switch for logging of trivialities
#define MBS_TRIVIAL_LOG_ACTIVE  (MB_LOG_OFF)

/// Compiler switch for logging to stdout
#define MBS_STDOUT_LOG_ACTIVE   (MB_LOG_OFF)


/**
 * @brief       Logger level mask values for Modbus Slave logging describing
 *              the reason and severity of massage to be logged.
 */
enum {
    /// MBS logging off
    MBSLOG_OFF      = 0x0000,

    /// Critical error, the system is unusable
    MBSLOG_PANIC    = 0x0001,

    /// Fatal error, MBS can not continue its process and must be restarted
    MBSLOG_FATAL    = 0x0002,

    /// Error, MBS can not continue process completely or partially until the fault clearance and
    /// the next process step may have an unpredictable result, respectively
    MBSLOG_ERROR    = 0x0004,

    /// Warning, unsatisfied condition occurs, MSB process continues
    MBSLOG_WARNING  = 0x0008,

    /// Information only
    MBSLOG_INFO     = 0x0010,

    /// Trace debug information
    MBSLOG_DEBUG    = 0x0020,

    /// Trace data accesses to PI buffer from the PLC site (normally used for vicyclic data exchange)
    MBSLOG_DEBUG_DATA_PLC = 0x0040,

    /// Trace data accesses to PI buffer from the Modbus site
    MBSLOG_DEBUG_DATA_FB  = 0x0080,

    /// Logging into a log file instead of terminal
    MBSLOG_LOGFILE  = 0x8000,

    /// Default Trace mask
    MBSLOG_DEFAULT  = MBSLOG_OFF,

    /// Full logging mask
    MBSLOG_FULLMASK = (  MBSLOG_PANIC | MBSLOG_FATAL | MBSLOG_ERROR | MBSLOG_WARNING | MBSLOG_INFO
                       | MBSLOG_DEBUG | MBSLOG_DEBUG_DATA_PLC | MBSLOG_DEBUG_DATA_FB )
};

/// Qualifier for logger message
#define LOGTYPE_PANIC       ("PANIC")

/// Qualifier for logger message
#define LOGTYPE_FATAL       ("FATAL ERROR")

/// Qualifier for logger message
#define LOGTYPE_ERROR       ("ERROR")

/// Qualifier for logger message
#define LOGTYPE_WARNING     ("WARNING")

/// Qualifier for logger message
#define LOGTYPE_INFO        ("INFO")

/// Qualifier for logger message
#define LOGTYPE_DEBUG       ("DEBUG")

/// Qualifier for logger message
#define LOGTYPE_DATA        ("DATA")


//--------------------------------------------------------------------------------------------------
//  Macros
//--------------------------------------------------------------------------------------------------

/// MBS logging mask check - useful for logging MBS data, which has to be prepared before
#define MBS_LOG_CHECK(mask)     (mbs_LogMask.mbs & mask)


//--------------------------------------------------------------------------------------------------
//  Typedefs
//--------------------------------------------------------------------------------------------------

/**
 * @brief       Modbus logging mask structure composed of logging mask members for each Modbus
 *              protocols stsck as well as logging mask for Modbus Slave (MBS) in common.
 */
typedef struct stMsbLogMask {
    unsigned long   tcp;        ///< Logging mask for Modbus TCP operation
    unsigned long   udp;        ///< Logging mask for Modbus UDP operation
    unsigned long   rtu;        ///< Logging mask for Modbus RTU operation
    unsigned long   mbs;        ///< Common logging mask for Modbus Slave
}tMbsLogMask;


//--------------------------------------------------------------------------------------------------
//  Globals
//--------------------------------------------------------------------------------------------------

/// Modbus global loging masks
extern tMbsLogMask  mbs_LogMask;


//--------------------------------------------------------------------------------------------------
//  function implementation
//--------------------------------------------------------------------------------------------------

/**
 * @brief       Gets the corresponding syslog log level.
 * @param       logmask         Common logging mask for Modbus Slave
 * @return      Returns the syslog log level.
 */
unsigned int mbs_LOG_GetSyslogLogLevel(unsigned int logmask);


/**
 * @brief       Trace MBS events corresponding to set logging mask
 * @param[in]   mask            MBS trace mask
 * @param[in]   formatstring    format string
 */
extern void mbs_Logger(unsigned int mask, const char *formatstring, ...);

/**
 * @brief       Trace MBS events regardless to the log masks
 * @param[in]   formatstring    format string
 */
extern void mbs_LogAlways(const char *formatstring, ...);


// Logging of trivialities not allowed (default)
#if (MBS_TRIVIAL_LOG_ACTIVE == MB_LOG_OFF)

/**
 * @brief       Do not log any trivialities
 * @param[in]   mask            MBS trace mask
 * @param[in]   formatstring    format string
 */
#define mbs_LogTrivial(msk, fmt, ...)

#else
#define mbs_LogTrivial    mbs_Logger

#endif  // (MBS_TRIVIAL_LOG_ACTIVE == MB_LOG_OFF)


/**
 * @brief       Provides actual logging mask for the required Modbus protocol
 *              stack and/or MBS
 * @note        The log masks can be obtained partially or all at once.
 *              For not required protocol stack or MBS the corresponding
 *              parameter should be set to NULL
 * @param[out]  tcpLogMask      pointer to TCP logging mask
 * @param[out]  udpLogMask      pointer to UDP logging mask
 * @param[out]  rtuLogMask      pointer to RTU logging mask
 * @param[out]  mbsLogMask      pointer to MBS logging mask
 */
extern void mbs_GetLogMasks( unsigned long* tcpLogMask, unsigned long* udpLogMask,
                             unsigned long* rtuLogMask, unsigned long* mbsLogMask);

/**
 * @brief       Sets actual logging mask for the required Modbus protocol
 *              stack and/or MBS
 * @note        The log masks can be set partially or all at once.
 *              For not required protocol stack or MBS the corresponding
 *              parameter should be set to NULL.
 * @param[in]   tcpLogMask      pointer to TCP logging mask
 * @param[in]   udpLogMask      pointer to UDP logging mask
 * @param[in]   rtuLogMask      pointer to RTU logging mask
 * @param[in]   mbsLogMask      pointer to MBS logging mask
 */
extern void mbs_SetLogMasks( const unsigned long* tcpLogMask, const unsigned long* udpLogMask,
                             const unsigned long* rtuLogMask, const unsigned long* mbsLogMask);

/**
 * @brief       Provides default logging mask (factory settings) for the required
 *              Modbus protocol stack and/or MBS
 * @note        The log masks can be obtained partially or all at once.
 *              For not required protocol stack or MBS the corresponding
 *              parameter should be set to NULL
 * @param[out]  tcpLogMask      pointer to TCP logging mask
 * @param[out]  udpLogMask      pointer to UDP logging mask
 * @param[out]  rtuLogMask      pointer to RTU logging mask
 * @param[out]  mbsLogMask      pointer to MBS logging mask
 */
extern void mbs_GetDefaultLogMasks( unsigned long* tcpLogMask, unsigned long* udpLogMask,
                                    unsigned long* rtuLogMask, unsigned long* mbsLogMask);

/**
 * @brief       Sets actual logging mask for all Modbus protocol stacks and MBS
 *              to default (factory settings)
 */
extern void mbs_SetDefaultLogMasks( void);

/**
 * @brief       Provides all actual logging mask stored in the config file
 * @param[out]  tcpLogMask      pointer to TCP logging mask
 * @param[out]  udpLogMask      pointer to UDP logging mask
 * @param[out]  rtuLogMask      pointer to RTU logging mask
 * @param[out]  mbsLogMask      pointer to MBS logging mask
 * @retval      MBS_SUCCESS     Reading was successfully
 * @retval      OBTAIN_SYSRES_FAILED    Config file does not exist or obtaining
 *                              of some system resources failed
 */
extern int mbs_GetStoredLogMasks( unsigned long* tcpLogMask, unsigned long* udpLogMask,
                                  unsigned long* rtuLogMask, unsigned long* mbsLogMask);

/**
 * @brief       Sets required logging mask and stores the new configuration in
 *              appropriate config file.
 * @details     Setting can be done partially, i.e. for particular log mask or
 *              completely for all available log mask. In the config file does
 *              not exist a new one will be created.
 * @note        Logging mask parameter set to NULL will not be changed (evaluated)
 * @param[in]   tcpLogMask      pointer to TCP logging mask
 * @param[in]   udpLogMask      pointer to UDP logging mask
 * @param[in]   rtuLogMask      pointer to RTU logging mask
 * @param[in]   mbsLogMask      pointer to MBS logging mask
 * @retval      MBS_SUCCESS     Setting was successfully
 * @retval      OBTAIN_SYSRES_FAILED    The new settings could not be stored
 */
extern int mbs_StoreLogMasks( const unsigned long* tcpLogMask, const unsigned long* udpLogMask,
                              const unsigned long* rtuLogMask, const unsigned long* mbsLogMask);


#endif /* MBS_LOG_H_ */
//---- End of source file ------------------------------------------------------
