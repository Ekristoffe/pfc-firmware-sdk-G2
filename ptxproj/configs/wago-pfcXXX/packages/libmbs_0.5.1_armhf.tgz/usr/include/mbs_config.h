//--------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co.\ KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
///  \file     mbs_config.h
///
///  \version  $Revision$
///
///  \brief    <b>Modbus Slave configuration interface.</b>
///
///  \author   M.Sopala : WAGO GmbH & Co. KG
//--------------------------------------------------------------------------------------------------
#ifndef MBS_CONFIG_H_
#define MBS_CONFIG_H_


//--------------------------------------------------------------------------------------------------
//  Includes
//--------------------------------------------------------------------------------------------------
#include <assert.h>
#include <modbus.h>
#include <modbus_serial.h>
#include "MbConfig.h"

#if 1
    #define STATIC
#else
    #define STATIC  static
#endif




//--------------------------------------------------------------------------------------------------
//  Defines
//--------------------------------------------------------------------------------------------------

//----  MBS common defines  ----------------------------------------------------

/// Common success result value
#define MBS_SUCCESS                 0x00
/// Common success result value
#define MBS_FAILURE                 (~MBS_SUCCESS)
/// MBS major version numnber
#define MBS_VERSION_MAJOR           0x01
/// MBS minor version number
#define MBS_VERSION_MINOR           0x00
/// MBS complete version number
#define MBS_VERSION                 ((MBS_VERSION_MAJOR << 8) | MBS_VERSION_MINOR)
/// Value for an enabled operation
#define MBS_ENABLED                 1
/// Value for disabled opeartion
#define MBS_DISABLED                0

//----  TCP settings defines  --------------------------------------------------

/// TCP operation enabled value
#define TCP_ENABLED                 MBS_ENABLED
/// TCP operation disabled value
#define TCP_DISABLED                MBS_DISABLED
/// Default value for TCP operation
#define TCP_DEFAULT                 MBS_ENABLED
/// TCP default port (502)
#define TCP_PORT_DEFAULT            MODBUS_PORT
/// TCP port for test purposes
#define TCP_PORT_TEST               5000
/// Maximum delay for TCP/UDP sockets (32 milliseconds)
#define IP_RESPONSE_DELAY_MAX          32
/// Minimum timeout for a TCP socket (1 second)
#define TCP_TIMEOUT_MS_MIN          1000
/// Default timeout for a TCP socket (5 seconds)
#define TCP_TIMEOUT_MS_DEFAULT      5000
/// coefficient for parameter TCP timout (delivered over RTS in 100 ms) to obtain
/// the same parameter in entity millisecond
#define MILLISECOND_COEFF           100
/// Max. allowed TCP connection number
#define TCP_MAXCONNECTIONS          1000
/// TCP response delay (ms)
#define TCP_RESPONSE_DELAY_DEFAULT  0

//----  UDP settings defines  --------------------------------------------------

/// UDP operation enabled value
#define UDP_ENABLED                 MBS_ENABLED
/// UDP operation disabled value
#define UDP_DISABLED                MBS_DISABLED
/// Default value for UDP operation
#define UDP_DEFAULT                 MBS_ENABLED
/// UDP default port (502)
#define UDP_PORT_DEFAULT            MODBUS_PORT
/// UDP port for test purposes
#define UDP_PORT_TEST               5000
/// UDP response delay (ms)
#define UDP_RESPONSE_DELAY_DEFAULT  0

//----  RTU settings defines  --------------------------------------------------
/// Bit size of 1 bit
#define BITSIZE_1       1
/// Bit size of 2 bit
#define BITSIZE_2       2
/// Bit size of 8 bit
#define BITSIZE_8       8

/// UDP operation enabled value
#define RTU_ENABLED                 MBS_ENABLED
/// UDP operation disabled value
#define RTU_DISABLED                MBS_DISABLED
/// Default value for UDP operation
#define RTU_DEFAULT                 MBS_DISABLED
/// Lower limit for a valid device address
#define NODE_ID_MIN                 1
/// Upper limit for a valid device address
#define NODE_ID_MAX                 247
/// Default device address
#define NODE_ID_DEFAULT             1
/// Minimum response timeout
#define RTU_TIMEOUT_MIN             (2 * 1000)
/// Default response timeout
#define RTU_TIMEOUT_DEFAULT         (5 * 1000)
/// Fix RTU interface name
#define RTU_INTERFACE_FIX           "/dev/serial"
#define RTU_INTERFACE_DEFAULT       RTU_INTERFACE_FIX
/// Default baud rate
#define RTU_BAUDRATE_DEFAULT        115200
/// Fix number of data bits in the data frame
#define RTU_DATA_BITS_FIX           BITSIZE_8
#define DATABITS_DEFAULT            RTU_DATA_BITS_FIX
/// Default number of stop bits
#define STOPBITS_DEFAULT            BITSIZE_1

//----  Other useful defines  --------------------------------------------------

#define PLC_MAPPING_INPUT_OFFSET    2000
#define PLC_MAPPING_OUTPUT_OFFSET   2000


/**
 * @brief       Modbus Mapping (Modbus register regions mapped to PLC address space).
 * @note        Definition of modbus access areas called also register regions
 *              mappad to PLC memory:\n
 *              - Register regions in Modbus-OUT-Area:
 *                  - 0x0000 - 0x01FF, REGMAP_MBOUT, register access to 512 resgister
 *                  - 0x0000 - 0x17FF, REGMAP_BIT_MBOUT, bit access to 6144 bits
 *              - Register regions Modbus-IN-Area:
 *                  - 0x0200 - 0x03FF, REGMAP_MBIN, register access to 512 resgister
 *                  - 0x1800 - 0x2FFF, REGMAP_BIT_MBIN, bit access to 6144 bits
 *              - Register region for WAGO internal registers:
 *                  - 0x1000 - 0x2FFF, REGMAP_WIREGS, register access to some particular
 *                                     register or group of them
 *              - Register regions in Flag Memory Area:
 *                  - 0x3000 - 0x5FFF, REGMAP_FLAGMEM, register access to 12280 flag register
 *                  - 0x3000 - 0x7FFF, REGMAP_BIT_FLAGMEM, bit access to 20480 flag bits
 */
enum {

    REGMAP_MBOUT        = 1,        ///< PLC register region in Modbus-OUT area
    REGMAP_MBIN         = 2,        ///< PLC register region in Modbus-IN-Area
    REGMAP_WIREGS       = 3,        ///< WAGO internal register rgister
    REGMAP_FLAGMEM      = 4,        ///< Register in PLC flag memory area (Non Volatile RAM)
    REGMAP_BIT_MBOUT    = 5,        ///< bit addressable PLC register region in Modbus-OUT area
    REGMAP_BIT_MBIN     = 6,        ///< bit addressable register region in Modbus-OUT area
    REGMAP_BIT_FLAGMEM  = 7,        ///< bit addressable register region in PLC flag memory area
    REGMAP_INVALID      = -1        ///< invalid mapping (illegal register region)
};

/// @brief  PLC register regions area
#define REGMAP_MBOUT_START          0x0000      ///< Modbus OUT region start address @ 0
#define REGMAP_MBOUT_END            0x03E7      ///< Modbus OUT region end address   @ 9999
#define REGMAP_MBOUT_REGSIZE        (REGMAP_MBOUT_END - REGMAP_MBOUT_START + 1)

#define REGMAP_MBIN_START           0x03E8      ///< Modbus IN region start address @ 1000
#define REGMAP_MBIN_END             0x07CF      ///< Modbus IN region end address   @ 1999
#define REGMAP_MBIN_REGSIZE         (REGMAP_MBIN_END - REGMAP_MBIN_START + 1)

#define REGMAP_WIREGS_START         0x1000      ///< Modbus WIREGS region start address
#define REGMAP_WIREGS_END           0x2FFF      ///< Modbus WIREGS region end address

#define REGMAP_FLAGMEM_START        0x3000      ///< Modbus Flag Memory region start address
#define REGMAP_FLAGMEM_END          0xFFFF      ///< Modbus Flag Memory region end address
#define REGMAP_FLAGMEM_REGSIZE      (REGMAP_FLAGMEM_END - REGMAP_FLAGMEM_START + 1)

#define REGMAP_BIT_MBOUT_START      0x0000
#define REGMAP_BIT_MBOUT_END        0x17FF
#define REGMAP_BIT_MBOUT_BITSIZE    (REGMAP_BIT_MBOUT_END - REGMAP_BIT_MBOUT_START + 1)

#define REGMAP_BIT_MBIN_START       0x1800
#define REGMAP_BIT_MBIN_END         0x2FFF
#define REGMAP_BIT_MBIN_BITSIZE     (REGMAP_BIT_MBIN_END - REGMAP_BIT_MBIN_START + 1)

#define REGMAP_BIT_FLAGMEM_START    0x3000
#define REGMAP_BIT_FLAGMEM_END      0xFFFF
#define REGMAP_BIT_FLAGMEM_BITSIZE  (REGMAP_BIT_FLAGMEM_END - REGMAP_BIT_FLAGMEM_START + 1)

/// Number of Modbus register in MBSprocess image (PI)
#define MODBUS_PI_REGSIZE           REGMAP_MBOUT_REGSIZE

/// Size of MBS process image in bytes
#define MODBUS_PI_SIZE              (MODBUS_PI_REGSIZE * sizeof(mb_uint16_t))

/// Size of MBS process image in bits
#define MODBUS_PI_BITSIZE           (MODBUS_PI_SIZE * 8)


//----  Definition of Modbus WAGO internal register sets  ----------------------

#define WIREGS_PI_PROPERTY_START    0x1022
#define WIREGS_PII_REG_NUM          WIREGS_PI_PROPERTY_START
#define WIREGS_PIO_REG_NUM          0x1023
#define WIREGS_PII_BIT_NUM          0x1024
#define WIREGS_PIO_BIT_NUM          0x1025
#define WIREGS_PI_PROPERTY_END      WIREGS_PIO_BIT_NUM

#define WIREGS_BOOT_IP_CONFIG       0x1028

#define WIREGS_TCP_CONNECT_NUM      0x102A

#define WIREGS_TCP_TIMEOUT          0x1030

#define WIREGS_MAC_START            0x1031
#define WIREGS_MAC_ETH0_START       WIREGS_MAC_START
#define WIREGS_MAC_ETH0_END         0x1033
#define WIREGS_MAC_END              WIREGS_MAC_ETH0_END

#define WIREGS_IP_RESPONSE_DELAY    0x1037

#define WIREGS_PLC_STATE            0x1040

#define WIREGS_WDT_START            0x1100
#define WIREGS_WDT_CMD              WIREGS_WDT_START
#define WIREGS_WDT_STATUS           0x1101
#define WIREGS_WDT_TIMEOUT          0x1102
#define WIREGS_WDT_CONFIG           0x1103
#define WIREGS_WDT_MODE             0x1104
#define WIREGS_WDT_END              WIREGS_WDT_MODE

#define WIREGS_CONSTANT_START       0x2000
#define WIREGS_CONSTANT_END         0x2008

#define WIREGS_TYPE_LABEL_START     0x2010
#define WIREGS_TL_REVISION          WIREGS_TYPE_LABEL_START
#define WIREGS_TL_SERIES_CODE       0x2011
#define WIREGS_TL_DEVICE_CODE       0x2012
#define WIREGS_TL_FW_MAJOR          0x2013
#define WIREGS_TL_FW_MINOR          0x2014
#define WIREGS_TL_MBS_VERSION       0x2015
#define WIREGS_TYPE_LABEL_END       WIREGS_TL_MBS_VERSION

#define WIREGS_RESTART              0x2040

#define WIREGS_TCP_LOGMASK          0x2050
#define WIREGS_UDP_LOGMASK          0x2051
#define WIREGS_RTU_LOGMASK          0x2052
#define WIREGS_MBS_LOGMASK          0x2053
#define WIREGS_LOGMASK_START        WIREGS_TCP_LOGMASK
#define WIREGS_LOGMASK_END          WIREGS_MBS_LOGMASK

#define WIREGS_LOGMASK_CMD          0x2054


/// @brief  Structure containing useful mapping properties
typedef struct stAddressMap {
    unsigned long   start;          ///< start address
    unsigned long   end;            ///< end address
    unsigned long   read;           ///< corresponding read function
    unsigned long   write;          ///< corresponding write function
} tAddressMap;

/**
 * @brief       regs_map
 * @details     The structure array regs_map[] contains boundaries and access
 *              types for particular modbus register mapping regions.
 */
#define REGS_MAP_REGION_NUM         4
extern const tAddressMap regs_map[REGS_MAP_REGION_NUM];

/**
 * @brief       bits_map
 * @details     The structure array bits_map[] contains boundaries and access
 *              types for particular modbus bit addressable mapping regions.
 */
#define BITS_MAP_REGION_NUM         3
extern const tAddressMap bits_map[BITS_MAP_REGION_NUM];

/*
 * Other definitions
 */
#define RESTART_MAGIC1              0x55AA
#define RESTART_MAGIC2              0xAA55

/// Alternate process image value
#define PI_ALTERNATE_VALUE          0x00

/// @brief      Enumeration describing various Modbus behaviour mode
typedef enum  {
    NO_DATA_EXCHANGE    = 0             ///< no data exchange possible
    ,ALT_VALUES         = 1             ///< alternate values are provided
    ,LAST_VALUES        = 2             ///< last value are provided
    ,PLC_STOP_DEFAULT   = ALT_VALUES    ///< default setting for stop behaviour
    ,BUS_ERROR_DEFAULT  = ALT_VALUES    ///< default setting for fieldbus error
    ,BEHAVIOUR_MAX      = LAST_VALUES   ///< Max allowed value
}tBehaviourMode;


/// @brief      Common Modbus setting section
typedef struct stCommonCnf
{
    tBehaviourMode  plcStopBehaviour;   ///< control stop behaviour
    tBehaviourMode  busErrorBehaviour;  ///< bus error behaviour
}tCommonCnf;


/// @brief      Modbus TCP setting section
typedef struct stTcpCnf {
    unsigned int    enable;             ///< enable modbus tcp > 0
    unsigned short  port;               ///< TCP connection port
    unsigned long   tcp_timeout;        ///< TCP socket timeout
}tTcpCnf;


/// @brief      Modbus UDP setting section
typedef struct stUdpCnf {
    unsigned int    enable;             ///< enable modbus udp > 0
    unsigned short  port;               ///< TCP connection port
}tUdpCnf;


/// @brief      Modbus RTU setting section
typedef struct tRtuCnf {
    unsigned int enable;                ///< enable modbus rtu > 0,
    unsigned short node_id;             ///< Node ID (device address)
    char dev_name[20];                  ///< device name, length according to libModbus
    enum baudrate {
         BAUD_1200    = 1200            ///< 1200 Baud
        ,BAUD_2400    = 2400            ///< 2400 Baud
        ,BAUD_4800    = 4800            ///< 4600 Baud
        ,BAUD_9600    = 9600            ///< 9600 Baud
        ,BAUD_19200   = 19200           ///< 19,2 kBaud
        ,BAUD_28800   = 28800           ///< 28,8 kBaud
        ,BAUD_38400   = 38400           ///< 38,4 kBaud
        ,BAUD_57600   = 57600           ///< 57,6 kBaud
        ,BAUD_115200  = 115200          ///< 115,2 kbaud
        ,BAUD_DEFAULT = BAUD_115200     ///< Default baudrate
    } baud;                             ///< predefined baudrates

    unsigned int datasize;              ///< number of data bits
    unsigned int stopsize;              ///< number of stop bits

    enum parity_mode {
         PARITY_NO    = NO_PARITY       ///< no parity
        ,PARITY_EVEN  = EVEN_PARITY     ///< even parity
        ,PARITY_ODD   = ODD_PARITY      ///< odd parity
        ,PARITY_DEFAULT = EVEN_PARITY   ///< default parity
    } parity;                           ///< predefined parity values

    enum flow_control {
         FLWCTRL_NONE = FLOW_CTRL_NONE  ///< no flow control
        ,FLWCTRL_SW   = FLOW_CTRL_SW    ///< SW flow control
        ,FLWCTRL_HW   = FLOW_CTRL_HW    ///< HW flow control
        ,FLWCTRL_DEFAULT = FLOW_CTRL_NONE  ///< default flow control
    } flowctrl;                         ///< predefined flow control

    enum phys_intf {
         PHYS_INTF_RS232 = 0            ///< RS232 as serial interface
        ,PHYS_INTF_RS485 = 1            ///< RS485 as serial interface
        ,PHYS_INTF_DEFAULT = PHYS_INTF_RS232  ///< default serial interface
    } physical_interface;               ///< physical interface mode

    unsigned long timeout;              ///< response timeout
}tRtuCnf;


/**
 * @brief       Modbus configuration structure composed as a set of particular
 *              configuration sections.
 */
typedef struct stMbsCnf {
    tCommonCnf  common;         ///< common configuration settings section
    tTcpCnf     tcp;            ///< TCP configuration settings section
    tUdpCnf     udp;            ///< UDP configuration settings section
    tRtuCnf     rtu;            ///< RTU configuration settings section
}tMbsCnf;

extern tMbsCnf   mbs_config;
extern mbcfg_Context_type * mbs_pConfigCtx;


/**
 * @brief       Validates the Modbus Common parameters.
 * @param[in]   config          Pointer to Common configuration data
 * @retval      MBS_SUCCESS     Configuration data is valid
 * @retval      EINVAL          Invalid configuration data
 */
extern int mbs_CONFIG_ValidateCommonParam(const tCommonCnf* config);


/**
 * @brief       Validates the Modbus TCP parameters.
 * @param[in]   config          Pointer to TCP configuration data
 * @retval      MBS_SUCCESS     Configuration data is valid
 * @retval      EINVAL          Invalid configuration data
 */
extern int mbs_CONFIG_ValidateTcpParam(const tTcpCnf* config);


/**
 * @brief       Validates the Modbus UDP parameters.
 * @param[in]   config          Pointer to UDP configuration data
 * @retval      MBS_SUCCESS     Configuration data is valid
 * @retval      EINVAL          Invalid configuration data
 */
extern int mbs_CONFIG_ValidateUdpParam(const tUdpCnf* config);


/**
 * @brief       Validates the Modbus RTU parameters.
 * @param[in]   config          Pointer to RTU configuration data
 * @retval      MBS_SUCCESS     Configuration data is valid
 * @retval      EINVAL          Invalid configuration data
 */
extern int mbs_CONFIG_ValidateRtuParam(const tRtuCnf* config);


/**
 * @brief       Provides default Common configuration settings
 * @param[out]  config          Pointer to Common configuration data
 */
extern void mbs_CONFIG_GetCommonDefaultCfg(tCommonCnf* config);


/**
 * @brief       Provides default TCP configuration settings
 * @param[out]  config          Pointer to TCP configuration data
 */
extern void mbs_CONFIG_GetTcpDefaultCfg(tTcpCnf* config);


/**
 * @brief       Provides default UDP configuration settings
 * @param[out]  config          Pointer to UDP configuration data
 */
extern void mbs_CONFIG_GetUdpDefaultCfg(tUdpCnf* config);


/**
 * @brief       Provides default RTU configuration settings
 * @param[out]  config          Pointer to RTU configuration data
 */
extern void mbs_CONFIG_GetRtuDefaultCfg(tRtuCnf* config);


#endif /* MBS_CONFIG_H_ */
//---- End of source file ------------------------------------------------------
