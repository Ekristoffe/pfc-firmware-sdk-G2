/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component TscExtTask</name>
 *  <description> 
 *  TODO
 *  </description>
 *  <copyright>
 *  TODO
 *  </copyright>
 */
#ifndef _TSCEXTTASKDEP_H_
#define _TSCEXTTASKDEP_H_

#define COMPONENT_NAME "TscExtTask" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscExtTask)
#define COMPONENT_NAME_UNQUOTED TscExtTask





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscExtTask	ADDVENDORID(CMP_VENDORID, TSCEXTTASK_CLASSID_C)
#define CMPID_TscExtTask	TSCEXTTASK_CMPID
#define ITFID_TscExtTask    ADDVENDORID(CMP_VENDORID, TSCEXTTASK_CLASSID_C)

#define CMP_VERSION         UINT32_C(0x00000001)
#define CMP_VERSION_STRING "0.0.0.1"
#define CMP_VERSION_RC      0,0,0,1
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"				






/**
 * \file TscExtTaskItf.h
 */
#include "TscExtTaskItf.h"







#include "CmpMemPoolItf.h"


#include "SysEventItf.h"


#include "CmpAppItf.h"


#include "CmpScheduleItf.h"



        













     













     


#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICmpSchedule == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSchedule, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSchedule = (ICmpSchedule *)pIBase->QueryInterface(pIBase, ITFID_ICmpSchedule, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysEvent == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysEvent, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysEvent = (ISysEvent *)pIBase->QueryInterface(pIBase, ITFID_ISysEvent, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpMemPool == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpMemPool, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpMemPool = (ICmpMemPool *)pIBase->QueryInterface(pIBase, ITFID_ICmpMemPool, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pICmpSchedule = NULL; \
          pICmpApp = NULL; \
          pISysEvent = NULL; \
          pICmpMemPool = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pICmpSchedule != NULL) \
        { \
            pIBase = (IBase *)pICmpSchedule->QueryInterface(pICmpSchedule, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSchedule = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pISysEvent != NULL) \
        { \
            pIBase = (IBase *)pISysEvent->QueryInterface(pISysEvent, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysEvent = NULL; \
            } \
        } \
          if (pICmpMemPool != NULL) \
        { \
            pIBase = (IBase *)pICmpMemPool->QueryInterface(pICmpMemPool, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpMemPool = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_SysEventSet(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolUnlockBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolLockBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolPutBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolRemoveUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolAddUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolGetBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolCreateStatic(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
          /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCEXTTASK_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
                    
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCEXTTASK_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                    
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCEXTTASK_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
        { (RTS_VOID_FCTPTR)TscExtTaskUnregisterTaskFromEvent, "TscExtTaskUnregisterTaskFromEvent", 0, 0 },\
          { (RTS_VOID_FCTPTR)TscExtTaskRegisterTaskToEvent, "TscExtTaskRegisterTaskToEvent", 0, 0 },\
          { (RTS_VOID_FCTPTR)TscExtTaskPostExternalEvent, "TscExtTaskPostExternalEvent", 0, 0 },\
          { (RTS_VOID_FCTPTR)TscExtTaskCheckExternalEvent, "TscExtTaskCheckExternalEvent", 0, 0 },\
          { (RTS_VOID_FCTPTR)TscExtTaskUnregisterExternalEvent, "TscExtTaskUnregisterExternalEvent", 0, 0 },\
          { (RTS_VOID_FCTPTR)TscExtTaskRegisterExternalEvent, "TscExtTaskRegisterExternalEvent", 0, 0 },\
          \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CmpMemPool     \
	ITF_SysEvent     \
	ITF_CmpApp     \
	ITF_CmpSchedule      \
    /*obsolete USE_LogAdd*/      \
    USE_EventOpen      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventClose      \
    USE_MemPoolCreateStatic      \
    USE_MemPoolDelete      \
    USE_MemPoolGetBlock      \
    USE_MemPoolAddUsedBlock      \
    USE_MemPoolRemoveUsedBlock      \
    USE_MemPoolPutBlock      \
    USE_MemPoolLockBlock      \
    USE_MemPoolUnlockBlock      \
    USE_SysEventSet     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CmpMemPool    \
	ITF_SysEvent    \
	ITF_CmpApp    \
	ITF_CmpSchedule     \
    /*obsolete USE_LogAdd*/      \
    USE_EventOpen      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventClose      \
    USE_MemPoolCreateStatic      \
    USE_MemPoolDelete      \
    USE_MemPoolGetBlock      \
    USE_MemPoolAddUsedBlock      \
    USE_MemPoolRemoveUsedBlock      \
    USE_MemPoolPutBlock      \
    USE_MemPoolLockBlock      \
    USE_MemPoolUnlockBlock      \
    USE_SysEventSet     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CmpMemPool    \
	EXTITF_SysEvent    \
	EXTITF_CmpApp    \
	EXTITF_CmpSchedule     \
    /*obsolete EXT_LogAdd*/  \
    EXT_EventOpen  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_EventClose  \
    EXT_MemPoolCreateStatic  \
    EXT_MemPoolDelete  \
    EXT_MemPoolGetBlock  \
    EXT_MemPoolAddUsedBlock  \
    EXT_MemPoolRemoveUsedBlock  \
    EXT_MemPoolPutBlock  \
    EXT_MemPoolLockBlock  \
    EXT_MemPoolUnlockBlock  \
    EXT_SysEventSet 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscExtTask__Entry
#endif


#ifdef CPLUSPLUS

class CTscExtTask : public ITscExtTask 
{
    public:
        CTscExtTask() : hTscExtTask(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscExtTask()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ITscExtTask *)this);            
            else if (iid == ITFID_ITscExtTask)
                pItf = dynamic_cast<ITscExtTask *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }
        virtual RTS_HANDLE CDECL ITscExtTaskRegisterExternalEvent(const char *pszExtEventName, RTS_RESULT *pResult);
        virtual RTS_RESULT CDECL ITscExtTaskUnregisterExternalEvent(RTS_HANDLE hExtEvent);
        virtual RTS_RESULT CDECL ITscExtTaskCheckExternalEvent(const char *pszExtEventName);
        virtual RTS_RESULT CDECL ITscExtTaskPostExternalEvent(RTS_HANDLE hExtEvent);
        virtual RTS_RESULT CDECL ITscExtTaskRegisterTaskToEvent(char *pszExtEventName , RTS_HANDLE hEvent);
        virtual RTS_RESULT CDECL ITscExtTaskUnregisterTaskFromEvent(char *pszExtEventName , RTS_HANDLE hEvent);

    public:
        RTS_HANDLE hTscExtTask;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
