//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     TscExtTask.h
///
///  \version  $Id: TscExtTask.h
///
///  \brief    <short description of the file contents>
///
// \author	Oleg Karfich : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef TSCEXTTASK_H_
#define TSCEXTTASK_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include "TscExtTaskDep.h"

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
#ifndef NUM_EXTERNAL_EVENTS
#define NUM_EXTERNAL_EVENTS	9
#endif

#ifndef NUM_EXTERNAL_TASKS_PER_EVENT
#define NUM_EXTERNAL_TASKS_PER_EVENT 8
#endif

#define MY_MEM_POOL_INIT_VALUE 0x0

typedef struct ExtTaskEventHandleTag
{
    RTS_HANDLE hEvent;
    struct ExtTaskEventHandleTag *pNext;
} ExtTaskEventHandle;

typedef struct ExtTaskEventTag
{
    const char *pszName;
    ExtTaskEventHandle *pTaskEventList;
} ExtTaskEvent;

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
static void InitMemPools();
static void DeleteMemPools();
static void FreeResources(void *pMemBlock, RTS_SIZE ulMemSize);
static void InitResources(void *pMemBlock, RTS_SIZE ulMemSize);
static RTS_RESULT RegisterCbToEvt(void);
static RTS_RESULT UnregisterCbFromEvt(void);

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function implementation
//------------------------------------------------------------------------------

#endif /* TSCEXTTASK_H_ */

//---- End of source file ------------------------------------------------------
