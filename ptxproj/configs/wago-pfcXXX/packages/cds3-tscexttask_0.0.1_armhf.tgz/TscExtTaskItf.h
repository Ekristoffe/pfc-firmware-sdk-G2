 /**
 * <interfacename>TscExtTask</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCEXTTASKITF_H_
#define _TSCEXTTASKITF_H_

#include "CmpStd.h"

 

 




/**
 * <description>
 * <p>Register an external event, which might be used later by
 * event tasks. You should register those events during the system
 * startup, so that the scheduler knows all events when the
 * application is loaded.</p>
 * <p>Valid Hook: CH_INIT2</p>
 * <p>Note: the parameter pszExtEventName needs to be constantly
 * allocated. It might either be a constant string, a global string
 * variable, or a dynamically allocated string. But the memory needs
 * to be valid during the life time of the event handle.</p>
 * <description>
 * <param name="pszExtEventName" type="IN">Name of the event, as it was specified in the device description. This parameter needs to be constantly allocated</param>
 * <param name="pResult" type="INOUT">Error Code</param>
 * <errorcode name="RTS_RESULT" type="ERR_OK">Event was registered successfully</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_NOMEMORY">There was not enough memory to register the new event handle</errorcode>
 * <result>Specific handle, wich is used when die function TscExtTaskPostExternalEvent() is called</result>
 */
RTS_HANDLE CDECL TscExtTaskRegisterExternalEvent(const char *pszExtEventName, RTS_RESULT *pResult);
typedef RTS_HANDLE (CDECL * PFTSCEXTTASKREGISTEREXTERNALEVENT) (const char *pszExtEventName, RTS_RESULT *pResult);
#if defined(TSCEXTTASK_NOTIMPLEMENTED) || defined(TSCEXTTASKREGISTEREXTERNALEVENT_NOTIMPLEMENTED)
	#define USE_TscExtTaskRegisterExternalEvent
	#define EXT_TscExtTaskRegisterExternalEvent
	#define GET_TscExtTaskRegisterExternalEvent(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscExtTaskRegisterExternalEvent(p0,p1)  (RTS_HANDLE)RTS_INVALID_HANDLE
	#define CHK_TscExtTaskRegisterExternalEvent  FALSE
	#define EXP_TscExtTaskRegisterExternalEvent  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscExtTaskRegisterExternalEvent
	#define EXT_TscExtTaskRegisterExternalEvent
	#define GET_TscExtTaskRegisterExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskRegisterExternalEvent" ) 
	#define CAL_TscExtTaskRegisterExternalEvent  TscExtTaskRegisterExternalEvent
	#define CHK_TscExtTaskRegisterExternalEvent  TRUE
	#define EXP_TscExtTaskRegisterExternalEvent  CAL_CMEXPAPI( "TscExtTaskRegisterExternalEvent" ) 
#elif defined(MIXED_LINK) && !defined(TSCEXTTASK_EXTERNAL)
	#define USE_TscExtTaskRegisterExternalEvent
	#define EXT_TscExtTaskRegisterExternalEvent
	#define GET_TscExtTaskRegisterExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskRegisterExternalEvent" ) 
	#define CAL_TscExtTaskRegisterExternalEvent  TscExtTaskRegisterExternalEvent
	#define CHK_TscExtTaskRegisterExternalEvent  TRUE
	#define EXP_TscExtTaskRegisterExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskRegisterExternalEvent", (RTS_UINTPTR)TscExtTaskRegisterExternalEvent, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscExtTaskTscExtTaskRegisterExternalEvent
	#define EXT_TscExtTaskTscExtTaskRegisterExternalEvent
	#define GET_TscExtTaskTscExtTaskRegisterExternalEvent  ERR_OK
	#define CAL_TscExtTaskTscExtTaskRegisterExternalEvent pITscExtTask->ITscExtTaskRegisterExternalEvent
	#define CHK_TscExtTaskTscExtTaskRegisterExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskTscExtTaskRegisterExternalEvent  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscExtTaskRegisterExternalEvent
	#define EXT_TscExtTaskRegisterExternalEvent
	#define GET_TscExtTaskRegisterExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskRegisterExternalEvent" ) 
	#define CAL_TscExtTaskRegisterExternalEvent pITscExtTask->ITscExtTaskRegisterExternalEvent
	#define CHK_TscExtTaskRegisterExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskRegisterExternalEvent  CAL_CMEXPAPI( "TscExtTaskRegisterExternalEvent" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscExtTaskRegisterExternalEvent  PFTSCEXTTASKREGISTEREXTERNALEVENT pfTscExtTaskRegisterExternalEvent;
	#define EXT_TscExtTaskRegisterExternalEvent  extern PFTSCEXTTASKREGISTEREXTERNALEVENT pfTscExtTaskRegisterExternalEvent;
	#define GET_TscExtTaskRegisterExternalEvent(fl)  s_pfCMGetAPI2( "TscExtTaskRegisterExternalEvent", (RTS_VOID_FCTPTR *)&pfTscExtTaskRegisterExternalEvent, (fl), 0, 0)
	#define CAL_TscExtTaskRegisterExternalEvent  pfTscExtTaskRegisterExternalEvent
	#define CHK_TscExtTaskRegisterExternalEvent  (pfTscExtTaskRegisterExternalEvent != NULL)
	#define EXP_TscExtTaskRegisterExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskRegisterExternalEvent", (RTS_UINTPTR)TscExtTaskRegisterExternalEvent, 0, 0) 
#endif




/**
 * <description>
 * <p>Unregister an external event, which was registered by
 * TscExtTaskRegisterExternalEvent() before.</p>
 * <p>This function should be called on system shutdown</p>
 * <p>Valid Hook: CH_EXIT2</p>
 * </description>
 * <param name="hExtEvent" type="IN">Handle, wich is returned by TscExtTaskRegisterExternalEvent(), that should be unregistered.</param>
 * <errorcode name="RTS_RESULT" type="ERR_OK">Event was deregistered successfully</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_PARAMETER">The event handle was not registered before</errorcode>
 * <result>Error code</result>
 */
RTS_RESULT CDECL TscExtTaskUnregisterExternalEvent(RTS_HANDLE hExtEvent);
typedef RTS_RESULT (CDECL * PFTSCEXTTASKUNREGISTEREXTERNALEVENT) (RTS_HANDLE hExtEvent);
#if defined(TSCEXTTASK_NOTIMPLEMENTED) || defined(TSCEXTTASKUNREGISTEREXTERNALEVENT_NOTIMPLEMENTED)
	#define USE_TscExtTaskUnregisterExternalEvent
	#define EXT_TscExtTaskUnregisterExternalEvent
	#define GET_TscExtTaskUnregisterExternalEvent(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscExtTaskUnregisterExternalEvent(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscExtTaskUnregisterExternalEvent  FALSE
	#define EXP_TscExtTaskUnregisterExternalEvent  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscExtTaskUnregisterExternalEvent
	#define EXT_TscExtTaskUnregisterExternalEvent
	#define GET_TscExtTaskUnregisterExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskUnregisterExternalEvent" ) 
	#define CAL_TscExtTaskUnregisterExternalEvent  TscExtTaskUnregisterExternalEvent
	#define CHK_TscExtTaskUnregisterExternalEvent  TRUE
	#define EXP_TscExtTaskUnregisterExternalEvent  CAL_CMEXPAPI( "TscExtTaskUnregisterExternalEvent" ) 
#elif defined(MIXED_LINK) && !defined(TSCEXTTASK_EXTERNAL)
	#define USE_TscExtTaskUnregisterExternalEvent
	#define EXT_TscExtTaskUnregisterExternalEvent
	#define GET_TscExtTaskUnregisterExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskUnregisterExternalEvent" ) 
	#define CAL_TscExtTaskUnregisterExternalEvent  TscExtTaskUnregisterExternalEvent
	#define CHK_TscExtTaskUnregisterExternalEvent  TRUE
	#define EXP_TscExtTaskUnregisterExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskUnregisterExternalEvent", (RTS_UINTPTR)TscExtTaskUnregisterExternalEvent, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscExtTaskTscExtTaskUnregisterExternalEvent
	#define EXT_TscExtTaskTscExtTaskUnregisterExternalEvent
	#define GET_TscExtTaskTscExtTaskUnregisterExternalEvent  ERR_OK
	#define CAL_TscExtTaskTscExtTaskUnregisterExternalEvent pITscExtTask->ITscExtTaskUnregisterExternalEvent
	#define CHK_TscExtTaskTscExtTaskUnregisterExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskTscExtTaskUnregisterExternalEvent  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscExtTaskUnregisterExternalEvent
	#define EXT_TscExtTaskUnregisterExternalEvent
	#define GET_TscExtTaskUnregisterExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskUnregisterExternalEvent" ) 
	#define CAL_TscExtTaskUnregisterExternalEvent pITscExtTask->ITscExtTaskUnregisterExternalEvent
	#define CHK_TscExtTaskUnregisterExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskUnregisterExternalEvent  CAL_CMEXPAPI( "TscExtTaskUnregisterExternalEvent" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscExtTaskUnregisterExternalEvent  PFTSCEXTTASKUNREGISTEREXTERNALEVENT pfTscExtTaskUnregisterExternalEvent;
	#define EXT_TscExtTaskUnregisterExternalEvent  extern PFTSCEXTTASKUNREGISTEREXTERNALEVENT pfTscExtTaskUnregisterExternalEvent;
	#define GET_TscExtTaskUnregisterExternalEvent(fl)  s_pfCMGetAPI2( "TscExtTaskUnregisterExternalEvent", (RTS_VOID_FCTPTR *)&pfTscExtTaskUnregisterExternalEvent, (fl), 0, 0)
	#define CAL_TscExtTaskUnregisterExternalEvent  pfTscExtTaskUnregisterExternalEvent
	#define CHK_TscExtTaskUnregisterExternalEvent  (pfTscExtTaskUnregisterExternalEvent != NULL)
	#define EXP_TscExtTaskUnregisterExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskUnregisterExternalEvent", (RTS_UINTPTR)TscExtTaskUnregisterExternalEvent, 0, 0) 
#endif




/**
 * <description>
 * <p>Check event by name.</p>
 * <description>
 * <param name="pszExtEventName" type="IN">Name of the event, as it was specified in the device description. This parameter needs to be constantly allocated</param>
 * <errorcode name="RTS_RESULT" type="ERR_OK">Event available</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_NO_OBJECT">No event with this specified name available</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_PARAMETER">Invalid pointer to name string</errorcode>
 */
RTS_RESULT CDECL TscExtTaskCheckExternalEvent(const char *pszExtEventName);
typedef RTS_RESULT (CDECL * PFTSCEXTTASKCHECKEXTERNALEVENT) (const char *pszExtEventName);
#if defined(TSCEXTTASK_NOTIMPLEMENTED) || defined(TSCEXTTASKCHECKEXTERNALEVENT_NOTIMPLEMENTED)
	#define USE_TscExtTaskCheckExternalEvent
	#define EXT_TscExtTaskCheckExternalEvent
	#define GET_TscExtTaskCheckExternalEvent(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscExtTaskCheckExternalEvent(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscExtTaskCheckExternalEvent  FALSE
	#define EXP_TscExtTaskCheckExternalEvent  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscExtTaskCheckExternalEvent
	#define EXT_TscExtTaskCheckExternalEvent
	#define GET_TscExtTaskCheckExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskCheckExternalEvent" ) 
	#define CAL_TscExtTaskCheckExternalEvent  TscExtTaskCheckExternalEvent
	#define CHK_TscExtTaskCheckExternalEvent  TRUE
	#define EXP_TscExtTaskCheckExternalEvent  CAL_CMEXPAPI( "TscExtTaskCheckExternalEvent" ) 
#elif defined(MIXED_LINK) && !defined(TSCEXTTASK_EXTERNAL)
	#define USE_TscExtTaskCheckExternalEvent
	#define EXT_TscExtTaskCheckExternalEvent
	#define GET_TscExtTaskCheckExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskCheckExternalEvent" ) 
	#define CAL_TscExtTaskCheckExternalEvent  TscExtTaskCheckExternalEvent
	#define CHK_TscExtTaskCheckExternalEvent  TRUE
	#define EXP_TscExtTaskCheckExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskCheckExternalEvent", (RTS_UINTPTR)TscExtTaskCheckExternalEvent, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscExtTaskTscExtTaskCheckExternalEvent
	#define EXT_TscExtTaskTscExtTaskCheckExternalEvent
	#define GET_TscExtTaskTscExtTaskCheckExternalEvent  ERR_OK
	#define CAL_TscExtTaskTscExtTaskCheckExternalEvent pITscExtTask->ITscExtTaskCheckExternalEvent
	#define CHK_TscExtTaskTscExtTaskCheckExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskTscExtTaskCheckExternalEvent  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscExtTaskCheckExternalEvent
	#define EXT_TscExtTaskCheckExternalEvent
	#define GET_TscExtTaskCheckExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskCheckExternalEvent" ) 
	#define CAL_TscExtTaskCheckExternalEvent pITscExtTask->ITscExtTaskCheckExternalEvent
	#define CHK_TscExtTaskCheckExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskCheckExternalEvent  CAL_CMEXPAPI( "TscExtTaskCheckExternalEvent" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscExtTaskCheckExternalEvent  PFTSCEXTTASKCHECKEXTERNALEVENT pfTscExtTaskCheckExternalEvent;
	#define EXT_TscExtTaskCheckExternalEvent  extern PFTSCEXTTASKCHECKEXTERNALEVENT pfTscExtTaskCheckExternalEvent;
	#define GET_TscExtTaskCheckExternalEvent(fl)  s_pfCMGetAPI2( "TscExtTaskCheckExternalEvent", (RTS_VOID_FCTPTR *)&pfTscExtTaskCheckExternalEvent, (fl), 0, 0)
	#define CAL_TscExtTaskCheckExternalEvent  pfTscExtTaskCheckExternalEvent
	#define CHK_TscExtTaskCheckExternalEvent  (pfTscExtTaskCheckExternalEvent != NULL)
	#define EXP_TscExtTaskCheckExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskCheckExternalEvent", (RTS_UINTPTR)TscExtTaskCheckExternalEvent, 0, 0) 
#endif




/**
 * <description>
 * <p>Execute all tasks, that are registered for the given
 * event.</p>
 * </description>
 * <param name="hExtEvent" type="IN">Handle to the specific external event, which tasks should be signaled</param>
 * <errorcode name="RTS_RESULT" type="ERR_OK">Event was signaled successfully</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_PARAMETER">The event handle was not found</errorcode>
 * <result>Error Code</result>
 */
RTS_RESULT CDECL TscExtTaskPostExternalEvent(RTS_HANDLE hExtEvent);
typedef RTS_RESULT (CDECL * PFTSCEXTTASKPOSTEXTERNALEVENT) (RTS_HANDLE hExtEvent);
#if defined(TSCEXTTASK_NOTIMPLEMENTED) || defined(TSCEXTTASKPOSTEXTERNALEVENT_NOTIMPLEMENTED)
	#define USE_TscExtTaskPostExternalEvent
	#define EXT_TscExtTaskPostExternalEvent
	#define GET_TscExtTaskPostExternalEvent(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscExtTaskPostExternalEvent(p0)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscExtTaskPostExternalEvent  FALSE
	#define EXP_TscExtTaskPostExternalEvent  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscExtTaskPostExternalEvent
	#define EXT_TscExtTaskPostExternalEvent
	#define GET_TscExtTaskPostExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskPostExternalEvent" ) 
	#define CAL_TscExtTaskPostExternalEvent  TscExtTaskPostExternalEvent
	#define CHK_TscExtTaskPostExternalEvent  TRUE
	#define EXP_TscExtTaskPostExternalEvent  CAL_CMEXPAPI( "TscExtTaskPostExternalEvent" ) 
#elif defined(MIXED_LINK) && !defined(TSCEXTTASK_EXTERNAL)
	#define USE_TscExtTaskPostExternalEvent
	#define EXT_TscExtTaskPostExternalEvent
	#define GET_TscExtTaskPostExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskPostExternalEvent" ) 
	#define CAL_TscExtTaskPostExternalEvent  TscExtTaskPostExternalEvent
	#define CHK_TscExtTaskPostExternalEvent  TRUE
	#define EXP_TscExtTaskPostExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskPostExternalEvent", (RTS_UINTPTR)TscExtTaskPostExternalEvent, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscExtTaskTscExtTaskPostExternalEvent
	#define EXT_TscExtTaskTscExtTaskPostExternalEvent
	#define GET_TscExtTaskTscExtTaskPostExternalEvent  ERR_OK
	#define CAL_TscExtTaskTscExtTaskPostExternalEvent pITscExtTask->ITscExtTaskPostExternalEvent
	#define CHK_TscExtTaskTscExtTaskPostExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskTscExtTaskPostExternalEvent  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscExtTaskPostExternalEvent
	#define EXT_TscExtTaskPostExternalEvent
	#define GET_TscExtTaskPostExternalEvent(fl)  CAL_CMGETAPI( "TscExtTaskPostExternalEvent" ) 
	#define CAL_TscExtTaskPostExternalEvent pITscExtTask->ITscExtTaskPostExternalEvent
	#define CHK_TscExtTaskPostExternalEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskPostExternalEvent  CAL_CMEXPAPI( "TscExtTaskPostExternalEvent" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscExtTaskPostExternalEvent  PFTSCEXTTASKPOSTEXTERNALEVENT pfTscExtTaskPostExternalEvent;
	#define EXT_TscExtTaskPostExternalEvent  extern PFTSCEXTTASKPOSTEXTERNALEVENT pfTscExtTaskPostExternalEvent;
	#define GET_TscExtTaskPostExternalEvent(fl)  s_pfCMGetAPI2( "TscExtTaskPostExternalEvent", (RTS_VOID_FCTPTR *)&pfTscExtTaskPostExternalEvent, (fl), 0, 0)
	#define CAL_TscExtTaskPostExternalEvent  pfTscExtTaskPostExternalEvent
	#define CHK_TscExtTaskPostExternalEvent  (pfTscExtTaskPostExternalEvent != NULL)
	#define EXP_TscExtTaskPostExternalEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskPostExternalEvent", (RTS_UINTPTR)TscExtTaskPostExternalEvent, 0, 0) 
#endif




/**
 * <description>
 * <p>Register an task to an external event.</p>
 * </description>
 * <param name="hEvent" type="IN">Handle to the task event, which triggers the task to execute</param>
 * <param name="pszExtEventName" type="IN">Pointer to the name of the external event</param>
 * <errorcode name="RTS_RESULT" type="ERR_OK">Task was registered successfully to the external event</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_PARAMETER">The external event was not found</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_NO_MEMORY">Max Tasks per external event reached</errorcode>
 * <result>Error Code</result>
 */
RTS_RESULT CDECL TscExtTaskRegisterTaskToEvent(char *pszExtEventName ,RTS_HANDLE hEvent);
typedef RTS_RESULT (CDECL * PFTSCEXTTASKREGISTERTASKTOEVENT) (char *pszExtEventName ,RTS_HANDLE hEvent);
#if defined(TSCEXTTASK_NOTIMPLEMENTED) || defined(TSCEXTTASKREGISTERTASKTOEVENT_NOTIMPLEMENTED)
	#define USE_TscExtTaskRegisterTaskToEvent
	#define EXT_TscExtTaskRegisterTaskToEvent
	#define GET_TscExtTaskRegisterTaskToEvent(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscExtTaskRegisterTaskToEvent(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscExtTaskRegisterTaskToEvent  FALSE
	#define EXP_TscExtTaskRegisterTaskToEvent  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscExtTaskRegisterTaskToEvent
	#define EXT_TscExtTaskRegisterTaskToEvent
	#define GET_TscExtTaskRegisterTaskToEvent(fl)  CAL_CMGETAPI( "TscExtTaskRegisterTaskToEvent" ) 
	#define CAL_TscExtTaskRegisterTaskToEvent  TscExtTaskRegisterTaskToEvent
	#define CHK_TscExtTaskRegisterTaskToEvent  TRUE
	#define EXP_TscExtTaskRegisterTaskToEvent  CAL_CMEXPAPI( "TscExtTaskRegisterTaskToEvent" ) 
#elif defined(MIXED_LINK) && !defined(TSCEXTTASK_EXTERNAL)
	#define USE_TscExtTaskRegisterTaskToEvent
	#define EXT_TscExtTaskRegisterTaskToEvent
	#define GET_TscExtTaskRegisterTaskToEvent(fl)  CAL_CMGETAPI( "TscExtTaskRegisterTaskToEvent" ) 
	#define CAL_TscExtTaskRegisterTaskToEvent  TscExtTaskRegisterTaskToEvent
	#define CHK_TscExtTaskRegisterTaskToEvent  TRUE
	#define EXP_TscExtTaskRegisterTaskToEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskRegisterTaskToEvent", (RTS_UINTPTR)TscExtTaskRegisterTaskToEvent, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscExtTaskTscExtTaskRegisterTaskToEvent
	#define EXT_TscExtTaskTscExtTaskRegisterTaskToEvent
	#define GET_TscExtTaskTscExtTaskRegisterTaskToEvent  ERR_OK
	#define CAL_TscExtTaskTscExtTaskRegisterTaskToEvent pITscExtTask->ITscExtTaskRegisterTaskToEvent
	#define CHK_TscExtTaskTscExtTaskRegisterTaskToEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskTscExtTaskRegisterTaskToEvent  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscExtTaskRegisterTaskToEvent
	#define EXT_TscExtTaskRegisterTaskToEvent
	#define GET_TscExtTaskRegisterTaskToEvent(fl)  CAL_CMGETAPI( "TscExtTaskRegisterTaskToEvent" ) 
	#define CAL_TscExtTaskRegisterTaskToEvent pITscExtTask->ITscExtTaskRegisterTaskToEvent
	#define CHK_TscExtTaskRegisterTaskToEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskRegisterTaskToEvent  CAL_CMEXPAPI( "TscExtTaskRegisterTaskToEvent" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscExtTaskRegisterTaskToEvent  PFTSCEXTTASKREGISTERTASKTOEVENT pfTscExtTaskRegisterTaskToEvent;
	#define EXT_TscExtTaskRegisterTaskToEvent  extern PFTSCEXTTASKREGISTERTASKTOEVENT pfTscExtTaskRegisterTaskToEvent;
	#define GET_TscExtTaskRegisterTaskToEvent(fl)  s_pfCMGetAPI2( "TscExtTaskRegisterTaskToEvent", (RTS_VOID_FCTPTR *)&pfTscExtTaskRegisterTaskToEvent, (fl), 0, 0)
	#define CAL_TscExtTaskRegisterTaskToEvent  pfTscExtTaskRegisterTaskToEvent
	#define CHK_TscExtTaskRegisterTaskToEvent  (pfTscExtTaskRegisterTaskToEvent != NULL)
	#define EXP_TscExtTaskRegisterTaskToEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskRegisterTaskToEvent", (RTS_UINTPTR)TscExtTaskRegisterTaskToEvent, 0, 0) 
#endif




/**
 * <description>
 * <p>Unregister an task from an external event.</p>
 * </description>
 * <param name="hEvent" type="IN">Handle to the task event, which triggers the task to execute</param>
 * <param name="pszExtEventName" type="IN">Pointer to the name of the external event</param>
 * <errorcode name="RTS_RESULT" type="ERR_OK">Task was unregistered successfully from the external event</errorcode>
 * <errorcode name="RTS_RESULT" type="ERR_PARAMETER">The external event was not found</errorcode>
 * <result>Error Code</result>
 */
RTS_RESULT CDECL TscExtTaskUnregisterTaskFromEvent(char *pszExtEventName ,RTS_HANDLE hEvent);
typedef RTS_RESULT (CDECL * PFTSCEXTTASKUNREGISTERTASKFROMEVENT) (char *pszExtEventName ,RTS_HANDLE hEvent);
#if defined(TSCEXTTASK_NOTIMPLEMENTED) || defined(TSCEXTTASKUNREGISTERTASKFROMEVENT_NOTIMPLEMENTED)
	#define USE_TscExtTaskUnregisterTaskFromEvent
	#define EXT_TscExtTaskUnregisterTaskFromEvent
	#define GET_TscExtTaskUnregisterTaskFromEvent(fl)  ERR_NOTIMPLEMENTED
	#define CAL_TscExtTaskUnregisterTaskFromEvent(p0,p1)  (RTS_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_TscExtTaskUnregisterTaskFromEvent  FALSE
	#define EXP_TscExtTaskUnregisterTaskFromEvent  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_TscExtTaskUnregisterTaskFromEvent
	#define EXT_TscExtTaskUnregisterTaskFromEvent
	#define GET_TscExtTaskUnregisterTaskFromEvent(fl)  CAL_CMGETAPI( "TscExtTaskUnregisterTaskFromEvent" ) 
	#define CAL_TscExtTaskUnregisterTaskFromEvent  TscExtTaskUnregisterTaskFromEvent
	#define CHK_TscExtTaskUnregisterTaskFromEvent  TRUE
	#define EXP_TscExtTaskUnregisterTaskFromEvent  CAL_CMEXPAPI( "TscExtTaskUnregisterTaskFromEvent" ) 
#elif defined(MIXED_LINK) && !defined(TSCEXTTASK_EXTERNAL)
	#define USE_TscExtTaskUnregisterTaskFromEvent
	#define EXT_TscExtTaskUnregisterTaskFromEvent
	#define GET_TscExtTaskUnregisterTaskFromEvent(fl)  CAL_CMGETAPI( "TscExtTaskUnregisterTaskFromEvent" ) 
	#define CAL_TscExtTaskUnregisterTaskFromEvent  TscExtTaskUnregisterTaskFromEvent
	#define CHK_TscExtTaskUnregisterTaskFromEvent  TRUE
	#define EXP_TscExtTaskUnregisterTaskFromEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskUnregisterTaskFromEvent", (RTS_UINTPTR)TscExtTaskUnregisterTaskFromEvent, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscExtTaskTscExtTaskUnregisterTaskFromEvent
	#define EXT_TscExtTaskTscExtTaskUnregisterTaskFromEvent
	#define GET_TscExtTaskTscExtTaskUnregisterTaskFromEvent  ERR_OK
	#define CAL_TscExtTaskTscExtTaskUnregisterTaskFromEvent pITscExtTask->ITscExtTaskUnregisterTaskFromEvent
	#define CHK_TscExtTaskTscExtTaskUnregisterTaskFromEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskTscExtTaskUnregisterTaskFromEvent  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_TscExtTaskUnregisterTaskFromEvent
	#define EXT_TscExtTaskUnregisterTaskFromEvent
	#define GET_TscExtTaskUnregisterTaskFromEvent(fl)  CAL_CMGETAPI( "TscExtTaskUnregisterTaskFromEvent" ) 
	#define CAL_TscExtTaskUnregisterTaskFromEvent pITscExtTask->ITscExtTaskUnregisterTaskFromEvent
	#define CHK_TscExtTaskUnregisterTaskFromEvent (pITscExtTask != NULL)
	#define EXP_TscExtTaskUnregisterTaskFromEvent  CAL_CMEXPAPI( "TscExtTaskUnregisterTaskFromEvent" ) 
#else /* DYNAMIC_LINK */
	#define USE_TscExtTaskUnregisterTaskFromEvent  PFTSCEXTTASKUNREGISTERTASKFROMEVENT pfTscExtTaskUnregisterTaskFromEvent;
	#define EXT_TscExtTaskUnregisterTaskFromEvent  extern PFTSCEXTTASKUNREGISTERTASKFROMEVENT pfTscExtTaskUnregisterTaskFromEvent;
	#define GET_TscExtTaskUnregisterTaskFromEvent(fl)  s_pfCMGetAPI2( "TscExtTaskUnregisterTaskFromEvent", (RTS_VOID_FCTPTR *)&pfTscExtTaskUnregisterTaskFromEvent, (fl), 0, 0)
	#define CAL_TscExtTaskUnregisterTaskFromEvent  pfTscExtTaskUnregisterTaskFromEvent
	#define CHK_TscExtTaskUnregisterTaskFromEvent  (pfTscExtTaskUnregisterTaskFromEvent != NULL)
	#define EXP_TscExtTaskUnregisterTaskFromEvent  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"TscExtTaskUnregisterTaskFromEvent", (RTS_UINTPTR)TscExtTaskUnregisterTaskFromEvent, 0, 0) 
#endif





typedef struct
{
	IBase_C *pBase;
	PFTSCEXTTASKREGISTEREXTERNALEVENT ITscExtTaskRegisterExternalEvent;
 	PFTSCEXTTASKUNREGISTEREXTERNALEVENT ITscExtTaskUnregisterExternalEvent;
 	PFTSCEXTTASKCHECKEXTERNALEVENT ITscExtTaskCheckExternalEvent;
 	PFTSCEXTTASKPOSTEXTERNALEVENT ITscExtTaskPostExternalEvent;
 	PFTSCEXTTASKREGISTERTASKTOEVENT ITscExtTaskRegisterTaskToEvent;
 	PFTSCEXTTASKUNREGISTERTASKFROMEVENT ITscExtTaskUnregisterTaskFromEvent;
 } ITscExtTask_C;

#ifdef CPLUSPLUS
class ITscExtTask : public IBase
{
	public:
		virtual RTS_HANDLE CDECL ITscExtTaskRegisterExternalEvent(const char *pszExtEventName, RTS_RESULT *pResult) =0;
		virtual RTS_RESULT CDECL ITscExtTaskUnregisterExternalEvent(RTS_HANDLE hExtEvent) =0;
		virtual RTS_RESULT CDECL ITscExtTaskCheckExternalEvent(const char *pszExtEventName) =0;
		virtual RTS_RESULT CDECL ITscExtTaskPostExternalEvent(RTS_HANDLE hExtEvent) =0;
		virtual RTS_RESULT CDECL ITscExtTaskRegisterTaskToEvent(char *pszExtEventName , RTS_HANDLE hEvent) =0;
		virtual RTS_RESULT CDECL ITscExtTaskUnregisterTaskFromEvent(char *pszExtEventName , RTS_HANDLE hEvent) =0;
};
	#ifndef ITF_TscExtTask
		#define ITF_TscExtTask static ITscExtTask *pITscExtTask = NULL;
	#endif
	#define EXTITF_TscExtTask
#else	/*CPLUSPLUS*/
	typedef ITscExtTask_C		ITscExtTask;
	#ifndef ITF_TscExtTask
		#define ITF_TscExtTask
	#endif
	#define EXTITF_TscExtTask
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCEXTTASKITF_H_*/
