#ifndef _DAL_CAPS_H_
#define _DAL_CAPS_H_

#include <stdint.h>
#include <stdbool.h>
#include <dal/sdi_stack_interface.h>

enum DeviceType
{
   DeviceType_Kbus,
   DeviceType_Sbus,
   DeviceType_RlbMaster,
   DeviceType_CanOpenMaster,
   DeviceType_CanOpenSlave,
   DeviceType_ModbusMaster,
   DeviceType_ModbusSlave,
   DeviceType_DeviceNetMaster,
   DeviceType_DeviceNetSlave,
   DeviceType_ProfibusMaster,
   DeviceType_ProfibusSlave,
   DeviceType_ProfinetController,
   DeviceType_ProfinetDevice,
   DeviceType_EthernetIpMaster,
   DeviceType_EthernetIpSlave,
   DeviceType_AsiDevice,
   DeviceType_CanLayer2,
   DeviceType_Bacnet
};


static inline bool dal_CAPS_IsDeviceType( IStackDevice dev, uint32_t deviceType)
{
   return (dev->Flags == deviceType);
}


#endif
