 //---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     http://svsv01003/svn/repo3/pfc/trunk/wago_intern/codesys3-Component/Include/TscInterfaces/IoDrvKbusCItf.m4 (.h) 
///
/// \version  $Rev$
///
/// \brief    target specific component to support dynamic module configuration; iec- and fw-interface
///
/// \author   u015479 / WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------

	
	
#ifndef _IODRVKBUSCITF_H_
#define _IODRVKBUSCITF_H_

#include "CmpStd.h"

 

 




#include "WagoSysdefines.h"
#include "WagoSysKbusTerminalControl_Internal_CommonItf.h"

#define ITFID_IIoDrvKbusC ADDVENDORID(RTS_VENDORID_WAGO, IODRVKBUSC_ITFID_I)


/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif


/**
 * <description>Function calculates module slot number
 * <p></p>
 * <p>Function calculates module slot number for asynchronous module</p>
 * <p>access. Function uses given configured connector to calculate</p>
 * <p>slot number.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively connector</param>
 * <param name="pConnector" type="IN">pointer to static configured connector of traget KBUS modul</param>
 * <param name="pudiSlotNo" type="OUT">pointer to slot number of traget KBUS modul</param>
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Slot number calculated</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pConnector or pudiSlotNo was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_TYPE_MISMATCH">Connector type not supported</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static configuration found</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_DEVICE">No slot number for current modul available</errorcode>
 */
STATICITF_DEF RTS_IEC_RESULT CDECL FuIoDrvCalculateSlotNumber_c(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVCALCULATESLOTNUMBER_C) (RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo);
#if defined(IODRVKBUSC_NOTIMPLEMENTED) || defined(FUIODRVCALCULATESLOTNUMBER_C_NOTIMPLEMENTED)
	#define USE_FuIoDrvCalculateSlotNumber_c
	#define EXT_FuIoDrvCalculateSlotNumber_c
	#define GET_FuIoDrvCalculateSlotNumber_c(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvCalculateSlotNumber_c(p0,p1,p2)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvCalculateSlotNumber_c  FALSE
	#define EXP_FuIoDrvCalculateSlotNumber_c  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvCalculateSlotNumber_c
	#define EXT_FuIoDrvCalculateSlotNumber_c
	#define GET_FuIoDrvCalculateSlotNumber_c(fl)  ERR_OK
	#define CAL_FuIoDrvCalculateSlotNumber_c(p0,p1,p2) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvCalculateSlotNumber_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2))
	#define CHK_FuIoDrvCalculateSlotNumber_c  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_c  ERR_OK
#elif defined(MIXED_LINK) && !defined(IODRVKBUSC_EXTERNAL)
	#define USE_FuIoDrvCalculateSlotNumber_c
	#define EXT_FuIoDrvCalculateSlotNumber_c
	#define GET_FuIoDrvCalculateSlotNumber_c(fl)  ERR_OK
	#define CAL_FuIoDrvCalculateSlotNumber_c(p0,p1,p2) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvCalculateSlotNumber_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2))
	#define CHK_FuIoDrvCalculateSlotNumber_c  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_c  ERR_OK
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusCFuIoDrvCalculateSlotNumber_c
	#define EXT_IoDrvKbusCFuIoDrvCalculateSlotNumber_c
	#define GET_IoDrvKbusCFuIoDrvCalculateSlotNumber_c  ERR_OK
	#define CAL_IoDrvKbusCFuIoDrvCalculateSlotNumber_c(p0,p1,p2)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvCalculateSlotNumber_c(p1,p2))
	#define CHK_IoDrvKbusCFuIoDrvCalculateSlotNumber_c  TRUE
	#define EXP_IoDrvKbusCFuIoDrvCalculateSlotNumber_c  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvCalculateSlotNumber_c
	#define EXT_FuIoDrvCalculateSlotNumber_c
	#define GET_FuIoDrvCalculateSlotNumber_c(fl)  ERR_OK
	#define CAL_FuIoDrvCalculateSlotNumber_c(p0,p1,p2)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvCalculateSlotNumber_c(p1,p2))
	#define CHK_FuIoDrvCalculateSlotNumber_c  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_c  ERR_OK
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvCalculateSlotNumber_c
	#define EXT_FuIoDrvCalculateSlotNumber_c
	#define GET_FuIoDrvCalculateSlotNumber_c(fl)  ERR_OK
	#define CAL_FuIoDrvCalculateSlotNumber_c(p0,p1,p2) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvCalculateSlotNumber_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2))
	#define CHK_FuIoDrvCalculateSlotNumber_c  TRUE
	#define EXP_FuIoDrvCalculateSlotNumber_c  ERR_OK
#endif




/**
 * <description>Function reads module configuration resp. module data mapping state
 * <p></p>
 * <p>Function reads module configuration state and module data mapping</p>
 * <p>state. Function uses given configured connector to address module.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively connector</param>
 * <param name="pConnector" type="IN">pointer to static configured connector of traget KBUS modul</param>
 * <param name="peCnfSts" type="OUT">pointer to modul configuration state of traget KBUS modul</param>
 * <param name="peMapSts" type="OUT">pointer to modul data mapping state of traget KBUS modul</param>
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Valid state information for current module</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pConnector, eCnfSts or eMapSts was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_TYPE_MISMATCH">Connector type not supported</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static configuration found</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_DEVICE">No state information for current module available</errorcode>
 */
STATICITF_DEF RTS_IEC_RESULT CDECL FuIoDrvGetConfMapState_c(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVGETCONFMAPSTATE_C) (RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts);
#if defined(IODRVKBUSC_NOTIMPLEMENTED) || defined(FUIODRVGETCONFMAPSTATE_C_NOTIMPLEMENTED)
	#define USE_FuIoDrvGetConfMapState_c
	#define EXT_FuIoDrvGetConfMapState_c
	#define GET_FuIoDrvGetConfMapState_c(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvGetConfMapState_c(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvGetConfMapState_c  FALSE
	#define EXP_FuIoDrvGetConfMapState_c  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvGetConfMapState_c
	#define EXT_FuIoDrvGetConfMapState_c
	#define GET_FuIoDrvGetConfMapState_c(fl)  ERR_OK
	#define CAL_FuIoDrvGetConfMapState_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvGetConfMapState_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvGetConfMapState_c  TRUE
	#define EXP_FuIoDrvGetConfMapState_c  ERR_OK
#elif defined(MIXED_LINK) && !defined(IODRVKBUSC_EXTERNAL)
	#define USE_FuIoDrvGetConfMapState_c
	#define EXT_FuIoDrvGetConfMapState_c
	#define GET_FuIoDrvGetConfMapState_c(fl)  ERR_OK
	#define CAL_FuIoDrvGetConfMapState_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvGetConfMapState_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvGetConfMapState_c  TRUE
	#define EXP_FuIoDrvGetConfMapState_c  ERR_OK
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusCFuIoDrvGetConfMapState_c
	#define EXT_IoDrvKbusCFuIoDrvGetConfMapState_c
	#define GET_IoDrvKbusCFuIoDrvGetConfMapState_c  ERR_OK
	#define CAL_IoDrvKbusCFuIoDrvGetConfMapState_c(p0,p1,p2,p3)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvGetConfMapState_c(p1,p2,p3))
	#define CHK_IoDrvKbusCFuIoDrvGetConfMapState_c  TRUE
	#define EXP_IoDrvKbusCFuIoDrvGetConfMapState_c  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvGetConfMapState_c
	#define EXT_FuIoDrvGetConfMapState_c
	#define GET_FuIoDrvGetConfMapState_c(fl)  ERR_OK
	#define CAL_FuIoDrvGetConfMapState_c(p0,p1,p2,p3)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvGetConfMapState_c(p1,p2,p3))
	#define CHK_FuIoDrvGetConfMapState_c  TRUE
	#define EXP_FuIoDrvGetConfMapState_c  ERR_OK
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvGetConfMapState_c
	#define EXT_FuIoDrvGetConfMapState_c
	#define GET_FuIoDrvGetConfMapState_c(fl)  ERR_OK
	#define CAL_FuIoDrvGetConfMapState_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvGetConfMapState_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvGetConfMapState_c  TRUE
	#define EXP_FuIoDrvGetConfMapState_c  ERR_OK
#endif




/**
 * <description>Function provides dynamic module configuration
 * <p></p>
 * <p>Function extends existing static module configuration.</p>
 * <p>Dynamic added configuration can be dynamic or static</p>
 * <p>removed. Function uses given connector list including</p>
 * <p>target module connector with parameter (4) slot number.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively connector list</param> 
 * <param name="pConnectorList" type="IN">pointer to list of connectors</param> 
 * <param name="nCount" type="IN">number of entries in the connector list</param> 
 * <param name="eCtrl" type="IN">control update configuration</param> 
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Dynamic configuration evaluated</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pConnectorList or nCount was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_TYPE_MISMATCH">At least one connector with unsupported type in list</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static configuration found</errorcode>
 */
STATICITF_DEF RTS_IEC_RESULT CDECL FuIoDrvUpdateConfiguration_dynamic_c(RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVUPDATECONFIGURATION_DYNAMIC_C) (RTS_IEC_HANDLE hIoDrv, IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl);
#if defined(IODRVKBUSC_NOTIMPLEMENTED) || defined(FUIODRVUPDATECONFIGURATION_DYNAMIC_C_NOTIMPLEMENTED)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_c
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_c
	#define GET_FuIoDrvUpdateConfiguration_dynamic_c(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_c(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_c  FALSE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_c
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_c
	#define GET_FuIoDrvUpdateConfiguration_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateConfiguration_dynamic_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
#elif defined(MIXED_LINK) && !defined(IODRVKBUSC_EXTERNAL)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_c
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_c
	#define GET_FuIoDrvUpdateConfiguration_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateConfiguration_dynamic_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusCFuIoDrvUpdateConfiguration_dynamic_c
	#define EXT_IoDrvKbusCFuIoDrvUpdateConfiguration_dynamic_c
	#define GET_IoDrvKbusCFuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
	#define CAL_IoDrvKbusCFuIoDrvUpdateConfiguration_dynamic_c(p0,p1,p2,p3)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateConfiguration_dynamic_c(p1,p2,p3))
	#define CHK_IoDrvKbusCFuIoDrvUpdateConfiguration_dynamic_c  TRUE
	#define EXP_IoDrvKbusCFuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvUpdateConfiguration_dynamic_c
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_c
	#define GET_FuIoDrvUpdateConfiguration_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_c(p0,p1,p2,p3)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateConfiguration_dynamic_c(p1,p2,p3))
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvUpdateConfiguration_dynamic_c
	#define EXT_FuIoDrvUpdateConfiguration_dynamic_c
	#define GET_FuIoDrvUpdateConfiguration_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateConfiguration_dynamic_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateConfiguration_dynamic_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvUpdateConfiguration_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateConfiguration_dynamic_c  ERR_OK
#endif




/**
 * <description>Function provides dynamic module mapping
 * <p></p>
 * <p>Function updates unmapped modules. Function uses given</p>
 * <p>task map list including task map for target module.</p>
 * </description> 
 * <param name="hIoDrv" type="IN">registered instance handle of the IO-driver, that operates device respectively task map list</param> 
 * <param name="pTaskMapList" type="IN">pointer to list of task mappings</param>
 * <param name="nCount" type="IN">number of task mappings in list</param> 
 * <param name="eCtrl" type="IN">control update mapping</param> 
 * <result>Error code</result>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_OK">Dynamic mapping evaluated</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_FAILED">Internal error</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_PARAMETER">pTaskMapList or nCount was NULL</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_INVALID_HANDLE">hIoDrv was invalid</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOT_SUPPORTED">Driver does not support function</errorcode>
 * <errorcode name="RTS_IEC_RESULT" type="ERR_NOTINITIALIZED">No static mapping found</errorcode>
 */
STATICITF_DEF RTS_IEC_RESULT CDECL FuIoDrvUpdateMapping_dynamic_c(RTS_IEC_HANDLE hIoDrv, IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
typedef RTS_IEC_RESULT (CDECL * PFFUIODRVUPDATEMAPPING_DYNAMIC_C) (RTS_IEC_HANDLE hIoDrv, IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl);
#if defined(IODRVKBUSC_NOTIMPLEMENTED) || defined(FUIODRVUPDATEMAPPING_DYNAMIC_C_NOTIMPLEMENTED)
	#define USE_FuIoDrvUpdateMapping_dynamic_c
	#define EXT_FuIoDrvUpdateMapping_dynamic_c
	#define GET_FuIoDrvUpdateMapping_dynamic_c(fl)  ERR_NOTIMPLEMENTED
	#define CAL_FuIoDrvUpdateMapping_dynamic_c(p0,p1,p2,p3)  (RTS_IEC_RESULT)ERR_NOTIMPLEMENTED
	#define CHK_FuIoDrvUpdateMapping_dynamic_c  FALSE
	#define EXP_FuIoDrvUpdateMapping_dynamic_c  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_FuIoDrvUpdateMapping_dynamic_c
	#define EXT_FuIoDrvUpdateMapping_dynamic_c
	#define GET_FuIoDrvUpdateMapping_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateMapping_dynamic_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateMapping_dynamic_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvUpdateMapping_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_c  ERR_OK
#elif defined(MIXED_LINK) && !defined(IODRVKBUSC_EXTERNAL)
	#define USE_FuIoDrvUpdateMapping_dynamic_c
	#define EXT_FuIoDrvUpdateMapping_dynamic_c
	#define GET_FuIoDrvUpdateMapping_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateMapping_dynamic_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateMapping_dynamic_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvUpdateMapping_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_c  ERR_OK
#elif defined(CPLUSPLUS_ONLY)
	#define USE_IoDrvKbusCFuIoDrvUpdateMapping_dynamic_c
	#define EXT_IoDrvKbusCFuIoDrvUpdateMapping_dynamic_c
	#define GET_IoDrvKbusCFuIoDrvUpdateMapping_dynamic_c  ERR_OK
	#define CAL_IoDrvKbusCFuIoDrvUpdateMapping_dynamic_c(p0,p1,p2,p3)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateMapping_dynamic_c(p1,p2,p3))
	#define CHK_IoDrvKbusCFuIoDrvUpdateMapping_dynamic_c  TRUE
	#define EXP_IoDrvKbusCFuIoDrvUpdateMapping_dynamic_c  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_FuIoDrvUpdateMapping_dynamic_c
	#define EXT_FuIoDrvUpdateMapping_dynamic_c
	#define GET_FuIoDrvUpdateMapping_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateMapping_dynamic_c(p0,p1,p2,p3)		(p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateMapping_dynamic_c(p1,p2,p3))
	#define CHK_FuIoDrvUpdateMapping_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_c  ERR_OK
#else /* DYNAMIC_LINK */
	#define USE_FuIoDrvUpdateMapping_dynamic_c
	#define EXT_FuIoDrvUpdateMapping_dynamic_c
	#define GET_FuIoDrvUpdateMapping_dynamic_c(fl)  ERR_OK
	#define CAL_FuIoDrvUpdateMapping_dynamic_c(p0,p1,p2,p3) (p0 == RTS_INVALID_HANDLE || p0 == NULL ? 0 : ((IIoDrvKbusC*)p0)->IFuIoDrvUpdateMapping_dynamic_c(((IIoDrvKbusC*)p0)->pBase->hInstance,p1,p2,p3))
	#define CHK_FuIoDrvUpdateMapping_dynamic_c  TRUE
	#define EXP_FuIoDrvUpdateMapping_dynamic_c  ERR_OK
#endif





#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFFUIODRVCALCULATESLOTNUMBER_C IFuIoDrvCalculateSlotNumber_c;
 	PFFUIODRVGETCONFMAPSTATE_C IFuIoDrvGetConfMapState_c;
 	PFFUIODRVUPDATECONFIGURATION_DYNAMIC_C IFuIoDrvUpdateConfiguration_dynamic_c;
 	PFFUIODRVUPDATEMAPPING_DYNAMIC_C IFuIoDrvUpdateMapping_dynamic_c;
 } IIoDrvKbusC_C;

#ifdef CPLUSPLUS
class IIoDrvKbusC : public IBase
{
	public:
		virtual RTS_IEC_RESULT CDECL IFuIoDrvCalculateSlotNumber_c(IoConfigConnector *pConnector, RTS_IEC_UDINT *pudiSlotNo) =0;
		virtual RTS_IEC_RESULT CDECL IFuIoDrvGetConfMapState_c(IoConfigConnector *pConnector, ECONFIG_STS *peCnfSts, EMAPPING_STS *peMapSts) =0;
		virtual RTS_IEC_RESULT CDECL IFuIoDrvUpdateConfiguration_dynamic_c(IoConfigConnector *pConnectorList, RTS_IEC_DINT nCount, ECONFIG_CTRL eCtrl) =0;
		virtual RTS_IEC_RESULT CDECL IFuIoDrvUpdateMapping_dynamic_c(IoConfigTaskMap *pTaskMapList, RTS_IEC_DINT nCount, EMAPPING_CTRL eCtrl) =0;
};
	#ifndef ITF_IoDrvKbusC
		#define ITF_IoDrvKbusC static IIoDrvKbusC *pIIoDrvKbusC = NULL;
	#endif
	#define EXTITF_IoDrvKbusC
#else	/*CPLUSPLUS*/
	typedef IIoDrvKbusC_C		IIoDrvKbusC;
	#ifndef ITF_IoDrvKbusC
		#define ITF_IoDrvKbusC
	#endif
	#define EXTITF_IoDrvKbusC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_IODRVKBUSCITF_H_*/
