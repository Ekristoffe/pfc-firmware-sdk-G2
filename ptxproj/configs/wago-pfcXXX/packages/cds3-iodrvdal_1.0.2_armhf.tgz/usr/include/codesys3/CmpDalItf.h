 /**
 * <interfacename>CmpDalItf</interfacename>
 * <description>The CmpDalItf grants access to the adi_CallDeviceSpecific function of the DAL.</description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _CMPDALITF_H_
#define _CMPDALITF_H_

#include "CmpStd.h"

 

 




#include "WagoSysdefines.h"
#include "dal/dal_types.h"

#define ITFID_ICmpDal ADDVENDORID(RTS_VENDORID_WAGO, CMPDAL_ITFID_I)

/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

 /**
    * @brief Calls a device-specific function implemented by a device library.
    *
    * @param fnName  Name of the function to invoke
    * @param retVal  Return value
    * @param ...     Additional parameters
    * @return DAL_SUCCESS if the function was invoked successfully
    *         DAL_FAILURE on error
    *         DAL_NOTUSED if the function was not found
    */

RTS_I32 CDECL Dal_CallDeviceSpecificFunction(const char * fnName, void* retVal, ...);
typedef RTS_I32 (CDECL * PFDAL_CALLDEVICESPECIFICFUNCTION) (const char * fnName, void* retVal, ...);
#if defined(CMPDAL_NOTIMPLEMENTED) || defined(DAL_CALLDEVICESPECIFICFUNCTION_NOTIMPLEMENTED)
	#define USE_Dal_CallDeviceSpecificFunction
	#define EXT_Dal_CallDeviceSpecificFunction
	#define GET_Dal_CallDeviceSpecificFunction(fl)  ERR_NOTIMPLEMENTED
	#define CAL_Dal_CallDeviceSpecificFunction  FUNCTION_NOTIMPLEMENTED2 
	#define CHK_Dal_CallDeviceSpecificFunction  FALSE
	#define EXP_Dal_CallDeviceSpecificFunction  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_Dal_CallDeviceSpecificFunction
	#define EXT_Dal_CallDeviceSpecificFunction
	#define GET_Dal_CallDeviceSpecificFunction(fl)  CAL_CMGETAPI( "Dal_CallDeviceSpecificFunction" ) 
	#define CAL_Dal_CallDeviceSpecificFunction  Dal_CallDeviceSpecificFunction
	#define CHK_Dal_CallDeviceSpecificFunction  TRUE
	#define EXP_Dal_CallDeviceSpecificFunction  CAL_CMEXPAPI( "Dal_CallDeviceSpecificFunction" ) 
#elif defined(MIXED_LINK) && !defined(CMPDAL_EXTERNAL)
	#define USE_Dal_CallDeviceSpecificFunction
	#define EXT_Dal_CallDeviceSpecificFunction
	#define GET_Dal_CallDeviceSpecificFunction(fl)  CAL_CMGETAPI( "Dal_CallDeviceSpecificFunction" ) 
	#define CAL_Dal_CallDeviceSpecificFunction  Dal_CallDeviceSpecificFunction
	#define CHK_Dal_CallDeviceSpecificFunction  TRUE
	#define EXP_Dal_CallDeviceSpecificFunction  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"Dal_CallDeviceSpecificFunction", (RTS_UINTPTR)Dal_CallDeviceSpecificFunction, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpDalDal_CallDeviceSpecificFunction
	#define EXT_CmpDalDal_CallDeviceSpecificFunction
	#define GET_CmpDalDal_CallDeviceSpecificFunction  ERR_OK
	#define CAL_CmpDalDal_CallDeviceSpecificFunction CCmpDal::IDal_CallDeviceSpecificFunction
	#define CHK_CmpDalDal_CallDeviceSpecificFunction  TRUE
	#define EXP_CmpDalDal_CallDeviceSpecificFunction  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_Dal_CallDeviceSpecificFunction
	#define EXT_Dal_CallDeviceSpecificFunction
	#define GET_Dal_CallDeviceSpecificFunction(fl)  CAL_CMGETAPI( "Dal_CallDeviceSpecificFunction" ) 
	#define CAL_Dal_CallDeviceSpecificFunction CCmpDal::IDal_CallDeviceSpecificFunction
	#define CHK_Dal_CallDeviceSpecificFunction  TRUE
	#define EXP_Dal_CallDeviceSpecificFunction  CAL_CMEXPAPI( "Dal_CallDeviceSpecificFunction" ) 
#else /* DYNAMIC_LINK */
	#define USE_Dal_CallDeviceSpecificFunction  PFDAL_CALLDEVICESPECIFICFUNCTION pfDal_CallDeviceSpecificFunction;
	#define EXT_Dal_CallDeviceSpecificFunction  extern PFDAL_CALLDEVICESPECIFICFUNCTION pfDal_CallDeviceSpecificFunction;
	#define GET_Dal_CallDeviceSpecificFunction(fl)  s_pfCMGetAPI2( "Dal_CallDeviceSpecificFunction", (RTS_VOID_FCTPTR *)&pfDal_CallDeviceSpecificFunction, (fl), 0, 0)
	#define CAL_Dal_CallDeviceSpecificFunction  pfDal_CallDeviceSpecificFunction
	#define CHK_Dal_CallDeviceSpecificFunction  (pfDal_CallDeviceSpecificFunction != NULL)
	#define EXP_Dal_CallDeviceSpecificFunction  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"Dal_CallDeviceSpecificFunction", (RTS_UINTPTR)Dal_CallDeviceSpecificFunction, 0, 0) 
#endif




/**
    * Get the state of the device (corresponds to codesys' bus).
    * @param[in] deviceName Name of the device. (i.e. "libpackbus")
    * @param[in] bufferSize Size of the supplied buffer.
    * @param[out] diagnoseBuffer Buffer where the state is stored in.
    * @param[out] busState The state of the bus.
    * @return Returns 0 on success, -1 otherwise.
    */
    
RTS_I32 CDECL Dal_DiagnoseGetDeviceState(const char * deviceName, RTS_UI32 bufferSize, RTS_UI8 *diagnoseBuffer, tBusState *busState);
typedef RTS_I32 (CDECL * PFDAL_DIAGNOSEGETDEVICESTATE) (const char * deviceName, RTS_UI32 bufferSize, RTS_UI8 *diagnoseBuffer, tBusState *busState);
#if defined(CMPDAL_NOTIMPLEMENTED) || defined(DAL_DIAGNOSEGETDEVICESTATE_NOTIMPLEMENTED)
	#define USE_Dal_DiagnoseGetDeviceState
	#define EXT_Dal_DiagnoseGetDeviceState
	#define GET_Dal_DiagnoseGetDeviceState(fl)  ERR_NOTIMPLEMENTED
	#define CAL_Dal_DiagnoseGetDeviceState(p0,p1,p2,p3)  (RTS_I32)ERR_NOTIMPLEMENTED
	#define CHK_Dal_DiagnoseGetDeviceState  FALSE
	#define EXP_Dal_DiagnoseGetDeviceState  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_Dal_DiagnoseGetDeviceState
	#define EXT_Dal_DiagnoseGetDeviceState
	#define GET_Dal_DiagnoseGetDeviceState(fl)  CAL_CMGETAPI( "Dal_DiagnoseGetDeviceState" ) 
	#define CAL_Dal_DiagnoseGetDeviceState  Dal_DiagnoseGetDeviceState
	#define CHK_Dal_DiagnoseGetDeviceState  TRUE
	#define EXP_Dal_DiagnoseGetDeviceState  CAL_CMEXPAPI( "Dal_DiagnoseGetDeviceState" ) 
#elif defined(MIXED_LINK) && !defined(CMPDAL_EXTERNAL)
	#define USE_Dal_DiagnoseGetDeviceState
	#define EXT_Dal_DiagnoseGetDeviceState
	#define GET_Dal_DiagnoseGetDeviceState(fl)  CAL_CMGETAPI( "Dal_DiagnoseGetDeviceState" ) 
	#define CAL_Dal_DiagnoseGetDeviceState  Dal_DiagnoseGetDeviceState
	#define CHK_Dal_DiagnoseGetDeviceState  TRUE
	#define EXP_Dal_DiagnoseGetDeviceState  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"Dal_DiagnoseGetDeviceState", (RTS_UINTPTR)Dal_DiagnoseGetDeviceState, 0, 0) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_CmpDalDal_DiagnoseGetDeviceState
	#define EXT_CmpDalDal_DiagnoseGetDeviceState
	#define GET_CmpDalDal_DiagnoseGetDeviceState  ERR_OK
	#define CAL_CmpDalDal_DiagnoseGetDeviceState CCmpDal::IDal_DiagnoseGetDeviceState
	#define CHK_CmpDalDal_DiagnoseGetDeviceState  TRUE
	#define EXP_CmpDalDal_DiagnoseGetDeviceState  ERR_OK
#elif defined(CPLUSPLUS)
	#define USE_Dal_DiagnoseGetDeviceState
	#define EXT_Dal_DiagnoseGetDeviceState
	#define GET_Dal_DiagnoseGetDeviceState(fl)  CAL_CMGETAPI( "Dal_DiagnoseGetDeviceState" ) 
	#define CAL_Dal_DiagnoseGetDeviceState CCmpDal::IDal_DiagnoseGetDeviceState
	#define CHK_Dal_DiagnoseGetDeviceState  TRUE
	#define EXP_Dal_DiagnoseGetDeviceState  CAL_CMEXPAPI( "Dal_DiagnoseGetDeviceState" ) 
#else /* DYNAMIC_LINK */
	#define USE_Dal_DiagnoseGetDeviceState  PFDAL_DIAGNOSEGETDEVICESTATE pfDal_DiagnoseGetDeviceState;
	#define EXT_Dal_DiagnoseGetDeviceState  extern PFDAL_DIAGNOSEGETDEVICESTATE pfDal_DiagnoseGetDeviceState;
	#define GET_Dal_DiagnoseGetDeviceState(fl)  s_pfCMGetAPI2( "Dal_DiagnoseGetDeviceState", (RTS_VOID_FCTPTR *)&pfDal_DiagnoseGetDeviceState, (fl), 0, 0)
	#define CAL_Dal_DiagnoseGetDeviceState  pfDal_DiagnoseGetDeviceState
	#define CHK_Dal_DiagnoseGetDeviceState  (pfDal_DiagnoseGetDeviceState != NULL)
	#define EXP_Dal_DiagnoseGetDeviceState  s_pfCMRegisterAPI( (const CMP_EXT_FUNCTION_REF*)"Dal_DiagnoseGetDeviceState", (RTS_UINTPTR)Dal_DiagnoseGetDeviceState, 0, 0) 
#endif



   

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
	PFDAL_CALLDEVICESPECIFICFUNCTION IDal_CallDeviceSpecificFunction;
 	PFDAL_DIAGNOSEGETDEVICESTATE IDal_DiagnoseGetDeviceState;
 } ICmpDal_C;

#ifdef CPLUSPLUS
class ICmpDal : public IBase
{
	public:
		static RTS_I32 CDECL IDal_CallDeviceSpecificFunction(const char * fnName, void* retVal, ...);
		static RTS_I32 CDECL IDal_DiagnoseGetDeviceState(const char * deviceName, RTS_UI32 bufferSize, RTS_UI8 *diagnoseBuffer, tBusState *busState);
};
	#ifndef ITF_CmpDal
		#define ITF_CmpDal static ICmpDal *pICmpDal = NULL;
	#endif
	#define EXTITF_CmpDal
#else	/*CPLUSPLUS*/
	typedef ICmpDal_C		ICmpDal;
	#ifndef ITF_CmpDal
		#define ITF_CmpDal
	#endif
	#define EXTITF_CmpDal
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_CMPDALITF_H_*/
