 //---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     http://svsv01003/svn/repo3/pfc/trunk/wago_intern/codesys3-Component/Include/TscInterfaces/WagoSysKbusTerminalControl_Internal_CommonItf.m4 (.h) 
///
/// \version  $Rev$
///
/// \brief    target specific component to support dynamic module configuration; iec- and fw-interface
///
/// \author   u015479 / WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------

	
	
#ifndef _WAGOSYSKBUSTERMINALCONTROL_INTERNAL_COMMONITF_H_
#define _WAGOSYSKBUSTERMINALCONTROL_INTERNAL_COMMONITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eCONFIG_CTRL</description>
 */
#define ECONFIG_CTRL_CONFIG_CTRL_CLEAR    RTS_IEC_UDINT_C(0x0)	/* remove dynamic configuration */
#define ECONFIG_CTRL_CONFIG_CTRL_DYNAMIC    RTS_IEC_UDINT_C(0x3)	/* establish dynamic configuration */
/* Typed enum definition */
#define ECONFIG_CTRL    RTS_IEC_UDINT

/**
 * <description>Enum: eCONFIG_STS</description>
 */
#define ECONFIG_STS_CONFIG_STS_NOT_CONF    RTS_IEC_UDINT_C(0x0)	/* module not configured */
#define ECONFIG_STS_CONFIG_STS_STAT_CONF    RTS_IEC_UDINT_C(0x1)	/* module static configured */
#define ECONFIG_STS_CONFIG_STS_DYN_CONF    RTS_IEC_UDINT_C(0x2)	/* module dynamic configured */
/* Typed enum definition */
#define ECONFIG_STS    RTS_IEC_UDINT

/**
 * <description>Enum: eKBTC_LIB_STATUS_CODES</description>
 */
#define EKBTC_LIB_STATUS_CODES_KBTC_OK    RTS_IEC_WORD_C(0x0)	/* evaluation OK */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_AUTO_INITIALIZED    RTS_IEC_WORD_C(0x1)	/* error module is auto initialized */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_SLOT_NO    RTS_IEC_WORD_C(0x2)	/* invalid slot number */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_INPUT_REFFERENCE    RTS_IEC_WORD_C(0x3)	/* input pointer and size do not fit */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_OUTPUT_REFFERENCE    RTS_IEC_WORD_C(0x4)	/* output pointer and size do not fit */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DEV_DESC    RTS_IEC_WORD_C(0x5)	/* inconsistent parameter set in device description */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DEV_DESC_INPUT    RTS_IEC_WORD_C(0x6)	/* inconsistent input parameter set in device description */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DEV_DESC_OUTPUT    RTS_IEC_WORD_C(0x7)	/* inconsistent output parameter set in device description */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_EVENT_HANDLER    RTS_IEC_WORD_C(0x8)	/* error from event handler */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_TASK_HANDLE    RTS_IEC_WORD_C(0x9)	/* invalid task handle */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DRIVER_NOT_FOUND    RTS_IEC_WORD_C(0xA)	/* no access to driver */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_ACTIVE_PDE    RTS_IEC_WORD_C(0xB)	/* active process data exchange */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_IO_MANAGER    RTS_IEC_WORD_C(0xC)	/* error from io manager */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_NOT_AUTO_INITIALIZED    RTS_IEC_WORD_C(0xD)	/* error module is not auto initialized */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_MODULE_NOT_FOUND    RTS_IEC_WORD_C(0xE)	/* error module not connected to BUS */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_CONFIGURATION    RTS_IEC_WORD_C(0xF)	/* configuration error */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_MODULE_STOPPED    RTS_IEC_WORD_C(0x10)	/* error module stopped */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_NOT_ENABLED    RTS_IEC_WORD_C(0x11)	/* error manual process data exchange is not enabled */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DEV_DESC_TYPE    RTS_IEC_WORD_C(0x12)	/* unsupported process data type in device description */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_PD_PREV_ALLOC    RTS_IEC_WORD_C(0x13)	/* process data has been previously allocated */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_NO_MEMORY    RTS_IEC_WORD_C(0x14)	/* error no memory available */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_UNSUPPORTED_UID    RTS_IEC_WORD_C(0x15)	/* error unsopported terminal type addressed */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_FB_REFFERENCE    RTS_IEC_WORD_C(0x16)	/* invalid function block refference */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_MAN_INITIALIZED    RTS_IEC_WORD_C(0x17)	/* error module is manual initialized */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_CON_NOT_FOUND    RTS_IEC_WORD_C(0x18)	/* error connector not found */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DRIVER_UC    RTS_IEC_WORD_C(0x19)	/* error from driver update configuration */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DRIVER_UM    RTS_IEC_WORD_C(0x1A)	/* error from driver update mapping */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DRIVER_RI    RTS_IEC_WORD_C(0x1B)	/* error from driver read inputs */
#define EKBTC_LIB_STATUS_CODES_KBTC_E_DRIVER_WO    RTS_IEC_WORD_C(0x1C)	/* error from driver write outputs */
#define EKBTC_LIB_STATUS_CODES_KBTC_NO_OF_STATUS_CODES    RTS_IEC_WORD_C(0x1D)	
/* Typed enum definition */
#define EKBTC_LIB_STATUS_CODES    RTS_IEC_WORD

/**
 * <description>Enum: eMAPPING_CTRL</description>
 */
#define EMAPPING_CTRL_MAPPING_CTRL_CLEAR    RTS_IEC_UDINT_C(0x0)	/* remove dynamic mapping */
#define EMAPPING_CTRL_MAPPING_CTRL_DYNAMIC    RTS_IEC_UDINT_C(0x3)	/* establish dynamic mapping (override static mapping) */
/* Typed enum definition */
#define EMAPPING_CTRL    RTS_IEC_UDINT

/**
 * <description>Enum: eMAPPING_STS</description>
 */
#define EMAPPING_STS_MAPPING_STS_NOT_MAPPED    RTS_IEC_UDINT_C(0x0)	/* modul data not mapped */
#define EMAPPING_STS_MAPPING_STS_STAT_MAPPED    RTS_IEC_UDINT_C(0x1)	/* modul data static mapped */
#define EMAPPING_STS_MAPPING_STS_DYN_MAPPED    RTS_IEC_UDINT_C(0x2)	/* modul data dynamic mapped */
#define EMAPPING_STS_MAPPING_STS_OVERRIDE_STAT    RTS_IEC_UDINT_C(0x3)	/* static modul data mapping overridden */
/* Typed enum definition */
#define EMAPPING_STS    RTS_IEC_UDINT

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysKbusTerminalControl_Internal_Common_C;

#ifdef CPLUSPLUS
class IWagoSysKbusTerminalControl_Internal_Common : public IBase
{
	public:
};
	#ifndef ITF_WagoSysKbusTerminalControl_Internal_Common
		#define ITF_WagoSysKbusTerminalControl_Internal_Common static IWagoSysKbusTerminalControl_Internal_Common *pIWagoSysKbusTerminalControl_Internal_Common = NULL;
	#endif
	#define EXTITF_WagoSysKbusTerminalControl_Internal_Common
#else	/*CPLUSPLUS*/
	typedef IWagoSysKbusTerminalControl_Internal_Common_C		IWagoSysKbusTerminalControl_Internal_Common;
	#ifndef ITF_WagoSysKbusTerminalControl_Internal_Common
		#define ITF_WagoSysKbusTerminalControl_Internal_Common
	#endif
	#define EXTITF_WagoSysKbusTerminalControl_Internal_Common
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSKBUSTERMINALCONTROL_INTERNAL_COMMONITF_H_*/
