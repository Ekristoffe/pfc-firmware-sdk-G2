//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// \file ${file_name}
//
// \version <Revision>: $Rev$
//
// \brief short description of the file contents
//
// \author ${user} $Author$ : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef IODRVDAL_H_
#define IODRVDAL_H_

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

#include "CmpStd.h"
#include "CmpItf.h"
#include "CmpIoDrvItf.h"
#include "CmpIoDrvParameterItf.h"

#include "IoDrvKbusCItf.h"

#include <dal/adi_application_interface.h>
#include <dal/dal_types.h>
#include <LibraryLoader.h>
//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
//

// Sets up the basic codesys 3 api functions.
#define CDS3_GET_MANDATORY_FUNCTIONS(pInitStruct)                              \
    do                                                                         \
    {                                                                          \
        s_pfCMRegisterAPI = pInitStruct->pfCMRegisterAPI;                      \
        s_pfCMRegisterAPI2 = pInitStruct->pfCMRegisterAPI2;                    \
        s_pfCMGetAPI = pInitStruct->pfCMGetAPI;                                \
        s_pfCMGetAPI2 = pInitStruct->pfCMGetAPI2;                              \
        s_pfCMCallHook = pInitStruct->pfCMCallHook;                            \
        s_pfCMRegisterClass = pInitStruct->pfCMRegisterClass;                  \
        s_pfCMCreateInstance = pInitStruct->pfCMCreateInstance;                \
    } while (0)

//------------------------------------------------------------------------------
// Constants
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Typedefs
//------------------------------------------------------------------------------

/* TODO: find a reasonable alternative to MAX_DEVICE_NAME_LEN */
typedef struct IoDrvDalSettings
{
    char        DalName[MAX_DEVICE_NAME_LEN];
    char        ConfigLibrary[MAX_DEVICE_NAME_LEN];
    int         TypeLabelFlag;
    int         ModuleType;
    char        DriverName[MAX_DEVICE_NAME_LEN];
    char        DeviceName[MAX_DEVICE_NAME_LEN];
    char        EntryFunction[MAX_DEVICE_NAME_LEN];
}tIoDrvDalSettings;

typedef struct IoDrvDal
{
#ifndef CPLUSPLUS
    ICmpIoDrv_C IoDrv;
    ICmpIoDrvParameter_C IoDrvParameter;
#endif
} IoDrvDal;

typedef struct IoDrvKbus
{
#ifndef CPLUSPLUS
    IIoDrvKbusC_C m;
#endif
} IoDrvKbus_t;

typedef struct IoDrvDalInfo
{
    IBase Base;
    IoDrvDal Driver;
    CLASSID ClassId;
    IoDrvInfo Info;
    tIoDrvDalSettings Settings;
    LibraryInfo LibraryInfo;
    tDeviceId DeviceId;
    const tApplicationDeviceInterface* Adi;
    const INIT_STRUCT *InitStruct;  //!< Pointer to codesys ComponentEntry init structure. Contains the basic functions to interact with the cds3 runtime.
    PF_HOOK_FUNCTION pfSpecificHookFunction;  // first call after CH_INIT2 and last call before CH_EXIT
    IoDrvKbus_t IoDrvKbus;
} IoDrvDalInfo;

//------------------------------------------------------------------------------
// Function declarations
//------------------------------------------------------------------------------



#endif /* IODRVDAL_H_ */
