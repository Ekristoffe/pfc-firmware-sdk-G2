//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// \file ${file_name}
//
// \version <Revision>: $Rev$
//
// \brief short description of the file contents
//
// \author ${user} $Author$ : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef IODRVDALCOMMON_H_
#define IODRVDALCOMMON_H_

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

#include <inttypes.h>
#include <dal/adi_application_interface.h>
#include <dal/dal_limits.h>
#include <OsLinux/OsCommon.h>
#include <OsLinux/OsTrace.h>

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

#define FOR_EACH_COUNT(iter,init,count) for( __typeof__(init) iter = init; iter < init + count; iter++)

//------------------------------------------------------------------------------
// Constants
//------------------------------------------------------------------------------

enum {
    TF_IoDrvDal     = TraceFacility_User11,
    TF_IoDrvKbus    = TraceFacility_User12,
    TF_IoDrvCan     = TraceFacility_User13,
};

//------------------------------------------------------------------------------
// Macros
//------------------------------------------------------------------------------

#define DEBUG(fmt, ...) OsTraceDebug(TF_IoDrvDal,"[IoDrvDal] " fmt,  __VA_ARGS__)
#define ERROR(fmt, ...) OsTraceError("[IoDrvDal] " fmt, __VA_ARGS__)
#define WARNING(fmt, ...) OsTraceWarning("[IoDrvDal] " fmt, __VA_ARGS__)
#define INFO(fmt, ...) OsTraceInfo("[IoDrvDal] " TF_IoDrvDal, fmt, __VA_VARGS__)

#ifdef CPLUSPLUS
#  define HIODRV_TO_BASE(hIoDrv)                                                 \
    (IBase *) QueryInterface((IBase *)(ICmpIoDrv *) this, ITFID_IBase, NULL);
#else
#  define HIODRV_TO_BASE(hIoDrv) ((ICmpIoDrv_C *)hIoDrv)->pBase;
#endif

#define HIODRV_TO_IODRVDALINFO(hIoDrv) (IoDrvDalInfo*) HIODRV_TO_BASE(hIoDrv)
//------------------------------------------------------------------------------
// Typedefs
//------------------------------------------------------------------------------

typedef struct IoDrvDal_DalIoMap
{
	tDeviceId Device;
	uint32_t  Offset_bits;
	uint32_t  Size_bits;
	uint32_t  Offset_bytes;
	uint32_t  Size_bytes;
}IoDrvDal_DalIoMap;


//------------------------------------------------------------------------------
// Function declarations
//------------------------------------------------------------------------------

bool IoDrvDal_WriteBits(IoDrvDal_DalIoMap *map, u8* data);
bool IoDrvDal_ReadBits(IoDrvDal_DalIoMap *map, u8* data);


#endif /* IODRVDALCOMMON_H_ */
