//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// \file ${file_name}
//
// \version <Revision>: $Rev$
//
// \brief
//
// \author ${user} $Author$ : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef IODRVDALSPECIFIC_H_
#define IODRVDALSPECIFIC_H_

//------------------------------------------------------------------------------
// Include files
//------------------------------------------------------------------------------

#include "CmpItf.h"
#include "CmpIoDrvItf.h"

#include "IoDrvDal.h"
#include "IoDrvDalCommon.h"

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Constants
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Typedefs
//------------------------------------------------------------------------------

/**
 * Entry function signature for the specific library implementations.
 * @param param
 * @return ERR_OK on success.
 */
typedef RTS_RESULT (*IoDrvDalLibraryEntry)(IoDrvDalInfo *param);

//------------------------------------------------------------------------------
// Function declarations
//------------------------------------------------------------------------------



#endif /* IODRVDALSPECIFIC_H_ */
