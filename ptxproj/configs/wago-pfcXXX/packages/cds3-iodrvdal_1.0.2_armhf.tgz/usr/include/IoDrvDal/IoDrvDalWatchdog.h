//---------------------------------------------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///  \file     IoDrvDalWatchdog.h
///
///  \version  <Revision>: $Rev: $
///
///  \brief    handle dal watchdogs
///
///  \author   U015479 : WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------
#ifndef IODRVDALWATCHDOG_H_
#define IODRVDALWATCHDOG_H_

//---------------------------------------------------------------------------------------------------------------------
// include files
//---------------------------------------------------------------------------------------------------------------------

#include <CmpStd.h>
#include <SysTaskItf.h>

//---------------------------------------------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//---------------------------------------------------------------------------------------------------------------------

#define NUMBER_OF_CFG_KEYS         (5)

#define CFG_KEY__WDG_TIME_OUT      "WatchDogTimeOut_ms"
#define CFG_KEY__WDG_FACTOR        "WatchDogFactor"
#define CFG_KEY__WDG_THREAD_PRIO   "WdgThreadPrio"
#define CFG_KEY__WDG_ERR_CNT_MAX   "WdgErrorCounterMax"                 /* maximum value of error counter            */
#define CFG_KEY__WDG_ADD_EFIFO_S   "WdgAddErrorFifoSize"                /* additional error fifo size                */

#define DEFAULT__WDG_TIME_OUT      (200)
#define DEFAULT__WDG_FACTOR        (5)
#define DEFAULT__WDG_THREAD_PRIO   (TASKPRIO_SYSTEM_BASE+30)            /* above suggestion in RtsHardwareWatchdog.c */
                                                                        /* (TASKPRIO_REALTIME_BASE)                  */
#define DEFAULT__WDG_ERR_CNT_MAX   ((DEFAULT__WDG_FACTOR * 2) + 1)      /* dynamic default value for WDG_ERR_CNT_MAX */
                                                                        /* is (current WDG_Factor * 2) + 1           */
#define DEFAULT__WDG_ADD_EFIFO_S   (((DEFAULT__WDG_ERR_CNT_MAX-1)*2)-1) /* dynamic default value for WDG_ADD_EFIFO_S */
                                                                        /* is ((current WDG_ERR_CNT_MAX -1) * 2) -1  */
#define MINIMUM__WDG_TIME_OUT      (100)
#define MINIMUM__WDG_FACTOR        (3)
#define MINIMUM__WDG_ERR_CNT_MAX   (MINIMUM__WDG_FACTOR)                /* dynamic min value is current WDG_Factor   */
#define MINIMUM__WDG_ADD_EFIFO_S   (0)

#define MAXIMUM__WDG_TIME_OUT      (10000)
#define MAXIMUM__WDG_FACTOR        (30)
#define MAXIMUM__WDG_ERR_CNT_MAX   (MAXIMUM__WDG_FACTOR*3)
#define MAXIMUM__WDG_ADD_EFIFO_S   (MAXIMUM__WDG_ERR_CNT_MAX*4)

#define FACTOR_2_DISABLE__WDG      (0)                                  /* to disable DAL watchdogs at all           */
#define ERR_CNT_MAX_2_DISABLE__REA (0)                                  /* to disable reaction on short time errors  */


//---------------------------------------------------------------------------------------------------------------------
// macros
//---------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------
// function prototypes
//---------------------------------------------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

  RTS_RESULT CDECL IoDrvDal_WatchdogInit(  void );
  RTS_RESULT CDECL IoDrvDal_WatchdogExit(  void );
  RTS_RESULT CDECL IoDrvDal_WatchdogStart( void );
  RTS_RESULT CDECL IoDrvDal_WatchdogStop(  void );
  RTS_RESULT CDECL IoDrvDal_WatchdogReset( void );

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus


#endif /* IODRVDALWATCHDOG_H_ */
//---- End of source file ---------------------------------------------------------------------------------------------

