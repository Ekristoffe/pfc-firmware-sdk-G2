 /**
 * <interfacename>WagoSysSSL_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSSSL_INTERNAL_PFCITF_H_
#define _WAGOSYSSSL_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 *
 *SSL_ERROR_NONE
 *The TLS/SSL I/O operation completed. This result code is returned if and only if ret > 0.
 *
 *SSL_ERROR_ZERO_RETURN
 *The TLS/SSL connection has been closed. If the protocol version is SSL 3.0 or TLS 1.0, this
 *result code is returned only if a closure alert has occurred in the protocol, that is, if the
 *connection has been closed cleanly. Note that in this case SSL_ERROR_ZERO_RETURN
 *does not necessarily indicate that the underlying transport has been closed.
 *
 *SSL_ERROR_WANT_READ, SSL_ERROR_WANT_WRITE
 *The operation did not complete; the same TLS/SSL I/O function should be called again
 *later. If, by then, the underlying LIO has data available for reading (if the result code is
 *SSL_ERROR_WANT_READ) or allows writing data (SSL_ERROR_WANT_WRITE),
 *then some TLS/SSL protocol progress will take place, for example, at least part of an
 *TLS/SSL record will be read or written. Note that the retry may again lead to a
 *SSL_ERROR_WANT_READ or SSL_ERROR_WANT_WRITE condition. There is no
 *fixed upper limit for the number of iterations that may be necessary until progress becomes
 *visible at application protocol level. select() or poll() on the underlying socket can be used
 *to find out when the TLS/SSL I/O function should be retried.
 *Caveat: Any TLS/SSL I/O function can lead to either of SSL_ERROR_WANT_READ and
 *SSL_ ERROR_WANT_WRITE. In particular, SSL_read() or SSL_peek() may want to
 *write data and SSL_write() may want to read data. This is mainly because TLS/SSL
 *handshakes may occur at any time during the protocol (initiated by either the client or the
 *server); SSL_read(), SSL_peek(), and SSL_write() will handle any pending handshakes.
 *Function Reference
 *SSL_get_error
 *
 *SSL_ERROR_WANT_CONNECT, SSL_ERROR_WANT_ACCEPT
 *The operation did not complete; the same TLS/SSL I/O function should be called again
 *later. The underlying LIO was not connected yet to the peer and the call would block in
 *connect()/accept(). The SSL function should be called again when the connection is
 *established. These messages can only appear with a LIO_s_connect() or
 *LIO_s_accept()LIO, respectively. In order to find out, when the connection has been
 *successfully established, on many platforms select() or poll() for writing on the socket file
 *descriptor can be used.
 *
 *SSL_ERROR_WANT_X509_LOOKUP
 *The operation did not complete because an application callback set by
 *SSL_CTX_set_client_cert_cb() has asked to be called again. The TLS/SSL I/O function
 *should be called again later. Details depend on the application.
 *
 *SSL_ERROR_SYSCALL
 *Some I/O error occurred. The mSSL error queue may contain more information on the error.
 *If the error queue is empty (that is, ERR_get_error() returns 0), ret can be used to find out
 *more about the error: If ret == 0, an EOF was observed that violates the protocol. If ret == -
 *1, the underlying LIO reported an I/O error (for socket I/O on Unix systems, consult errno
 *for details).
 *
 *SSL_ERROR_SSL
 *A failure in the SSL library occurred, usually a protocol error. The mSSL error queue
 *contains more information on the error.
 *
 */
#define ESSL_ERROR_RTS_SSL_ERROR_NONE    RTS_IEC_INT_C(0x0)	
#define ESSL_ERROR_RTS_SSL_ERROR_SSL    RTS_IEC_INT_C(0x1)	
#define ESSL_ERROR_RTS_SSL_ERROR_WANT_READ    RTS_IEC_INT_C(0x2)	
#define ESSL_ERROR_RTS_SSL_ERROR_WANT_WRITE    RTS_IEC_INT_C(0x3)	
#define ESSL_ERROR_RTS_SSL_ERROR_WANT_X509_LOOKUP    RTS_IEC_INT_C(0x4)	
#define ESSL_ERROR_RTS_SSL_ERROR_SYSCALL    RTS_IEC_INT_C(0x5)	
#define ESSL_ERROR_RTS_SSL_ERROR_ZERO_RETURN    RTS_IEC_INT_C(0x6)	
#define ESSL_ERROR_RTS_SSL_ERROR_WANT_CONNECT    RTS_IEC_INT_C(0x7)	
#define ESSL_ERROR_RTS_SSL_ERROR_WANT_ACCEPT    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ESSL_ERROR_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_FileType_RTS</description>
 */
#define ESSL_FILETYPE_RTS_PEM    RTS_IEC_INT_C(0x1)	/* Base64 coded certificate or key */
#define ESSL_FILETYPE_RTS_DER    RTS_IEC_INT_C(0x2)	/* Binary coded certificate or key */
/* Typed enum definition */
#define ESSL_FILETYPE_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_Method_RTS</description>
 */
#define ESSL_METHOD_RTS_SSLV23    RTS_IEC_INT_C(0x3)	
#define ESSL_METHOD_RTS_SSLV23_SERVER    RTS_IEC_INT_C(0x4)	
#define ESSL_METHOD_RTS_SSLV23_CLIENT    RTS_IEC_INT_C(0x5)	
#define ESSL_METHOD_RTS_SSLV3    RTS_IEC_INT_C(0x6)	
#define ESSL_METHOD_RTS_SSLV3_SERVER    RTS_IEC_INT_C(0x7)	
#define ESSL_METHOD_RTS_SSLV3_CLIENT    RTS_IEC_INT_C(0x8)	
#define ESSL_METHOD_RTS_TLSV1    RTS_IEC_INT_C(0x9)	
#define ESSL_METHOD_RTS_TLSV1_SERVER    RTS_IEC_INT_C(0xA)	
#define ESSL_METHOD_RTS_TLSV1_CLIENT    RTS_IEC_INT_C(0xB)	
#define ESSL_METHOD_RTS_TLSV1_1    RTS_IEC_INT_C(0xC)	
#define ESSL_METHOD_RTS_TLSV1_1_SERVER    RTS_IEC_INT_C(0xD)	
#define ESSL_METHOD_RTS_TLSV1_1_CLIENT    RTS_IEC_INT_C(0xE)	
#define ESSL_METHOD_RTS_TLSV1_2    RTS_IEC_INT_C(0xF)	
#define ESSL_METHOD_RTS_TLSV1_2_SERVER    RTS_IEC_INT_C(0x10)	
#define ESSL_METHOD_RTS_TLSV1_2_CLIENT    RTS_IEC_INT_C(0x11)	
#define ESSL_METHOD_RTS_DTLSV1    RTS_IEC_INT_C(0x12)	
#define ESSL_METHOD_RTS_DTLSV1_SERVER    RTS_IEC_INT_C(0x13)	
#define ESSL_METHOD_RTS_DTLSV1_CLIENT    RTS_IEC_INT_C(0x14)	
#define ESSL_METHOD_RTS_DTLSV1_2    RTS_IEC_INT_C(0x15)	
#define ESSL_METHOD_RTS_DTLSV1_2_SERVER    RTS_IEC_INT_C(0x16)	
#define ESSL_METHOD_RTS_DTLSV1_2_CLIENT    RTS_IEC_INT_C(0x17)	
#define ESSL_METHOD_RTS_DTLS    RTS_IEC_INT_C(0x18)	
#define ESSL_METHOD_RTS_DTLS_SERVER    RTS_IEC_INT_C(0x19)	
#define ESSL_METHOD_RTS_DTLS_CLIENT    RTS_IEC_INT_C(0x1A)	
#define ESSL_METHOD_RTS_TLS    RTS_IEC_INT_C(0x1B)	
#define ESSL_METHOD_RTS_TLS_SERVER    RTS_IEC_INT_C(0x1C)	
#define ESSL_METHOD_RTS_TLS_CLIENT    RTS_IEC_INT_C(0x1D)	
/* Typed enum definition */
#define ESSL_METHOD_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_Verify_RTS</description>
 */
#define ESSL_VERIFY_RTS_SSL_VERIFY_NONE    RTS_IEC_INT_C(0x0)	/* 
	Server mode: the server will not send a client certificate request to the client, so the client will not send a certificate.
    Client mode: if not using an anonymous cipher (by default disabled), the server will send a certificate which will be checked.
 */
#define ESSL_VERIFY_RTS_SSL_VERIFY_PEER    RTS_IEC_INT_C(0x1)	/* 
	Server mode: the server sends a client certificate request to the client. The certificate returned (if any) is checked. 
    If the verification process fails, the TLS/SSL handshake is immediately terminated with an alert message containing the
    reason for the verification failure.
 */
#define ESSL_VERIFY_RTS_SSL_VERIFY_FAIL_IF_NO_PEER_CERT    RTS_IEC_INT_C(0x2)	/* 
	Server mode: if the client did not return a certificate, the TLS/SSL handshake is immediately terminated with a
 	"handshake failure" alert. This flag must be used together with SSL_VERIFY_PEER.
	Client mode: ignored
 */
#define ESSL_VERIFY_RTS_SSL_VERIFY_CLIENT_ONCE    RTS_IEC_INT_C(0x4)	/* 
	Server mode: only request a client certificate on the initial TLS/SSL handshake. Do not ask for a client certificate
	again in case of a renegotiation. This flag must be used together with SSL_VERIFY_PEER.
	Client mode: ignored
 */
/* Typed enum definition */
#define ESSL_VERIFY_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_X509_Check_RTS</description>
 */
#define ESSL_X509_CHECK_RTS_FLAG_ALWAYS_CHECK_SUBJECT    RTS_IEC_INT_C(0x1)	
#define ESSL_X509_CHECK_RTS_FLAG_NO_WILDCARDS    RTS_IEC_INT_C(0x2)	
#define ESSL_X509_CHECK_RTS_FLAG_NO_PARTIAL_WILDCARDS    RTS_IEC_INT_C(0x4)	
/* Typed enum definition */
#define ESSL_X509_CHECK_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_X509_V_RTS</description>
 */
#define ESSL_X509_V_RTS_OK    RTS_IEC_INT_C(0x0)	
#define ESSL_X509_V_RTS_ERR_UNSPECIFIED    RTS_IEC_INT_C(0x1)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_GET_ISSUER_CERT    RTS_IEC_INT_C(0x2)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_GET_CRL    RTS_IEC_INT_C(0x3)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_DECRYPT_CERT_SIGNATURE    RTS_IEC_INT_C(0x4)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_DECRYPT_CRL_SIGNATURE    RTS_IEC_INT_C(0x5)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY    RTS_IEC_INT_C(0x6)	
#define ESSL_X509_V_RTS_ERR_CERT_SIGNATURE_FAILURE    RTS_IEC_INT_C(0x7)	
#define ESSL_X509_V_RTS_ERR_CRL_SIGNATURE_FAILURE    RTS_IEC_INT_C(0x8)	
#define ESSL_X509_V_RTS_ERR_CERT_NOT_YET_VALID    RTS_IEC_INT_C(0x9)	
#define ESSL_X509_V_RTS_ERR_CERT_HAS_EXPIRED    RTS_IEC_INT_C(0xA)	
#define ESSL_X509_V_RTS_ERR_CRL_NOT_YET_VALID    RTS_IEC_INT_C(0xB)	
#define ESSL_X509_V_RTS_ERR_CRL_HAS_EXPIRED    RTS_IEC_INT_C(0xC)	
#define ESSL_X509_V_RTS_ERR_ERROR_IN_CERT_NOT_BEFORE_FIELD    RTS_IEC_INT_C(0xD)	
#define ESSL_X509_V_RTS_ERR_ERROR_IN_CERT_NOT_AFTER_FIELD    RTS_IEC_INT_C(0xE)	
#define ESSL_X509_V_RTS_ERR_ERROR_IN_CRL_LAST_UPDATE_FIELD    RTS_IEC_INT_C(0xF)	
#define ESSL_X509_V_RTS_ERR_ERROR_IN_CRL_NEXT_UPDATE_FIELD    RTS_IEC_INT_C(0x10)	
#define ESSL_X509_V_RTS_ERR_OUT_OF_MEM    RTS_IEC_INT_C(0x11)	
#define ESSL_X509_V_RTS_ERR_DEPTH_ZERO_SELF_SIGNED_CERT    RTS_IEC_INT_C(0x12)	
#define ESSL_X509_V_RTS_ERR_SELF_SIGNED_CERT_IN_CHAIN    RTS_IEC_INT_C(0x13)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_GET_ISSUER_CERT_LOCALLY    RTS_IEC_INT_C(0x14)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_VERIFY_LEAF_SIGNATURE    RTS_IEC_INT_C(0x15)	
#define ESSL_X509_V_RTS_ERR_CERT_CHAIN_TOO_LONG    RTS_IEC_INT_C(0x16)	
#define ESSL_X509_V_RTS_ERR_CERT_REVOKED    RTS_IEC_INT_C(0x17)	
#define ESSL_X509_V_RTS_ERR_INVALID_CA    RTS_IEC_INT_C(0x18)	
#define ESSL_X509_V_RTS_ERR_PATH_LENGTH_EXCEEDED    RTS_IEC_INT_C(0x19)	
#define ESSL_X509_V_RTS_ERR_INVALID_PURPOSE    RTS_IEC_INT_C(0x1A)	
#define ESSL_X509_V_RTS_ERR_CERT_UNTRUSTED    RTS_IEC_INT_C(0x1B)	
#define ESSL_X509_V_RTS_ERR_CERT_REJECTED    RTS_IEC_INT_C(0x1C)	
#define ESSL_X509_V_RTS_ERR_SUBJECT_ISSUER_MISMATCH    RTS_IEC_INT_C(0x1D)	/* These are 'informational' when looking for issuer cert */
#define ESSL_X509_V_RTS_ERR_AKID_SKID_MISMATCH    RTS_IEC_INT_C(0x1E)	
#define ESSL_X509_V_RTS_ERR_AKID_ISSUER_SERIAL_MISMATCH    RTS_IEC_INT_C(0x1F)	
#define ESSL_X509_V_RTS_ERR_KEYUSAGE_NO_CERTSIGN    RTS_IEC_INT_C(0x20)	
#define ESSL_X509_V_RTS_ERR_UNABLE_TO_GET_CRL_ISSUER    RTS_IEC_INT_C(0x21)	
#define ESSL_X509_V_RTS_ERR_UNHANDLED_CRITICAL_EXTENSION    RTS_IEC_INT_C(0x22)	
#define ESSL_X509_V_RTS_ERR_KEYUSAGE_NO_CRL_SIGN    RTS_IEC_INT_C(0x23)	
#define ESSL_X509_V_RTS_ERR_UNHANDLED_CRITICAL_CRL_EXTENSION    RTS_IEC_INT_C(0x24)	
#define ESSL_X509_V_RTS_ERR_INVALID_NON_CA    RTS_IEC_INT_C(0x25)	
#define ESSL_X509_V_RTS_ERR_PROXY_PATH_LENGTH_EXCEEDED    RTS_IEC_INT_C(0x26)	
#define ESSL_X509_V_RTS_ERR_KEYUSAGE_NO_DIGITAL_SIGNATURE    RTS_IEC_INT_C(0x27)	
#define ESSL_X509_V_RTS_ERR_PROXY_CERTIFICATES_NOT_ALLOWED    RTS_IEC_INT_C(0x28)	
#define ESSL_X509_V_RTS_ERR_INVALID_EXTENSION    RTS_IEC_INT_C(0x29)	
#define ESSL_X509_V_RTS_ERR_INVALID_POLICY_EXTENSION    RTS_IEC_INT_C(0x2A)	
#define ESSL_X509_V_RTS_ERR_NO_EXPLICIT_POLICY    RTS_IEC_INT_C(0x2B)	
#define ESSL_X509_V_RTS_ERR_DIFFERENT_CRL_SCOPE    RTS_IEC_INT_C(0x2C)	
#define ESSL_X509_V_RTS_ERR_UNSUPPORTED_EXTENSION_FEATURE    RTS_IEC_INT_C(0x2D)	
#define ESSL_X509_V_RTS_ERR_UNNESTED_RESOURCE    RTS_IEC_INT_C(0x2E)	
#define ESSL_X509_V_RTS_ERR_PERMITTED_VIOLATION    RTS_IEC_INT_C(0x2F)	
#define ESSL_X509_V_RTS_ERR_EXCLUDED_VIOLATION    RTS_IEC_INT_C(0x30)	
#define ESSL_X509_V_RTS_ERR_SUBTREE_MINMAX    RTS_IEC_INT_C(0x31)	
#define ESSL_X509_V_RTS_ERR_APPLICATION_VERIFICATION    RTS_IEC_INT_C(0x32)	
#define ESSL_X509_V_RTS_ERR_UNSUPPORTED_CONSTRAINT_TYPE    RTS_IEC_INT_C(0x33)	
#define ESSL_X509_V_RTS_ERR_UNSUPPORTED_CONSTRAINT_SYNTAX    RTS_IEC_INT_C(0x34)	
#define ESSL_X509_V_RTS_ERR_UNSUPPORTED_NAME_SYNTAX    RTS_IEC_INT_C(0x35)	
#define ESSL_X509_V_RTS_ERR_CRL_PATH_VALIDATION_ERROR    RTS_IEC_INT_C(0x36)	
#define ESSL_X509_V_RTS_ERR_SUITE_B_INVALID_VERSION    RTS_IEC_INT_C(0x38)	/* Suite B mode algorithm violation */
#define ESSL_X509_V_RTS_ERR_SUITE_B_INVALID_ALGORITHM    RTS_IEC_INT_C(0x39)	
#define ESSL_X509_V_RTS_ERR_SUITE_B_INVALID_CURVE    RTS_IEC_INT_C(0x3A)	
#define ESSL_X509_V_RTS_ERR_SUITE_B_INVALID_SIGNATURE_ALGORITHM    RTS_IEC_INT_C(0x3B)	
#define ESSL_X509_V_RTS_ERR_SUITE_B_LOS_NOT_ALLOWED    RTS_IEC_INT_C(0x3C)	
#define ESSL_X509_V_RTS_ERR_SUITE_B_CANNOT_SIGN_P_384_WITH_P_256    RTS_IEC_INT_C(0x3D)	
#define ESSL_X509_V_RTS_ERR_HOSTNAME_MISMATCH    RTS_IEC_INT_C(0x3E)	/* Host, email and IP check errors */
#define ESSL_X509_V_RTS_ERR_EMAIL_MISMATCH    RTS_IEC_INT_C(0x3F)	
#define ESSL_X509_V_RTS_ERR_IP_ADDRESS_MISMATCH    RTS_IEC_INT_C(0x40)	
#define ESSL_X509_V_RTS_ERR_INVALID_CALL    RTS_IEC_INT_C(0x41)	/* Caller error */
#define ESSL_X509_V_RTS_ERR_STORE_LOOKUP    RTS_IEC_INT_C(0x42)	/* Issuer lookup error */
#define ESSL_X509_V_RTS_ERR_PROXY_SUBJECT_NAME_VIOLATION    RTS_IEC_INT_C(0x43)	
/* Typed enum definition */
#define ESSL_X509_V_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_X509_Verification_RTS</description>
 */
#define ESSL_X509_VERIFICATION_RTS_FLAG_CRL_CHECK    RTS_IEC_INT_C(0x4)	
#define ESSL_X509_VERIFICATION_RTS_FLAG_CRL_CHECK_ALL    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ESSL_X509_VERIFICATION_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_X509_Verification_RTS</description>
 */
#define ESSL_X509_VERIFICATION_RTS_FLAG_CRL_CHECK    RTS_IEC_INT_C(0x4)	
#define ESSL_X509_VERIFICATION_RTS_FLAG_CRL_CHECK_ALL    RTS_IEC_INT_C(0x8)	
/* Typed enum definition */
#define ESSL_X509_VERIFICATION_RTS    RTS_IEC_INT

/**
 * <description>Enum: eSSL_X509_Check_RTS</description>
 */
#define ESSL_X509_CHECK_RTS_FLAG_ALWAYS_CHECK_SUBJECT    RTS_IEC_INT_C(0x1)	
#define ESSL_X509_CHECK_RTS_FLAG_NO_WILDCARDS    RTS_IEC_INT_C(0x2)	
#define ESSL_X509_CHECK_RTS_FLAG_NO_PARTIAL_WILDCARDS    RTS_IEC_INT_C(0x4)	
/* Typed enum definition */
#define ESSL_X509_CHECK_RTS    RTS_IEC_INT

/**
 * <description>fbssl_ctx__main</description>
 */
typedef struct tagfbssl_ctx_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of FbSSL_CTX */

	RTS_IEC_UINT *pSSL_CTX;				/* Local variable */	
	RTS_IEC_UINT connectedSockets;		/* Local variable */	
} fbssl_ctx_struct;

/**
 *
 *return  1 for success
 *return  0 if a error is ocured during reset.
 *return  -1 if sockets are connected to the ctx. The ctx will be not reset.
 */
typedef struct tagfbssl_ctx_reset_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_DINT reset;					/* VAR_OUTPUT */	
} fbssl_ctx_reset_struct;

void CDECL CDECL_EXT fbssl_ctx__reset(fbssl_ctx_reset_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__RESET_IEC) (fbssl_ctx_reset_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__RESET_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__reset
	#define EXT_fbssl_ctx__reset
	#define GET_fbssl_ctx__reset(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__reset(p0) 
	#define CHK_fbssl_ctx__reset  FALSE
	#define EXP_fbssl_ctx__reset  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__reset
	#define EXT_fbssl_ctx__reset
	#define GET_fbssl_ctx__reset(fl)  CAL_CMGETAPI( "fbssl_ctx__reset" ) 
	#define CAL_fbssl_ctx__reset  fbssl_ctx__reset
	#define CHK_fbssl_ctx__reset  TRUE
	#define EXP_fbssl_ctx__reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__reset", (RTS_UINTPTR)fbssl_ctx__reset, 1, 0x22E41261, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__reset {(RTS_VOID_FCTPTR)fbssl_ctx__reset, "fbssl_ctx__reset", 0x22E41261, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__reset
	#define EXT_fbssl_ctx__reset
	#define GET_fbssl_ctx__reset(fl)  CAL_CMGETAPI( "fbssl_ctx__reset" ) 
	#define CAL_fbssl_ctx__reset  fbssl_ctx__reset
	#define CHK_fbssl_ctx__reset  TRUE
	#define EXP_fbssl_ctx__reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__reset", (RTS_UINTPTR)fbssl_ctx__reset, 1, 0x22E41261, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__reset
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__reset
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__reset  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__reset  fbssl_ctx__reset
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__reset  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__reset", (RTS_UINTPTR)fbssl_ctx__reset, 1, 0x22E41261, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__reset
	#define EXT_fbssl_ctx__reset
	#define GET_fbssl_ctx__reset(fl)  CAL_CMGETAPI( "fbssl_ctx__reset" ) 
	#define CAL_fbssl_ctx__reset  fbssl_ctx__reset
	#define CHK_fbssl_ctx__reset  TRUE
	#define EXP_fbssl_ctx__reset  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__reset", (RTS_UINTPTR)fbssl_ctx__reset, 1, 0x22E41261, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__reset  PFFBSSL_CTX__RESET_IEC pffbssl_ctx__reset;
	#define EXT_fbssl_ctx__reset  extern PFFBSSL_CTX__RESET_IEC pffbssl_ctx__reset;
	#define GET_fbssl_ctx__reset(fl)  s_pfCMGetAPI2( "fbssl_ctx__reset", (RTS_VOID_FCTPTR *)&pffbssl_ctx__reset, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x22E41261, 0x01010600)
	#define CAL_fbssl_ctx__reset  pffbssl_ctx__reset
	#define CHK_fbssl_ctx__reset  (pffbssl_ctx__reset != NULL)
	#define EXP_fbssl_ctx__reset   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__reset", (RTS_UINTPTR)fbssl_ctx__reset, 1, 0x22E41261, 0x01010600) 
#endif


/**
 *
 *	set the depth of accepte certification chain.
 */
typedef struct tagfbssl_ctx_verify_depth_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_DINT depth;					/* VAR_INPUT */	
	RTS_IEC_UDINT verify_depth;			/* VAR_OUTPUT */	
} fbssl_ctx_verify_depth_struct;

void CDECL CDECL_EXT fbssl_ctx__verify_depth(fbssl_ctx_verify_depth_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__VERIFY_DEPTH_IEC) (fbssl_ctx_verify_depth_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__VERIFY_DEPTH_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__verify_depth
	#define EXT_fbssl_ctx__verify_depth
	#define GET_fbssl_ctx__verify_depth(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__verify_depth(p0) 
	#define CHK_fbssl_ctx__verify_depth  FALSE
	#define EXP_fbssl_ctx__verify_depth  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__verify_depth
	#define EXT_fbssl_ctx__verify_depth
	#define GET_fbssl_ctx__verify_depth(fl)  CAL_CMGETAPI( "fbssl_ctx__verify_depth" ) 
	#define CAL_fbssl_ctx__verify_depth  fbssl_ctx__verify_depth
	#define CHK_fbssl_ctx__verify_depth  TRUE
	#define EXP_fbssl_ctx__verify_depth  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__verify_depth", (RTS_UINTPTR)fbssl_ctx__verify_depth, 1, 0xD65BA329, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__verify_depth {(RTS_VOID_FCTPTR)fbssl_ctx__verify_depth, "fbssl_ctx__verify_depth", 0xD65BA329, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__verify_depth
	#define EXT_fbssl_ctx__verify_depth
	#define GET_fbssl_ctx__verify_depth(fl)  CAL_CMGETAPI( "fbssl_ctx__verify_depth" ) 
	#define CAL_fbssl_ctx__verify_depth  fbssl_ctx__verify_depth
	#define CHK_fbssl_ctx__verify_depth  TRUE
	#define EXP_fbssl_ctx__verify_depth  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__verify_depth", (RTS_UINTPTR)fbssl_ctx__verify_depth, 1, 0xD65BA329, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__verify_depth
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__verify_depth
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__verify_depth  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__verify_depth  fbssl_ctx__verify_depth
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__verify_depth  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__verify_depth  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__verify_depth", (RTS_UINTPTR)fbssl_ctx__verify_depth, 1, 0xD65BA329, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__verify_depth
	#define EXT_fbssl_ctx__verify_depth
	#define GET_fbssl_ctx__verify_depth(fl)  CAL_CMGETAPI( "fbssl_ctx__verify_depth" ) 
	#define CAL_fbssl_ctx__verify_depth  fbssl_ctx__verify_depth
	#define CHK_fbssl_ctx__verify_depth  TRUE
	#define EXP_fbssl_ctx__verify_depth  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__verify_depth", (RTS_UINTPTR)fbssl_ctx__verify_depth, 1, 0xD65BA329, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__verify_depth  PFFBSSL_CTX__VERIFY_DEPTH_IEC pffbssl_ctx__verify_depth;
	#define EXT_fbssl_ctx__verify_depth  extern PFFBSSL_CTX__VERIFY_DEPTH_IEC pffbssl_ctx__verify_depth;
	#define GET_fbssl_ctx__verify_depth(fl)  s_pfCMGetAPI2( "fbssl_ctx__verify_depth", (RTS_VOID_FCTPTR *)&pffbssl_ctx__verify_depth, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD65BA329, 0x01010600)
	#define CAL_fbssl_ctx__verify_depth  pffbssl_ctx__verify_depth
	#define CHK_fbssl_ctx__verify_depth  (pffbssl_ctx__verify_depth != NULL)
	#define EXP_fbssl_ctx__verify_depth   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__verify_depth", (RTS_UINTPTR)fbssl_ctx__verify_depth, 1, 0xD65BA329, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_fb_exit</description>
 */
typedef struct tagfbssl_ctx_fb_exit_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* bei TRUE wird die exit-Methode aufgerufen, um die Instanz zu verlassen, die hinterher kopiert wird (Online Change). */
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} fbssl_ctx_fb_exit_struct;

void CDECL CDECL_EXT fbssl_ctx__fb_exit(fbssl_ctx_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__FB_EXIT_IEC) (fbssl_ctx_fb_exit_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__FB_EXIT_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__fb_exit
	#define EXT_fbssl_ctx__fb_exit
	#define GET_fbssl_ctx__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__fb_exit(p0) 
	#define CHK_fbssl_ctx__fb_exit  FALSE
	#define EXP_fbssl_ctx__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__fb_exit
	#define EXT_fbssl_ctx__fb_exit
	#define GET_fbssl_ctx__fb_exit(fl)  CAL_CMGETAPI( "fbssl_ctx__fb_exit" ) 
	#define CAL_fbssl_ctx__fb_exit  fbssl_ctx__fb_exit
	#define CHK_fbssl_ctx__fb_exit  TRUE
	#define EXP_fbssl_ctx__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_exit", (RTS_UINTPTR)fbssl_ctx__fb_exit, 1, 0xCF7557FF, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__fb_exit {(RTS_VOID_FCTPTR)fbssl_ctx__fb_exit, "fbssl_ctx__fb_exit", 0xCF7557FF, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__fb_exit
	#define EXT_fbssl_ctx__fb_exit
	#define GET_fbssl_ctx__fb_exit(fl)  CAL_CMGETAPI( "fbssl_ctx__fb_exit" ) 
	#define CAL_fbssl_ctx__fb_exit  fbssl_ctx__fb_exit
	#define CHK_fbssl_ctx__fb_exit  TRUE
	#define EXP_fbssl_ctx__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_exit", (RTS_UINTPTR)fbssl_ctx__fb_exit, 1, 0xCF7557FF, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__fb_exit
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__fb_exit
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__fb_exit  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__fb_exit  fbssl_ctx__fb_exit
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__fb_exit  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_exit", (RTS_UINTPTR)fbssl_ctx__fb_exit, 1, 0xCF7557FF, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__fb_exit
	#define EXT_fbssl_ctx__fb_exit
	#define GET_fbssl_ctx__fb_exit(fl)  CAL_CMGETAPI( "fbssl_ctx__fb_exit" ) 
	#define CAL_fbssl_ctx__fb_exit  fbssl_ctx__fb_exit
	#define CHK_fbssl_ctx__fb_exit  TRUE
	#define EXP_fbssl_ctx__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_exit", (RTS_UINTPTR)fbssl_ctx__fb_exit, 1, 0xCF7557FF, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__fb_exit  PFFBSSL_CTX__FB_EXIT_IEC pffbssl_ctx__fb_exit;
	#define EXT_fbssl_ctx__fb_exit  extern PFFBSSL_CTX__FB_EXIT_IEC pffbssl_ctx__fb_exit;
	#define GET_fbssl_ctx__fb_exit(fl)  s_pfCMGetAPI2( "fbssl_ctx__fb_exit", (RTS_VOID_FCTPTR *)&pffbssl_ctx__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCF7557FF, 0x01010600)
	#define CAL_fbssl_ctx__fb_exit  pffbssl_ctx__fb_exit
	#define CHK_fbssl_ctx__fb_exit  (pffbssl_ctx__fb_exit != NULL)
	#define EXP_fbssl_ctx__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_exit", (RTS_UINTPTR)fbssl_ctx__fb_exit, 1, 0xCF7557FF, 0x01010600) 
#endif


/**
 *
 *return always 1 for success
 *set the handel to stack in parameter hStack
 */
typedef struct tagfbssl_ctx_set_client_ca_list_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_LWORD hStack;				/* VAR_INPUT */	/* handle of list returns by SSL_loadClinet_CA_file */
	RTS_IEC_UDINT set_client_CA_list;	/* VAR_OUTPUT */	
} fbssl_ctx_set_client_ca_list_struct;

void CDECL CDECL_EXT fbssl_ctx__set_client_ca_list(fbssl_ctx_set_client_ca_list_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__SET_CLIENT_CA_LIST_IEC) (fbssl_ctx_set_client_ca_list_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__SET_CLIENT_CA_LIST_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__set_client_ca_list
	#define EXT_fbssl_ctx__set_client_ca_list
	#define GET_fbssl_ctx__set_client_ca_list(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__set_client_ca_list(p0) 
	#define CHK_fbssl_ctx__set_client_ca_list  FALSE
	#define EXP_fbssl_ctx__set_client_ca_list  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__set_client_ca_list
	#define EXT_fbssl_ctx__set_client_ca_list
	#define GET_fbssl_ctx__set_client_ca_list(fl)  CAL_CMGETAPI( "fbssl_ctx__set_client_ca_list" ) 
	#define CAL_fbssl_ctx__set_client_ca_list  fbssl_ctx__set_client_ca_list
	#define CHK_fbssl_ctx__set_client_ca_list  TRUE
	#define EXP_fbssl_ctx__set_client_ca_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_client_ca_list", (RTS_UINTPTR)fbssl_ctx__set_client_ca_list, 1, 0x44879AFB, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__set_client_ca_list {(RTS_VOID_FCTPTR)fbssl_ctx__set_client_ca_list, "fbssl_ctx__set_client_ca_list", 0x44879AFB, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__set_client_ca_list
	#define EXT_fbssl_ctx__set_client_ca_list
	#define GET_fbssl_ctx__set_client_ca_list(fl)  CAL_CMGETAPI( "fbssl_ctx__set_client_ca_list" ) 
	#define CAL_fbssl_ctx__set_client_ca_list  fbssl_ctx__set_client_ca_list
	#define CHK_fbssl_ctx__set_client_ca_list  TRUE
	#define EXP_fbssl_ctx__set_client_ca_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_client_ca_list", (RTS_UINTPTR)fbssl_ctx__set_client_ca_list, 1, 0x44879AFB, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__set_client_ca_list
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__set_client_ca_list
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__set_client_ca_list  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__set_client_ca_list  fbssl_ctx__set_client_ca_list
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__set_client_ca_list  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__set_client_ca_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_client_ca_list", (RTS_UINTPTR)fbssl_ctx__set_client_ca_list, 1, 0x44879AFB, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__set_client_ca_list
	#define EXT_fbssl_ctx__set_client_ca_list
	#define GET_fbssl_ctx__set_client_ca_list(fl)  CAL_CMGETAPI( "fbssl_ctx__set_client_ca_list" ) 
	#define CAL_fbssl_ctx__set_client_ca_list  fbssl_ctx__set_client_ca_list
	#define CHK_fbssl_ctx__set_client_ca_list  TRUE
	#define EXP_fbssl_ctx__set_client_ca_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_client_ca_list", (RTS_UINTPTR)fbssl_ctx__set_client_ca_list, 1, 0x44879AFB, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__set_client_ca_list  PFFBSSL_CTX__SET_CLIENT_CA_LIST_IEC pffbssl_ctx__set_client_ca_list;
	#define EXT_fbssl_ctx__set_client_ca_list  extern PFFBSSL_CTX__SET_CLIENT_CA_LIST_IEC pffbssl_ctx__set_client_ca_list;
	#define GET_fbssl_ctx__set_client_ca_list(fl)  s_pfCMGetAPI2( "fbssl_ctx__set_client_ca_list", (RTS_VOID_FCTPTR *)&pffbssl_ctx__set_client_ca_list, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x44879AFB, 0x01010600)
	#define CAL_fbssl_ctx__set_client_ca_list  pffbssl_ctx__set_client_ca_list
	#define CHK_fbssl_ctx__set_client_ca_list  (pffbssl_ctx__set_client_ca_list != NULL)
	#define EXP_fbssl_ctx__set_client_ca_list   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_client_ca_list", (RTS_UINTPTR)fbssl_ctx__set_client_ca_list, 1, 0x44879AFB, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_use_privatekey_file</description>
 */
typedef struct tagfbssl_ctx_use_privatekey_file_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_STRING cfile[81];			/* VAR_INPUT */	/* path and file name */
	RTS_IEC_INT uFileType;				/* VAR_INPUT, Enum: ESSL_FILETYPE_RTS */
	RTS_IEC_UDINT use_PrivateKey_file;	/* VAR_OUTPUT */	
} fbssl_ctx_use_privatekey_file_struct;

void CDECL CDECL_EXT fbssl_ctx__use_privatekey_file(fbssl_ctx_use_privatekey_file_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__USE_PRIVATEKEY_FILE_IEC) (fbssl_ctx_use_privatekey_file_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__USE_PRIVATEKEY_FILE_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__use_privatekey_file
	#define EXT_fbssl_ctx__use_privatekey_file
	#define GET_fbssl_ctx__use_privatekey_file(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__use_privatekey_file(p0) 
	#define CHK_fbssl_ctx__use_privatekey_file  FALSE
	#define EXP_fbssl_ctx__use_privatekey_file  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__use_privatekey_file
	#define EXT_fbssl_ctx__use_privatekey_file
	#define GET_fbssl_ctx__use_privatekey_file(fl)  CAL_CMGETAPI( "fbssl_ctx__use_privatekey_file" ) 
	#define CAL_fbssl_ctx__use_privatekey_file  fbssl_ctx__use_privatekey_file
	#define CHK_fbssl_ctx__use_privatekey_file  TRUE
	#define EXP_fbssl_ctx__use_privatekey_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_privatekey_file", (RTS_UINTPTR)fbssl_ctx__use_privatekey_file, 1, 0x36A0748A, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__use_privatekey_file {(RTS_VOID_FCTPTR)fbssl_ctx__use_privatekey_file, "fbssl_ctx__use_privatekey_file", 0x36A0748A, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__use_privatekey_file
	#define EXT_fbssl_ctx__use_privatekey_file
	#define GET_fbssl_ctx__use_privatekey_file(fl)  CAL_CMGETAPI( "fbssl_ctx__use_privatekey_file" ) 
	#define CAL_fbssl_ctx__use_privatekey_file  fbssl_ctx__use_privatekey_file
	#define CHK_fbssl_ctx__use_privatekey_file  TRUE
	#define EXP_fbssl_ctx__use_privatekey_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_privatekey_file", (RTS_UINTPTR)fbssl_ctx__use_privatekey_file, 1, 0x36A0748A, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__use_privatekey_file
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__use_privatekey_file
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__use_privatekey_file  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__use_privatekey_file  fbssl_ctx__use_privatekey_file
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__use_privatekey_file  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__use_privatekey_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_privatekey_file", (RTS_UINTPTR)fbssl_ctx__use_privatekey_file, 1, 0x36A0748A, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__use_privatekey_file
	#define EXT_fbssl_ctx__use_privatekey_file
	#define GET_fbssl_ctx__use_privatekey_file(fl)  CAL_CMGETAPI( "fbssl_ctx__use_privatekey_file" ) 
	#define CAL_fbssl_ctx__use_privatekey_file  fbssl_ctx__use_privatekey_file
	#define CHK_fbssl_ctx__use_privatekey_file  TRUE
	#define EXP_fbssl_ctx__use_privatekey_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_privatekey_file", (RTS_UINTPTR)fbssl_ctx__use_privatekey_file, 1, 0x36A0748A, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__use_privatekey_file  PFFBSSL_CTX__USE_PRIVATEKEY_FILE_IEC pffbssl_ctx__use_privatekey_file;
	#define EXT_fbssl_ctx__use_privatekey_file  extern PFFBSSL_CTX__USE_PRIVATEKEY_FILE_IEC pffbssl_ctx__use_privatekey_file;
	#define GET_fbssl_ctx__use_privatekey_file(fl)  s_pfCMGetAPI2( "fbssl_ctx__use_privatekey_file", (RTS_VOID_FCTPTR *)&pffbssl_ctx__use_privatekey_file, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x36A0748A, 0x01010600)
	#define CAL_fbssl_ctx__use_privatekey_file  pffbssl_ctx__use_privatekey_file
	#define CHK_fbssl_ctx__use_privatekey_file  (pffbssl_ctx__use_privatekey_file != NULL)
	#define EXP_fbssl_ctx__use_privatekey_file   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_privatekey_file", (RTS_UINTPTR)fbssl_ctx__use_privatekey_file, 1, 0x36A0748A, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_sess_set_cache_size</description>
 */
typedef struct tagfbssl_ctx_sess_set_cache_size_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_UDINT uCacheSize;			/* VAR_INPUT */	/* maximum number of internal sessions that will be held in the context cache */
	RTS_IEC_UDINT sess_set_cache_size;	/* VAR_OUTPUT */	
} fbssl_ctx_sess_set_cache_size_struct;

void CDECL CDECL_EXT fbssl_ctx__sess_set_cache_size(fbssl_ctx_sess_set_cache_size_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__SESS_SET_CACHE_SIZE_IEC) (fbssl_ctx_sess_set_cache_size_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__SESS_SET_CACHE_SIZE_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__sess_set_cache_size
	#define EXT_fbssl_ctx__sess_set_cache_size
	#define GET_fbssl_ctx__sess_set_cache_size(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__sess_set_cache_size(p0) 
	#define CHK_fbssl_ctx__sess_set_cache_size  FALSE
	#define EXP_fbssl_ctx__sess_set_cache_size  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__sess_set_cache_size
	#define EXT_fbssl_ctx__sess_set_cache_size
	#define GET_fbssl_ctx__sess_set_cache_size(fl)  CAL_CMGETAPI( "fbssl_ctx__sess_set_cache_size" ) 
	#define CAL_fbssl_ctx__sess_set_cache_size  fbssl_ctx__sess_set_cache_size
	#define CHK_fbssl_ctx__sess_set_cache_size  TRUE
	#define EXP_fbssl_ctx__sess_set_cache_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__sess_set_cache_size", (RTS_UINTPTR)fbssl_ctx__sess_set_cache_size, 1, 0x9436FFCC, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__sess_set_cache_size {(RTS_VOID_FCTPTR)fbssl_ctx__sess_set_cache_size, "fbssl_ctx__sess_set_cache_size", 0x9436FFCC, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__sess_set_cache_size
	#define EXT_fbssl_ctx__sess_set_cache_size
	#define GET_fbssl_ctx__sess_set_cache_size(fl)  CAL_CMGETAPI( "fbssl_ctx__sess_set_cache_size" ) 
	#define CAL_fbssl_ctx__sess_set_cache_size  fbssl_ctx__sess_set_cache_size
	#define CHK_fbssl_ctx__sess_set_cache_size  TRUE
	#define EXP_fbssl_ctx__sess_set_cache_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__sess_set_cache_size", (RTS_UINTPTR)fbssl_ctx__sess_set_cache_size, 1, 0x9436FFCC, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__sess_set_cache_size
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__sess_set_cache_size
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__sess_set_cache_size  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__sess_set_cache_size  fbssl_ctx__sess_set_cache_size
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__sess_set_cache_size  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__sess_set_cache_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__sess_set_cache_size", (RTS_UINTPTR)fbssl_ctx__sess_set_cache_size, 1, 0x9436FFCC, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__sess_set_cache_size
	#define EXT_fbssl_ctx__sess_set_cache_size
	#define GET_fbssl_ctx__sess_set_cache_size(fl)  CAL_CMGETAPI( "fbssl_ctx__sess_set_cache_size" ) 
	#define CAL_fbssl_ctx__sess_set_cache_size  fbssl_ctx__sess_set_cache_size
	#define CHK_fbssl_ctx__sess_set_cache_size  TRUE
	#define EXP_fbssl_ctx__sess_set_cache_size  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__sess_set_cache_size", (RTS_UINTPTR)fbssl_ctx__sess_set_cache_size, 1, 0x9436FFCC, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__sess_set_cache_size  PFFBSSL_CTX__SESS_SET_CACHE_SIZE_IEC pffbssl_ctx__sess_set_cache_size;
	#define EXT_fbssl_ctx__sess_set_cache_size  extern PFFBSSL_CTX__SESS_SET_CACHE_SIZE_IEC pffbssl_ctx__sess_set_cache_size;
	#define GET_fbssl_ctx__sess_set_cache_size(fl)  s_pfCMGetAPI2( "fbssl_ctx__sess_set_cache_size", (RTS_VOID_FCTPTR *)&pffbssl_ctx__sess_set_cache_size, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9436FFCC, 0x01010600)
	#define CAL_fbssl_ctx__sess_set_cache_size  pffbssl_ctx__sess_set_cache_size
	#define CHK_fbssl_ctx__sess_set_cache_size  (pffbssl_ctx__sess_set_cache_size != NULL)
	#define EXP_fbssl_ctx__sess_set_cache_size   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__sess_set_cache_size", (RTS_UINTPTR)fbssl_ctx__sess_set_cache_size, 1, 0x9436FFCC, 0x01010600) 
#endif


/**
 *
 *set method of SSL handling. Must be called first during using the SSL_CTX.
 *
 *Return 1 if success, otherwise 0.
 */
typedef struct tagfbssl_ctx_set_method_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_INT uMethode;				/* VAR_INPUT, Enum: ESSL_METHOD_RTS */
	RTS_IEC_UDINT set_method;			/* VAR_OUTPUT */	
} fbssl_ctx_set_method_struct;

void CDECL CDECL_EXT fbssl_ctx__set_method(fbssl_ctx_set_method_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__SET_METHOD_IEC) (fbssl_ctx_set_method_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__SET_METHOD_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__set_method
	#define EXT_fbssl_ctx__set_method
	#define GET_fbssl_ctx__set_method(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__set_method(p0) 
	#define CHK_fbssl_ctx__set_method  FALSE
	#define EXP_fbssl_ctx__set_method  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__set_method
	#define EXT_fbssl_ctx__set_method
	#define GET_fbssl_ctx__set_method(fl)  CAL_CMGETAPI( "fbssl_ctx__set_method" ) 
	#define CAL_fbssl_ctx__set_method  fbssl_ctx__set_method
	#define CHK_fbssl_ctx__set_method  TRUE
	#define EXP_fbssl_ctx__set_method  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_method", (RTS_UINTPTR)fbssl_ctx__set_method, 1, 0xB5E00FB4, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__set_method {(RTS_VOID_FCTPTR)fbssl_ctx__set_method, "fbssl_ctx__set_method", 0xB5E00FB4, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__set_method
	#define EXT_fbssl_ctx__set_method
	#define GET_fbssl_ctx__set_method(fl)  CAL_CMGETAPI( "fbssl_ctx__set_method" ) 
	#define CAL_fbssl_ctx__set_method  fbssl_ctx__set_method
	#define CHK_fbssl_ctx__set_method  TRUE
	#define EXP_fbssl_ctx__set_method  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_method", (RTS_UINTPTR)fbssl_ctx__set_method, 1, 0xB5E00FB4, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__set_method
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__set_method
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__set_method  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__set_method  fbssl_ctx__set_method
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__set_method  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__set_method  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_method", (RTS_UINTPTR)fbssl_ctx__set_method, 1, 0xB5E00FB4, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__set_method
	#define EXT_fbssl_ctx__set_method
	#define GET_fbssl_ctx__set_method(fl)  CAL_CMGETAPI( "fbssl_ctx__set_method" ) 
	#define CAL_fbssl_ctx__set_method  fbssl_ctx__set_method
	#define CHK_fbssl_ctx__set_method  TRUE
	#define EXP_fbssl_ctx__set_method  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_method", (RTS_UINTPTR)fbssl_ctx__set_method, 1, 0xB5E00FB4, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__set_method  PFFBSSL_CTX__SET_METHOD_IEC pffbssl_ctx__set_method;
	#define EXT_fbssl_ctx__set_method  extern PFFBSSL_CTX__SET_METHOD_IEC pffbssl_ctx__set_method;
	#define GET_fbssl_ctx__set_method(fl)  s_pfCMGetAPI2( "fbssl_ctx__set_method", (RTS_VOID_FCTPTR *)&pffbssl_ctx__set_method, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB5E00FB4, 0x01010600)
	#define CAL_fbssl_ctx__set_method  pffbssl_ctx__set_method
	#define CHK_fbssl_ctx__set_method  (pffbssl_ctx__set_method != NULL)
	#define EXP_fbssl_ctx__set_method   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_method", (RTS_UINTPTR)fbssl_ctx__set_method, 1, 0xB5E00FB4, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_load_revocation_list</description>
 */
typedef struct tagfbssl_ctx_load_revocation_list_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_STRING cfile[81];			/* VAR_INPUT */	/* path and file name */
	RTS_IEC_DINT load_revocation_list;	/* VAR_OUTPUT */	
} fbssl_ctx_load_revocation_list_struct;

void CDECL CDECL_EXT fbssl_ctx__load_revocation_list(fbssl_ctx_load_revocation_list_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__LOAD_REVOCATION_LIST_IEC) (fbssl_ctx_load_revocation_list_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__LOAD_REVOCATION_LIST_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__load_revocation_list
	#define EXT_fbssl_ctx__load_revocation_list
	#define GET_fbssl_ctx__load_revocation_list(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__load_revocation_list(p0) 
	#define CHK_fbssl_ctx__load_revocation_list  FALSE
	#define EXP_fbssl_ctx__load_revocation_list  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__load_revocation_list
	#define EXT_fbssl_ctx__load_revocation_list
	#define GET_fbssl_ctx__load_revocation_list(fl)  CAL_CMGETAPI( "fbssl_ctx__load_revocation_list" ) 
	#define CAL_fbssl_ctx__load_revocation_list  fbssl_ctx__load_revocation_list
	#define CHK_fbssl_ctx__load_revocation_list  TRUE
	#define EXP_fbssl_ctx__load_revocation_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_revocation_list", (RTS_UINTPTR)fbssl_ctx__load_revocation_list, 1, 0x02F68F7E, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__load_revocation_list {(RTS_VOID_FCTPTR)fbssl_ctx__load_revocation_list, "fbssl_ctx__load_revocation_list", 0x02F68F7E, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__load_revocation_list
	#define EXT_fbssl_ctx__load_revocation_list
	#define GET_fbssl_ctx__load_revocation_list(fl)  CAL_CMGETAPI( "fbssl_ctx__load_revocation_list" ) 
	#define CAL_fbssl_ctx__load_revocation_list  fbssl_ctx__load_revocation_list
	#define CHK_fbssl_ctx__load_revocation_list  TRUE
	#define EXP_fbssl_ctx__load_revocation_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_revocation_list", (RTS_UINTPTR)fbssl_ctx__load_revocation_list, 1, 0x02F68F7E, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__load_revocation_list
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__load_revocation_list
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__load_revocation_list  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__load_revocation_list  fbssl_ctx__load_revocation_list
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__load_revocation_list  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__load_revocation_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_revocation_list", (RTS_UINTPTR)fbssl_ctx__load_revocation_list, 1, 0x02F68F7E, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__load_revocation_list
	#define EXT_fbssl_ctx__load_revocation_list
	#define GET_fbssl_ctx__load_revocation_list(fl)  CAL_CMGETAPI( "fbssl_ctx__load_revocation_list" ) 
	#define CAL_fbssl_ctx__load_revocation_list  fbssl_ctx__load_revocation_list
	#define CHK_fbssl_ctx__load_revocation_list  TRUE
	#define EXP_fbssl_ctx__load_revocation_list  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_revocation_list", (RTS_UINTPTR)fbssl_ctx__load_revocation_list, 1, 0x02F68F7E, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__load_revocation_list  PFFBSSL_CTX__LOAD_REVOCATION_LIST_IEC pffbssl_ctx__load_revocation_list;
	#define EXT_fbssl_ctx__load_revocation_list  extern PFFBSSL_CTX__LOAD_REVOCATION_LIST_IEC pffbssl_ctx__load_revocation_list;
	#define GET_fbssl_ctx__load_revocation_list(fl)  s_pfCMGetAPI2( "fbssl_ctx__load_revocation_list", (RTS_VOID_FCTPTR *)&pffbssl_ctx__load_revocation_list, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x02F68F7E, 0x01010600)
	#define CAL_fbssl_ctx__load_revocation_list  pffbssl_ctx__load_revocation_list
	#define CHK_fbssl_ctx__load_revocation_list  (pffbssl_ctx__load_revocation_list != NULL)
	#define EXP_fbssl_ctx__load_revocation_list   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_revocation_list", (RTS_UINTPTR)fbssl_ctx__load_revocation_list, 1, 0x02F68F7E, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_load_verfiy_locations</description>
 */
typedef struct tagfbssl_ctx_load_verfiy_locations_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_STRING cfile[81];			/* VAR_INPUT */	/* path and file name */
	RTS_IEC_INT uFileType;				/* VAR_INPUT, Enum: ESSL_FILETYPE_RTS */
	RTS_IEC_DINT load_verfiy_locations;	/* VAR_OUTPUT */	
} fbssl_ctx_load_verfiy_locations_struct;

void CDECL CDECL_EXT fbssl_ctx__load_verfiy_locations(fbssl_ctx_load_verfiy_locations_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__LOAD_VERFIY_LOCATIONS_IEC) (fbssl_ctx_load_verfiy_locations_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__LOAD_VERFIY_LOCATIONS_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__load_verfiy_locations
	#define EXT_fbssl_ctx__load_verfiy_locations
	#define GET_fbssl_ctx__load_verfiy_locations(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__load_verfiy_locations(p0) 
	#define CHK_fbssl_ctx__load_verfiy_locations  FALSE
	#define EXP_fbssl_ctx__load_verfiy_locations  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__load_verfiy_locations
	#define EXT_fbssl_ctx__load_verfiy_locations
	#define GET_fbssl_ctx__load_verfiy_locations(fl)  CAL_CMGETAPI( "fbssl_ctx__load_verfiy_locations" ) 
	#define CAL_fbssl_ctx__load_verfiy_locations  fbssl_ctx__load_verfiy_locations
	#define CHK_fbssl_ctx__load_verfiy_locations  TRUE
	#define EXP_fbssl_ctx__load_verfiy_locations  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_verfiy_locations", (RTS_UINTPTR)fbssl_ctx__load_verfiy_locations, 1, 0xD992A2AA, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__load_verfiy_locations {(RTS_VOID_FCTPTR)fbssl_ctx__load_verfiy_locations, "fbssl_ctx__load_verfiy_locations", 0xD992A2AA, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__load_verfiy_locations
	#define EXT_fbssl_ctx__load_verfiy_locations
	#define GET_fbssl_ctx__load_verfiy_locations(fl)  CAL_CMGETAPI( "fbssl_ctx__load_verfiy_locations" ) 
	#define CAL_fbssl_ctx__load_verfiy_locations  fbssl_ctx__load_verfiy_locations
	#define CHK_fbssl_ctx__load_verfiy_locations  TRUE
	#define EXP_fbssl_ctx__load_verfiy_locations  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_verfiy_locations", (RTS_UINTPTR)fbssl_ctx__load_verfiy_locations, 1, 0xD992A2AA, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__load_verfiy_locations
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__load_verfiy_locations
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__load_verfiy_locations  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__load_verfiy_locations  fbssl_ctx__load_verfiy_locations
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__load_verfiy_locations  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__load_verfiy_locations  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_verfiy_locations", (RTS_UINTPTR)fbssl_ctx__load_verfiy_locations, 1, 0xD992A2AA, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__load_verfiy_locations
	#define EXT_fbssl_ctx__load_verfiy_locations
	#define GET_fbssl_ctx__load_verfiy_locations(fl)  CAL_CMGETAPI( "fbssl_ctx__load_verfiy_locations" ) 
	#define CAL_fbssl_ctx__load_verfiy_locations  fbssl_ctx__load_verfiy_locations
	#define CHK_fbssl_ctx__load_verfiy_locations  TRUE
	#define EXP_fbssl_ctx__load_verfiy_locations  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_verfiy_locations", (RTS_UINTPTR)fbssl_ctx__load_verfiy_locations, 1, 0xD992A2AA, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__load_verfiy_locations  PFFBSSL_CTX__LOAD_VERFIY_LOCATIONS_IEC pffbssl_ctx__load_verfiy_locations;
	#define EXT_fbssl_ctx__load_verfiy_locations  extern PFFBSSL_CTX__LOAD_VERFIY_LOCATIONS_IEC pffbssl_ctx__load_verfiy_locations;
	#define GET_fbssl_ctx__load_verfiy_locations(fl)  s_pfCMGetAPI2( "fbssl_ctx__load_verfiy_locations", (RTS_VOID_FCTPTR *)&pffbssl_ctx__load_verfiy_locations, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD992A2AA, 0x01010600)
	#define CAL_fbssl_ctx__load_verfiy_locations  pffbssl_ctx__load_verfiy_locations
	#define CHK_fbssl_ctx__load_verfiy_locations  (pffbssl_ctx__load_verfiy_locations != NULL)
	#define EXP_fbssl_ctx__load_verfiy_locations   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__load_verfiy_locations", (RTS_UINTPTR)fbssl_ctx__load_verfiy_locations, 1, 0xD992A2AA, 0x01010600) 
#endif


/**
 *
 *  set_verify() sets the verification flags for ctx to be mode.  
 */
typedef struct tagfbssl_ctx_set_verify_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_INT verify;					/* VAR_INPUT, Enum: ESSL_VERIFY_RTS */
	RTS_IEC_UDINT set_verify;			/* VAR_OUTPUT */	
} fbssl_ctx_set_verify_struct;

void CDECL CDECL_EXT fbssl_ctx__set_verify(fbssl_ctx_set_verify_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__SET_VERIFY_IEC) (fbssl_ctx_set_verify_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__SET_VERIFY_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__set_verify
	#define EXT_fbssl_ctx__set_verify
	#define GET_fbssl_ctx__set_verify(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__set_verify(p0) 
	#define CHK_fbssl_ctx__set_verify  FALSE
	#define EXP_fbssl_ctx__set_verify  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__set_verify
	#define EXT_fbssl_ctx__set_verify
	#define GET_fbssl_ctx__set_verify(fl)  CAL_CMGETAPI( "fbssl_ctx__set_verify" ) 
	#define CAL_fbssl_ctx__set_verify  fbssl_ctx__set_verify
	#define CHK_fbssl_ctx__set_verify  TRUE
	#define EXP_fbssl_ctx__set_verify  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_verify", (RTS_UINTPTR)fbssl_ctx__set_verify, 1, 0xF64FD325, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__set_verify {(RTS_VOID_FCTPTR)fbssl_ctx__set_verify, "fbssl_ctx__set_verify", 0xF64FD325, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__set_verify
	#define EXT_fbssl_ctx__set_verify
	#define GET_fbssl_ctx__set_verify(fl)  CAL_CMGETAPI( "fbssl_ctx__set_verify" ) 
	#define CAL_fbssl_ctx__set_verify  fbssl_ctx__set_verify
	#define CHK_fbssl_ctx__set_verify  TRUE
	#define EXP_fbssl_ctx__set_verify  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_verify", (RTS_UINTPTR)fbssl_ctx__set_verify, 1, 0xF64FD325, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__set_verify
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__set_verify
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__set_verify  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__set_verify  fbssl_ctx__set_verify
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__set_verify  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__set_verify  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_verify", (RTS_UINTPTR)fbssl_ctx__set_verify, 1, 0xF64FD325, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__set_verify
	#define EXT_fbssl_ctx__set_verify
	#define GET_fbssl_ctx__set_verify(fl)  CAL_CMGETAPI( "fbssl_ctx__set_verify" ) 
	#define CAL_fbssl_ctx__set_verify  fbssl_ctx__set_verify
	#define CHK_fbssl_ctx__set_verify  TRUE
	#define EXP_fbssl_ctx__set_verify  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_verify", (RTS_UINTPTR)fbssl_ctx__set_verify, 1, 0xF64FD325, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__set_verify  PFFBSSL_CTX__SET_VERIFY_IEC pffbssl_ctx__set_verify;
	#define EXT_fbssl_ctx__set_verify  extern PFFBSSL_CTX__SET_VERIFY_IEC pffbssl_ctx__set_verify;
	#define GET_fbssl_ctx__set_verify(fl)  s_pfCMGetAPI2( "fbssl_ctx__set_verify", (RTS_VOID_FCTPTR *)&pffbssl_ctx__set_verify, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xF64FD325, 0x01010600)
	#define CAL_fbssl_ctx__set_verify  pffbssl_ctx__set_verify
	#define CHK_fbssl_ctx__set_verify  (pffbssl_ctx__set_verify != NULL)
	#define EXP_fbssl_ctx__set_verify   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__set_verify", (RTS_UINTPTR)fbssl_ctx__set_verify, 1, 0xF64FD325, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_use_certificate_file</description>
 */
typedef struct tagfbssl_ctx_use_certificate_file_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_STRING cfile[81];			/* VAR_INPUT */	/* path and file name */
	RTS_IEC_INT uFileType;				/* VAR_INPUT, Enum: ESSL_FILETYPE_RTS */
	RTS_IEC_UDINT use_certificate_file;	/* VAR_OUTPUT */	
} fbssl_ctx_use_certificate_file_struct;

void CDECL CDECL_EXT fbssl_ctx__use_certificate_file(fbssl_ctx_use_certificate_file_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__USE_CERTIFICATE_FILE_IEC) (fbssl_ctx_use_certificate_file_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__USE_CERTIFICATE_FILE_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__use_certificate_file
	#define EXT_fbssl_ctx__use_certificate_file
	#define GET_fbssl_ctx__use_certificate_file(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__use_certificate_file(p0) 
	#define CHK_fbssl_ctx__use_certificate_file  FALSE
	#define EXP_fbssl_ctx__use_certificate_file  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__use_certificate_file
	#define EXT_fbssl_ctx__use_certificate_file
	#define GET_fbssl_ctx__use_certificate_file(fl)  CAL_CMGETAPI( "fbssl_ctx__use_certificate_file" ) 
	#define CAL_fbssl_ctx__use_certificate_file  fbssl_ctx__use_certificate_file
	#define CHK_fbssl_ctx__use_certificate_file  TRUE
	#define EXP_fbssl_ctx__use_certificate_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_certificate_file", (RTS_UINTPTR)fbssl_ctx__use_certificate_file, 1, 0x01A01091, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__use_certificate_file {(RTS_VOID_FCTPTR)fbssl_ctx__use_certificate_file, "fbssl_ctx__use_certificate_file", 0x01A01091, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__use_certificate_file
	#define EXT_fbssl_ctx__use_certificate_file
	#define GET_fbssl_ctx__use_certificate_file(fl)  CAL_CMGETAPI( "fbssl_ctx__use_certificate_file" ) 
	#define CAL_fbssl_ctx__use_certificate_file  fbssl_ctx__use_certificate_file
	#define CHK_fbssl_ctx__use_certificate_file  TRUE
	#define EXP_fbssl_ctx__use_certificate_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_certificate_file", (RTS_UINTPTR)fbssl_ctx__use_certificate_file, 1, 0x01A01091, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__use_certificate_file
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__use_certificate_file
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__use_certificate_file  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__use_certificate_file  fbssl_ctx__use_certificate_file
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__use_certificate_file  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__use_certificate_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_certificate_file", (RTS_UINTPTR)fbssl_ctx__use_certificate_file, 1, 0x01A01091, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__use_certificate_file
	#define EXT_fbssl_ctx__use_certificate_file
	#define GET_fbssl_ctx__use_certificate_file(fl)  CAL_CMGETAPI( "fbssl_ctx__use_certificate_file" ) 
	#define CAL_fbssl_ctx__use_certificate_file  fbssl_ctx__use_certificate_file
	#define CHK_fbssl_ctx__use_certificate_file  TRUE
	#define EXP_fbssl_ctx__use_certificate_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_certificate_file", (RTS_UINTPTR)fbssl_ctx__use_certificate_file, 1, 0x01A01091, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__use_certificate_file  PFFBSSL_CTX__USE_CERTIFICATE_FILE_IEC pffbssl_ctx__use_certificate_file;
	#define EXT_fbssl_ctx__use_certificate_file  extern PFFBSSL_CTX__USE_CERTIFICATE_FILE_IEC pffbssl_ctx__use_certificate_file;
	#define GET_fbssl_ctx__use_certificate_file(fl)  s_pfCMGetAPI2( "fbssl_ctx__use_certificate_file", (RTS_VOID_FCTPTR *)&pffbssl_ctx__use_certificate_file, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x01A01091, 0x01010600)
	#define CAL_fbssl_ctx__use_certificate_file  pffbssl_ctx__use_certificate_file
	#define CHK_fbssl_ctx__use_certificate_file  (pffbssl_ctx__use_certificate_file != NULL)
	#define EXP_fbssl_ctx__use_certificate_file   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__use_certificate_file", (RTS_UINTPTR)fbssl_ctx__use_certificate_file, 1, 0x01A01091, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_main</description>
 */
typedef struct tagfbssl_ctx_main_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
} fbssl_ctx_main_struct;

void CDECL CDECL_EXT fbssl_ctx__main(fbssl_ctx_main_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__MAIN_IEC) (fbssl_ctx_main_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__MAIN_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__main
	#define EXT_fbssl_ctx__main
	#define GET_fbssl_ctx__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__main(p0) 
	#define CHK_fbssl_ctx__main  FALSE
	#define EXP_fbssl_ctx__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__main
	#define EXT_fbssl_ctx__main
	#define GET_fbssl_ctx__main(fl)  CAL_CMGETAPI( "fbssl_ctx__main" ) 
	#define CAL_fbssl_ctx__main  fbssl_ctx__main
	#define CHK_fbssl_ctx__main  TRUE
	#define EXP_fbssl_ctx__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__main", (RTS_UINTPTR)fbssl_ctx__main, 1, 0xEA57F659, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__main {(RTS_VOID_FCTPTR)fbssl_ctx__main, "fbssl_ctx__main", 0xEA57F659, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__main
	#define EXT_fbssl_ctx__main
	#define GET_fbssl_ctx__main(fl)  CAL_CMGETAPI( "fbssl_ctx__main" ) 
	#define CAL_fbssl_ctx__main  fbssl_ctx__main
	#define CHK_fbssl_ctx__main  TRUE
	#define EXP_fbssl_ctx__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__main", (RTS_UINTPTR)fbssl_ctx__main, 1, 0xEA57F659, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__main
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__main
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__main  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__main  fbssl_ctx__main
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__main  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__main", (RTS_UINTPTR)fbssl_ctx__main, 1, 0xEA57F659, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__main
	#define EXT_fbssl_ctx__main
	#define GET_fbssl_ctx__main(fl)  CAL_CMGETAPI( "fbssl_ctx__main" ) 
	#define CAL_fbssl_ctx__main  fbssl_ctx__main
	#define CHK_fbssl_ctx__main  TRUE
	#define EXP_fbssl_ctx__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__main", (RTS_UINTPTR)fbssl_ctx__main, 1, 0xEA57F659, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__main  PFFBSSL_CTX__MAIN_IEC pffbssl_ctx__main;
	#define EXT_fbssl_ctx__main  extern PFFBSSL_CTX__MAIN_IEC pffbssl_ctx__main;
	#define GET_fbssl_ctx__main(fl)  s_pfCMGetAPI2( "fbssl_ctx__main", (RTS_VOID_FCTPTR *)&pffbssl_ctx__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xEA57F659, 0x01010600)
	#define CAL_fbssl_ctx__main  pffbssl_ctx__main
	#define CHK_fbssl_ctx__main  (pffbssl_ctx__main != NULL)
	#define EXP_fbssl_ctx__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__main", (RTS_UINTPTR)fbssl_ctx__main, 1, 0xEA57F659, 0x01010600) 
#endif


/**
 * <description>fbssl_ctx_fb_init</description>
 */
typedef struct tagfbssl_ctx_fb_init_struct
{
	fbssl_ctx_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	/* bei TRUE werden die Retain-Variablen initialisiert (Warmstart / Kaltstart) */
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* bei TRUE wird die Instanz anschließend in den Copy-Code kopiert (Online Change) */
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} fbssl_ctx_fb_init_struct;

void CDECL CDECL_EXT fbssl_ctx__fb_init(fbssl_ctx_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_CTX__FB_INIT_IEC) (fbssl_ctx_fb_init_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_CTX__FB_INIT_NOTIMPLEMENTED)
	#define USE_fbssl_ctx__fb_init
	#define EXT_fbssl_ctx__fb_init
	#define GET_fbssl_ctx__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_ctx__fb_init(p0) 
	#define CHK_fbssl_ctx__fb_init  FALSE
	#define EXP_fbssl_ctx__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_ctx__fb_init
	#define EXT_fbssl_ctx__fb_init
	#define GET_fbssl_ctx__fb_init(fl)  CAL_CMGETAPI( "fbssl_ctx__fb_init" ) 
	#define CAL_fbssl_ctx__fb_init  fbssl_ctx__fb_init
	#define CHK_fbssl_ctx__fb_init  TRUE
	#define EXP_fbssl_ctx__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_init", (RTS_UINTPTR)fbssl_ctx__fb_init, 1, 0x99F4E743, 0x01010600) 
	#define EXTREF_ITF_fbssl_ctx__fb_init {(RTS_VOID_FCTPTR)fbssl_ctx__fb_init, "fbssl_ctx__fb_init", 0x99F4E743, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_ctx__fb_init
	#define EXT_fbssl_ctx__fb_init
	#define GET_fbssl_ctx__fb_init(fl)  CAL_CMGETAPI( "fbssl_ctx__fb_init" ) 
	#define CAL_fbssl_ctx__fb_init  fbssl_ctx__fb_init
	#define CHK_fbssl_ctx__fb_init  TRUE
	#define EXP_fbssl_ctx__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_init", (RTS_UINTPTR)fbssl_ctx__fb_init, 1, 0x99F4E743, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_ctx__fb_init
	#define EXT_WagoSysSSL_Internal_PFCfbssl_ctx__fb_init
	#define GET_WagoSysSSL_Internal_PFCfbssl_ctx__fb_init  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_ctx__fb_init  fbssl_ctx__fb_init
	#define CHK_WagoSysSSL_Internal_PFCfbssl_ctx__fb_init  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_ctx__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_init", (RTS_UINTPTR)fbssl_ctx__fb_init, 1, 0x99F4E743, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_ctx__fb_init
	#define EXT_fbssl_ctx__fb_init
	#define GET_fbssl_ctx__fb_init(fl)  CAL_CMGETAPI( "fbssl_ctx__fb_init" ) 
	#define CAL_fbssl_ctx__fb_init  fbssl_ctx__fb_init
	#define CHK_fbssl_ctx__fb_init  TRUE
	#define EXP_fbssl_ctx__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_init", (RTS_UINTPTR)fbssl_ctx__fb_init, 1, 0x99F4E743, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_ctx__fb_init  PFFBSSL_CTX__FB_INIT_IEC pffbssl_ctx__fb_init;
	#define EXT_fbssl_ctx__fb_init  extern PFFBSSL_CTX__FB_INIT_IEC pffbssl_ctx__fb_init;
	#define GET_fbssl_ctx__fb_init(fl)  s_pfCMGetAPI2( "fbssl_ctx__fb_init", (RTS_VOID_FCTPTR *)&pffbssl_ctx__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x99F4E743, 0x01010600)
	#define CAL_fbssl_ctx__fb_init  pffbssl_ctx__fb_init
	#define CHK_fbssl_ctx__fb_init  (pffbssl_ctx__fb_init != NULL)
	#define EXP_fbssl_ctx__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_ctx__fb_init", (RTS_UINTPTR)fbssl_ctx__fb_init, 1, 0x99F4E743, 0x01010600) 
#endif


/**
 * <description>fbssl_sock__main</description>
 */
typedef struct tagfbssl_sock_struct
{
	void* __VFTABLEPOINTER;				/* Pointer to virtual function table */

	/* Member variables of FbSSL_Sock */

	RTS_IEC_UDINT signatur;				/* Local variable */	
	RTS_IEC_UINT *pSSL;					/* Local variable */	
	fbssl_ctx_struct *pFbSSL_CTX;		/* Local variable */	
	RTS_IEC_UINT state;					/* Local variable */	
	RTS_IEC_STRING nHostName[81];		/* Local variable */	
	RTS_IEC_UDINT uHostFlags;			/* Local variable */	
	RTS_IEC_UDINT uFlags;				/* Local variable */	
	RTS_IEC_INT verify_result;			/* Local variable */	
} fbssl_sock_struct;

/**
 * <description>fbssl_sock_get0_param</description>
 */
typedef struct tagfbssl_sock_get0_param_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_LWORD get0_param;			/* VAR_OUTPUT */	
} fbssl_sock_get0_param_struct;

void CDECL CDECL_EXT fbssl_sock__get0_param(fbssl_sock_get0_param_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__GET0_PARAM_IEC) (fbssl_sock_get0_param_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__GET0_PARAM_NOTIMPLEMENTED)
	#define USE_fbssl_sock__get0_param
	#define EXT_fbssl_sock__get0_param
	#define GET_fbssl_sock__get0_param(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__get0_param(p0) 
	#define CHK_fbssl_sock__get0_param  FALSE
	#define EXP_fbssl_sock__get0_param  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__get0_param
	#define EXT_fbssl_sock__get0_param
	#define GET_fbssl_sock__get0_param(fl)  CAL_CMGETAPI( "fbssl_sock__get0_param" ) 
	#define CAL_fbssl_sock__get0_param  fbssl_sock__get0_param
	#define CHK_fbssl_sock__get0_param  TRUE
	#define EXP_fbssl_sock__get0_param  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get0_param", (RTS_UINTPTR)fbssl_sock__get0_param, 1, 0x5CE5BD47, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__get0_param {(RTS_VOID_FCTPTR)fbssl_sock__get0_param, "fbssl_sock__get0_param", 0x5CE5BD47, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__get0_param
	#define EXT_fbssl_sock__get0_param
	#define GET_fbssl_sock__get0_param(fl)  CAL_CMGETAPI( "fbssl_sock__get0_param" ) 
	#define CAL_fbssl_sock__get0_param  fbssl_sock__get0_param
	#define CHK_fbssl_sock__get0_param  TRUE
	#define EXP_fbssl_sock__get0_param  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get0_param", (RTS_UINTPTR)fbssl_sock__get0_param, 1, 0x5CE5BD47, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__get0_param
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__get0_param
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__get0_param  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__get0_param  fbssl_sock__get0_param
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__get0_param  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__get0_param  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get0_param", (RTS_UINTPTR)fbssl_sock__get0_param, 1, 0x5CE5BD47, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__get0_param
	#define EXT_fbssl_sock__get0_param
	#define GET_fbssl_sock__get0_param(fl)  CAL_CMGETAPI( "fbssl_sock__get0_param" ) 
	#define CAL_fbssl_sock__get0_param  fbssl_sock__get0_param
	#define CHK_fbssl_sock__get0_param  TRUE
	#define EXP_fbssl_sock__get0_param  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get0_param", (RTS_UINTPTR)fbssl_sock__get0_param, 1, 0x5CE5BD47, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__get0_param  PFFBSSL_SOCK__GET0_PARAM_IEC pffbssl_sock__get0_param;
	#define EXT_fbssl_sock__get0_param  extern PFFBSSL_SOCK__GET0_PARAM_IEC pffbssl_sock__get0_param;
	#define GET_fbssl_sock__get0_param(fl)  s_pfCMGetAPI2( "fbssl_sock__get0_param", (RTS_VOID_FCTPTR *)&pffbssl_sock__get0_param, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5CE5BD47, 0x01010600)
	#define CAL_fbssl_sock__get0_param  pffbssl_sock__get0_param
	#define CHK_fbssl_sock__get0_param  (pffbssl_sock__get0_param != NULL)
	#define EXP_fbssl_sock__get0_param   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get0_param", (RTS_UINTPTR)fbssl_sock__get0_param, 1, 0x5CE5BD47, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_fb_exit</description>
 */
typedef struct tagfbssl_sock_fb_exit_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* bei TRUE wird die exit-Methode aufgerufen, um die Instanz zu verlassen, die hinterher kopiert wird (Online Change). */
	RTS_IEC_BOOL FB_Exit;				/* VAR_OUTPUT */	
} fbssl_sock_fb_exit_struct;

void CDECL CDECL_EXT fbssl_sock__fb_exit(fbssl_sock_fb_exit_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__FB_EXIT_IEC) (fbssl_sock_fb_exit_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__FB_EXIT_NOTIMPLEMENTED)
	#define USE_fbssl_sock__fb_exit
	#define EXT_fbssl_sock__fb_exit
	#define GET_fbssl_sock__fb_exit(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__fb_exit(p0) 
	#define CHK_fbssl_sock__fb_exit  FALSE
	#define EXP_fbssl_sock__fb_exit  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__fb_exit
	#define EXT_fbssl_sock__fb_exit
	#define GET_fbssl_sock__fb_exit(fl)  CAL_CMGETAPI( "fbssl_sock__fb_exit" ) 
	#define CAL_fbssl_sock__fb_exit  fbssl_sock__fb_exit
	#define CHK_fbssl_sock__fb_exit  TRUE
	#define EXP_fbssl_sock__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_exit", (RTS_UINTPTR)fbssl_sock__fb_exit, 1, 0x5E3688AE, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__fb_exit {(RTS_VOID_FCTPTR)fbssl_sock__fb_exit, "fbssl_sock__fb_exit", 0x5E3688AE, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__fb_exit
	#define EXT_fbssl_sock__fb_exit
	#define GET_fbssl_sock__fb_exit(fl)  CAL_CMGETAPI( "fbssl_sock__fb_exit" ) 
	#define CAL_fbssl_sock__fb_exit  fbssl_sock__fb_exit
	#define CHK_fbssl_sock__fb_exit  TRUE
	#define EXP_fbssl_sock__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_exit", (RTS_UINTPTR)fbssl_sock__fb_exit, 1, 0x5E3688AE, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__fb_exit
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__fb_exit
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__fb_exit  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__fb_exit  fbssl_sock__fb_exit
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__fb_exit  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_exit", (RTS_UINTPTR)fbssl_sock__fb_exit, 1, 0x5E3688AE, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__fb_exit
	#define EXT_fbssl_sock__fb_exit
	#define GET_fbssl_sock__fb_exit(fl)  CAL_CMGETAPI( "fbssl_sock__fb_exit" ) 
	#define CAL_fbssl_sock__fb_exit  fbssl_sock__fb_exit
	#define CHK_fbssl_sock__fb_exit  TRUE
	#define EXP_fbssl_sock__fb_exit  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_exit", (RTS_UINTPTR)fbssl_sock__fb_exit, 1, 0x5E3688AE, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__fb_exit  PFFBSSL_SOCK__FB_EXIT_IEC pffbssl_sock__fb_exit;
	#define EXT_fbssl_sock__fb_exit  extern PFFBSSL_SOCK__FB_EXIT_IEC pffbssl_sock__fb_exit;
	#define GET_fbssl_sock__fb_exit(fl)  s_pfCMGetAPI2( "fbssl_sock__fb_exit", (RTS_VOID_FCTPTR *)&pffbssl_sock__fb_exit, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5E3688AE, 0x01010600)
	#define CAL_fbssl_sock__fb_exit  pffbssl_sock__fb_exit
	#define CHK_fbssl_sock__fb_exit  (pffbssl_sock__fb_exit != NULL)
	#define EXP_fbssl_sock__fb_exit   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_exit", (RTS_UINTPTR)fbssl_sock__fb_exit, 1, 0x5E3688AE, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_load_client_ca_file</description>
 */
typedef struct tagfbssl_sock_load_client_ca_file_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_STRING cfile[81];			/* VAR_INPUT */	/* path and file name */
	RTS_IEC_INT uFileType;				/* VAR_INPUT, Enum: ESSL_FILETYPE_RTS */
	RTS_IEC_LWORD load_client_CA_file;	/* VAR_OUTPUT */	
} fbssl_sock_load_client_ca_file_struct;

void CDECL CDECL_EXT fbssl_sock__load_client_ca_file(fbssl_sock_load_client_ca_file_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__LOAD_CLIENT_CA_FILE_IEC) (fbssl_sock_load_client_ca_file_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__LOAD_CLIENT_CA_FILE_NOTIMPLEMENTED)
	#define USE_fbssl_sock__load_client_ca_file
	#define EXT_fbssl_sock__load_client_ca_file
	#define GET_fbssl_sock__load_client_ca_file(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__load_client_ca_file(p0) 
	#define CHK_fbssl_sock__load_client_ca_file  FALSE
	#define EXP_fbssl_sock__load_client_ca_file  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__load_client_ca_file
	#define EXT_fbssl_sock__load_client_ca_file
	#define GET_fbssl_sock__load_client_ca_file(fl)  CAL_CMGETAPI( "fbssl_sock__load_client_ca_file" ) 
	#define CAL_fbssl_sock__load_client_ca_file  fbssl_sock__load_client_ca_file
	#define CHK_fbssl_sock__load_client_ca_file  TRUE
	#define EXP_fbssl_sock__load_client_ca_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__load_client_ca_file", (RTS_UINTPTR)fbssl_sock__load_client_ca_file, 1, 0x1A84C0BF, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__load_client_ca_file {(RTS_VOID_FCTPTR)fbssl_sock__load_client_ca_file, "fbssl_sock__load_client_ca_file", 0x1A84C0BF, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__load_client_ca_file
	#define EXT_fbssl_sock__load_client_ca_file
	#define GET_fbssl_sock__load_client_ca_file(fl)  CAL_CMGETAPI( "fbssl_sock__load_client_ca_file" ) 
	#define CAL_fbssl_sock__load_client_ca_file  fbssl_sock__load_client_ca_file
	#define CHK_fbssl_sock__load_client_ca_file  TRUE
	#define EXP_fbssl_sock__load_client_ca_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__load_client_ca_file", (RTS_UINTPTR)fbssl_sock__load_client_ca_file, 1, 0x1A84C0BF, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__load_client_ca_file
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__load_client_ca_file
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__load_client_ca_file  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__load_client_ca_file  fbssl_sock__load_client_ca_file
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__load_client_ca_file  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__load_client_ca_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__load_client_ca_file", (RTS_UINTPTR)fbssl_sock__load_client_ca_file, 1, 0x1A84C0BF, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__load_client_ca_file
	#define EXT_fbssl_sock__load_client_ca_file
	#define GET_fbssl_sock__load_client_ca_file(fl)  CAL_CMGETAPI( "fbssl_sock__load_client_ca_file" ) 
	#define CAL_fbssl_sock__load_client_ca_file  fbssl_sock__load_client_ca_file
	#define CHK_fbssl_sock__load_client_ca_file  TRUE
	#define EXP_fbssl_sock__load_client_ca_file  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__load_client_ca_file", (RTS_UINTPTR)fbssl_sock__load_client_ca_file, 1, 0x1A84C0BF, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__load_client_ca_file  PFFBSSL_SOCK__LOAD_CLIENT_CA_FILE_IEC pffbssl_sock__load_client_ca_file;
	#define EXT_fbssl_sock__load_client_ca_file  extern PFFBSSL_SOCK__LOAD_CLIENT_CA_FILE_IEC pffbssl_sock__load_client_ca_file;
	#define GET_fbssl_sock__load_client_ca_file(fl)  s_pfCMGetAPI2( "fbssl_sock__load_client_ca_file", (RTS_VOID_FCTPTR *)&pffbssl_sock__load_client_ca_file, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1A84C0BF, 0x01010600)
	#define CAL_fbssl_sock__load_client_ca_file  pffbssl_sock__load_client_ca_file
	#define CHK_fbssl_sock__load_client_ca_file  (pffbssl_sock__load_client_ca_file != NULL)
	#define EXP_fbssl_sock__load_client_ca_file   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__load_client_ca_file", (RTS_UINTPTR)fbssl_sock__load_client_ca_file, 1, 0x1A84C0BF, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_get_error</description>
 */
typedef struct tagfbssl_sock_get_error_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_DINT sRetCode;				/* VAR_INPUT */	
	RTS_IEC_INT get_error;				/* VAR_OUTPUT, Enum: ESSL_ERROR_RTS */
} fbssl_sock_get_error_struct;

void CDECL CDECL_EXT fbssl_sock__get_error(fbssl_sock_get_error_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__GET_ERROR_IEC) (fbssl_sock_get_error_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__GET_ERROR_NOTIMPLEMENTED)
	#define USE_fbssl_sock__get_error
	#define EXT_fbssl_sock__get_error
	#define GET_fbssl_sock__get_error(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__get_error(p0) 
	#define CHK_fbssl_sock__get_error  FALSE
	#define EXP_fbssl_sock__get_error  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__get_error
	#define EXT_fbssl_sock__get_error
	#define GET_fbssl_sock__get_error(fl)  CAL_CMGETAPI( "fbssl_sock__get_error" ) 
	#define CAL_fbssl_sock__get_error  fbssl_sock__get_error
	#define CHK_fbssl_sock__get_error  TRUE
	#define EXP_fbssl_sock__get_error  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_error", (RTS_UINTPTR)fbssl_sock__get_error, 1, 0x9788B0D7, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__get_error {(RTS_VOID_FCTPTR)fbssl_sock__get_error, "fbssl_sock__get_error", 0x9788B0D7, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__get_error
	#define EXT_fbssl_sock__get_error
	#define GET_fbssl_sock__get_error(fl)  CAL_CMGETAPI( "fbssl_sock__get_error" ) 
	#define CAL_fbssl_sock__get_error  fbssl_sock__get_error
	#define CHK_fbssl_sock__get_error  TRUE
	#define EXP_fbssl_sock__get_error  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_error", (RTS_UINTPTR)fbssl_sock__get_error, 1, 0x9788B0D7, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__get_error
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__get_error
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__get_error  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__get_error  fbssl_sock__get_error
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__get_error  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__get_error  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_error", (RTS_UINTPTR)fbssl_sock__get_error, 1, 0x9788B0D7, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__get_error
	#define EXT_fbssl_sock__get_error
	#define GET_fbssl_sock__get_error(fl)  CAL_CMGETAPI( "fbssl_sock__get_error" ) 
	#define CAL_fbssl_sock__get_error  fbssl_sock__get_error
	#define CHK_fbssl_sock__get_error  TRUE
	#define EXP_fbssl_sock__get_error  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_error", (RTS_UINTPTR)fbssl_sock__get_error, 1, 0x9788B0D7, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__get_error  PFFBSSL_SOCK__GET_ERROR_IEC pffbssl_sock__get_error;
	#define EXT_fbssl_sock__get_error  extern PFFBSSL_SOCK__GET_ERROR_IEC pffbssl_sock__get_error;
	#define GET_fbssl_sock__get_error(fl)  s_pfCMGetAPI2( "fbssl_sock__get_error", (RTS_VOID_FCTPTR *)&pffbssl_sock__get_error, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9788B0D7, 0x01010600)
	#define CAL_fbssl_sock__get_error  pffbssl_sock__get_error
	#define CHK_fbssl_sock__get_error  (pffbssl_sock__get_error != NULL)
	#define EXP_fbssl_sock__get_error   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_error", (RTS_UINTPTR)fbssl_sock__get_error, 1, 0x9788B0D7, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_get_peer_certificate</description>
 */
typedef struct tagfbssl_sock_get_peer_certificate_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_LWORD get_peer_certificate;	/* VAR_OUTPUT */	
} fbssl_sock_get_peer_certificate_struct;

void CDECL CDECL_EXT fbssl_sock__get_peer_certificate(fbssl_sock_get_peer_certificate_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__GET_PEER_CERTIFICATE_IEC) (fbssl_sock_get_peer_certificate_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__GET_PEER_CERTIFICATE_NOTIMPLEMENTED)
	#define USE_fbssl_sock__get_peer_certificate
	#define EXT_fbssl_sock__get_peer_certificate
	#define GET_fbssl_sock__get_peer_certificate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__get_peer_certificate(p0) 
	#define CHK_fbssl_sock__get_peer_certificate  FALSE
	#define EXP_fbssl_sock__get_peer_certificate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__get_peer_certificate
	#define EXT_fbssl_sock__get_peer_certificate
	#define GET_fbssl_sock__get_peer_certificate(fl)  CAL_CMGETAPI( "fbssl_sock__get_peer_certificate" ) 
	#define CAL_fbssl_sock__get_peer_certificate  fbssl_sock__get_peer_certificate
	#define CHK_fbssl_sock__get_peer_certificate  TRUE
	#define EXP_fbssl_sock__get_peer_certificate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_peer_certificate", (RTS_UINTPTR)fbssl_sock__get_peer_certificate, 1, 0x6E878F93, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__get_peer_certificate {(RTS_VOID_FCTPTR)fbssl_sock__get_peer_certificate, "fbssl_sock__get_peer_certificate", 0x6E878F93, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__get_peer_certificate
	#define EXT_fbssl_sock__get_peer_certificate
	#define GET_fbssl_sock__get_peer_certificate(fl)  CAL_CMGETAPI( "fbssl_sock__get_peer_certificate" ) 
	#define CAL_fbssl_sock__get_peer_certificate  fbssl_sock__get_peer_certificate
	#define CHK_fbssl_sock__get_peer_certificate  TRUE
	#define EXP_fbssl_sock__get_peer_certificate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_peer_certificate", (RTS_UINTPTR)fbssl_sock__get_peer_certificate, 1, 0x6E878F93, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__get_peer_certificate
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__get_peer_certificate
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__get_peer_certificate  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__get_peer_certificate  fbssl_sock__get_peer_certificate
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__get_peer_certificate  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__get_peer_certificate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_peer_certificate", (RTS_UINTPTR)fbssl_sock__get_peer_certificate, 1, 0x6E878F93, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__get_peer_certificate
	#define EXT_fbssl_sock__get_peer_certificate
	#define GET_fbssl_sock__get_peer_certificate(fl)  CAL_CMGETAPI( "fbssl_sock__get_peer_certificate" ) 
	#define CAL_fbssl_sock__get_peer_certificate  fbssl_sock__get_peer_certificate
	#define CHK_fbssl_sock__get_peer_certificate  TRUE
	#define EXP_fbssl_sock__get_peer_certificate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_peer_certificate", (RTS_UINTPTR)fbssl_sock__get_peer_certificate, 1, 0x6E878F93, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__get_peer_certificate  PFFBSSL_SOCK__GET_PEER_CERTIFICATE_IEC pffbssl_sock__get_peer_certificate;
	#define EXT_fbssl_sock__get_peer_certificate  extern PFFBSSL_SOCK__GET_PEER_CERTIFICATE_IEC pffbssl_sock__get_peer_certificate;
	#define GET_fbssl_sock__get_peer_certificate(fl)  s_pfCMGetAPI2( "fbssl_sock__get_peer_certificate", (RTS_VOID_FCTPTR *)&pffbssl_sock__get_peer_certificate, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6E878F93, 0x01010600)
	#define CAL_fbssl_sock__get_peer_certificate  pffbssl_sock__get_peer_certificate
	#define CHK_fbssl_sock__get_peer_certificate  (pffbssl_sock__get_peer_certificate != NULL)
	#define EXP_fbssl_sock__get_peer_certificate   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_peer_certificate", (RTS_UINTPTR)fbssl_sock__get_peer_certificate, 1, 0x6E878F93, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_write</description>
 */
typedef struct tagfbssl_sock_write_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BYTE *pBuffer;				/* VAR_INPUT */	/* Address of buffer to send */
	RTS_IEC_DINT uSize;					/* VAR_INPUT */	/* maximum size of data in byte to receive */
	RTS_IEC_DINT write;					/* VAR_OUTPUT */	
} fbssl_sock_write_struct;

void CDECL CDECL_EXT fbssl_sock__write(fbssl_sock_write_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__WRITE_IEC) (fbssl_sock_write_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__WRITE_NOTIMPLEMENTED)
	#define USE_fbssl_sock__write
	#define EXT_fbssl_sock__write
	#define GET_fbssl_sock__write(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__write(p0) 
	#define CHK_fbssl_sock__write  FALSE
	#define EXP_fbssl_sock__write  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__write
	#define EXT_fbssl_sock__write
	#define GET_fbssl_sock__write(fl)  CAL_CMGETAPI( "fbssl_sock__write" ) 
	#define CAL_fbssl_sock__write  fbssl_sock__write
	#define CHK_fbssl_sock__write  TRUE
	#define EXP_fbssl_sock__write  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__write", (RTS_UINTPTR)fbssl_sock__write, 1, 0x468D88E5, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__write {(RTS_VOID_FCTPTR)fbssl_sock__write, "fbssl_sock__write", 0x468D88E5, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__write
	#define EXT_fbssl_sock__write
	#define GET_fbssl_sock__write(fl)  CAL_CMGETAPI( "fbssl_sock__write" ) 
	#define CAL_fbssl_sock__write  fbssl_sock__write
	#define CHK_fbssl_sock__write  TRUE
	#define EXP_fbssl_sock__write  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__write", (RTS_UINTPTR)fbssl_sock__write, 1, 0x468D88E5, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__write
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__write
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__write  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__write  fbssl_sock__write
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__write  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__write  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__write", (RTS_UINTPTR)fbssl_sock__write, 1, 0x468D88E5, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__write
	#define EXT_fbssl_sock__write
	#define GET_fbssl_sock__write(fl)  CAL_CMGETAPI( "fbssl_sock__write" ) 
	#define CAL_fbssl_sock__write  fbssl_sock__write
	#define CHK_fbssl_sock__write  TRUE
	#define EXP_fbssl_sock__write  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__write", (RTS_UINTPTR)fbssl_sock__write, 1, 0x468D88E5, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__write  PFFBSSL_SOCK__WRITE_IEC pffbssl_sock__write;
	#define EXT_fbssl_sock__write  extern PFFBSSL_SOCK__WRITE_IEC pffbssl_sock__write;
	#define GET_fbssl_sock__write(fl)  s_pfCMGetAPI2( "fbssl_sock__write", (RTS_VOID_FCTPTR *)&pffbssl_sock__write, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x468D88E5, 0x01010600)
	#define CAL_fbssl_sock__write  pffbssl_sock__write
	#define CHK_fbssl_sock__write  (pffbssl_sock__write != NULL)
	#define EXP_fbssl_sock__write   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__write", (RTS_UINTPTR)fbssl_sock__write, 1, 0x468D88E5, 0x01010600) 
#endif


/**
 *
 *SSL_Hndshk_Accept initiates the actual SSL communication. Once this function returns,
 *SSL_Socket will be filled in according to the template structure hCtx, and is specific to
 *this SSL session.
 *The application is now able to perform secure communications.
 *!!WARNING!!
 *This function may take a couple of seconds to complete. So do not use this functionality in high-priority
 *tasks with small timeout values.
 *
 *Returns:
 *<0 = Error call "get_error()" for more information. Connection still activ
 *0 = funtion fail call "get_error()" for more information 
 *1 = success
 *
 */
typedef struct tagfbssl_sock_handshake_accept_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_HANDLE hSysSock;			/* VAR_INPUT */	/* Handle of SysSocket */
	fbssl_ctx_struct *pFbSSL_CTX;		/* VAR_INPUT */	/* Handle of tls channel */
	RTS_IEC_DINT handshake_accept;		/* VAR_OUTPUT */	
} fbssl_sock_handshake_accept_struct;

void CDECL CDECL_EXT fbssl_sock__handshake_accept(fbssl_sock_handshake_accept_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__HANDSHAKE_ACCEPT_IEC) (fbssl_sock_handshake_accept_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__HANDSHAKE_ACCEPT_NOTIMPLEMENTED)
	#define USE_fbssl_sock__handshake_accept
	#define EXT_fbssl_sock__handshake_accept
	#define GET_fbssl_sock__handshake_accept(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__handshake_accept(p0) 
	#define CHK_fbssl_sock__handshake_accept  FALSE
	#define EXP_fbssl_sock__handshake_accept  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__handshake_accept
	#define EXT_fbssl_sock__handshake_accept
	#define GET_fbssl_sock__handshake_accept(fl)  CAL_CMGETAPI( "fbssl_sock__handshake_accept" ) 
	#define CAL_fbssl_sock__handshake_accept  fbssl_sock__handshake_accept
	#define CHK_fbssl_sock__handshake_accept  TRUE
	#define EXP_fbssl_sock__handshake_accept  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_accept", (RTS_UINTPTR)fbssl_sock__handshake_accept, 1, 0xEDA7626A, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__handshake_accept {(RTS_VOID_FCTPTR)fbssl_sock__handshake_accept, "fbssl_sock__handshake_accept", 0xEDA7626A, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__handshake_accept
	#define EXT_fbssl_sock__handshake_accept
	#define GET_fbssl_sock__handshake_accept(fl)  CAL_CMGETAPI( "fbssl_sock__handshake_accept" ) 
	#define CAL_fbssl_sock__handshake_accept  fbssl_sock__handshake_accept
	#define CHK_fbssl_sock__handshake_accept  TRUE
	#define EXP_fbssl_sock__handshake_accept  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_accept", (RTS_UINTPTR)fbssl_sock__handshake_accept, 1, 0xEDA7626A, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__handshake_accept
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__handshake_accept
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__handshake_accept  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__handshake_accept  fbssl_sock__handshake_accept
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__handshake_accept  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__handshake_accept  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_accept", (RTS_UINTPTR)fbssl_sock__handshake_accept, 1, 0xEDA7626A, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__handshake_accept
	#define EXT_fbssl_sock__handshake_accept
	#define GET_fbssl_sock__handshake_accept(fl)  CAL_CMGETAPI( "fbssl_sock__handshake_accept" ) 
	#define CAL_fbssl_sock__handshake_accept  fbssl_sock__handshake_accept
	#define CHK_fbssl_sock__handshake_accept  TRUE
	#define EXP_fbssl_sock__handshake_accept  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_accept", (RTS_UINTPTR)fbssl_sock__handshake_accept, 1, 0xEDA7626A, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__handshake_accept  PFFBSSL_SOCK__HANDSHAKE_ACCEPT_IEC pffbssl_sock__handshake_accept;
	#define EXT_fbssl_sock__handshake_accept  extern PFFBSSL_SOCK__HANDSHAKE_ACCEPT_IEC pffbssl_sock__handshake_accept;
	#define GET_fbssl_sock__handshake_accept(fl)  s_pfCMGetAPI2( "fbssl_sock__handshake_accept", (RTS_VOID_FCTPTR *)&pffbssl_sock__handshake_accept, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xEDA7626A, 0x01010600)
	#define CAL_fbssl_sock__handshake_accept  pffbssl_sock__handshake_accept
	#define CHK_fbssl_sock__handshake_accept  (pffbssl_sock__handshake_accept != NULL)
	#define EXP_fbssl_sock__handshake_accept   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_accept", (RTS_UINTPTR)fbssl_sock__handshake_accept, 1, 0xEDA7626A, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_get_verify_result</description>
 */
typedef struct tagfbssl_sock_get_verify_result_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_INT get_verify_result;		/* VAR_OUTPUT, Enum: ESSL_X509_V_RTS */
} fbssl_sock_get_verify_result_struct;

void CDECL CDECL_EXT fbssl_sock__get_verify_result(fbssl_sock_get_verify_result_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__GET_VERIFY_RESULT_IEC) (fbssl_sock_get_verify_result_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__GET_VERIFY_RESULT_NOTIMPLEMENTED)
	#define USE_fbssl_sock__get_verify_result
	#define EXT_fbssl_sock__get_verify_result
	#define GET_fbssl_sock__get_verify_result(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__get_verify_result(p0) 
	#define CHK_fbssl_sock__get_verify_result  FALSE
	#define EXP_fbssl_sock__get_verify_result  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__get_verify_result
	#define EXT_fbssl_sock__get_verify_result
	#define GET_fbssl_sock__get_verify_result(fl)  CAL_CMGETAPI( "fbssl_sock__get_verify_result" ) 
	#define CAL_fbssl_sock__get_verify_result  fbssl_sock__get_verify_result
	#define CHK_fbssl_sock__get_verify_result  TRUE
	#define EXP_fbssl_sock__get_verify_result  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_verify_result", (RTS_UINTPTR)fbssl_sock__get_verify_result, 1, 0xCA796872, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__get_verify_result {(RTS_VOID_FCTPTR)fbssl_sock__get_verify_result, "fbssl_sock__get_verify_result", 0xCA796872, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__get_verify_result
	#define EXT_fbssl_sock__get_verify_result
	#define GET_fbssl_sock__get_verify_result(fl)  CAL_CMGETAPI( "fbssl_sock__get_verify_result" ) 
	#define CAL_fbssl_sock__get_verify_result  fbssl_sock__get_verify_result
	#define CHK_fbssl_sock__get_verify_result  TRUE
	#define EXP_fbssl_sock__get_verify_result  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_verify_result", (RTS_UINTPTR)fbssl_sock__get_verify_result, 1, 0xCA796872, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__get_verify_result
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__get_verify_result
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__get_verify_result  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__get_verify_result  fbssl_sock__get_verify_result
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__get_verify_result  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__get_verify_result  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_verify_result", (RTS_UINTPTR)fbssl_sock__get_verify_result, 1, 0xCA796872, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__get_verify_result
	#define EXT_fbssl_sock__get_verify_result
	#define GET_fbssl_sock__get_verify_result(fl)  CAL_CMGETAPI( "fbssl_sock__get_verify_result" ) 
	#define CAL_fbssl_sock__get_verify_result  fbssl_sock__get_verify_result
	#define CHK_fbssl_sock__get_verify_result  TRUE
	#define EXP_fbssl_sock__get_verify_result  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_verify_result", (RTS_UINTPTR)fbssl_sock__get_verify_result, 1, 0xCA796872, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__get_verify_result  PFFBSSL_SOCK__GET_VERIFY_RESULT_IEC pffbssl_sock__get_verify_result;
	#define EXT_fbssl_sock__get_verify_result  extern PFFBSSL_SOCK__GET_VERIFY_RESULT_IEC pffbssl_sock__get_verify_result;
	#define GET_fbssl_sock__get_verify_result(fl)  s_pfCMGetAPI2( "fbssl_sock__get_verify_result", (RTS_VOID_FCTPTR *)&pffbssl_sock__get_verify_result, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCA796872, 0x01010600)
	#define CAL_fbssl_sock__get_verify_result  pffbssl_sock__get_verify_result
	#define CHK_fbssl_sock__get_verify_result  (pffbssl_sock__get_verify_result != NULL)
	#define EXP_fbssl_sock__get_verify_result   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__get_verify_result", (RTS_UINTPTR)fbssl_sock__get_verify_result, 1, 0xCA796872, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_shutdown</description>
 */
typedef struct tagfbssl_sock_shutdown_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_DINT shutdown;				/* VAR_OUTPUT */	
} fbssl_sock_shutdown_struct;

void CDECL CDECL_EXT fbssl_sock__shutdown(fbssl_sock_shutdown_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__SHUTDOWN_IEC) (fbssl_sock_shutdown_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__SHUTDOWN_NOTIMPLEMENTED)
	#define USE_fbssl_sock__shutdown
	#define EXT_fbssl_sock__shutdown
	#define GET_fbssl_sock__shutdown(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__shutdown(p0) 
	#define CHK_fbssl_sock__shutdown  FALSE
	#define EXP_fbssl_sock__shutdown  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__shutdown
	#define EXT_fbssl_sock__shutdown
	#define GET_fbssl_sock__shutdown(fl)  CAL_CMGETAPI( "fbssl_sock__shutdown" ) 
	#define CAL_fbssl_sock__shutdown  fbssl_sock__shutdown
	#define CHK_fbssl_sock__shutdown  TRUE
	#define EXP_fbssl_sock__shutdown  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__shutdown", (RTS_UINTPTR)fbssl_sock__shutdown, 1, 0x1656CD85, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__shutdown {(RTS_VOID_FCTPTR)fbssl_sock__shutdown, "fbssl_sock__shutdown", 0x1656CD85, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__shutdown
	#define EXT_fbssl_sock__shutdown
	#define GET_fbssl_sock__shutdown(fl)  CAL_CMGETAPI( "fbssl_sock__shutdown" ) 
	#define CAL_fbssl_sock__shutdown  fbssl_sock__shutdown
	#define CHK_fbssl_sock__shutdown  TRUE
	#define EXP_fbssl_sock__shutdown  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__shutdown", (RTS_UINTPTR)fbssl_sock__shutdown, 1, 0x1656CD85, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__shutdown
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__shutdown
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__shutdown  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__shutdown  fbssl_sock__shutdown
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__shutdown  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__shutdown  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__shutdown", (RTS_UINTPTR)fbssl_sock__shutdown, 1, 0x1656CD85, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__shutdown
	#define EXT_fbssl_sock__shutdown
	#define GET_fbssl_sock__shutdown(fl)  CAL_CMGETAPI( "fbssl_sock__shutdown" ) 
	#define CAL_fbssl_sock__shutdown  fbssl_sock__shutdown
	#define CHK_fbssl_sock__shutdown  TRUE
	#define EXP_fbssl_sock__shutdown  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__shutdown", (RTS_UINTPTR)fbssl_sock__shutdown, 1, 0x1656CD85, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__shutdown  PFFBSSL_SOCK__SHUTDOWN_IEC pffbssl_sock__shutdown;
	#define EXT_fbssl_sock__shutdown  extern PFFBSSL_SOCK__SHUTDOWN_IEC pffbssl_sock__shutdown;
	#define GET_fbssl_sock__shutdown(fl)  s_pfCMGetAPI2( "fbssl_sock__shutdown", (RTS_VOID_FCTPTR *)&pffbssl_sock__shutdown, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1656CD85, 0x01010600)
	#define CAL_fbssl_sock__shutdown  pffbssl_sock__shutdown
	#define CHK_fbssl_sock__shutdown  (pffbssl_sock__shutdown != NULL)
	#define EXP_fbssl_sock__shutdown   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__shutdown", (RTS_UINTPTR)fbssl_sock__shutdown, 1, 0x1656CD85, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_main</description>
 */
typedef struct tagfbssl_sock_main_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
} fbssl_sock_main_struct;

void CDECL CDECL_EXT fbssl_sock__main(fbssl_sock_main_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__MAIN_IEC) (fbssl_sock_main_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__MAIN_NOTIMPLEMENTED)
	#define USE_fbssl_sock__main
	#define EXT_fbssl_sock__main
	#define GET_fbssl_sock__main(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__main(p0) 
	#define CHK_fbssl_sock__main  FALSE
	#define EXP_fbssl_sock__main  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__main
	#define EXT_fbssl_sock__main
	#define GET_fbssl_sock__main(fl)  CAL_CMGETAPI( "fbssl_sock__main" ) 
	#define CAL_fbssl_sock__main  fbssl_sock__main
	#define CHK_fbssl_sock__main  TRUE
	#define EXP_fbssl_sock__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__main", (RTS_UINTPTR)fbssl_sock__main, 1, 0xD2EC2C3A, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__main {(RTS_VOID_FCTPTR)fbssl_sock__main, "fbssl_sock__main", 0xD2EC2C3A, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__main
	#define EXT_fbssl_sock__main
	#define GET_fbssl_sock__main(fl)  CAL_CMGETAPI( "fbssl_sock__main" ) 
	#define CAL_fbssl_sock__main  fbssl_sock__main
	#define CHK_fbssl_sock__main  TRUE
	#define EXP_fbssl_sock__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__main", (RTS_UINTPTR)fbssl_sock__main, 1, 0xD2EC2C3A, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__main
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__main
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__main  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__main  fbssl_sock__main
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__main  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__main", (RTS_UINTPTR)fbssl_sock__main, 1, 0xD2EC2C3A, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__main
	#define EXT_fbssl_sock__main
	#define GET_fbssl_sock__main(fl)  CAL_CMGETAPI( "fbssl_sock__main" ) 
	#define CAL_fbssl_sock__main  fbssl_sock__main
	#define CHK_fbssl_sock__main  TRUE
	#define EXP_fbssl_sock__main  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__main", (RTS_UINTPTR)fbssl_sock__main, 1, 0xD2EC2C3A, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__main  PFFBSSL_SOCK__MAIN_IEC pffbssl_sock__main;
	#define EXT_fbssl_sock__main  extern PFFBSSL_SOCK__MAIN_IEC pffbssl_sock__main;
	#define GET_fbssl_sock__main(fl)  s_pfCMGetAPI2( "fbssl_sock__main", (RTS_VOID_FCTPTR *)&pffbssl_sock__main, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD2EC2C3A, 0x01010600)
	#define CAL_fbssl_sock__main  pffbssl_sock__main
	#define CHK_fbssl_sock__main  (pffbssl_sock__main != NULL)
	#define EXP_fbssl_sock__main   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__main", (RTS_UINTPTR)fbssl_sock__main, 1, 0xD2EC2C3A, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_fb_init</description>
 */
typedef struct tagfbssl_sock_fb_init_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BOOL bInitRetains;			/* VAR_INPUT */	/* bei TRUE werden die Retain-Variablen initialisiert (Warmstart / Kaltstart) */
	RTS_IEC_BOOL bInCopyCode;			/* VAR_INPUT */	/* bei TRUE wird die Instanz anschließend in den Copy-Code kopiert (Online Change) */
	RTS_IEC_BOOL FB_Init;				/* VAR_OUTPUT */	
} fbssl_sock_fb_init_struct;

void CDECL CDECL_EXT fbssl_sock__fb_init(fbssl_sock_fb_init_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__FB_INIT_IEC) (fbssl_sock_fb_init_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__FB_INIT_NOTIMPLEMENTED)
	#define USE_fbssl_sock__fb_init
	#define EXT_fbssl_sock__fb_init
	#define GET_fbssl_sock__fb_init(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__fb_init(p0) 
	#define CHK_fbssl_sock__fb_init  FALSE
	#define EXP_fbssl_sock__fb_init  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__fb_init
	#define EXT_fbssl_sock__fb_init
	#define GET_fbssl_sock__fb_init(fl)  CAL_CMGETAPI( "fbssl_sock__fb_init" ) 
	#define CAL_fbssl_sock__fb_init  fbssl_sock__fb_init
	#define CHK_fbssl_sock__fb_init  TRUE
	#define EXP_fbssl_sock__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_init", (RTS_UINTPTR)fbssl_sock__fb_init, 1, 0x8E908075, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__fb_init {(RTS_VOID_FCTPTR)fbssl_sock__fb_init, "fbssl_sock__fb_init", 0x8E908075, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__fb_init
	#define EXT_fbssl_sock__fb_init
	#define GET_fbssl_sock__fb_init(fl)  CAL_CMGETAPI( "fbssl_sock__fb_init" ) 
	#define CAL_fbssl_sock__fb_init  fbssl_sock__fb_init
	#define CHK_fbssl_sock__fb_init  TRUE
	#define EXP_fbssl_sock__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_init", (RTS_UINTPTR)fbssl_sock__fb_init, 1, 0x8E908075, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__fb_init
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__fb_init
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__fb_init  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__fb_init  fbssl_sock__fb_init
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__fb_init  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_init", (RTS_UINTPTR)fbssl_sock__fb_init, 1, 0x8E908075, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__fb_init
	#define EXT_fbssl_sock__fb_init
	#define GET_fbssl_sock__fb_init(fl)  CAL_CMGETAPI( "fbssl_sock__fb_init" ) 
	#define CAL_fbssl_sock__fb_init  fbssl_sock__fb_init
	#define CHK_fbssl_sock__fb_init  TRUE
	#define EXP_fbssl_sock__fb_init  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_init", (RTS_UINTPTR)fbssl_sock__fb_init, 1, 0x8E908075, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__fb_init  PFFBSSL_SOCK__FB_INIT_IEC pffbssl_sock__fb_init;
	#define EXT_fbssl_sock__fb_init  extern PFFBSSL_SOCK__FB_INIT_IEC pffbssl_sock__fb_init;
	#define GET_fbssl_sock__fb_init(fl)  s_pfCMGetAPI2( "fbssl_sock__fb_init", (RTS_VOID_FCTPTR *)&pffbssl_sock__fb_init, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8E908075, 0x01010600)
	#define CAL_fbssl_sock__fb_init  pffbssl_sock__fb_init
	#define CHK_fbssl_sock__fb_init  (pffbssl_sock__fb_init != NULL)
	#define EXP_fbssl_sock__fb_init   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__fb_init", (RTS_UINTPTR)fbssl_sock__fb_init, 1, 0x8E908075, 0x01010600) 
#endif


/**
 * <description>fbssl_sock_read</description>
 */
typedef struct tagfbssl_sock_read_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_BYTE *pBuffer;				/* VAR_INPUT */	/* Address of buffer to receive */
	RTS_IEC_DINT uSize;					/* VAR_INPUT */	/* maximum size of data in byte to receive */
	RTS_IEC_DINT read;					/* VAR_OUTPUT */	
} fbssl_sock_read_struct;

void CDECL CDECL_EXT fbssl_sock__read(fbssl_sock_read_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__READ_IEC) (fbssl_sock_read_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__READ_NOTIMPLEMENTED)
	#define USE_fbssl_sock__read
	#define EXT_fbssl_sock__read
	#define GET_fbssl_sock__read(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__read(p0) 
	#define CHK_fbssl_sock__read  FALSE
	#define EXP_fbssl_sock__read  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__read
	#define EXT_fbssl_sock__read
	#define GET_fbssl_sock__read(fl)  CAL_CMGETAPI( "fbssl_sock__read" ) 
	#define CAL_fbssl_sock__read  fbssl_sock__read
	#define CHK_fbssl_sock__read  TRUE
	#define EXP_fbssl_sock__read  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__read", (RTS_UINTPTR)fbssl_sock__read, 1, 0xD02BB28B, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__read {(RTS_VOID_FCTPTR)fbssl_sock__read, "fbssl_sock__read", 0xD02BB28B, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__read
	#define EXT_fbssl_sock__read
	#define GET_fbssl_sock__read(fl)  CAL_CMGETAPI( "fbssl_sock__read" ) 
	#define CAL_fbssl_sock__read  fbssl_sock__read
	#define CHK_fbssl_sock__read  TRUE
	#define EXP_fbssl_sock__read  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__read", (RTS_UINTPTR)fbssl_sock__read, 1, 0xD02BB28B, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__read
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__read
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__read  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__read  fbssl_sock__read
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__read  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__read  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__read", (RTS_UINTPTR)fbssl_sock__read, 1, 0xD02BB28B, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__read
	#define EXT_fbssl_sock__read
	#define GET_fbssl_sock__read(fl)  CAL_CMGETAPI( "fbssl_sock__read" ) 
	#define CAL_fbssl_sock__read  fbssl_sock__read
	#define CHK_fbssl_sock__read  TRUE
	#define EXP_fbssl_sock__read  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__read", (RTS_UINTPTR)fbssl_sock__read, 1, 0xD02BB28B, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__read  PFFBSSL_SOCK__READ_IEC pffbssl_sock__read;
	#define EXT_fbssl_sock__read  extern PFFBSSL_SOCK__READ_IEC pffbssl_sock__read;
	#define GET_fbssl_sock__read(fl)  s_pfCMGetAPI2( "fbssl_sock__read", (RTS_VOID_FCTPTR *)&pffbssl_sock__read, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD02BB28B, 0x01010600)
	#define CAL_fbssl_sock__read  pffbssl_sock__read
	#define CHK_fbssl_sock__read  (pffbssl_sock__read != NULL)
	#define EXP_fbssl_sock__read   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__read", (RTS_UINTPTR)fbssl_sock__read, 1, 0xD02BB28B, 0x01010600) 
#endif


/**
 *
 *SSL_Hndshk_Connect initiates the SSL connection. Once this function returns, SSL_Socket will
 *be filled-in according to the template structure SSL_Ctx, and is specific to this SSL
 *session.
 *!!WARNING!!
 *This function may easily take a couple of seconds to complete. So do not use this functionality in high-priority tasks 
 *with small timeout values.
 *
 *Returns:
 *<0 = Error call "get_error()" for more information. Connection still activ
 *0 = funtion fail call "get_error()" for more information 
 *1 = success
 *
 */
typedef struct tagfbssl_sock_handshake_connect_struct
{
	fbssl_sock_struct *pInstance;		/* VAR_INPUT */	
	RTS_IEC_HANDLE hSysSock;			/* VAR_INPUT */	/* Handle of SysSocket */
	fbssl_ctx_struct *pFbSSL_CTX;		/* VAR_INPUT */	/* Handle of SSL channel */
	RTS_IEC_DINT handshake_connect;		/* VAR_OUTPUT */	
} fbssl_sock_handshake_connect_struct;

void CDECL CDECL_EXT fbssl_sock__handshake_connect(fbssl_sock_handshake_connect_struct *p);
typedef void (CDECL CDECL_EXT* PFFBSSL_SOCK__HANDSHAKE_CONNECT_IEC) (fbssl_sock_handshake_connect_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FBSSL_SOCK__HANDSHAKE_CONNECT_NOTIMPLEMENTED)
	#define USE_fbssl_sock__handshake_connect
	#define EXT_fbssl_sock__handshake_connect
	#define GET_fbssl_sock__handshake_connect(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fbssl_sock__handshake_connect(p0) 
	#define CHK_fbssl_sock__handshake_connect  FALSE
	#define EXP_fbssl_sock__handshake_connect  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fbssl_sock__handshake_connect
	#define EXT_fbssl_sock__handshake_connect
	#define GET_fbssl_sock__handshake_connect(fl)  CAL_CMGETAPI( "fbssl_sock__handshake_connect" ) 
	#define CAL_fbssl_sock__handshake_connect  fbssl_sock__handshake_connect
	#define CHK_fbssl_sock__handshake_connect  TRUE
	#define EXP_fbssl_sock__handshake_connect  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_connect", (RTS_UINTPTR)fbssl_sock__handshake_connect, 1, 0x4C1748AA, 0x01010600) 
	#define EXTREF_ITF_fbssl_sock__handshake_connect {(RTS_VOID_FCTPTR)fbssl_sock__handshake_connect, "fbssl_sock__handshake_connect", 0x4C1748AA, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_fbssl_sock__handshake_connect
	#define EXT_fbssl_sock__handshake_connect
	#define GET_fbssl_sock__handshake_connect(fl)  CAL_CMGETAPI( "fbssl_sock__handshake_connect" ) 
	#define CAL_fbssl_sock__handshake_connect  fbssl_sock__handshake_connect
	#define CHK_fbssl_sock__handshake_connect  TRUE
	#define EXP_fbssl_sock__handshake_connect  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_connect", (RTS_UINTPTR)fbssl_sock__handshake_connect, 1, 0x4C1748AA, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCfbssl_sock__handshake_connect
	#define EXT_WagoSysSSL_Internal_PFCfbssl_sock__handshake_connect
	#define GET_WagoSysSSL_Internal_PFCfbssl_sock__handshake_connect  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCfbssl_sock__handshake_connect  fbssl_sock__handshake_connect
	#define CHK_WagoSysSSL_Internal_PFCfbssl_sock__handshake_connect  TRUE
	#define EXP_WagoSysSSL_Internal_PFCfbssl_sock__handshake_connect  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_connect", (RTS_UINTPTR)fbssl_sock__handshake_connect, 1, 0x4C1748AA, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_fbssl_sock__handshake_connect
	#define EXT_fbssl_sock__handshake_connect
	#define GET_fbssl_sock__handshake_connect(fl)  CAL_CMGETAPI( "fbssl_sock__handshake_connect" ) 
	#define CAL_fbssl_sock__handshake_connect  fbssl_sock__handshake_connect
	#define CHK_fbssl_sock__handshake_connect  TRUE
	#define EXP_fbssl_sock__handshake_connect  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_connect", (RTS_UINTPTR)fbssl_sock__handshake_connect, 1, 0x4C1748AA, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_fbssl_sock__handshake_connect  PFFBSSL_SOCK__HANDSHAKE_CONNECT_IEC pffbssl_sock__handshake_connect;
	#define EXT_fbssl_sock__handshake_connect  extern PFFBSSL_SOCK__HANDSHAKE_CONNECT_IEC pffbssl_sock__handshake_connect;
	#define GET_fbssl_sock__handshake_connect(fl)  s_pfCMGetAPI2( "fbssl_sock__handshake_connect", (RTS_VOID_FCTPTR *)&pffbssl_sock__handshake_connect, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x4C1748AA, 0x01010600)
	#define CAL_fbssl_sock__handshake_connect  pffbssl_sock__handshake_connect
	#define CHK_fbssl_sock__handshake_connect  (pffbssl_sock__handshake_connect != NULL)
	#define EXP_fbssl_sock__handshake_connect   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fbssl_sock__handshake_connect", (RTS_UINTPTR)fbssl_sock__handshake_connect, 1, 0x4C1748AA, 0x01010600) 
#endif


/**
 * <description>x509_free</description>
 */
typedef struct tagx509_free_struct
{
	RTS_IEC_LWORD certificate;			/* VAR_INPUT */	
	RTS_IEC_UDINT X509_free;			/* VAR_OUTPUT */	
} x509_free_struct;

void CDECL CDECL_EXT x509_free(x509_free_struct *p);
typedef void (CDECL CDECL_EXT* PFX509_FREE_IEC) (x509_free_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(X509_FREE_NOTIMPLEMENTED)
	#define USE_x509_free
	#define EXT_x509_free
	#define GET_x509_free(fl)  ERR_NOTIMPLEMENTED
	#define CAL_x509_free(p0) 
	#define CHK_x509_free  FALSE
	#define EXP_x509_free  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_x509_free
	#define EXT_x509_free
	#define GET_x509_free(fl)  CAL_CMGETAPI( "x509_free" ) 
	#define CAL_x509_free  x509_free
	#define CHK_x509_free  TRUE
	#define EXP_x509_free  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_free", (RTS_UINTPTR)x509_free, 1, 0xCAC77908, 0x01010600) 
	#define EXTREF_ITF_x509_free {(RTS_VOID_FCTPTR)x509_free, "x509_free", 0xCAC77908, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_x509_free
	#define EXT_x509_free
	#define GET_x509_free(fl)  CAL_CMGETAPI( "x509_free" ) 
	#define CAL_x509_free  x509_free
	#define CHK_x509_free  TRUE
	#define EXP_x509_free  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_free", (RTS_UINTPTR)x509_free, 1, 0xCAC77908, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCx509_free
	#define EXT_WagoSysSSL_Internal_PFCx509_free
	#define GET_WagoSysSSL_Internal_PFCx509_free  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCx509_free  x509_free
	#define CHK_WagoSysSSL_Internal_PFCx509_free  TRUE
	#define EXP_WagoSysSSL_Internal_PFCx509_free  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_free", (RTS_UINTPTR)x509_free, 1, 0xCAC77908, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_x509_free
	#define EXT_x509_free
	#define GET_x509_free(fl)  CAL_CMGETAPI( "x509_free" ) 
	#define CAL_x509_free  x509_free
	#define CHK_x509_free  TRUE
	#define EXP_x509_free  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_free", (RTS_UINTPTR)x509_free, 1, 0xCAC77908, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_x509_free  PFX509_FREE_IEC pfx509_free;
	#define EXT_x509_free  extern PFX509_FREE_IEC pfx509_free;
	#define GET_x509_free(fl)  s_pfCMGetAPI2( "x509_free", (RTS_VOID_FCTPTR *)&pfx509_free, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCAC77908, 0x01010600)
	#define CAL_x509_free  pfx509_free
	#define CHK_x509_free  (pfx509_free != NULL)
	#define EXP_x509_free   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_free", (RTS_UINTPTR)x509_free, 1, 0xCAC77908, 0x01010600) 
#endif


/**
 * <description>x509_verify_param_set_flags</description>
 */
typedef struct tagx509_verify_param_set_flags_struct
{
	RTS_IEC_LWORD param;				/* VAR_INPUT */	
	RTS_IEC_INT flags;					/* VAR_INPUT, Enum: ESSL_X509_VERIFICATION_RTS */
	RTS_IEC_UDINT X509_verify_param_set_flags;	/* VAR_OUTPUT */	
} x509_verify_param_set_flags_struct;

void CDECL CDECL_EXT x509_verify_param_set_flags(x509_verify_param_set_flags_struct *p);
typedef void (CDECL CDECL_EXT* PFX509_VERIFY_PARAM_SET_FLAGS_IEC) (x509_verify_param_set_flags_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(X509_VERIFY_PARAM_SET_FLAGS_NOTIMPLEMENTED)
	#define USE_x509_verify_param_set_flags
	#define EXT_x509_verify_param_set_flags
	#define GET_x509_verify_param_set_flags(fl)  ERR_NOTIMPLEMENTED
	#define CAL_x509_verify_param_set_flags(p0) 
	#define CHK_x509_verify_param_set_flags  FALSE
	#define EXP_x509_verify_param_set_flags  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_x509_verify_param_set_flags
	#define EXT_x509_verify_param_set_flags
	#define GET_x509_verify_param_set_flags(fl)  CAL_CMGETAPI( "x509_verify_param_set_flags" ) 
	#define CAL_x509_verify_param_set_flags  x509_verify_param_set_flags
	#define CHK_x509_verify_param_set_flags  TRUE
	#define EXP_x509_verify_param_set_flags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_flags", (RTS_UINTPTR)x509_verify_param_set_flags, 1, 0xA591157B, 0x01010600) 
	#define EXTREF_ITF_x509_verify_param_set_flags {(RTS_VOID_FCTPTR)x509_verify_param_set_flags, "x509_verify_param_set_flags", 0xA591157B, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_x509_verify_param_set_flags
	#define EXT_x509_verify_param_set_flags
	#define GET_x509_verify_param_set_flags(fl)  CAL_CMGETAPI( "x509_verify_param_set_flags" ) 
	#define CAL_x509_verify_param_set_flags  x509_verify_param_set_flags
	#define CHK_x509_verify_param_set_flags  TRUE
	#define EXP_x509_verify_param_set_flags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_flags", (RTS_UINTPTR)x509_verify_param_set_flags, 1, 0xA591157B, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCx509_verify_param_set_flags
	#define EXT_WagoSysSSL_Internal_PFCx509_verify_param_set_flags
	#define GET_WagoSysSSL_Internal_PFCx509_verify_param_set_flags  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCx509_verify_param_set_flags  x509_verify_param_set_flags
	#define CHK_WagoSysSSL_Internal_PFCx509_verify_param_set_flags  TRUE
	#define EXP_WagoSysSSL_Internal_PFCx509_verify_param_set_flags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_flags", (RTS_UINTPTR)x509_verify_param_set_flags, 1, 0xA591157B, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_x509_verify_param_set_flags
	#define EXT_x509_verify_param_set_flags
	#define GET_x509_verify_param_set_flags(fl)  CAL_CMGETAPI( "x509_verify_param_set_flags" ) 
	#define CAL_x509_verify_param_set_flags  x509_verify_param_set_flags
	#define CHK_x509_verify_param_set_flags  TRUE
	#define EXP_x509_verify_param_set_flags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_flags", (RTS_UINTPTR)x509_verify_param_set_flags, 1, 0xA591157B, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_x509_verify_param_set_flags  PFX509_VERIFY_PARAM_SET_FLAGS_IEC pfx509_verify_param_set_flags;
	#define EXT_x509_verify_param_set_flags  extern PFX509_VERIFY_PARAM_SET_FLAGS_IEC pfx509_verify_param_set_flags;
	#define GET_x509_verify_param_set_flags(fl)  s_pfCMGetAPI2( "x509_verify_param_set_flags", (RTS_VOID_FCTPTR *)&pfx509_verify_param_set_flags, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA591157B, 0x01010600)
	#define CAL_x509_verify_param_set_flags  pfx509_verify_param_set_flags
	#define CHK_x509_verify_param_set_flags  (pfx509_verify_param_set_flags != NULL)
	#define EXP_x509_verify_param_set_flags   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_flags", (RTS_UINTPTR)x509_verify_param_set_flags, 1, 0xA591157B, 0x01010600) 
#endif


/**
 * <description>x509_verify_param_set_hostflags</description>
 */
typedef struct tagx509_verify_param_set_hostflags_struct
{
	RTS_IEC_LWORD param;				/* VAR_INPUT */	
	RTS_IEC_INT flags;					/* VAR_INPUT, Enum: ESSL_X509_CHECK_RTS */
	RTS_IEC_UDINT X509_verify_param_set_hostflags;	/* VAR_OUTPUT */	
} x509_verify_param_set_hostflags_struct;

void CDECL CDECL_EXT x509_verify_param_set_hostflags(x509_verify_param_set_hostflags_struct *p);
typedef void (CDECL CDECL_EXT* PFX509_VERIFY_PARAM_SET_HOSTFLAGS_IEC) (x509_verify_param_set_hostflags_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(X509_VERIFY_PARAM_SET_HOSTFLAGS_NOTIMPLEMENTED)
	#define USE_x509_verify_param_set_hostflags
	#define EXT_x509_verify_param_set_hostflags
	#define GET_x509_verify_param_set_hostflags(fl)  ERR_NOTIMPLEMENTED
	#define CAL_x509_verify_param_set_hostflags(p0) 
	#define CHK_x509_verify_param_set_hostflags  FALSE
	#define EXP_x509_verify_param_set_hostflags  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_x509_verify_param_set_hostflags
	#define EXT_x509_verify_param_set_hostflags
	#define GET_x509_verify_param_set_hostflags(fl)  CAL_CMGETAPI( "x509_verify_param_set_hostflags" ) 
	#define CAL_x509_verify_param_set_hostflags  x509_verify_param_set_hostflags
	#define CHK_x509_verify_param_set_hostflags  TRUE
	#define EXP_x509_verify_param_set_hostflags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_hostflags", (RTS_UINTPTR)x509_verify_param_set_hostflags, 1, 0x3420D974, 0x01010600) 
	#define EXTREF_ITF_x509_verify_param_set_hostflags {(RTS_VOID_FCTPTR)x509_verify_param_set_hostflags, "x509_verify_param_set_hostflags", 0x3420D974, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_x509_verify_param_set_hostflags
	#define EXT_x509_verify_param_set_hostflags
	#define GET_x509_verify_param_set_hostflags(fl)  CAL_CMGETAPI( "x509_verify_param_set_hostflags" ) 
	#define CAL_x509_verify_param_set_hostflags  x509_verify_param_set_hostflags
	#define CHK_x509_verify_param_set_hostflags  TRUE
	#define EXP_x509_verify_param_set_hostflags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_hostflags", (RTS_UINTPTR)x509_verify_param_set_hostflags, 1, 0x3420D974, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCx509_verify_param_set_hostflags
	#define EXT_WagoSysSSL_Internal_PFCx509_verify_param_set_hostflags
	#define GET_WagoSysSSL_Internal_PFCx509_verify_param_set_hostflags  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCx509_verify_param_set_hostflags  x509_verify_param_set_hostflags
	#define CHK_WagoSysSSL_Internal_PFCx509_verify_param_set_hostflags  TRUE
	#define EXP_WagoSysSSL_Internal_PFCx509_verify_param_set_hostflags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_hostflags", (RTS_UINTPTR)x509_verify_param_set_hostflags, 1, 0x3420D974, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_x509_verify_param_set_hostflags
	#define EXT_x509_verify_param_set_hostflags
	#define GET_x509_verify_param_set_hostflags(fl)  CAL_CMGETAPI( "x509_verify_param_set_hostflags" ) 
	#define CAL_x509_verify_param_set_hostflags  x509_verify_param_set_hostflags
	#define CHK_x509_verify_param_set_hostflags  TRUE
	#define EXP_x509_verify_param_set_hostflags  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_hostflags", (RTS_UINTPTR)x509_verify_param_set_hostflags, 1, 0x3420D974, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_x509_verify_param_set_hostflags  PFX509_VERIFY_PARAM_SET_HOSTFLAGS_IEC pfx509_verify_param_set_hostflags;
	#define EXT_x509_verify_param_set_hostflags  extern PFX509_VERIFY_PARAM_SET_HOSTFLAGS_IEC pfx509_verify_param_set_hostflags;
	#define GET_x509_verify_param_set_hostflags(fl)  s_pfCMGetAPI2( "x509_verify_param_set_hostflags", (RTS_VOID_FCTPTR *)&pfx509_verify_param_set_hostflags, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3420D974, 0x01010600)
	#define CAL_x509_verify_param_set_hostflags  pfx509_verify_param_set_hostflags
	#define CHK_x509_verify_param_set_hostflags  (pfx509_verify_param_set_hostflags != NULL)
	#define EXP_x509_verify_param_set_hostflags   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set_hostflags", (RTS_UINTPTR)x509_verify_param_set_hostflags, 1, 0x3420D974, 0x01010600) 
#endif


/**
 * <description>x509_verify_param_set1_host</description>
 */
typedef struct tagx509_verify_param_set1_host_struct
{
	RTS_IEC_LWORD param;				/* VAR_INPUT */	
	RTS_IEC_STRING servername[81];		/* VAR_INPUT */	
	RTS_IEC_UDINT X509_verify_param_set1_host;	/* VAR_OUTPUT */	
} x509_verify_param_set1_host_struct;

void CDECL CDECL_EXT x509_verify_param_set1_host(x509_verify_param_set1_host_struct *p);
typedef void (CDECL CDECL_EXT* PFX509_VERIFY_PARAM_SET1_HOST_IEC) (x509_verify_param_set1_host_struct *p);
#if defined(WAGOSYSSSL_INTERNAL_PFC_NOTIMPLEMENTED) || defined(X509_VERIFY_PARAM_SET1_HOST_NOTIMPLEMENTED)
	#define USE_x509_verify_param_set1_host
	#define EXT_x509_verify_param_set1_host
	#define GET_x509_verify_param_set1_host(fl)  ERR_NOTIMPLEMENTED
	#define CAL_x509_verify_param_set1_host(p0) 
	#define CHK_x509_verify_param_set1_host  FALSE
	#define EXP_x509_verify_param_set1_host  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_x509_verify_param_set1_host
	#define EXT_x509_verify_param_set1_host
	#define GET_x509_verify_param_set1_host(fl)  CAL_CMGETAPI( "x509_verify_param_set1_host" ) 
	#define CAL_x509_verify_param_set1_host  x509_verify_param_set1_host
	#define CHK_x509_verify_param_set1_host  TRUE
	#define EXP_x509_verify_param_set1_host  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set1_host", (RTS_UINTPTR)x509_verify_param_set1_host, 1, 0x7221104E, 0x01010600) 
	#define EXTREF_ITF_x509_verify_param_set1_host {(RTS_VOID_FCTPTR)x509_verify_param_set1_host, "x509_verify_param_set1_host", 0x7221104E, 0x01010600}
#elif defined(MIXED_LINK) && !defined(WAGOSYSSSL_INTERNAL_PFC_EXTERNAL)
	#define USE_x509_verify_param_set1_host
	#define EXT_x509_verify_param_set1_host
	#define GET_x509_verify_param_set1_host(fl)  CAL_CMGETAPI( "x509_verify_param_set1_host" ) 
	#define CAL_x509_verify_param_set1_host  x509_verify_param_set1_host
	#define CHK_x509_verify_param_set1_host  TRUE
	#define EXP_x509_verify_param_set1_host  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set1_host", (RTS_UINTPTR)x509_verify_param_set1_host, 1, 0x7221104E, 0x01010600) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysSSL_Internal_PFCx509_verify_param_set1_host
	#define EXT_WagoSysSSL_Internal_PFCx509_verify_param_set1_host
	#define GET_WagoSysSSL_Internal_PFCx509_verify_param_set1_host  ERR_OK
	#define CAL_WagoSysSSL_Internal_PFCx509_verify_param_set1_host  x509_verify_param_set1_host
	#define CHK_WagoSysSSL_Internal_PFCx509_verify_param_set1_host  TRUE
	#define EXP_WagoSysSSL_Internal_PFCx509_verify_param_set1_host  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set1_host", (RTS_UINTPTR)x509_verify_param_set1_host, 1, 0x7221104E, 0x01010600) 
#elif defined(CPLUSPLUS)
	#define USE_x509_verify_param_set1_host
	#define EXT_x509_verify_param_set1_host
	#define GET_x509_verify_param_set1_host(fl)  CAL_CMGETAPI( "x509_verify_param_set1_host" ) 
	#define CAL_x509_verify_param_set1_host  x509_verify_param_set1_host
	#define CHK_x509_verify_param_set1_host  TRUE
	#define EXP_x509_verify_param_set1_host  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set1_host", (RTS_UINTPTR)x509_verify_param_set1_host, 1, 0x7221104E, 0x01010600) 
#else /* DYNAMIC_LINK */
	#define USE_x509_verify_param_set1_host  PFX509_VERIFY_PARAM_SET1_HOST_IEC pfx509_verify_param_set1_host;
	#define EXT_x509_verify_param_set1_host  extern PFX509_VERIFY_PARAM_SET1_HOST_IEC pfx509_verify_param_set1_host;
	#define GET_x509_verify_param_set1_host(fl)  s_pfCMGetAPI2( "x509_verify_param_set1_host", (RTS_VOID_FCTPTR *)&pfx509_verify_param_set1_host, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7221104E, 0x01010600)
	#define CAL_x509_verify_param_set1_host  pfx509_verify_param_set1_host
	#define CHK_x509_verify_param_set1_host  (pfx509_verify_param_set1_host != NULL)
	#define EXP_x509_verify_param_set1_host   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"x509_verify_param_set1_host", (RTS_UINTPTR)x509_verify_param_set1_host, 1, 0x7221104E, 0x01010600) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysSSL_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysSSL_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysSSL_Internal_PFC
		#define ITF_WagoSysSSL_Internal_PFC static IWagoSysSSL_Internal_PFC *pIWagoSysSSL_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysSSL_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysSSL_Internal_PFC_C		IWagoSysSSL_Internal_PFC;
	#ifndef ITF_WagoSysSSL_Internal_PFC
		#define ITF_WagoSysSSL_Internal_PFC
	#endif
	#define EXTITF_WagoSysSSL_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSSSL_INTERNAL_PFCITF_H_*/
