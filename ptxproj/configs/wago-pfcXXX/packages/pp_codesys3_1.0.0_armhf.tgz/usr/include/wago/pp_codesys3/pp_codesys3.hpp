//------------------------------------------------------------------------------
// Copyright 2020-2022 WAGO GmbH & Co. KG
//
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     pp_codesys3.hpp
///
///  \brief    Implementation of the parameter provider for e!Runtime
///
///  \author   WDt : WAGO GmbH & Co. KG
///  \author   JMu : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#pragma once
//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>
#include <wago/wdx/linuxos/file/config_file.hpp>

#include <wc/structuring.h>

#include "cfg_file_handler.hpp"

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
namespace wago {
namespace codesys3 {

using wdx::base_parameter_provider;
using wdx::parameter_selector_response;
using wdx::parameter_instance_id;
using wdx::value_response;
using wdx::value_request;
using wdx::set_parameter_response;
using wdx::parameter_value;
using wdx::method_invocation_response;

constexpr uint16_t status_code_runtime_not_active = 1;
constexpr uint16_t status_code_application_running = 2;
//------------------------------------------------------------------------------
// class definitions
//------------------------------------------------------------------------------
class pp_codesys3 final : public wdx::base_parameter_provider
{

public:
    WC_DISBALE_CLASS_COPY_ASSIGN_AND_MOVE_ASSIGN(pp_codesys3);
    explicit pp_codesys3(wdx::linuxos::file::config_file* cache_file);
    ~pp_codesys3() override = default;

    // Parameter provider interface
    parameter_selector_response get_provided_parameters() override;

    /// \copydoc ::wago::wdx::parameter_provider_i::get_parameter_values()
    wago::future<std::vector<value_response>> get_parameter_values(std::vector<parameter_instance_id> parameter_ids) override;

    /// \copydoc ::wago::wdx::parameter_provider_i::set_parameter_values()
    wago::future<std::vector<set_parameter_response>> set_parameter_values(std::vector<value_request> value_requests) override;
    
    /// \copydoc ::wago::wdx::parameter_provider_i::invoke_method()
    wago::future<wdx::method_invocation_response> invoke_method(wdx::parameter_instance_id method_id,
                                                                    std::vector<std::shared_ptr<wdx::parameter_value>> in_args) override;

    std::string display_name() override;

private:
    void get_codesys3_enabled(value_response& response);
    void get_userauthentication_enabled(value_response& response);
    void get_webserver_enabled(value_response& response);
    void get_webserver_userauthentication_enabled(value_response& response);
    void get_homedirectory(value_response& response);
    void set_codesys3_enabled(const value_request& request, set_parameter_response& response);
    void set_userauthentication_enabled(const value_request& request, set_parameter_response& response);
    void set_webserver_enabled(const value_request& request, set_parameter_response& response);
    void set_webserver_userauthentication_enabled(const value_request& request, set_parameter_response& response);
    void set_homedirectory(const value_request& request, set_parameter_response& response);
    void call_chplcconfig(const std::string&      section,
                          const std::string&      key,
                          const std::string&      value,
                          set_parameter_response& response);
    void update_cache_file(const std::string& key, const std::string& value);

    cfg_file_handler      cfg_file_m;
    wdx::linuxos::file::config_file* cache_file_m;

};

} // Namespace codesys3
} // Namespace wago

//---- End of source file ------------------------------------------------------
