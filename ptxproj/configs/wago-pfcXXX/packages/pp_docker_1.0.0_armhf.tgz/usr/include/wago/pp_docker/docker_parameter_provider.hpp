//----------------------------------------------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All manufacturing, reproduction, use and
// sales rights pertaining to this subject matter are governed by the license agreement. The recipient of this software
// implicitly accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
///---------------------------------------------------------------------------------------------------------------------
///  \file
///
///  \brief    Parameter provider for Docker settings.
///
///  \author   MWW : WAGO GmbH & Co. KG
///---------------------------------------------------------------------------------------------------------------------
#ifndef WAGO_PP_DOCKER_PARAMETER_PROVIDER_HPP_
#define WAGO_PP_DOCKER_PARAMETER_PROVIDER_HPP_

#include <wago/wdx/base_parameter_provider.hpp>

namespace wago
{
namespace pp_docker
{

/// \class docker_parameter_provider
/// \brief This parameter providers allows to access docker settings.
class docker_parameter_provider final
    : public wago::wdx::base_parameter_provider
{
public:
    docker_parameter_provider(docker_parameter_provider const &) = delete;
    docker_parameter_provider& operator=(docker_parameter_provider const &) = delete;
    docker_parameter_provider();
    ~docker_parameter_provider() override;

    std::string display_name() override;

    wago::wdx::parameter_selector_response get_provided_parameters() override;

    wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(
        std::vector<wago::wdx::parameter_instance_id> parameter_ids) override;

    wago::future<std::vector<wago::wdx::set_parameter_response>> set_parameter_values(
        std::vector<wago::wdx::value_request> value_requests) override;

private:
    class detail;
    detail *d_ptr;
};

} // namespace pp_docker
} // namespace wago

#endif // WAGO_PP_DOCKER_PARAMETER_PROVIDER_HPP_
