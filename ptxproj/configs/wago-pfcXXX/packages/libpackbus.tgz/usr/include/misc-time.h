//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    misc-time.h
///
///  \version $Revision$
///
///  \brief   Time measurement functions interface
///
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef MISC_TIME_H
#define MISC_TIME_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdint.h>
//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
#if defined __GNUC__
#define ATTRIBUTE_WEAK  __attribute__((weak))
#elif defined __arm__arm__
#define ATTRIBUTE_WEAK  __attribute__((weak))
#else
#warning "Weak linking not supported currently with this compiler!"
#define ATTRIBUTE_WEAK
#endif
#define MISC_TIME_NS_PER_SECOND  (1000000000)
#define MISC_TIME_US_PER_SECOND  (1000000)
#define MISC_TIME_MS_PER_SECOND  (1000)
//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
/// \brief Available timers
/// If more timers are needed, just add more enumeration values before
/// MISC_TIMER_COUNT. It's okay to add before or after MISC_TIMER_KBUS_TIMING.
typedef enum MISC_time_timer_id
{
  MISC_TIMER_0,           ///< Free for use
  MISC_TIMER_1,           ///< Free for use
  MISC_TIMER_2,           ///< Free for use
  MISC_TIMER_KBUS_TIMING, ///< Reserved for kbus cycle time measurement
  MISC_TIMER_COUNT
} MISC_time_timer_id_t;
//------------------------------------------------------------------------------
// Implementation
//------------------------------------------------------------------------------
int ATTRIBUTE_WEAK MISC_get_timer_stats(MISC_time_timer_id_t idx_timer,
                                        int *cur,
                                        int *min,
                                        int *max,
                                        int *avg);

int  ATTRIBUTE_WEAK MISC_get_timer_time(MISC_time_timer_id_t idx_timer);
int  ATTRIBUTE_WEAK MISC_create_timer(MISC_time_timer_id_t idx_timer);
void ATTRIBUTE_WEAK MISC_destroy_timer(MISC_time_timer_id_t idx_timer);
void ATTRIBUTE_WEAK MISC_start_timer(MISC_time_timer_id_t idx_timer);
void ATTRIBUTE_WEAK MISC_stop_timer(MISC_time_timer_id_t idx_timer);
void ATTRIBUTE_WEAK MISC_print_timer(MISC_time_timer_id_t idx_timer);
void ATTRIBUTE_WEAK MISC_log_timer(MISC_time_timer_id_t idx_timer);
#endif
