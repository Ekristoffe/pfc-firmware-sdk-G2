//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    kbus-dbus.h
///
///  \brief   API for access to the kbus via the dbus
///
///  \version  $Revision$
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef KBUS_DBUS_H
#define KBUS_DBUS_H
#include <stdbool.h>
#include <stdint.h>
#include "PTP/ptp-states.h"
//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------
#define KBUS_DBUS_PATH_KBUS_TABLE           "/wago/kbus/table"
#define KBUS_DBUS_PATH_KBUS_MODE_PI         "/wago/kbus/mode/pi"
#define KBUS_DBUS_PATH_KBUS_MODE_STATE      "/wago/kbus/mode/state"
#define KBUS_DBUS_PATH_KBUS_MODE_EXT        "/wago/kbus/mode/extension"
#define KBUS_DBUS_PATH_KBUS_STATUS          "/wago/kbus/status"
#define KBUS_DBUS_PATH_KBUS_REGISTERS       "/wago/kbus/registers"
#define KBUS_DBUS_PATH_KBUS_TIMING          "/wago/kbus/timing/interval"
#define KBUS_DBUS_PATH_TERMINALS_PI_POS     "/wago/kbus/terminals/pi/pos"
#define KBUS_DBUS_PATH_TERMINALS_PI_OFFSET  "/wago/kbus/terminals/pi/offset"
#define KBUS_DBUS_PATH_TERMINALS_DIAG       "/wago/kbus/terminals/diag"
#define KBUS_DBUS_PATH_TCM                  "/wago/kbus/tcm"
#define KBUS_DBUS_PATH_KBUS_TERM_REGISTERS  "/wago/kbus/term/registers"

#define KBUS_DBUS_NAME_KBUS             "wago.kbus"
#define KBUS_DBUS_IF_KBUS               "wago.kbus"
#define KBUS_DBUS_IF_KBUS_TABLE         "wago.kbus.table"
#define KBUS_DBUS_IF_KBUS_MODE_PI       "wago.kbus.mode.pi"
#define KBUS_DBUS_IF_KBUS_MODE_STATE    "wago.kbus.mode.state"
#define KBUS_DBUS_IF_KBUS_MODE_EXT      "wago.kbus.mode.extension"
#define KBUS_DBUS_IF_KBUS_STATUS        "wago.kbus.status"
#define KBUS_DBUS_IF_KBUS_TIMING        "wago.kbus.timing.interval"
#define KBUS_DBUS_IF_KBUS_REGISTERS     "wago.kbus.registers"


#define KBUS_DBUS_MSG_GET         "get"
#define KBUS_DBUS_MSG_GET_INFO    "getInfo"
#define KBUS_DBUS_MSG_SET         "set"
#define KBUS_DBUS_MSG_GET_CURRENT "getActual"
#define KBUS_DBUS_MSG_GET_MIN     "getMin"
#define KBUS_DBUS_MSG_GET_MAX     "getMax"
#define KBUS_DBUS_MSG_RESET       "reset"


#define DBUS_WORKER_PRIO_STD           ( 0)
#define DBUS_WORKER_PRIO_TCM_MODE      (49)
#define DBUS_WORKER_TERM_REG_COM_PRIO  ( 0)
#define DBUS_WORKER_TERM_REG_COM_NAME  "TermReg"


typedef enum KBUS_dbus_access
{
  KBUS_DBUS_INVALID,
  KBUS_DBUS_SET,
  KBUS_DBUS_GET,
  KBUS_DBUS_GET_MIN,
  KBUS_DBUS_GET_MAX,
  KBUS_DBUS_GET_INFO,
  KBUS_DBUS_RESET,
  KBUS_DBUS_LAST
} KBUS_dbus_access_t;
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// \brief Callback, when data is about to be pushed
void KBUS_dbus_pre_push(void);


/// \brief Callback, when data was pushed (received)
void KBUS_dbus_post_push(void);


/// \brief Inits the KBUS DBus module
void KBUS_dbus_init(void);


/// \brief Shut the kbus dbus module down
void KBUS_dbus_close(void);


/// \brief Call this function when the application started
void KBUS_dbus_event_app_started(void);


/// \brief Call this function when the application switches from unconfigured to stopped
void KBUS_dbus_event_app_uc2stop(void);


/// \brief Enable or disable autopush mode
/// \param[in] enable	true to enable autopush, false to disable
/// \param[in] interval_us if true, use this value for the autopush cycle time,
///                        unused when disabling autopush
void KBUS_dbus_thread_set_autopush(bool enable, unsigned int interval_us);


/// \brief checks if addressed terminal is in specific control mode TCM
///
/// \param[in]  SlotNo:   slot number of terminal to be checked
///
/// \return     status:   true:   addressed terminal is in TCM
///                       false:  else
bool KBUS_dbus_TCM_check_active( uint8_t SlotNo );


/// \brief checks if terminal specific control mode TCM is active
///
/// \return     status:   true:   TCM is active
///                       false:  else
bool KBUS_dbus_TCM_active( void );


/// \brief returns slot number of active terminal in TCM
///
/// \return       TCM is active:  slot number of terminal
///               else:           null
uint16_t KBUS_dbus_TCM_get_slot_no( void );


/// \brief compares given pointer with address of kbus dbus ptp instance
///
/// \param[in]  PtpState:   pointer to compare
///
/// \return         true:   PtpState points to kbus dbus ptp instance
///                false:   else or kbus dbus context not initialized
// Incomplete forward description
bool KBUS_dbus_IsPtpStateInst( struct PTP_state_description const * const PtpState );
#endif
