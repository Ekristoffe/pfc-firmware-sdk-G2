//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    ptp-types.h
///
///  \version $Revision$
///
///  \brief   Datatypes for the PTP mechanism
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef PTP_TYPES_H
#define PTP_TYPES_H

#include <stdint.h>
#include <stdbool.h>

/// \brief max number of active PTP - requests
#define MAX_PTP_REQUESTS       4

/// \brief max number of search iterations to find operable requests
#define MAX_NO_OF_ITERATIONS  (MAX_PTP_REQUESTS + 12)

/// \brief status of a PTP request/evaluation
typedef enum PTP_REQ_EVA_STATUS_e
{
  PTP_REQ_EVA_STATUS_OK         =  0, ///< request/evaluation OK
  PTP_REQ_EVA_GEN_ERROR         =  1, ///< unspecified internal error occurred -> see log
  PTP_REQ_EVA_WRP_ENABLED       =  2, ///< unspecified internal error occurred -> see log
  PTP_REQ_EVA_ERROR_TERM_IDX    =  3, ///< invalid terminal index / terminal not present
  PTP_REQ_EVA_NO_REGISTER_COM   =  4, ///< terminal does not support register communication
  PTP_REQ_EVA_NO_PARAMETER_CHAN =  5, ///< terminal does not support parameter channel
  PTP_REQ_EVA_ERROR_TABLE_IDX   =  6, ///< invalid table/channel index
  PTP_REQ_EVA_ERROR_REG_PAR_IDX =  7, ///< invalid register/parameter index
  PTP_REQ_EVA_ERROR_REQ_COUNT   =  8, ///< number of requested words leads to invalid register/parameter index
  PTP_REQ_EVA_ERROR_WRONG_STATE =  9, ///< new request started during ongoing request
  PTP_REQ_EVA_ERROR_TIMEOUT_PAR = 10, ///< timeout during parameter access
  PTP_REQ_EVA_ERROR_PAR_COM     = 11, ///< parameter communication error
  PTP_REQ_EVA_AA_NO_REG_RD_ACC  = 12, ///< during application is active terminal does not support register read access
  PTP_REQ_EVA_AA_NO_REG_WR_ACC  = 13, ///< during application is active terminal does not support register write access
  PTP_REQ_EVA_AA_NO_PAR_ACC     = 14, ///< during application is active terminal does not support parameter access

  PTP_REQ_EVA_INFO_CON_ACTIVE   = 18  ///< evaluation information connection is active -> poll again

} PTP_REQ_EVA_STATUS_t;

/// \brief Relevant data for a PTP request
/// The information in this structure needs to be passed to the PTP state
/// machine to start the PTP communication.
typedef struct PTP_request_header
{
  uint32_t                idx_terminal;     ///< Requested terminal
  uint32_t                idx_table;        ///< Requested table number (as in channel number)
  uint32_t                idx_register;     ///< Requested isParReq=false -> (starting)register; isParReq=true -> (starting)parameter
  uint32_t                cnt_req_words;    ///< Requested count of words/registers/parameters
  uint16_t                *buf;             ///< Ptr where to take write data from or put read data to
  uint16_t                *sts;             ///< Ptr where to write status of last parameter access
  PTP_REQ_EVA_STATUS_t    EvaSts;           ///< [out] status of request evaluation
  uint16_t                DisableWRP;       ///< value for/of register 31 to disable write protection
  bool                    isWriteRequest;   ///< Write request flag
  bool                    isParReq;         ///< TRUE: parameter request; FALSE: register/register access request
  bool                    isRegAcc;         ///< TRUE: register access request inclusive WRP handling; FALSE: register request
} PTP_request_header_t;


/// \brief Layout of the control/status register for PTP
typedef struct PTP_ctrl_bitfield
{
  uint16_t  RegNum   : 6;   ///< Register number
  uint16_t  Write    : 1;   ///< Write access
  uint16_t  RegComm  : 1;   ///< Register communication enabled flag
  uint16_t  unused1  : 8;   ///< Unused
  uint16_t  TableNum : 3;   ///< Table number (as in channel number)
  uint16_t  MuxKanal : 3;   ///< Multiplex channel
  uint16_t  unused2  : 10;  ///< Unused
} PTP_ctrl_bitfield_t;


/// \brief Grants access to the PTP control bits in word or bit format
typedef union PTP_ctrl_header
{
  uint16_t             word[2];
  PTP_ctrl_bitfield_t  bitset;
} PTP_ctrl_header_t;


/// \brief Data for the PTP communication
/// This structure contains all necessary data for an ongoing PTP communication.
typedef struct PTP_communication_data
{
  PTP_request_header_t  *req;         ///< Pointer to the request the data is based upon
  uint32_t              idx_terminal; ///< Requested terminal
  PTP_ctrl_header_t     ctrl;         ///< The control/status register bits
  uint16_t              count;        ///< The amount of registers already processed
  uint32_t              bitpos_TX;    ///< Position in bits of the TX SSC
  uint32_t              bitpos_RX;    ///< Position in bits of the RX SSC
  uint16_t              wordoffsetTX; ///< Offset in words TX
  uint16_t              wordoffsetRX; ///< Offset in words

  bool  unalignedTXwordoffset;        ///< Set to true, when the TX position is not on a word boundary
  bool  unalignedRXwordoffset;        ///< Set to true, when the RX position is not on a word boundary

  uint16_t  cur_value_RX[2];          ///< Received current value from the terminal

  uint16_t  backup_value_TX[2];       ///< TX process data before PTP was started
  uint16_t  backup_value_RX[2];       ///< RX process data before PTP was started

  uint16_t  *req_buf;                 ///< Pointer to the buffer for the request data itself
                                      ///  Data is taken from there for writes and put in there
                                      ///  for reads

  uint16_t  *tx_buf;                  ///< Pointer to the TX SSC
  uint16_t  *rx_buf;                  ///< Pointer to the RX SSC

  uint16_t  ComValue[4];

  bool  FirstRegComCycle;
  bool  RegDataXchanged;
  bool  RestoreOldProcessData;
  bool  EnablePiCycle;                ///< TRUE: alternates PTP and PI com.; FALSE: permanent PTP communication
} PTP_communication_data_t;
#endif
