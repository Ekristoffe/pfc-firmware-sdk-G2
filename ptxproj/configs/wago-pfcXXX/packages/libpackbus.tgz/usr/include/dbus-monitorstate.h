//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    dbus-monitorstate.h
///
///  \brief   API for the 'Monitor Active' state of the PTP state machine
///
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef DBUS_MONITORSTATE_H
#define DBUS_MONITORSTATE_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "dbus-states.h"
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
void DBUS_state_transitionToMonitorState(DBUS_state_ptr);
#endif
