//------------------------------------------------------------------------------
// Copyright (c) 2013-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     scpu-boot.h
///
///  \brief    Slave CPU Boot submodule.
///
///  This module capsulates the boot mechanisms for the slave cpu.
///
///  \attention This is a submodule used by the SCPU module. It is not expected
///             that any other module uses it.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef SCPU_BOOT_H
#define SCPU_BOOT_H
//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
/// The state the SCPU boot mechanism is in
/// \todo Right now not very useful
typedef enum SCPU_bootstate
{
  SCPU_BOOTSTATE_PRE_BOOT,
  SCPU_BOOTSTATE_BOOTSTRAP_HEADER,
  SCPU_BOOTSTATE_BOOTLOADER
} SCPU_boot_state_t;
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// Initializes the boot module mechanism and tries to boot the slave cpu.
int SCPU_boot_slave(void);


/// Gets the current state the boot module is in.
SCPU_boot_state_t SCPU_boot_get_state(void);


/// Resets the slave cpu module state.
/// \attention This does not reset or reboot the slave cpu itself, as the b
void SCPU_boot_reset(void);


/// Tests the boot module by trying to boot the slave cpu.
void SCPU_boot_test(void);
#endif
