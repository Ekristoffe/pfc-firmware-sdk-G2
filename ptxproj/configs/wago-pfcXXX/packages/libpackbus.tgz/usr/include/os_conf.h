//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file      os_conf.h
///
///  \brief     Configuration subsystem
///
/// The os_conf module contains a set of functions to set and retrieve configuration
/// parameters from a database. The functions are similar to the Win32 registry
/// API functions. Parameters are identified by a character string in UTF-8 format,
/// and are organized in a tree structure. The format of the database is completely
/// platform-specific. Configuration parameters may be read from, written to,
/// or deleted from the configuration database. Each parameter is identified
/// by an unique key - a character string. The parameter value may be a long
/// integer or UTF-8 string.
/// Parameter keys aren’t assigned randomly: related parameters are grouped
/// in a hierarchy (similar to X Window resources). Each level in this hierarchy
/// is named by a word, levels (words) are separated by special character
/// CONFIG_SUBLEVEL_CHAR. For example, the following keys:
/// Nl*Port_Table*Num_Entries
/// Nl*Port_Table*Entry0*Port
/// Nl*Port_Table*Entry0*Dnet
/// form hierarchy "Nl" with three sub-levels.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef OS_CONF_H
#define OS_CONF_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
//------------------------------------------------------------------------------
// Configuration
//------------------------------------------------------------------------------
/// Defines the token that indicates the hierarchy of a given key string
/// The token must be ASCII!
/// Level 0
///   |-Level 1
///       |-Level 2
/// is the key "Level 0"+CONFIG_SUBLEVEL_CHAR+"Level 1"+CONFIG_SUBLEVEL_CHAR+"Level 2"
#define CONFIG_SUBLEVEL_CHAR ((uint8_t) '*')
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// os_conf_init prepares the os_conf configuration module for usage
void os_conf_init(void);

/// os_conf_close prepares the os_conf configuration module for usage
void os_conf_close(void);

///  os_conf_read_long reads an integer value from \p key of configuration file and
///  stores it at \p value. If the key parameter does not exist in the
///  configuration file, value is set to \p default and the function succeeds.
///
///  \param   key  The parameter key to retrieve
///  \param   value  The pointer where to store the retrieved value
///  \param   defaultValue  Default value if key does not exist
///
///  \return  returns TRUE on success. If the configuration file cannot
///  be read or key refers to a parameter of type other than long integer,
///  os_conf_read_long returns FALSE. If key or value is equal to NULL,
///  os_conf_read_long returns FALSE.
bool os_conf_read_long(const uint8_t* key, long *value, long defaultValue);


///  os_conf_read_long_only reads an integer value from \p key of configuration
///  file and stores it at \p value.
///
///  \param   key  The parameter key to retrieve
///  \param   value  The pointer where to store the retrieved value
///
///  \return  returns TRUE on success.
bool os_conf_read_long_only(const uint8_t* key, long *value);


///  os_conf_write_long writes \p value as long integer parameter specified by \p key so
///  that subsequent calls to os_conf_read_long will return \p value. If the
///  configuration file already contains a parameter identified by \p key,
///  the old parameter value is overwritten.
///
///  \param   key  Parameter key to write
///  \param   value  Value of the parameter key
///
///  \return  os_conf_write_long returns TRUE on success. If the configuration file
///   cannot be read or written or key refers to an existing parameter of type
///   other than integer, os_conf_write_long returns FALSE. If key is equal to NULL,
///   os_conf_write_long returns FALSE.
bool os_conf_write_long(const uint8_t* key, long value);


///  os_conf_read_string reads the character string referred to by \p key from the
///  configuration file and stores it at \p value. The \p valueSize is a value-result
///  argument; on entrance it indicates the value size (in char units); on
///  return it will contain the actual length (also in char units and
///  including terminating ’\0’) of the string read. If \p value is NULL on
///  entrance, \p valueSize content is ignored and on return it will contain the
///  actual length of the parameter string; the string itself is not read.
///  If a parameter named \p key does not exist in the configuration file,
///  \p value is set to default and the function succeeds.
///  os_conf_read_string treats \p defaultValue set to NULL as an empty string ("").
///
///  \param         key          The parameter key to read
///  \param         value        The pointer to store the retrieved data
///  \param[in,out] valueSize    Amount of storage in bytes available for value/
///                              Amount of used bytes
///  \param         defaultValue Default value to take if key does not exist
///
///  \return  os_conf_read_string returns TRUE on success. If the configuration file
///           cannot be read or key refers to a parameter of type other than
///           character string, os_conf_read_string returns FALSE. If key or
///           valueSize is equal to NULL or key is empty (""), os_conf_read_string
///           returns FALSE. If value is not NULL, and the actual configuration
///           parameter exceeds the size specified by valueSize, the contents
///           of value and valueSize become undefined and os_conf_read_string
///           returns FALSE. If value is equal to NULL and no error occurs,
///           os_conf_read_string returns TRUE, and valueSize is valid on return.
bool os_conf_read_string(const uint8_t* key, uint8_t* value, size_t* valueSize, const uint8_t* defaultValue);


///  os_conf_read_string_only reads the character string referred to by \p key from the
///  configuration file and stores it at \p value. The \p valueSize is a value-result
///  argument; on entrance it indicates the value size (in char units); on
///  return it will contain the actual length (also in char units and
///  including terminating ’\0’) of the string read. If \p value is NULL on
///  entrance, \p valueSize content is ignored and on return it will contain the
///  actual length of the parameter string; the string itself is not read.
///  os_conf_read_string treats \p defaultValue set to NULL as an empty string ("").
///
///  \param         key          The parameter key to read
///  \param         value        The pointer to store the retrieved data
///  \param[in,out] valueSize    Amount of storage in bytes available for value/
///                              Amount of used bytes
///
///  \return  os_conf_read_string_only returns TRUE on success. If the configuration
///           file cannot be read or key refers to a parameter of type other than
///           character string, os_conf_read_string returns FALSE. If key or
///           valueSize is equal to NULL or key is empty (""), os_conf_read_string
///           returns FALSE. If value is not NULL, and the actual configuration
///           parameter exceeds the size specified by valueSize, the contents
///           of value and valueSize become undefined and os_conf_read_string
///           returns FALSE.
bool os_conf_read_string_only(const uint8_t* key, uint8_t* value, size_t* valueSize);


///  os_conf_write_string writes the \p value character string to the parameter
///  specified by \p key so that subsequent calls to os_conf_read_multi_stringstring will read
///  value. If the configuration file already contains a parameter specified
///  by \p key, it is overwritten.
///
///  \param   key    Parameter key to write
///  \param   value  Value for the parameter key
///
///  \return  returns TRUE on success. If the configuration file cannot be
///  read or written or \p key refers to an existing parameter of type other than
///  character string, OSAWriteString returns FALSE. If \p key or \p value is
///  NULL, or \p key is an empty string (""), OSAWriteString returns FALSE.
bool os_conf_write_string(const uint8_t* key, const uint8_t* value);


///  os_conf_delete_key removes from the configuration file all configuration
///  parameters whose identifiers begin with \p key.
///  In other words, os_conf_delete_key removes configuration subtree having \p key as
///  its root (that is, all existing parameters from levels equal to or lower
///  than the key level and the key level itself). The key parameter can
///  specify an individual parameter on any level. If configuration file
///  does not contain any matching parameter, the function succeeds (because
///  the goal, that the key is no longer part of the configuration, is met).
///
///  \param   key  The key hierachy to delete
///
///  \return  os_conf_delete_key returns TRUE on success. If the configuration file
///  cannot be read or written, os_conf_delete_key returns FALSE. If key is equal to
///  NULL, or key is an empty string (""), os_conf_delete_key returns FALSE.
bool os_conf_delete_key(const uint8_t* key);


///  This functions renames a parameter key or hierarchy.
///
///  \param   oldKey  The old key name
///  \param   newKey  The new key name
///
///  \return  returns TRUE if at least one key was renamed, false if no key
///           was found.
bool os_conf_rename_key(const uint8_t * oldKey, const uint8_t *newKey);


/// Retrieves the current configuration from the designated persistent storage
/// system. It depends on the platform, what this actually is.
///
/// \param[in]  bGen  true:   set configuration to default
///                   false:  do change configuration
///
/// \return           true:   valid configuration found and loaded
///                   false:  no valid configuration available
bool os_conf_load( bool bGen );


/// Stores the current configuration to the designated persistant storage system.
/// It depends on the platform, what this actually is. Changes to the configuration
/// with one of the os_conf_write functions may be lost after a power down, if
/// os_conf_save was not called.
void os_conf_save(void);


/// Execute the conf module test
void os_conf_test(void);
//------------------------------------------------------------------------------
// Lower Layer for submodules - do not use this
//------------------------------------------------------------------------------
typedef enum os_conf_type
{
  OS_CONF_TYPE_UNKNOWN,
  OS_CONF_TYPE_LONG,
  OS_CONF_TYPE_UTF8_STRING
} os_conf_type_t;

void os_conf_found_key_cb(const uint8_t *key, os_conf_type_t type, const uint8_t * value);
#endif
