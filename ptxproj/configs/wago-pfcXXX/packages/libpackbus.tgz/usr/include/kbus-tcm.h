//---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2016-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     kbus-tcm.h
///
/// \version  $Revision$
///
/// \brief    terminal specific control mode
///
/// \author   WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------
#ifndef KBUS_TCM_H_
#define KBUS_TCM_H_
//---------------------------------------------------------------------------------------------------------------------
// include files
//---------------------------------------------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>

//---------------------------------------------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//---------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------
// function prototypes
//---------------------------------------------------------------------------------------------------------------------

/// \brief switches addressed terminal in specific control mode TCM
///
/// \param[in]  SlotNo:       slot number of terminal to be checked
///
/// \return     status:   true:   addressed terminal is in TCM
///                       false:  TCM is not active
bool KBUS_tcm_dbus_activate( uint8_t SlotNo );


/// \brief switches addressed terminal in specific control mode TCM and stores last PI input values for application
///
/// param[in]  SlotNo:       slot number of terminal to be checked
///
/// return     status:   true:   addressed terminal is in TCM
///                      false:  TCM is not active
bool KBUS_tcm_dbus_activate_mode_last( uint8_t SlotNo );


/// \brief stops terminal specific control mode TCM
///
/// \return     status:   true:   TCM is stopped
///                       false:  internal error
bool KBUS_tcm_dbus_deactivate( void );
#endif /* KBUS_TCM_H_ */
