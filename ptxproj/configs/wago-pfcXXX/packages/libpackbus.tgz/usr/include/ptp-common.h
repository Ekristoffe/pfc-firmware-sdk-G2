//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    ptp-common.h
///
///  \version $Revision$
///
///  \brief   API for the common ptp functions
///
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef PTP_COMMON_H
#define PTP_COMMON_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "ptp-types.h"
#include "ptp-states.h"
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
typedef enum PTP_state_event
{
  PTP_EVENT_GET_PTP,
  PTP_EVENT_SET_PTP
} PTP_state_event_t;

void PTP_pre_push(void);
void PTP_post_push(void);

void PTP_common_add_to_callback(PTP_state_ptr state);
void PTP_common_remove_from_callback(PTP_state_ptr state);
void PTP_common_execute_callback(PTP_state_event_t event);

bool PTP_common_set_request_obsolet( PTP_state_ptr state );

bool PTP_common_rm_obsolet_request( PTP_state_ptr state );

bool PTP_common_request_to_data(PTP_request_header_t     *req,
                                PTP_communication_data_t *data);

PTP_REQ_EVA_STATUS_t ePTP_common_check_par_request( PTP_request_header_t * prReq );
PTP_REQ_EVA_STATUS_t ePTP_common_check_reg_request( PTP_request_header_t * prReq );

#endif
