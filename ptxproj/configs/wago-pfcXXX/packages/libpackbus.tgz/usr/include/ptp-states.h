//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    ptp-states.h
///
///  \version $Revision$
///
///  \brief   Main header file for the PTP state machine
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef PTP_STATES_H
#define PTP_STATES_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>
#include "ptp-types.h"
//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
// Incomplete forward description
typedef struct PTP_state_description *PTP_state_ptr;

/// This event is called, when there is a PTP request shall be handled.
typedef PTP_REQ_EVA_STATUS_t (*fnEventStartPTP)(PTP_state_ptr, PTP_request_header_t *req);

typedef void (*fnEventRestartPTP)(PTP_state_ptr);

typedef void (*fnEventEndPTP)(PTP_state_ptr);

typedef void (*fnEventSetPTP)(PTP_state_ptr);

typedef void (*fnEventGetPTP)(PTP_state_ptr);

/// \brief Supported PTP states
typedef enum PTP_state {
  PTP_STATE_PREINIT,
  PTP_STATE_IDLE,
  PTP_STATE_ACTIVE,         ///< read/write register
  PTP_STATE_CLEANUP,
  PTP_STATE_PAR_ACC,        ///< parameter access (active state)
  PTP_STATE_REG_ACC         ///< register access (active state)
} PTP_state_t;


/// \brief states of parameter access
typedef enum PTP_PAR_ACC_STATE_e
{
  PTP_PAR_ACC_STATE_INACTIVE      =  0,
  PTP_PAR_ACC_STATE_READ_WRP      =  1, ///< read  register 31
  PTP_PAR_ACC_STATE_DUMMY_RD_1    =  2, ///< read register = 31 (register != 57)
  PTP_PAR_ACC_STATE_DISABLE_WRP   =  3, ///< write register 31 (0x1235; 0xAFFE)
  PTP_PAR_ACC_STATE_READ_STATUS   =  4, ///< single read  register 57
  PTP_PAR_ACC_STATE_READ_STATUS_2 =  5, ///< single read  register 57
  PTP_PAR_ACC_STATE_DUMMY_RD_2    =  6, ///< read register = 31 (register != 57)
  PTP_PAR_ACC_STATE_WRITE_CTRL    =  7, ///< write register 57
  PTP_PAR_ACC_STATE_POLL_STATUS   =  8, ///< multiple read  register 57
  PTP_PAR_ACC_STATE_READ_DATA     =  9, ///< read register 56
  PTP_PAR_ACC_STATE_WRITE_DATA    = 10, ///< write register 56
  PTP_PAR_ACC_STATE_RESTORE_WRP   = 11, ///< restore register 31

  // do not use as PAR_ACC states! only for debug purpose defined here
  PTP_PAR_ACC_DBG_PAR_ACC_START_SINGLE_PI_CYCLE,
  PTP_PAR_ACC_DBG_PAR_ACC_STOP_SINGLE_PI_CYCLE,
  PTP_PAR_ACC_DBG_PTP_ACTIVE_SET,
  PTP_PAR_ACC_DBG_PTP_ACTIVE_GET,
  PTP_PAR_ACC_DBG_PTP_ACTIVE_RESTART,
  PTP_PAR_ACC_DBG_PTP_CLEAN_UP_SET,
  PTP_PAR_ACC_DBG_PTP_CLEAN_UP_GET,
  PTP_PAR_ACC_DBG_PTP_CLEAN_UP_END,
  PTP_PAR_ACC_DBG_PTP_PASSIVE_SET,
  PTP_PAR_ACC_DBG_PTP_PASSIVE_GET,
  PTP_REG_ACC_DBG_STATE_DUMMY_READ,
  PTP_REG_ACC_DBG_STATE_READ_WRP,
  PTP_REG_ACC_DBG_STATE_DISABLE_WRP,
  PTP_REG_ACC_DBG_STATE_REGISTER_ACCESS,
  PTP_REG_ACC_DBG_STATE_RESTORE_WRP

} PTP_PAR_ACC_STATE_t;


/// \brief data needed for parameter access
typedef struct PTP_PAR_ACC_COM_DATA
{
  PTP_PAR_ACC_STATE_t   eParAccState; ///< state of ongoing parameter access
  uint16_t *          pusReqBuf;      ///< Pointer where to take write data from or put read data to
  uint16_t *          pusStsBuf;      ///< Pointer where to write status of last parameter access
  uint16_t             usStartTime;   ///< time [ms] a single parameter access has been started
  uint16_t             usStartCount;  ///< set to zero when a single parameter access has been started
  uint16_t             usDisableWRP;  ///< value for/of register 31 to enable parameter com. / disable write protection
  uint16_t             usContReg31;   ///< current content of register 31 for restoring value
  uint16_t             usParStsWord;  ///< parameter channel register 57 (latest read access)
  uint16_t             usParCtrlWord; ///< parameter channel register 57 (latest write access)
  uint16_t             usNumberOfPar; ///< number of parameter to read/write
  uint8_t              ucParameterNo; ///< parameter number
  bool                  bWriteAccess; ///< parameter write access

} PTP_PAR_ACC_COM_DATA_t;


/// \brief data needed for register access
typedef struct PTP_REG_ACC_COM_DATA
{
//  PTP_REG_ACC_STATE_t   eRegAccState; ///< state of ongoing register access from RTS
  uint16_t *          pusReqBuf;      ///< Pointer where to take write data from or put read data to
  uint16_t             usDisableWRP;  ///< value for/of register 31 to disable write protection
  uint16_t             usContReg31;   ///< current content of register 31 for restoring value
  uint8_t              ucRegisterNo;  ///< register number
  uint8_t              ucNumberOfReg; ///< number of register to read/write
  bool                  bWriteAccess; ///< parameter write access

} PTP_REG_ACC_COM_DATA_t;


/// \brief The description of a statemachine state
typedef struct PTP_state_description
{
  PTP_state_t         state;        ///< Shows the state as an enumerated value
  const char *        statename;    ///< Shows the state as a plain text value

  fnEventStartPTP     start_ptp;    ///< Current valid function for the start ptp event
  fnEventRestartPTP   restart_ptp;  ///< Current valid function for the restart ptp event
  fnEventEndPTP       end_ptp;      ///< Current valid function for the end ptp event
  fnEventSetPTP       set_ptp;      ///< Current valid function for the set ptp event
  fnEventGetPTP       get_ptp;      ///< Current valid function for the get ptp event

  PTP_communication_data_t data;    ///< Communication data of the PTP state machine

  pthread_mutex_t  mutex;
  pthread_cond_t   done;

  PTP_PAR_ACC_COM_DATA_t  rParData; ///< Communication data for parameter access
  PTP_REG_ACC_COM_DATA_t  rRegData; ///< Communication data for register access from RTS

} PTP_state_description_t;
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
void PTP_state_wait_for_end(PTP_state_ptr state);

bool PTP_state_set_request_obsolet(PTP_state_ptr prState);

PTP_REQ_EVA_STATUS_t PTP_state_poll_req_status( PTP_state_ptr prState );

void PTP_state_init_statemachine(PTP_state_ptr state);


/// \brief The default action a state transition needs to call
/// This makes sure that when a new transition is added, old states that have no
/// clue about the new transition fall back to a defined behavior.
void PTP_state_default_action(PTP_state_ptr state);
#endif
