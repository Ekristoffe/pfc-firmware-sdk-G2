//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     ssc-parse.h
///
///  \version  $Revision$
///
///  \brief    Interface to the SSC parse methods
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef SSC_PARSE_H
#define SSC_PARSE_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "ssc-types.h"
#include "ssc-access.h"

//------------------------------------------------------------------------------
// Defines
// -----------------------------------------------------------------------------

// masks to prevent dynamic process image switch
#define MBYTE_MASK_NO_REG_COM      (0x7F) // clear bit 7 in control byte
#define MBYTE_MASK_NO_REG_NO_MBX_1 (0x5F) // clear bit 7 and bit 5 in control byte

//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
/// \brief Bitlengths of process data
typedef struct SSC_content_length
{
  uint32_t  bitlenAnalogOut;  ///< Analog output length in bits
  uint32_t  bitlenAnalogIn;   ///< Analog input length in bits
  uint32_t  bitlenDigitalOut; ///< Digital output length in bits
  uint32_t  bitlenDigitalIn;  ///< Digital input length in bits
} SSC_content_length_t;


typedef struct SSC_content_terminal_info
{
  uint32_t bitoffsetInput;
  uint32_t bitoffsetOutput;
  uint32_t bitlenInputProcessImage;
  uint32_t bitlenOutputProcessImage;
} SSC_content_terminal_info_t;
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// \brief Retrieve the bitlength of process data
/// \param[in] PabNr A secret number that you need to know.
/// \return A pointer to the length information
const SSC_content_length_t * SSC_parse_get_content_lengths(uint32_t PabNr);


/// \brief Retrieve information about terminals in a process image
/// \param[in] PabNr A secret number that you need to know.
/// \return A pointer to the terminal information
const SSC_content_terminal_info_t* SSC_parse_get_terminal_info(uint32_t PabNr);


/// \brief Reset information about terminals in a process image
/// \param[in] PabNr A secret number that you need to know.
/// \return
void SSC_parse_reset_terminal_info(uint32_t PabNr);


/// \brief Generates a copy table from an assignment list
///
/// \param[in,out]  head    Pointer to an array of copy table entries large enough to hold the expected maximum
/// \param[in]      pZuord  A list of mapping information, retrieved from GetCnfFromRail
/// \param[in]      isWrite Whether the copy table is made for write (true) or read (false) accesses
/// \return Always return 0
unsigned int SSC_generate_copy_table(SSC_copy_table_entry_t (*head)[MAX_COPY_TABLE_ENTRIES], ZUORD * pZuord, bool isWrite);


/// \brief Frees allocated memory in a copy table
///
/// \param[in,out]  head    Pointer to an array of copy table entries large enough to hold the expected maximum
/// \return Always return 0
unsigned int SSC_free_mem_in_copy_table(SSC_copy_table_entry_t (*head)[MAX_COPY_TABLE_ENTRIES]);


/// \brief Print the contents of a copy table in human readable form
/// \param[in] head Pointer to an array of copy table entries large enough to hold the expected maximum
void SSC_print_copy_table(SSC_copy_table_entry_t (*head)[MAX_COPY_TABLE_ENTRIES]);


/// \brief Print the contents of an assignment list in human readable form
/// \param[in] zuord Pointer to an assignment list
void SSC_print_zuord(ZUORD * zuord);


/// \brief  Magic function which generates an assignment list from various variables and information
///
/// \param[in]      IoType      Whether input or output data is generated
/// \param[in]      PabNr       Magic fieldbus number
/// \param[in]      ImageDesc   Process Image description to use
/// \param[in]      uiTarget    Another magic number, like the fieldbus number
/// \param[in]      TCM_SlotNo  slot number of terminal in TCM
/// \param[out]     pZuord      Pointer to enough memory to hold the generated assignment list
/// \param[out]     pulOffset   Pointer to return offset [Byte] in PI for first digital terminal
///
/// \return Always return 0
uint32_t GetCnfFromRail(uint32_t           IoType,
                        uint32_t           PabNr,
                        PROCESS_IMAGE_DESC *ImageDesc,
                        uint32_t           uiTarget,
                        uint8_t              TCM_SlotNo,
                        ZUORD              * pZuord,
                        uint32_t           * pulOffset);
#endif
