//------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     misc-threads.h
///
///  \brief    This module encapsulates thread-related helper functions.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef MISC_THREADS_H
#define MISC_THREADS_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <pthread.h>
#include <bits/local_lim.h>
#include <time.h>
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// \brief Creates a mutex for use within a subsystem
/// \param[in,out] mutex Pointer to the memory for a pthread mutex object which has not been initialized.
/// \return A pthread result code
int MISC_threads_create_lock(pthread_mutex_t *mutex);


/// \brief Creates a mutex for use within a subsystem with additional attributes
/// \param[in,out] mutex Pointer to the memory for a pthread mutex object which has not been initialized.
/// \param[in,out] mta   A pthread attribute object which must have been initialized with
///                      pthread_mutexattr_init() and needs to be cleaned up by the caller with
///                      pthread_mutexattr_destroy()
/// \return A pthread result code
int MISC_threads_create_lock_with_attributes(pthread_mutex_t     *mutex,
                                             pthread_mutexattr_t *mta);

/// \brief Acquire a lock
/// \return A pthread result code
int MISC_threads_acquire_lock(pthread_mutex_t *mutex);

/// \brief Release a lock
/// \return A pthread result code
#define MISC_threads_release_lock(mutex)  pthread_mutex_unlock(mutex)

/// \brief Destroy a lock
/// \return A pthread result code
#define MISC_threads_destroy_lock(mutex)  pthread_mutex_destroy(mutex)

/// \brief Waits a relative amount of time for a condition
/// \param[in] cond     pthread condition to use
/// \param[in] mutex    pthread mutex to use
/// \param[in] reltime  structure containing the time to wait in relative format, i.e. reltime->tv_sec = 1 for one second
/// \return A pthread result code
int MISC_threads_cond_timedwait_rel(pthread_cond_t *cond, pthread_mutex_t *mutex, struct timespec *reltime);
#endif
