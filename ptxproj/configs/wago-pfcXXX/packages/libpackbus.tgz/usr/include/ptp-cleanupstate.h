#ifndef PTP_CLEANUPSTATE
#define PTP_CLEANUPSTATE
#include "ptp-states.h"

void PTP_state_transitionToCleanupState(PTP_state_ptr state);
void cleanup_get_ptp(PTP_state_ptr state);
void cleanup_set_ptp(PTP_state_ptr state);

#endif
