//------------------------------------------------------------------------------
// Copyright (c) 2000 - 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     kbus-info.h
///
///  \version  $Revision$
///
///  \brief    Information about the KBus module
///
///  This module is the interface for information about the KBus module.
///  It implements the diagnostic access and retrieval, debug information
///  and everything else that is considered information for the user.
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef KBUS_INFO_H
#define KBUS_INFO_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#ifdef USE_DBUS
#include <diagnostic/diagnostic_API.h>
#include <diagnostic/kbusdiag.h>
#endif
#include <dal/dal_types.h>
#include <dal/sdi_stack_interface.h>
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// \brief maximum number of supported IO - modules
#define RAIL_DESC_MAX_NUMBER_OF_IO_MODULES    (250)
/// \brief number of supported IO - modules at fast KBUS communication
#define RAIL_DESC_FST_NUMBER_OF_IO_MODULES    ( 64)


/// \brief Static (build-time) assertation
/// This can be used by any module to verify conditions during build time. If the condition
/// is false, the build will fail already. The condition is limited to build time known values
/// therefore obviously. The param msg is not a string, but a single word without quotes (underlines
/// allowed as replacement for spaces)
#ifndef STATIC_ASSERT
  #define STATIC_ASSERT(condition, msg) enum{static_assertion_##msg = 1/(!!(condition))}
#endif

/// Enable to generate debug output
#define DEBUG_INFO 0 //1

/// \brief Describes the modules in the library that support debugging output
typedef enum KBUS_info_debug_module
{
  DEBUG_MODULE_NONE = 0x0000,
  DEBUG_MODULE_PTP  = 0x0001,
  DEBUG_MODULE_DBUS = 0x0002,
  DEBUG_MODULE_SSC  = 0x0004,
  DEBUG_MODULE_SCPU = 0x0008,
  DEBUG_MODULE_SPI  = 0x0010,
  DEBUG_MODULE_CONF = 0x0020,
  DEBUG_THREADING   = 0x0040,
  DEBUG_MODULE_WDG  = 0x0080,         // kbus-watchdog
} KBUS_info_module_t;

#ifndef USE_DBUS
typedef enum {
  DIAG_KBUS_FAILURE_RECOVERABLE = 1,
  DIAG_KBUS_FAILURE_RAIL_COMMUNICATION,
  DIAG_KBUS_FAILURE_RAIL_FAILED_AT,
  DIAG_KBUS_FAILURE_RAIL_TOO_LARGE,
  DIAG_KBUS_FAILURE_TERMINAL_FAILED,
  DIAG_KBUS_FAILURE_INTERNAL_LIMIT,
  DIAG_KBUS_OPERATIONAL,
  DIAG_KBUS_NOT_OPERATIONAL,
  DIAG_KBUS_BOOTING,
  DIAG_KBUS_BOOTING_END,
  DIAG_KBUS_FAILURE_UNRECOVERABLE,
  DIAG_KBUS_WDT_EXPIRED,
  DIAG_KBUS_RESET_ERROR
} log_tEventId;

void log_EVENT_Init(char *logcomp);
void log_EVENT_LogDev(int logtype, char *fmt, ...);
void log_EVENT_LogId(log_tEventId event_id, bool state);
void log_EVENT_LogIdParam(log_tEventId event_id, bool state, int type, void *param, int t2);

#define	LOG_TYPE_UINT32		1
#define	LOG_TYPE_INVALID	0

#define LOG_WARNING		1
#define LOG_DEBUG		2
#define LOG_INFO		3
#endif

/// \brief Binary OR the desired modules for debug output
#define DEBUG_OUTPUT (DEBUG_MODULE_WDG)

/// \brief Set to true to enable trace output.
#define DEBUG_TRACE   true

/// \brief helper to suppress warning caused by unused parameter
#ifndef UNUSED_PARAMETER
  #define UNUSED_PARAMETER(x) ((void)x)
#endif

#if DEBUG_INFO

#define KBUS_info_debug_trace(module)     if(DEBUG_TRACE && (module & DEBUG_OUTPUT)) log_EVENT_LogDev(LOG_DEBUG, "[TRACE] %s - %s:%d - Thread:%ld\n", __func__, __FILE__, __LINE__, pthread_self())

#define KBUS_info_debug(module, fmt, ...) if(module & DEBUG_OUTPUT) log_EVENT_LogDev(LOG_DEBUG, "[DEBUG] " fmt, ## __VA_ARGS__)

#define KBUS_info_failure(fmt, ...)       log_EVENT_LogDev(LOG_WARNING, "[FAIL] %s: " fmt, __func__, ## __VA_ARGS__)

#define KBUS_info_success(fmt, ...)       log_EVENT_LogDev(LOG_DEBUG, "[OK] %s: "  fmt, __func__, ## __VA_ARGS__)

#define KBUS_info_general(fmt, ...)       log_EVENT_LogDev(LOG_INFO,  "[INFO] " fmt, ## __VA_ARGS__)

#else

#define KBUS_info_debug_trace(module)

#define KBUS_info_debug(module, fmt, ...)

#define KBUS_info_failure(fmt, ...)  log_EVENT_LogDev(LOG_WARNING, "[FAIL] %s: " fmt, __func__, ## __VA_ARGS__)

#define KBUS_info_success(fmt, ...)

#define KBUS_info_general(fmt, ...)  log_EVENT_LogDev(LOG_INFO,  "[INFO] " fmt, ## __VA_ARGS__)

#endif

void KBUS_info_init(tDeviceId id, tDalSystemInterface *dsi);

void KBUS_info_log_error(unsigned int errorcode, unsigned int param);

void KBUS_info_log_no_error(void);

void KBUS_info_log_event_id( log_tEventId event_id );

#endif /* KBUS_INFO_H */
