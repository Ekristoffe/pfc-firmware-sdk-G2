#ifndef SPI_WAGODEV
#define SPI_WAGODEV

#include <sys/ioctl.h>
#include <stdint.h>
/// \name IOCTL codes
///@{
#define KBUS_IOC_MAGIC      'K'
#define KBUS_IOC_DATA       _IOW(KBUS_IOC_MAGIC, 1, struct kbus_data)
#define KBUS_IOC_CMD        _IOW(KBUS_IOC_MAGIC, 2, struct kbus_cmd)
#define KBUS_IOC_CONFIG     _IOW(KBUS_IOC_MAGIC, 3, struct kbus_spi_config)
#define KBUS_IOC_BINARY     _IOW(KBUS_IOC_MAGIC, 4, struct kbus_data)
///@}

/// Structure as expected by the KBUS_IOC_DATA command
struct kbus_data
{
  uint8_t  *tx_buf;     ///< Buffer to take data from.
  uint8_t  *rx_buf;     ///< Buffer to put data into
  uint32_t  byte_len;   ///< Length of data in bytes
  uint8_t  *err;        ///< Error result - these values actually have no reasonable meaning and should be ignored
  uint8_t  *err_state;  ///< Error state - these values actually have no reasonable meaning and should be ignored
  uint32_t timeout_ms;  ///< Timeout in ms for the data transfer
};


/// Structure as expected by the KBUS_IOC_CMD command
struct kbus_cmd
{
  uint8_t   *tx_buf;        ///< Buffer to take data from.
  uint8_t   *rx_buf;        ///< Buffer to put data into
  uint32_t   byte_len_tx;   ///< Length of data to send
  uint32_t   byte_len_rx;   ///< Expected length of reply
  uint8_t    *err;          ///< Error result - these values actually have no reasonable meaning and should be ignored
  uint8_t    *err_state;    ///< Error state - these values actually have no reasonable meaning and should be ignored
  uint32_t   timeout_ms;    ///< Timeout in ms for the data transfer
};


/// Structure as expected by the KBUS_IOC_CONFIG command
struct kbus_spi_config
{
  uint8_t   bits_per_word;  ///< Sets the bits per data word. This is usually 8 for a command and 16 for data
  uint8_t   mode;           ///< Sets the SPI mode. See SPI_ mode bits in spi.h
  uint32_t  max_speed_hz;   ///< Sets the desired SPI speed
};
#endif
