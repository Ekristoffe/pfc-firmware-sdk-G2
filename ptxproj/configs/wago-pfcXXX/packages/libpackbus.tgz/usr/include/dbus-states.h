//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    dbus-states.h
///
///  \brief   Main header file for the DBUS state machine
///
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef DBUS_STATES_H
#define DBUS_STATES_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdint.h>

// PTP State machine
#include "../PTP/ptp-states.h"

// Incomplete forward description
typedef struct DBUS_state_description *DBUS_state_ptr;

//------------------------------------------------------------------------------
// Events of the statemachine
//------------------------------------------------------------------------------
// Function pointers for ease of reading
typedef void (*fnEventStartControl)(DBUS_state_ptr);
typedef void (*fnEventStopControl)(DBUS_state_ptr);

typedef void (*fnEventStartMonitor)(DBUS_state_ptr);
typedef void (*fnEventStopMonitor)(DBUS_state_ptr);

typedef void (*fnEventApplicationStarted)(DBUS_state_ptr);
typedef void (*fnEventApplicationuc2stop)(DBUS_state_ptr);

typedef PTP_REQ_EVA_STATUS_t (*fnEventWriteRegister)(DBUS_state_ptr, uint32_t terminal, uint32_t table, uint32_t regnr, uint32_t cnt, uint16_t *value);
typedef PTP_REQ_EVA_STATUS_t (*fnEventReadRegister)(DBUS_state_ptr,  uint32_t terminal, uint32_t table, uint32_t regnr, uint32_t cnt, uint16_t *value);

typedef PTP_REQ_EVA_STATUS_t (*fnEventWriteParameter)(DBUS_state_ptr, uint32_t terminal, uint32_t table, uint32_t parnr, uint32_t cnt, uint16_t *value, uint16_t *status, uint16_t DisableWRP);
typedef PTP_REQ_EVA_STATUS_t (*fnEventReadParameter)(DBUS_state_ptr,  uint32_t terminal, uint32_t table, uint32_t parnr, uint32_t cnt, uint16_t *value, uint16_t *status, uint16_t DisableWRP);

typedef void (*fnEventStartTCM)(DBUS_state_ptr);
typedef void (*fnEventStopTCM)(DBUS_state_ptr);

//------------------------------------------------------------------------------
// States of the statemachine
//------------------------------------------------------------------------------
typedef enum DBUS_state
{
  DBUS_STATE_INIT,
  DBUS_STATE_DEFAULT,
  DBUS_STATE_IDLE,
  DBUS_STATE_MONITOR,
  DBUS_STATE_CONTROL,
  DBUS_STATE_TCM
} DBUS_state_t;

typedef struct TCM_ctx_data
{
  uint16_t    slotNo;
  uint16_t    enable;
  uint16_t    replaceMode;

} TCM_ctx_data_t;

//------------------------------------------------------------------------------
// The statemachine state
//------------------------------------------------------------------------------
// The description of a statemachine state
typedef struct DBUS_state_description
{
  DBUS_state_t  state;
  char          *statename;

  PTP_state_description_t     ptp;
  TCM_ctx_data_t              tcm;

  fnEventStartControl         control_start;
  fnEventStopControl          control_stop;
  fnEventStartMonitor         monitor_start;
  fnEventStopMonitor          monitor_stop;
  fnEventApplicationStarted   app_started;
  fnEventApplicationuc2stop   app_uc2stop;
  fnEventWriteRegister        write_register;
  fnEventReadRegister         read_register;
  fnEventWriteRegister        write_registerT;    /// terminal register access
  fnEventReadRegister         read_registerT;     /// terminal register access
  fnEventWriteParameter       write_parameter;
  fnEventReadParameter        read_parameter;
  fnEventStartTCM             TCM_start;
  fnEventStopTCM              TCM_stop;
} DBUS_state_description_t;


/// Inits the state machine and makes it ready for the first transition (usually to idle state)
void DBUS_state_init_statemachine(DBUS_state_ptr state);


/// The default action a state needs to call
/// This makes sure that when a new transition is added,
/// old states that have no clue about the new transition
/// fall back to a defined behavior.
void DBUS_state_default_action(DBUS_state_ptr state);

#endif
