//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     rail-info.h
///
///  \version  $Revision$
///
///  \brief    API for the RAIL info system
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
#ifndef RAIL_INFO_H
#define RAIL_INFO_H

#include <stdbool.h>

//------------------------------------------------------------------------------
// Defines
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Types
//------------------------------------------------------------------------------
typedef struct // Bestellbezeichnung der Klemme
{uint16_t  uiSeries;              // Baureihenbezeichnung
 uint16_t  uiPartNo;              // Teilenummer
 uint16_t  uiExtSeries;           // Baureihenerweiterung
 uint16_t  uiExtPartNo;           // Teilenummererweiterung
//  uint8_t aucOrderNo[16];
} T_ORDER_NO;


typedef union
{
  struct // Schieberegistereigneschaften einer komplexen Busklemme aus deren Register R10
  {uint16_t  ucSize       :  8;   // Schieberegisterlaenge der Busklemme in Bit/Byte
   uint16_t  ucCycles     :  8;   // Erforderliche Schiebezyklen
  } stShiftRegs;
  uint16_t  uiShiftRegs;
} T_R10_SHIFT_REG_DESC;


typedef union
{
  struct // Signaleigenschaften einer komplexen Busklemme aus deren Register R11
  {uint16_t  ucSize         : 8;    // Signalkanallaenge in Bit/Byte
   uint16_t  ucAmount       : 5;    // Anzahl Signalkanaele
   uint16_t  bAltFormat     : 1;    // Alternatives (TRUE), Standard- (FALSE) Mapping
   uint16_t  bAdsSupport    : 1;    // ADS wird unterstuetzt (TRUE)
   uint16_t  bNoPtpSupport  : 1;    // PTP wird nicht unterstützt
  } stSignals;
  uint16_t  uiSignals;
} T_R11_SIGNAL_DESC;


typedef union
{
  struct // Mappingvorschrift einer komplexen Busklemme aus deren Register R12
  {uint16_t  ucInpSize    : 7;    // Eingangsdatenlaenge komplexer Busklemmen in Bit/Byte
   uint16_t  bStatOpt     : 1;    // Statusbyte optional (TRUE), zwingend (FALSE)
   uint16_t  ucOutpSize   : 7;    // Ausgangsdatenlaenge komplexer Busklemmen in Bit/Byte
   uint16_t  bCtrlOpt     : 1;    // Controlbyte optional (TRUE), zwingend (FALSE)
  } stCplxProcDataDesc;
  struct // Mappingvorschrift einer binaeren Busklemme deren Klemmen-ID (T_DLT_TYPE)
  {uint16_t  ucInpSize    : 8;    // Eingangsdatenlaenge binaerer Busklemmen in Bit
   uint16_t  ucInpOffs    : 8;    // Offset der Einggangsdaten im Schieberegister der binaeren Busklemme
   uint16_t  ucOutpSize   : 8;    // Ausgangsdatenlaenge binaerer Busklemmen in Bit
   uint16_t  ucOutpOffs   : 8;    // Offset der Ausgangsdaten im Schieberegister der binaeren Busklemme
   uint16_t  ucDiagSize   : 8;    // Diagnosedatenlaenge binaerer Busklemmen in Bit
   uint16_t  ucDiagOffs   : 8;    // Offset der Diagnosedaten im Schieberegister der binaeren Busklemme
  } stBinProcDataDesc;
  uint16_t  uiProcDataDesc;
} T_R12_MAPPING_DESC;


typedef union
{
  struct // Eigenschaften der komplexen Busklemme aus deren Register R13
  {uint16_t  ucDataType   : 8;    // Datentyp der Busklemme
   uint16_t  _2bDiagSupp  : 2;    // Unterstuetzung von Busklemmendiagnose:
   // 00: keine Diagnose
   // 01: Diagnose im Statusbyte
   // 10: Diagnose im Register referenziert durch Statusbyte
   // 11: reserviert fuer Erweiterungen
   uint16_t  reserved     : 2;    // reserviert fuer Erweiterungen
   uint16_t  bMbx2Supp    : 1;    // Busklemme unterstuetzt den Mailbox 2.0 Mechanismus (Fragmentieren und Defragmentieren)
   uint16_t  bAcyChSupp   : 1;    // Busklemmen-Gateway, Gateway-Eigenschaften muessen beim Hochlauf ermittelt werden
   uint16_t  bPrmable     : 1;    // Busklemme kann ueber Feldbus parametriert werden (Parameterkanal R56, R57 vorhanden)
   uint16_t  bSizeInByte  : 1;    // Laengenangaben sind in Byte (TRUE), Bit (FALSE) angegeben
  } stProperties;
  uint16_t  uiProperties;
} T_R13_TERM_PROP_DESC;


typedef union
{
  struct // Eigenschaften einer Gateway-Busklemme (z.Z. nur ASi-Masterklemme)
  {uint16_t  ucDataLen    : 8;    // K-Bus-seitige Prozessdatenlaenge des Gateways
   uint16_t  ucMbxLen     : 7;    // Mailboxdatenlaenge des Gateways
   uint16_t  bMbxOverlap  : 1;    // Flag ob die Mailbox ueberlappend betrieben wird
  } stLenInfos;
  uint16_t  uiLenInfos;
} T_R33_GATEWAY_PROP;

#if PRM_COM

typedef union
{
  struct
  {
    unsigned
      ucBugfix            : 8,  // Bugfix Index
      ucFuncExt : 4,            // Funktionserweiterungsindex
      ucIncomp  : 4;            // Inkompatibilitaetsindex
  } stSoftwareDesc;
  uint16_t  uiSoftwareDesc;
} T_R14_SOFTWARE_DESC;


typedef union
{
  struct
  {
    unsigned
      ucIndex             : 8,  // Hardware Index
      bSerie753 : 1,            // Serie 753
      res0      : 7;            // reserviert fuer Erweiterungen
  } stHardwareDesc;
  uint16_t  uiHardwareDesc;
} T_R16_HARDWARE_DESC;


typedef union
{
  struct
  {
    unsigned
      bFCSEnabled         : 1,  // Mailbox-Datensicherung eingeschaltet
      bChgKbusCfg : 1,          // K-Bus-Konfiguration (SR) aendern
      bfPrmId     : 2,          // verwendete Parameter-ID (IOL-M)
      res0        : 12;         // reserviert fuer Erweiterungen
  } stExtMbxDesc;
  uint16_t  uiExtMbxDesc;
} T_EXT_MBX_DESC;


typedef union
{
  struct
  {
    unsigned
      bAcyclicMbx         : 1,  // Flag, ob Mailbox azyklisch bedient wird
      res0    : 7,              // reserviert fuer Erweiterungen
      ucMbxID : 8;              // Identifikation der Mailbox
  } stAcyMbxDesc;
  uint16_t  uiAcyMbxDesc;
} T_ACY_MBX_DESC;
#endif // PRM_COM


typedef union
{
  struct // Typinformation einer komplexen Busklemme (BK200- bzw. WA200-ASIC)
  {uint16_t  bInputs        : 1;    // Busklemme hat Eingangsinformationen
   uint16_t  bOutputs       : 1;    // Busklemme hat Ausgangsinformationen
   uint16_t  bBk200ModeSupp : 1;    // Busklemme unterstuetzt die BK200-Umschaltung (6-Byte-Modus)
   uint16_t  bPtpSupp       : 1;    // Busklemme unterstuetzt PTP-Kommunikation
   uint16_t  res0           : 1;    // reserviert fuer Erweiterungen
   uint16_t  _2bCycles      : 2;    // Anzahl erforderlicher Schiebezyklen
   uint16_t  bProcessor     : 1;    // Komplexe Busklemme mit Prozesssoer
   uint16_t  res1           : 1;    // reserviert fuer Erweiterungen
   uint16_t  bPfcAssigned   : 1;    // Busklemme ist dem Laufzeitsystem zugeordnet
   uint16_t  bMapCompl      : 1;    // Alle Daten der Busklemme mappen
   uint16_t  res2           : 5;    // reserviert fuer Erweiterungen
  } stCplxTrmType;
  struct // Typinformation einer binaeren Busklemme (BK100-, BK108-, WA800- oder WA8K-ASIC)
  {uint16_t  bInputs        : 1;    // Busklemme hat Eingangsinformationen
   uint16_t  bOutputs       : 1;    // Busklemme hat Ausgangsinformationen
   uint16_t  _4bExtType     : 4;    // erweiterte Typinformation
   uint16_t  res0           : 2;    // reserviert fuer Erweiterungen
   uint16_t  bNewByte       : 1;    // Busklemme eroeffnet ein neues Byte
   uint16_t  bPfcAssigned   : 1;    // Busklemme ist dem Laufzeitsystem zugeordnet
   uint16_t  bEmuSupplyMod  : 1;    // Emulation Einspeisemodul mit Diagnose durchfuehren
   uint16_t  bMapBinDiaToPi : 1;    // binaere Diagnose ins Prozessabbild mappen
   uint16_t  bNewOutpByte   : 1;    // Busklemme eroeffnet ein neues Ausgangsbyte
   uint16_t  bNewInpByte    : 1;    // Busklemme eroeffnet ein neues Eingangsbyte
   uint16_t  res2           : 2;    // reserviert fuer Erweiterungen
  } stBinTrmType;
  uint16_t  uiTrmType;
} T_DLT_TYPE;


#if PRM_COM
typedef union
{
  struct // Parameterdaten-Descriptor
  {uint16_t  ucLen          : 8;
   uint16_t  ucOffs         : 8; } stPrmDataDesc;
  uint16_t  uiPrmDataDesc;
} T_PRM_DATA_DESC;


typedef union
{
  struct // Datensatzindex-Descriptor
  {uint16_t  ucInd            : 8;
   uint16_t  ucStd            : 8; } stPrmRecIdx;
  uint16_t  uiPrmRecIdx;
} T_RECORD_DATA_DESC;
#endif // PRM_COM

typedef struct
{
  uint16_t reg;
} T_R30_PART_ID;


typedef struct
{
  uint16_t reg;
} T_R8_ID;


typedef struct // Eigenschaften der Busklemme
{uint16_t              uiSlot;                  // Steckplatz der Busklemme
 T_ORDER_NO            stOrderNo;               // Bestellnummer der Busklemme      (R28..R30)
 uint16_t              uiKbusBitPos;            // Bitposition im K-Bus-Schieberegister (DLL)
 uint16_t              uiKbusBitSize;           // Laenge der Klemmenschieberegisters (DLL)
 T_DLT_TYPE            unKbusTrmType;           // Klemmentyp (DLT)
 T_R8_ID               unTermID;                // Terminal ID                      (R08)
 T_R10_SHIFT_REG_DESC  unPhysChannelDesc;       // physikalische Kanalbeschreibung  (R10)
 T_R11_SIGNAL_DESC     unLogiChannelDesc;       // logische Kanalbeschreibung       (R11)
 T_R12_MAPPING_DESC    unProcDataDesc;          // Mapping-Beschreibung             (R12)
 T_R13_TERM_PROP_DESC  unTermProp;              // Klemmen-Eigenschaften            (R13)
 T_R30_PART_ID         unPartID;                // Teilebezeichnung                 (R30)
 T_R33_GATEWAY_PROP    unGatewayProp;           // Gateway-Eigenschaften            (R33)
 uint16_t              r32;
 uint16_t              r34;
 uint16_t              r35;
 T_R11_SIGNAL_DESC     unOrgLogiChannelDesc;    // original logische Kanalbeschreibung  (R11)
 T_R12_MAPPING_DESC    unOrgProcDataDesc;       // original Mapping-Beschreibung        (R12)
 T_R13_TERM_PROP_DESC  unOrgTermProp;           // original Klemmen-Eigenschaften       (R13)
 uint16_t              usR16;                   // Hardware-Eigenschaften (Baureihe)    (R16)
 uint16_t              usR28;                   // Artikelnummer Ziffern 10..12         (R28)
 uint16_t              usR29;                   // Artikelnummer Ziffern 07..09         (R29)
#if PRM_COM
 T_R14_SOFTWARE_DESC  unSoftwareDesc;           // Software-Eigenschaften           (R14)
 T_R16_HARDWARE_DESC  unHardwareDesc;           // Hardware-Eigenschaften           (R16)
 uint16_t             uiIndPrmRetries;          // verbleibende Versuche, iParameter zu erhalten
 T_EXT_MBX_DESC       unExtMbxDesc;             // erweiterte Mailbox-Beschreibung
 T_ACY_MBX_DESC       unAcyMbxDesc;             // Beschreibung einer vorhandenen azyklishen Mailbox (z. B. HART-Profil)

 uint16_t            uiResPrmChannel;           // reserviert fuer Erweiterungen
 uint16_t            uiRefToPrmErrReg;          // Referenz zum Register, das den Parametrierungsfehler beinhaltet
 T_RECORD_DATA_DESC  unRecordDataIdx;           // Record Data Index zur azyklischen Parametrierung
 T_PRM_DATA_DESC     unIndPrmDataDesc;          // Descriptor Individual-Parameter
 uint16_t            uiMilliSecTimeout;         // Timeout der parametrierbaren Busklemme in ms
 T_PRM_DATA_DESC     unStdPrmDataDesc;          // Descriptor Standard-Parameter
#endif // PRM_COM
} RAIL_DESC;


typedef struct
{
  uint8_t  *puc1stMbxByte;
  uint8_t  uiNoOfMbxBytes;
} T_MBX_AREA;


typedef struct
{
  uint8_t   ucProtocol;
  uint8_t   ucReserved;
  uint16_t  ucMbxBitOffs  : 8;
  uint16_t  ucMbxLen      : 7;  // Anzahl der Bytes, die vom temporaeren Mailbox-Eingangspuffer
  // in das Eingangsprozessabbild kopiert werden muessen
  uint16_t  bMbxOvlp      : 1;  // Flag, ob die Mailbox-Ueberlappung eingestellt ist
} T_MBX_PROP;


typedef struct
{
  uint16_t    uiSlot;               // Steckplatz der Mailbox
  T_MBX_PROP  stMbxProp;            // siehe oben
  uint16_t    uiTmpMbxInpBuff[12];  // temporaerer Eingangspuffer fuer Mailboxdaten
  uint16_t    uiTmpMbxOutBuff[12];  // temporaerer Ausgangspuffer fuer Mailboxdaten
} T_ACMBX_TERM_PROP;


typedef union RAIL_info_rail_settings
{
    uint16_t reg;
    struct {
      uint16_t AutoResetEnabled     : 1;
      uint16_t unused1              : 1;
      uint16_t unused2              : 1;
      uint16_t RailExtensionEnabled : 1;
      uint16_t unused4              : 1;
      uint16_t unused5              : 1;
      uint16_t unused6              : 1;
      uint16_t unused7              : 1;
      uint16_t unused8              : 1;
      uint16_t unused9              : 1;
      uint16_t unused10             : 1;
      uint16_t unused11             : 1;
      uint16_t unused12             : 1;
      uint16_t unused13             : 1;
      uint16_t unused14             : 1;
      uint16_t unused15             : 1;
    } bits;
} RAIL_info_rail_settings_t;

typedef struct RAIL_info_rail_frequenzies
{
  uint16_t usSlow_Com;          // KBUS-Taktfrequenz mit  Verlaengerung (STD)
  uint16_t usFast_Com;          // KBUS-Taktfrequenz ohne Verlaengerung

} RAIL_info_rail_frequenzies_t;


/// Status of the rail
typedef struct rail_status
{
  uint16_t  cntTerminals;       // Anzahl gesteckter Busklemmen mit Prozessdaten (ASIC)
  uint16_t  bytelenSSC;		      //
  uint16_t  bitoffsetOutput;    // Verschiebung der SSC-Ausgangsdaten
  uint16_t  cntMux;		          //
  uint16_t  bitlenKBus;         // Bitlaenge des K-Bus-Schieberegisters
  uint16_t  Error;              // anstehender Fehlercode auf der I/O (-ERR)-LED
  uint16_t  ErrArg;             // anstehendes Fehlerargument auf der I/O (-ERR)-LED
  uint16_t  idxFailedTerminal;  // Steckplatz der den Fehler verursacht hat
  uint16_t  DiagCode;		        // to be merged with error -- KBUS-CMD Fehler
} RAIL_STATUS;


typedef enum RAIL_info_error
{
  RAIL_INFO_ERR_NO_ERROR,
  RAIL_INFO_ERR_INTERNAL,
  RAIL_INFO_ERR_COMMUNICATION,
  RAIL_INFO_ERR_UNRELIABLE,
  RAIL_INFO_ERR_BUS,
  RAIL_INFO_ERR_RAIL_TOO_LARGE,
  RAIL_INFO_ERR_PI_TOO_LARGE,
  RAIL_INFO_ERR_INTERNAL_LIMIT,
  RAIL_INFO_ERR_CONFIGURATION
} RAIL_info_error_t;


typedef enum RAIL_info_binary_terminal_property
{
  BINARY_TERMINAL_PROPERTY_INPUTS,
  BINARY_TERMINAL_PROPERTY_OUTPUTS,
  BINARY_TERMINAL_PROPERTY_DIAGS,
  BINARY_TERMINAL_PROPERTY_DIAG_CHANNELS,
  BINARY_TERMINAL_PROPERTY_COUNT
} RAIL_info_binary_terminal_property_t;

/// \brief Inits the rail info module
/// It is allowed to call this function multiple times without a RAIL_info_free(),
/// but this serves no purpose.
/// ::RAIL_info_update() should be called after ::RAIL_info_init() to get useful rail values.
/// ::RAIL_info_update() returns RAIL_INFO_ERR_INTERNAL when the init failed,
/// so it's actually safe to ignore the return value of RAIL_info_init() and just check the
/// return value of RAIL_info_update().
RAIL_info_error_t RAIL_info_init(void);

/// \brief Updates the rail info module with the latest data
/// It is allowed to call this function multiple times without a RAIL_info_free(),
/// in order to re-init the rail info module data.
/// \attention The SCPU module needs to be initialized prior calling this function!
RAIL_info_error_t RAIL_info_update(void);

/// \brief Free resources allocated during init
void RAIL_info_free(void);

/// \brief Retrieve a pointer to the current valid rail description or NULL
RAIL_DESC * RAIL_info_get_rail_desc(void);

/// \brief Retrieve a pointer to the current valid rail status or NULL
RAIL_STATUS * RAIL_info_get_rail_status(void);

//---------------------------------------------------------------------------------------------------------------------
// function copies last valid rail status
//
// param[out]     pRailstatus_cp    pointer to buffer for rail status
//
// return                 status    RAIL_INFO_ERR_NO_ERROR: rail status is valid
//                                  RAIL_INFO_ERR_INTERNAL: invalid context pointer
//---------------------------------------------------------------------------------------------------------------------
RAIL_info_error_t RAIL_info_get_rail_status_cp( RAIL_STATUS * const pRailstatus_cp );

/// \brief Retrieve the amount of terminals on the rail
unsigned int RAIL_info_get_terminal_count(void);

unsigned int RAIL_info_get_size(void);

unsigned int RAIL_info_get_mux_count(void);

uint16_t RAIL_info_get_terminal_id(unsigned int pos_terminal);

//---------------------------------------------------------------------------------------------------------------------
// function reads register copy from rail description
//
// param[in]      uchSlotNo   terminal slot number [1..250]
// param[in]      uchRegNo    terminal register number [8,10,11,12,13,16,28,29,30,32,33,34,35]
//                            modified terminal register (-)number [-11,-12,-13]
// param[out]     pusValue    pointer to target buffer: register content
//
// return         status      0 = OK: valid register number and value pointer
//                           -1 = NOT_OK: terminal not found
//                           -2 = NOT_OK: unsupported register number
//                           -3 = NOT_OK: invalid value pointer (NULL)
//                            2 = NOT_OK: value not available / copies not initialized
//---------------------------------------------------------------------------------------------------------------------
int32_t RAIL_info_get_reg_copy_from_rail_desc( uint8_t uchSlotNo, uint8_t uchRegNo, uint16_t * pusValue );

uint16_t RAIL_info_get_rail_settings(void);

uint16_t RAIL_info_get_rail_extension(void);

uint16_t RAIL_info_get_rail_frequency( void );

void RAIL_info_set_rail_extension(uint16_t value);

void RAIL_info_test(void);

unsigned int RAIL_info_get_terminal_mapping_size(unsigned int idx_terminal,
                                                 RAIL_info_binary_terminal_property_t prop);

unsigned int RAIL_info_get_terminal_mapping_offset(unsigned int idx_terminal,
                                                   RAIL_info_binary_terminal_property_t prop);

unsigned int RAIL_info_get_terminal_mapping_channels(unsigned int idx_terminal,
                                                     RAIL_info_binary_terminal_property_t prop);


bool RAIL_info_get_terminal_diag_support(unsigned int idx_terminal);
#endif
