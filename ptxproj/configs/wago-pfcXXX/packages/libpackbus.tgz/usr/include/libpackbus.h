//---------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS are involved in the subject matter of this material.
/// All manufacturing, reproduction, use and sales rights pertaining to this
/// subject matter are governed by the license agreement. The recipient of this
/// software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
///  \file     libpackbus.h
///
///  \version  $Revision$
///
///  \brief    This header contains global definitions for he KBus API.
///
///  \author   HFS : WAGO GmbH & Co. KG
//---------------------------------------------------------------------------------------------------------------------
#ifndef LIBPACKBUS_H_
#define LIBPACKBUS_H_

//---------------------------------------------------------------------------------------------------------------------
// include files
//---------------------------------------------------------------------------------------------------------------------
#include <stdbool.h>
#include <stdint.h>

//---------------------------------------------------------------------------------------------------------------------
// defines
//---------------------------------------------------------------------------------------------------------------------

//                                                                    1         2         3
//                                                          "12345678901234567890123456789012"
#define LIBPACKBUS_DAL_FUNCTION_PUSH                        "libpackbus_Push"
#define LIBPACKBUS_DAL_FUNC_READ_TAB_9                      "libpackbus_read_table_9"
#define LIBPACKBUS_DAL_FUNC_READ_CONF_REG                   "libpackbus_read_conf_reg"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_OPEN                  "libpackbus_async_com_open"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_CLOSE                 "libpackbus_async_com_close"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_RD_REG          "libpackbus_async_com_startrdreg"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_RD_REG           "libpackbus_async_com_pollrdreg"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_WR_REG          "libpackbus_async_com_startwrreg"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_WR_REG           "libpackbus_async_com_pollwrreg"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_RD_REG_LIST     "libpackbus_async_com_strdreglst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_RD_REG_LIST      "libpackbus_async_com_pordreglst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_WR_REG_LIST     "libpackbus_async_com_stwrreglst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_WR_REG_LIST      "libpackbus_async_com_powrreglst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_RD_PAR          "libpackbus_async_com_startrdpar"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_RD_PAR           "libpackbus_async_com_pollrdpar"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_WR_PAR          "libpackbus_async_com_startwrpar"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_WR_PAR           "libpackbus_async_com_pollwrpar"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_RD_PAR_LIST     "libpackbus_async_com_strdparlst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_RD_PAR_LIST      "libpackbus_async_com_pordparlst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_START_WR_PAR_LIST     "libpackbus_async_com_stwrparlst"
#define LIBPACKBUS_DAL_FUNC_ASYNC_COM_POLL_WR_PAR_LIST      "libpackbus_async_com_powrparlst"
#define LIBPACKBUS_DAL_FUNC_GET_DIGITAL_OFFSET              "libpackbus_get_dig_offset"
#define LIBPACKBUS_DAL_FUNC_SET_DIGITAL_OFFSET              "libpackbus_set_dig_offset"
#define LIBPACKBUS_DAL_FUNC_GET_UID                         "libpackbus_get_uid"
#define LIBPACKBUS_DAL_FUNC_GET_TERMINAL_INFO_32            "libpackbus_get_terminal_info_32"
#define LIBPACKBUS_DAL_FUNC_GET_KBUS_STATUS                 "libpackbus_get_kbus_status"
#define LIBPACKBUS_DAL_FUNC_GET_KBUS_TIMING                 "libpackbus_get_kbus_timing"
#define LIBPACKBUS_DAL_FUNC_RESET_KBUS_TIMING               "libpackbus_reset_kbus_timing"


#define NO_OF_REGISTER_IN_TERMINAL    ( 64)
#define NO_OF_PARAMETER_IN_TERMINAL   (256)


//---------------------------------------------------------------------------------------------------------------------
// enumeration; type definitions
//---------------------------------------------------------------------------------------------------------------------

// Describes how the outputs are handled when the app changes its state from running to stopped.
typedef enum ePLC_STOP_BEHAVIOR
{
  PSB_DISCARD_WRITE_ON_PLC_STOP = 1,  ///< application stop -> hold last output values
  PSB_NORMAL_OPERATION          = 2,  ///< application stop -> set output values to zero
                                      ///
  PSB_MAX_INDEX_4_CHECK               ///< maximum index -> Do not change! mast not exceed size of 'tTYPE_CONF_DEV'

} tPLC_STOP_BEHAVIOR;

// defines for 'stCONFIGURE_DEVICE'
typedef enum eTYPE_CONF_DEV
{
  TCF_NO_STRUCT           = 0,  ///< invalid configuration structure
  TCF_SSC_CONF_STRUCT_1   = 1,  ///< use information in SSC_CONF_STRUCT_I
  TCF_SSC_CONF_STRUCT_2   = 2,  ///< use information in SSC_CONF_STRUCT_II
  TCF_SSC_CONF_STRUCT_3   = 3   ///< use information in SSC_CONF_STRUCT_III

} tTYPE_CONF_DEV;

/// \brief status of a request/evaluation
typedef enum LPKD_REQ_EVA_STATUS_e
{
  LPKD_REQ_EVA_STATUS_OK            =  0, ///< request/evaluation OK
  LPKD_REQ_EVA_GEN_ERROR            =  1, ///< unspecified internal error occurred -> see log
  LPKD_REQ_EVA_WRP_ENABLED          =  2, ///< unspecified internal error occurred -> see log
  LPKD_REQ_EVA_ERROR_TERM_IDX       =  3, ///< invalid terminal index / terminal not present
  LPKD_REQ_EVA_NO_REGISTER_COM      =  4, ///< terminal does not support register communication
  LPKD_REQ_EVA_NO_PARAMETER_CHAN    =  5, ///< terminal does not support parameter channel
  LPKD_REQ_EVA_ERROR_TABLE_IDX      =  6, ///< invalid table/channel index
  LPKD_REQ_EVA_ERROR_REG_PAR_IDX    =  7, ///< invalid register/parameter index
  LPKD_REQ_EVA_ERROR_REQ_COUNT      =  8, ///< number of requested words leads to invalid register/parameter index
  LPKD_REQ_EVA_ERROR_WRONG_STATE    =  9, ///< new request started during ongoing request
  LPKD_REQ_EVA_ERROR_TIMEOUT_PAR    = 10, ///< timeout during parameter access
  LPKD_REQ_EVA_ERROR_PAR_COM        = 11, ///< parameter communication error
  LPKD_REQ_EVA_AA_NO_REG_RD_ACC     = 12, ///< during application is active terminal does not support register read access
  LPKD_REQ_EVA_AA_NO_REG_WR_ACC     = 13, ///< during application is active terminal does not support register write access
  LPKD_REQ_EVA_AA_NO_PAR_ACC        = 14, ///< during application is active terminal does not support parameter access
  LPKD_REQ_EVA_ERROR_INV_HANDLE     = 15, ///< parameter error invalid handle
  LPKD_REQ_EVA_ERROR_VALUE_PTR      = 16, ///< parameter error invalid data pointer
  LPKD_REQ_EVA_ERROR_CON_IN_USE     = 17, ///< evaluation error connection is in use
  LPKD_REQ_EVA_INFO_CON_ACTIVE      = 18, ///< evaluation information connection is active; poll again
  LPKD_REQ_EVA_ERROR_NOT_INIT       = 19, ///< library module is not initialized
  LPKD_REQ_EVA_ERROR_NO_KBUS_ACC    = 20, ///< library module has not KBUS access
  LPKD_REQ_EVA_ERROR_NO_HANDLE_GEN  = 21, ///< system out of memory; no handle generated
  LPKD_REQ_EVA_ERROR_CONT_NOT_FIT   = 22, ///< content does not fit to request
  LPKD_REQ_EVA_ERROR_STS_NOT_FIT    = 23, ///< status does not fit to request
  LPKD_REQ_EVA_ERROR_TIMEOUT_TERM   = 24, ///< parameter access status from terminal: TIMEOUT
  LPKD_REQ_EVA_ERROR_BUF_OVF_TERM   = 25, ///< parameter access status from terminal: BUFFER OVERFLOW
  LPKD_REQ_EVA_ERROR_PRM_ERR_TERM   = 26, ///< parameter access status from terminal: PARAMETER ERROR


  NUMBER_OF_LPKD_REQ_EVA_VALUES           ///< number of defined return values

} LPKD_REQ_EVA_STATUS_t;


//---------------------------------------------------------------------------------------------------------------------
// structure; type definitions
//---------------------------------------------------------------------------------------------------------------------

// configuration structure for CS2 (analog before digital)
typedef struct st_ssc_conf_struct_I
{
  tPLC_STOP_BEHAVIOR   ePLCStopBehavior;    ///< Describes how the outputs are handled when the
                                            ///< application changes its state from running to stopped.
  bool                boSSC_NewProcessImag; ///< TRUE:  PI without register communication over PI
                                            ///< FALSE: PI with register communication over PI
} tSSC_CONF_STRUCT_I;


// configuration structure for CS3 (without register communication over PI)
typedef struct st_ssc_conf_struct_II
{
  bool                boSSC_NewProcessImag; ///< TRUE:  PI without dummy bytes
                                            ///< FALSE: PI with dummy bytes

} tSSC_CONF_STRUCT_II;


// configuration structure for CS3 (without register communication over PI)
typedef struct st_ssc_conf_struct_III
{
  uint32_t            ulTcmControl;         ///< 0:           disable TCM
                                            ///< 0x01000000:  enable TCM in version 1
  bool                boSSC_NewProcessImag; ///< TRUE:  PI without dummy bytes
                                            ///< FALSE: PI with dummy bytes
} tSSC_CONF_STRUCT_III;


// structure to configure device from DAL application
typedef struct st_configure_device
{
  // defines given data structure in uConfStruct
  tTYPE_CONF_DEV  eStructType;

  // union of data structures
  union
  {
    tSSC_CONF_STRUCT_I    rSSC_ConfStruct_I;
    tSSC_CONF_STRUCT_II   rSSC_ConfStruct_II;
    tSSC_CONF_STRUCT_III  rSSC_ConfStruct_III;

  } uConfStru;
} tCONFIGURE_DEVICE;


// structure for KBUS terminal information
typedef struct st_kbus_terminal_info_32
{
   uint32_t ulOffsetInput_bits;
   uint32_t ulOffsetOutput_bits;
   uint32_t ulSizeInput_bits;
   uint32_t ulSizeOutput_bits;

} tKBUS_TERMINAL_INFO_32;


//---------------------------------------------------------------------------------------------------------------------
// type definitions
//---------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------
// function prototypes
//---------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------
// macros
//---------------------------------------------------------------------------------------------------------------------

#endif /* LIBPACKBUS_H_ */
//---- End of source file ---------------------------------------------------------------------------------------------
