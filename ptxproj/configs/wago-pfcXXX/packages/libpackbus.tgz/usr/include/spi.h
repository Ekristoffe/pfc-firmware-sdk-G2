//------------------------------------------------------------------------------
// Copyright (c) 2000 - 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file     spi.h
///
///  \brief    Serial Peripheral Interface
///
///  \author   Lars Friedrich : WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
// Documentation
//------------------------------------------------------------------------------
/// \defgroup SPI-API SPI API description
/// These functions define the official SPI API.
/// Neither behavior nor interface should change without prior notice. So even
/// if the implementation inside changes, modules which worked successfully with
/// prior versions will work with later versions, too.
/// \section Usage
/// A module that wants to use the SPI module should call ::SPI_Init() and then
/// ::SPI_Open() to retrieve a handle. From there on, the ::SPI_ReadBytes(),
/// ::SPI_WriteBytes() and ::SPI_ReadWrite() functions can be used. When done,
/// the handle should be closed via ::SPI_Close()
/// A user should check the maximum transfer block size with ::SPI_GetTransferSize()
/// and segment it's data accordingly, otherwise there is no guarantee, the
/// recipient didn't overflow. The SPI module does not segment the data, because
/// it would limit the options of the user how to handle transfer with
/// full- and halfduplex mode.
#ifndef SPI_H
#define SPI_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include <stdint.h>
#include <stddef.h>
#include <inttypes.h>
#include <stdbool.h>
//------------------------------------------------------------------------------
// Datatypes
//------------------------------------------------------------------------------
/// \brief Determines the SPI type that is supported
typedef enum SPI_type
{
  SPI_TYPE_BITBANGING = 0,    ///< Bit-Banging-like SPI
  SPI_TYPE_GENERIC    = 1,    ///< UART-like SPI
  SPI_TYPE_LAST       = 1,    ///< Last element of enumeration
} SPI_type_t;

/// \brief Contains all possible error codes the SPI module delivers
typedef enum SPI_error
{
  SPI_ERR_NO_ERROR = 0,     ///< No error detected
  SPI_ERR_ERROR    = 1,     ///< Generic error detected
  SPI_ERR_COMM     = 2,     ///< Communication error
  SPI_ERR_LAST     = 2,     ///< Last element of enumeration
} SPI_error_t;

/// \brief Test cases for ::SPI_TestInterface()
typedef enum SPI_tests
{
  SPI_TEST_COMMUNICATION,
  SPI_TEST_PERFORMANCE,
  SPI_TEST_SETTINGS,
  SPI_TEST_LOOP
} SPI_tests_t;

/// \name SPI Internal
///@{

/// \brief Handle returned for use with the SPI functions.
typedef struct SPI_descriptor
{
  SPI_type_t  type;
  int         fd;
} *SPI_descriptor_t;

/// \brief Information about the SPI interface to the kernel
typedef struct SPI_interface
{
  bool      isCPOL;
  bool      isCPHA;
  bool      isChipSelectHigh;
  bool      isNoChipSelect;
  bool      isThreeWire;
  bool      isReady;
  bool      isLSBfirst;
  bool      isLoopbackEnabled;
  uint8_t   bits_per_word;
  uint32_t  speed;
} SPI_interface_t;

///@}

//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
/// \name SPI API
/// \ingroup SPI-API
/// \copydoc SPI-API

///@{

/// \brief Init function for the SPI module.
/// The function performs the necessary initialization for the SPI module. It has to be called prior the use of any
/// other SPI function. Multiple calls are allowed, but serve no purpose.
SPI_error_t       SPI_Init(void);

/// \brief Opens a port to the SPI module for data transfer.
/// \return A port descriptor which is required for the ::SPI_ReadBytes(), ::SPI_WriteBytes() and ::SPI_Close() calls.
SPI_descriptor_t  SPI_Open(void);

/// \brief Reads a number of bytes from the SPI interface
///  The function returns when all data was read.
/// \param[in]  sd        Descriptor received by a previous call of ::SPI_Open().
/// \param[out] buf       Buffer pointing to a memory area holding at least len bytes.
/// \param[in]  len       Amount of data to be read.
/// \return Pointer to the data read.
uint8_t          *SPI_ReadBytes(SPI_descriptor_t sd,
                                uint8_t          *buf,
                                unsigned int     len);

/// \brief Wites a number of bytes to the SPI interface
///  The function returns when the data was written.
/// \param[in]  sd        Descriptor received by a previous call of ::SPI_Open().
/// \param[out] buf       Buffer pointing to a memory area containing len bytes to write.
/// \param[in]  len       Amount of data to be written.
/// \return Amount of bytes actually written.
unsigned int      SPI_WriteBytes(SPI_descriptor_t sd,
                                 uint8_t          *buf,
                                 unsigned int     len);

/// \brief Reads a number of bytes from the SPI interface
/// \param[in]  sd        Descriptor received by a previous call of _Open().
/// \retval SPI_NO_ERROR  Handle closed.
/// \retval SPI_ERROR     Unknown error while closing the handle. The handle is no longer valid though.
SPI_error_t       SPI_Close(SPI_descriptor_t sd);

/// \brief Writes and reads a number of bytes from the SPI interface
/// This function does a full-duplex access and reads what is returned when the data is written.
/// It returns when all data is written resp. read.
/// \param[in] sd Descriptor received by a previous call of _Open().
/// \param[in,out] tx_buf Buffer to take for the bytes to write
/// \param[in,out] rx_buf Buffer to put the read bytes in
/// \param[in] len Bytes to read/write
/// \retval SPI_NO_ERROR  Bytes written/read
/// \retval SPI_ERROR     Unknown error occurred
SPI_error_t SPI_ReadWrite(SPI_descriptor_t sd,
                          uint8_t          *tx_buf,
                          uint8_t          *rx_buf,
                          unsigned int     len);

/// \brief Gets the maximum size of a single SPI transfer
/// \param[in] sd Descriptor received by a previous call of _Open().
/// \return The maximum spi transfer block size
size_t SPI_GetTransferSize(SPI_descriptor_t sd);


SPI_error_t SPI_Command(SPI_descriptor_t sd,
                        uint8_t          *tx_buf,
                        uint8_t          *rx_buf,
                        unsigned int     len_tx,
			unsigned int     len_rx);

#if SPI_DEBUG_FUNCTIONS
/// \brief Perform specific test function on the spi interface
/// \param[in] sd Descriptor received by a previous call of _Open().
/// \param[in] test The test to perform
/// \return The result of the test
SPI_error_t SPI_TestInterface(SPI_descriptor_t sd,
                              SPI_tests_t      test);
#endif
///@}
#endif
