//------------------------------------------------------------------------------
// Copyright (c) 2012-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
// the subject matter of this material. All manufacturing, reproduction,
// use, and sales rights pertaining to this subject matter are governed
// by the license agreement. The recipient of this software implicitly
// accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///
///  \file    dbus-controlstate.h
///
///  \brief   API for the 'Control Active' state of the PTP state machine
///
///
///  \author  Lars Friedrich : WAGO GmbH & Co. KG
///
///  \copydoc Copyright
///
//------------------------------------------------------------------------------
#ifndef DBUS_CONTROLSTATE_H
#define DBUS_CONTROLSTATE_H
//------------------------------------------------------------------------------
// Includes
//------------------------------------------------------------------------------
#include "dbus-states.h"
#include "../kbus-dal.h"
//------------------------------------------------------------------------------
// API
//------------------------------------------------------------------------------
void DBUS_state_transitionToControlState(DBUS_state_ptr);
#endif
