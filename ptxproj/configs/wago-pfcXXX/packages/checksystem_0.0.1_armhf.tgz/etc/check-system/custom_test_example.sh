#!/bin/bash

# WAGO GmbH & Co. KG
#
# Example of custom test script to check/log additional things for system analysis script "check_system.sh".
#######################################################################################################################


# Log something simply by echoing
#echo "My log line 1"
#sleep 1
#echo "My log line 2"

# OK:    Exit code 0
# FAIL:  Exit code 1
exit 0

