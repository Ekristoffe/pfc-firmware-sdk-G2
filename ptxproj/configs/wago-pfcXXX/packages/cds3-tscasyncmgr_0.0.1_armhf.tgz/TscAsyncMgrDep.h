/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 * <name>TscAsyncMgr</name>
 * <description> 
 *	
 * </description>
 *
 * <copyright>(c) 2003-2010 3S-Smart Software Solutions</copyright>
 */
#ifndef _TSCASYNCMGRDEP_H_
#define _TSCASYNCMGRDEP_H_

#define COMPONENT_NAME "TscAsyncMgr" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscAsyncMgr)
#define COMPONENT_NAME_UNQUOTED TscAsyncMgr





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscAsyncMgr	ADDVENDORID(CMP_VENDORID, TSCASYNCMGR_CLASSID_C)
#define CMPID_TscAsyncMgr	TSCASYNCMGR_CMPID
#define ITFID_TscAsyncMgr    ADDVENDORID(CMP_VENDORID, TSCASYNCMGR_CLASSID_C)


#define CMP_VERSION         UINT32_C(0x00000001)
#define CMP_VERSION_STRING "0.0.0.1"
#define CMP_VERSION_RC      0,0,0,1
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"


#include "CmpMemPoolItf.h"


#include "SysCpuHandlingItf.h"


#include "SysTimeItf.h"


#include "SysTaskItf.h"


#include "SysEventItf.h"


#include "CmpEventMgrItf.h"


/*Obsolete include: CMUtilsItf.m4*/


#include "SysExceptItf.h"


#include "CmpAppItf.h"


#include "TscExtTaskItf.h"








/**
 * \file TscAsyncMgrItf.h
 */
#include "TscAsyncMgrItf.h"







/**
 * <category>Task prefix</category>
 * <description>
 *	Task prefix to handle asynchronous task based jobs. The task priority is added to the prefix to get a unique task name.
 * </description>
 */
#ifndef RTS_TASKPREFIX_ASYNCTASK
    #define RTS_TASKPREFIX_ASYNCTASK         "AsyncTask"
#endif
#ifndef RTS_TASKPRIO_ASYNCTASK
    #define RTS_TASKPRIO_ASYNCTASK           TASKPRIO_IDLE
#endif



        
















      
















      


        


























     


























     

 


#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pITscExtTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CTscExtTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pITscExtTask = (ITscExtTask *)pIBase->QueryInterface(pIBase, ITFID_ITscExtTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysExcept == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysExcept, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysExcept = (ISysExcept *)pIBase->QueryInterface(pIBase, ITFID_ISysExcept, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		  if (pICmpEventMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpEventMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpEventMgr = (ICmpEventMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpEventMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysEvent == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysEvent, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysEvent = (ISysEvent *)pIBase->QueryInterface(pIBase, ITFID_ISysEvent, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTime == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTime, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTime = (ISysTime *)pIBase->QueryInterface(pIBase, ITFID_ISysTime, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysCpuHandling == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysCpuHandling, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysCpuHandling = (ISysCpuHandling *)pIBase->QueryInterface(pIBase, ITFID_ISysCpuHandling, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpMemPool == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpMemPool, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpMemPool = (ICmpMemPool *)pIBase->QueryInterface(pIBase, ITFID_ICmpMemPool, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pITscExtTask = NULL; \
          pICmpApp = NULL; \
          pISysExcept = NULL; \
          /*Obsolete include CMUtils*/ \
		  pICmpEventMgr = NULL; \
          pISysEvent = NULL; \
          pISysTask = NULL; \
          pISysTime = NULL; \
          pISysCpuHandling = NULL; \
          pICmpMemPool = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pITscExtTask != NULL) \
        { \
            pIBase = (IBase *)pITscExtTask->QueryInterface(pITscExtTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pITscExtTask = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pISysExcept != NULL) \
        { \
            pIBase = (IBase *)pISysExcept->QueryInterface(pISysExcept, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysExcept = NULL; \
            } \
        } \
          /*Obsolete include CMUtils*/ \
		  if (pICmpEventMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpEventMgr->QueryInterface(pICmpEventMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpEventMgr = NULL; \
            } \
        } \
          if (pISysEvent != NULL) \
        { \
            pIBase = (IBase *)pISysEvent->QueryInterface(pISysEvent, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysEvent = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
          if (pISysTime != NULL) \
        { \
            pIBase = (IBase *)pISysTime->QueryInterface(pISysTime, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTime = NULL; \
            } \
        } \
          if (pISysCpuHandling != NULL) \
        { \
            pIBase = (IBase *)pISysCpuHandling->QueryInterface(pISysCpuHandling, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysCpuHandling = NULL; \
            } \
        } \
          if (pICmpMemPool != NULL) \
        { \
            pIBase = (IBase *)pICmpMemPool->QueryInterface(pICmpMemPool, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpMemPool = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_CMUtlsnprintf(0);\
          if (ERR_OK == importResult ) importResult = GET_CMUtlSafeStrCpy(0);\
          if (ERR_OK == importResult ) importResult = GET_EventGetEvent(0);\
          if (ERR_OK == importResult ) importResult = GET_EventGetClass(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTimeGetMs(0);\
          if (ERR_OK == importResult ) importResult = GET_SysCpuCallIecFuncWithParams(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolUnlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolLock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolAppendUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolRemoveUsedBlockFromPool(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolAddUsedBlockToPool(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolRemoveUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolAddUsedBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolPutBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolExtendDynamic(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolGetBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolDelete(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolCreateStatic(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolUnlockBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_MemPoolLockBlock(0);\
          if (ERR_OK == importResult ) importResult = GET_TscExtTaskCheckExternalEvent(0);\
          if (ERR_OK == importResult ) importResult = GET_TscExtTaskUnregisterTaskFromEvent(0);\
          if (ERR_OK == importResult ) importResult = GET_TscExtTaskRegisterTaskToEvent(0);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskSetPriority(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysEventWait(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysEventSet(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysEventDelete(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysEventCreate(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskAutoReleaseOnExit(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskDestroy(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskExit(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskSetExit(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskEnd(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskLeave(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskEnter(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskGetCurrent(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskWaitSleep(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskResume(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskCreate(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_SysTaskGetInfo(CM_IMPORT_OPTIONAL_FUNCTION);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCASYNCMGR_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)tscasyncgetjobreturnvalue, "tscasyncgetjobreturnvalue", 0, 0x01000000 },\
            { (RTS_VOID_FCTPTR)tscasyncremoveall, "tscasyncremoveall", 0, 0x01000000 },\
            { (RTS_VOID_FCTPTR)tscasyncremove, "tscasyncremove", 0, 0x01000000 },\
              { (RTS_VOID_FCTPTR)tscasyncaddjob, "tscasyncaddjob", 0, 0x01000000 },\
            { (RTS_VOID_FCTPTR)tscasyncadd, "tscasyncadd", 0, 0x01000000 },\
            
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCASYNCMGR_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                              
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCASYNCMGR_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
          { (RTS_VOID_FCTPTR)TscAsyncGetJobReturnValue, "TscAsyncGetJobReturnValue", 0, 0 },\
            { (RTS_VOID_FCTPTR)TscAsyncRemoveAll, "TscAsyncRemoveAll", 0, 0 },\
            { (RTS_VOID_FCTPTR)TscAsyncRemove, "TscAsyncRemove", 0, 0 },\
          { (RTS_VOID_FCTPTR)TscAsyncAddJob2, "TscAsyncAddJob2", 0, 0 },\
            { (RTS_VOID_FCTPTR)TscAsyncAddJob, "TscAsyncAddJob", 0, 0 },\
            { (RTS_VOID_FCTPTR)TscAsyncAdd, "TscAsyncAdd", 0, 0 },\
          \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CmpMemPool     \
	ITF_SysCpuHandling     \
	ITF_SysTime     \
	ITF_SysTask     \
	ITF_SysEvent     \
	ITF_CmpEventMgr     \
	/*obsolete entry ITF_CMUtils*/      \
	ITF_SysExcept     \
	ITF_CmpApp     \
	ITF_TscExtTask      \
    USE_SysTaskGetInfo      \
    USE_SysTaskCreate      \
    USE_SysTaskResume      \
    USE_SysTaskWaitSleep      \
    USE_SysTaskGetCurrent      \
    USE_SysTaskEnter      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskSetExit      \
    USE_SysTaskExit      \
    USE_SysTaskDestroy      \
    USE_SysTaskAutoReleaseOnExit      \
    USE_SysEventCreate      \
    USE_SysEventDelete      \
    USE_SysEventSet      \
    USE_SysEventWait      \
    USE_SysTaskSetPriority      \
    USE_TscExtTaskRegisterTaskToEvent      \
    USE_TscExtTaskUnregisterTaskFromEvent      \
    USE_TscExtTaskCheckExternalEvent      \
    USE_MemPoolLockBlock      \
    USE_MemPoolUnlockBlock      \
    USE_MemPoolCreateStatic      \
    USE_MemPoolDelete      \
    USE_MemPoolGetBlock      \
    USE_MemPoolExtendDynamic      \
    USE_MemPoolPutBlock      \
    USE_MemPoolAddUsedBlock      \
    USE_MemPoolRemoveUsedBlock      \
    USE_MemPoolAddUsedBlockToPool      \
    USE_MemPoolRemoveUsedBlockFromPool      \
    USE_MemPoolAppendUsedBlock      \
    USE_MemPoolLock      \
    USE_MemPoolUnlock      \
    USE_SysCpuCallIecFuncWithParams      \
    USE_SysTimeGetMs      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventGetClass      \
    USE_EventGetEvent      \
    USE_CMUtlSafeStrCpy      \
    USE_CMUtlsnprintf     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CmpMemPool    \
	ITF_SysCpuHandling    \
	ITF_SysTime    \
	ITF_SysTask    \
	ITF_SysEvent    \
	ITF_CmpEventMgr    \
	/*obsolete entry ITF_CMUtils*/     \
	ITF_SysExcept    \
	ITF_CmpApp    \
	ITF_TscExtTask     \
    USE_SysTaskGetInfo      \
    USE_SysTaskCreate      \
    USE_SysTaskResume      \
    USE_SysTaskWaitSleep      \
    USE_SysTaskGetCurrent      \
    USE_SysTaskEnter      \
    USE_SysTaskLeave      \
    USE_SysTaskEnd      \
    USE_SysTaskSetExit      \
    USE_SysTaskExit      \
    USE_SysTaskDestroy      \
    USE_SysTaskAutoReleaseOnExit      \
    USE_SysEventCreate      \
    USE_SysEventDelete      \
    USE_SysEventSet      \
    USE_SysEventWait      \
    USE_SysTaskSetPriority      \
    USE_TscExtTaskRegisterTaskToEvent      \
    USE_TscExtTaskUnregisterTaskFromEvent      \
    USE_TscExtTaskCheckExternalEvent      \
    USE_MemPoolLockBlock      \
    USE_MemPoolUnlockBlock      \
    USE_MemPoolCreateStatic      \
    USE_MemPoolDelete      \
    USE_MemPoolGetBlock      \
    USE_MemPoolExtendDynamic      \
    USE_MemPoolPutBlock      \
    USE_MemPoolAddUsedBlock      \
    USE_MemPoolRemoveUsedBlock      \
    USE_MemPoolAddUsedBlockToPool      \
    USE_MemPoolRemoveUsedBlockFromPool      \
    USE_MemPoolAppendUsedBlock      \
    USE_MemPoolLock      \
    USE_MemPoolUnlock      \
    USE_SysCpuCallIecFuncWithParams      \
    USE_SysTimeGetMs      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_EventGetClass      \
    USE_EventGetEvent      \
    USE_CMUtlSafeStrCpy      \
    USE_CMUtlsnprintf     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CmpMemPool    \
	EXTITF_SysCpuHandling    \
	EXTITF_SysTime    \
	EXTITF_SysTask    \
	EXTITF_SysEvent    \
	EXTITF_CmpEventMgr    \
	/*obsolete entry EXTITF_CMUtils*/     \
	EXTITF_SysExcept    \
	EXTITF_CmpApp    \
	EXTITF_TscExtTask     \
    EXT_SysTaskGetInfo  \
    EXT_SysTaskCreate  \
    EXT_SysTaskResume  \
    EXT_SysTaskWaitSleep  \
    EXT_SysTaskGetCurrent  \
    EXT_SysTaskEnter  \
    EXT_SysTaskLeave  \
    EXT_SysTaskEnd  \
    EXT_SysTaskSetExit  \
    EXT_SysTaskExit  \
    EXT_SysTaskDestroy  \
    EXT_SysTaskAutoReleaseOnExit  \
    EXT_SysEventCreate  \
    EXT_SysEventDelete  \
    EXT_SysEventSet  \
    EXT_SysEventWait  \
    EXT_SysTaskSetPriority  \
    EXT_TscExtTaskRegisterTaskToEvent  \
    EXT_TscExtTaskUnregisterTaskFromEvent  \
    EXT_TscExtTaskCheckExternalEvent  \
    EXT_MemPoolLockBlock  \
    EXT_MemPoolUnlockBlock  \
    EXT_MemPoolCreateStatic  \
    EXT_MemPoolDelete  \
    EXT_MemPoolGetBlock  \
    EXT_MemPoolExtendDynamic  \
    EXT_MemPoolPutBlock  \
    EXT_MemPoolAddUsedBlock  \
    EXT_MemPoolRemoveUsedBlock  \
    EXT_MemPoolAddUsedBlockToPool  \
    EXT_MemPoolRemoveUsedBlockFromPool  \
    EXT_MemPoolAppendUsedBlock  \
    EXT_MemPoolLock  \
    EXT_MemPoolUnlock  \
    EXT_SysCpuCallIecFuncWithParams  \
    EXT_SysTimeGetMs  \
    EXT_EventOpen  \
    EXT_EventClose  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_EventGetClass  \
    EXT_EventGetEvent  \
    EXT_CMUtlSafeStrCpy  \
    EXT_CMUtlsnprintf 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscAsyncMgr__Entry
#endif


#ifdef CPLUSPLUS

class CTscAsyncMgr : public ITscAsyncMgr 
{
    public:
        CTscAsyncMgr() : hTscAsyncMgr(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscAsyncMgr()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((ITscAsyncMgr *)this);            
            else if (iid == ITFID_ITscAsyncMgr)
                pItf = dynamic_cast<ITscAsyncMgr *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }
        virtual RTS_HANDLE CDECL ITscAsyncAdd(PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, RTS_UI32 ulJobPriority, RTS_RESULT *pResult);
        virtual RTS_HANDLE CDECL ITscAsyncAddJob(PFASYNCJOBFUNCTION pfAsyncJobFunc, void* pParam, void* pInstance, RTS_UI32* pulState, int bIecFunc, RTS_UI32 ulTimeout, ASYNCJOB_PARAM* pAsyncJobParam, RTS_RESULT *pResult);
        virtual RTS_RESULT CDECL ITscAsyncAddJob2(ASYNCJOB_INFO *pJob);
        virtual RTS_RESULT CDECL ITscAsyncRemove(RTS_HANDLE hJob);
        virtual RTS_RESULT CDECL ITscAsyncRemoveAll(void);
        virtual RTS_RESULT CDECL ITscAsyncGetJobReturnValue(RTS_HANDLE hJob, RTS_UI32* pulRetVal);

    public:
        RTS_HANDLE hTscAsyncMgr;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
