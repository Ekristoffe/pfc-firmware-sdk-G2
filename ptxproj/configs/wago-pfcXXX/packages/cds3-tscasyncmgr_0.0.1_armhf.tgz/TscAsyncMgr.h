//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     TscAsyncMgr.h
///
///  \version  $Id: TscAsyncMgr.h
///
///  \brief    <short description of the file contents>
///
// \author  Oleg Karfich : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------

#ifndef TSCASYNCMGR_H_
#define TSCASYNCMGR_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include "TscAsyncMgrDep.h"

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
#define NOT_INITIALIZED                     -1
#define TOGGLE_VALUE                        1

#define TASK_DEAMON_TIMEOUT                 (long)5

#define TASK_CANCEL_TIMEOUT                 1000

#define NUM_SCHED_MODES                     7
#define NUM_LOCAL_BUS_EVENTS                5

#define BACKGROUND_PRIO_RESET_VAL           TASKPRIO_HIGH_BASE + 6

// iec-priorities; corresponds to WagoSysAsync-Lib Scheduling-Modes
#define PRIO_SCHED_MODE_LOCAL_BUS_CYCLE     0
#define PRIO_SCHED_MODE_REAL_TIME_HIGH      1
#define PRIO_SCHED_MODE_REAL_TIME_MEDIUM    2
#define PRIO_SCHED_MODE_REAL_TIME_LOW       3
#define PRIO_SCHED_MODE_ASYNC_HIGH          4
#define PRIO_SCHED_MODE_ASYNC_MEDIUM        7
#define PRIO_SCHED_MODE_ASYNC_LOW           14
#define PRIO_SCHED_MODE_BACKGROUND          15


#define NAME_SIZE                           32

typedef struct ASYNCTASK_INFOtag
{
  RTS_HANDLE hTask;
  RTS_HANDLE hEvent;
  RTS_UI32 ulPriority;
  char szName[NAME_SIZE];
  char szExtEvtName[NAME_SIZE];
  RTS_I8 cycleState;
} ASYNCTASK_INFO;

//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
static RTS_RESULT TscAsyncDoJob(RTS_HANDLE hJob);
static void CDECL TscAsyncExecuteTask(SYS_TASK_PARAM *ptp);
static void CDECL TscDeleteTask(ASYNCTASK_INFO *pTask);

static RTS_RESULT TscAsyncCreateStaticTasks(void);
static void CDECL TscAsyncDeleteStaticTasks(void);

static void CDECL ResetPriority(RTS_HANDLE hTask);
static RTS_RESULT RegisterCbToEvt(void);
static RTS_RESULT UnregisterCbFromEvt(void);
static void EventCallBack(EventParam * const pEventParam);

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------
const char * const schedModeNames[NUM_SCHED_MODES] = {"WagoAsyncRtHigh",
                                                      "WagoAsyncRtMed",
                                                      "WagoAsyncRtLow",
                                                      "WagoAsyncHigh",
                                                      "WagoAsyncMed",
                                                      "WagoAsyncLow",
                                                      "WagoAsyncBg",
};

const RTS_UI32 schedModePrios[NUM_SCHED_MODES] = {PRIO_SCHED_MODE_REAL_TIME_HIGH,
                                                  PRIO_SCHED_MODE_REAL_TIME_MEDIUM,
                                                  PRIO_SCHED_MODE_REAL_TIME_LOW,
                                                  PRIO_SCHED_MODE_ASYNC_HIGH,
                                                  PRIO_SCHED_MODE_ASYNC_MEDIUM,
                                                  PRIO_SCHED_MODE_ASYNC_LOW,
                                                  PRIO_SCHED_MODE_BACKGROUND,
};

const char * const extEvtSchedModeNames[NUM_LOCAL_BUS_EVENTS] = {
                                                      "WagoAsyncBusCyclicEvt",
                                                      "WagoAsyncBusEvt_1",
                                                      "WagoAsyncBusEvt_2",
                                                      "WagoAsyncBusEvt_3",
                                                      "WagoAsyncBusEvt_4"
};

#define INDEX__LocalBusCycleEvent__IN_NAME_LIST    (0)

const char * const localBusCycleEventNames[NUM_LOCAL_BUS_EVENTS] = {"LocalBusCycleEvent",
                                                                    "LocalBusEvent_1",
                                                                    "LocalBusEvent_2",
                                                                    "LocalBusEvent_3",
                                                                    "LocalBusEvent_4"
};

#endif /* TSCASYNCMGR_H_ */

//---- End of source file ------------------------------------------------------
