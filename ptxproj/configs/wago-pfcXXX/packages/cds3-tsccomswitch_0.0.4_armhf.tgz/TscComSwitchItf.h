 /**
 * <interfacename>TscComSwitch</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCCOMSWITCHITF_H_
#define _TSCCOMSWITCHITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eComMode</description>
 */
#define ECOMMODE_COM_MODE_RS232    0	
#define ECOMMODE_COM_MODE_RS485    1	
/* Typed enum definition */
#define ECOMMODE    RTS_IEC_INT

/**
 * Returns the Protocol-Mode of the Serial Hardware  
 * 	
 *=============  ====================================================================================== 
 ***result codes**
 *----------------------------------------------------------------------------------------------------- 
 *0              success
 *EBADF		   Bad Filehandle 
 *=============  ====================================================================================== 
 *
 */
typedef struct tagcomsw_get_mode_struct
{
	RTS_IEC_HANDLE hCom;				/* VAR_INPUT */	
	RTS_IEC_INT COMSW_GET_MODE;			/* VAR_OUTPUT, Enum: ECOMMODE */
} comsw_get_mode_struct;

void CDECL CDECL_EXT comsw_get_mode(comsw_get_mode_struct *p);
typedef void (CDECL CDECL_EXT* PFCOMSW_GET_MODE_IEC) (comsw_get_mode_struct *p);
#if defined(TSCCOMSWITCH_NOTIMPLEMENTED) || defined(COMSW_GET_MODE_NOTIMPLEMENTED)
	#define USE_comsw_get_mode
	#define EXT_comsw_get_mode
	#define GET_comsw_get_mode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_comsw_get_mode(p0) 
	#define CHK_comsw_get_mode  FALSE
	#define EXP_comsw_get_mode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_comsw_get_mode
	#define EXT_comsw_get_mode
	#define GET_comsw_get_mode(fl)  CAL_CMGETAPI( "comsw_get_mode" ) 
	#define CAL_comsw_get_mode  comsw_get_mode
	#define CHK_comsw_get_mode  TRUE
	#define EXP_comsw_get_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_get_mode", (RTS_UINTPTR)comsw_get_mode, 1, 0x31146E4D, 0x01000004) 
	#define EXTREF_ITF_comsw_get_mode {(RTS_VOID_FCTPTR)comsw_get_mode, "comsw_get_mode", 0x31146E4D, 0x01000004}
#elif defined(MIXED_LINK) && !defined(TSCCOMSWITCH_EXTERNAL)
	#define USE_comsw_get_mode
	#define EXT_comsw_get_mode
	#define GET_comsw_get_mode(fl)  CAL_CMGETAPI( "comsw_get_mode" ) 
	#define CAL_comsw_get_mode  comsw_get_mode
	#define CHK_comsw_get_mode  TRUE
	#define EXP_comsw_get_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_get_mode", (RTS_UINTPTR)comsw_get_mode, 1, 0x31146E4D, 0x01000004) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscComSwitchcomsw_get_mode
	#define EXT_TscComSwitchcomsw_get_mode
	#define GET_TscComSwitchcomsw_get_mode  ERR_OK
	#define CAL_TscComSwitchcomsw_get_mode  comsw_get_mode
	#define CHK_TscComSwitchcomsw_get_mode  TRUE
	#define EXP_TscComSwitchcomsw_get_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_get_mode", (RTS_UINTPTR)comsw_get_mode, 1, 0x31146E4D, 0x01000004) 
#elif defined(CPLUSPLUS)
	#define USE_comsw_get_mode
	#define EXT_comsw_get_mode
	#define GET_comsw_get_mode(fl)  CAL_CMGETAPI( "comsw_get_mode" ) 
	#define CAL_comsw_get_mode  comsw_get_mode
	#define CHK_comsw_get_mode  TRUE
	#define EXP_comsw_get_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_get_mode", (RTS_UINTPTR)comsw_get_mode, 1, 0x31146E4D, 0x01000004) 
#else /* DYNAMIC_LINK */
	#define USE_comsw_get_mode  PFCOMSW_GET_MODE_IEC pfcomsw_get_mode;
	#define EXT_comsw_get_mode  extern PFCOMSW_GET_MODE_IEC pfcomsw_get_mode;
	#define GET_comsw_get_mode(fl)  s_pfCMGetAPI2( "comsw_get_mode", (RTS_VOID_FCTPTR *)&pfcomsw_get_mode, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x31146E4D, 0x01000004)
	#define CAL_comsw_get_mode  pfcomsw_get_mode
	#define CHK_comsw_get_mode  (pfcomsw_get_mode != NULL)
	#define EXP_comsw_get_mode   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_get_mode", (RTS_UINTPTR)comsw_get_mode, 1, 0x31146E4D, 0x01000004) 
#endif


/**
 * Set the Protocol-Mode of the Serial Hardware  
 * 	
 *===============  ==================================================================================== 
 ***result codes**
 *----------------------------------------------------------------------------------------------------- 
 *0                success
 *EPROTONOSUPPORT  Invalid Protocol-Mode
 *EBADF            Bad File Handle
 *EINVAL           Invalid Argument
 *===============  ==================================================================================== 
 *
 */
typedef struct tagcomsw_set_mode_struct
{
	RTS_IEC_HANDLE hCom;				/* VAR_INPUT */	
	RTS_IEC_INT eMode;					/* VAR_INPUT, Enum: ECOMMODE */
	RTS_IEC_DWORD COMSW_SET_MODE;		/* VAR_OUTPUT */	
} comsw_set_mode_struct;

void CDECL CDECL_EXT comsw_set_mode(comsw_set_mode_struct *p);
typedef void (CDECL CDECL_EXT* PFCOMSW_SET_MODE_IEC) (comsw_set_mode_struct *p);
#if defined(TSCCOMSWITCH_NOTIMPLEMENTED) || defined(COMSW_SET_MODE_NOTIMPLEMENTED)
	#define USE_comsw_set_mode
	#define EXT_comsw_set_mode
	#define GET_comsw_set_mode(fl)  ERR_NOTIMPLEMENTED
	#define CAL_comsw_set_mode(p0) 
	#define CHK_comsw_set_mode  FALSE
	#define EXP_comsw_set_mode  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_comsw_set_mode
	#define EXT_comsw_set_mode
	#define GET_comsw_set_mode(fl)  CAL_CMGETAPI( "comsw_set_mode" ) 
	#define CAL_comsw_set_mode  comsw_set_mode
	#define CHK_comsw_set_mode  TRUE
	#define EXP_comsw_set_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_set_mode", (RTS_UINTPTR)comsw_set_mode, 1, 0x97ADF18E, 0x01000004) 
	#define EXTREF_ITF_comsw_set_mode {(RTS_VOID_FCTPTR)comsw_set_mode, "comsw_set_mode", 0x97ADF18E, 0x01000004}
#elif defined(MIXED_LINK) && !defined(TSCCOMSWITCH_EXTERNAL)
	#define USE_comsw_set_mode
	#define EXT_comsw_set_mode
	#define GET_comsw_set_mode(fl)  CAL_CMGETAPI( "comsw_set_mode" ) 
	#define CAL_comsw_set_mode  comsw_set_mode
	#define CHK_comsw_set_mode  TRUE
	#define EXP_comsw_set_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_set_mode", (RTS_UINTPTR)comsw_set_mode, 1, 0x97ADF18E, 0x01000004) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscComSwitchcomsw_set_mode
	#define EXT_TscComSwitchcomsw_set_mode
	#define GET_TscComSwitchcomsw_set_mode  ERR_OK
	#define CAL_TscComSwitchcomsw_set_mode  comsw_set_mode
	#define CHK_TscComSwitchcomsw_set_mode  TRUE
	#define EXP_TscComSwitchcomsw_set_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_set_mode", (RTS_UINTPTR)comsw_set_mode, 1, 0x97ADF18E, 0x01000004) 
#elif defined(CPLUSPLUS)
	#define USE_comsw_set_mode
	#define EXT_comsw_set_mode
	#define GET_comsw_set_mode(fl)  CAL_CMGETAPI( "comsw_set_mode" ) 
	#define CAL_comsw_set_mode  comsw_set_mode
	#define CHK_comsw_set_mode  TRUE
	#define EXP_comsw_set_mode  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_set_mode", (RTS_UINTPTR)comsw_set_mode, 1, 0x97ADF18E, 0x01000004) 
#else /* DYNAMIC_LINK */
	#define USE_comsw_set_mode  PFCOMSW_SET_MODE_IEC pfcomsw_set_mode;
	#define EXT_comsw_set_mode  extern PFCOMSW_SET_MODE_IEC pfcomsw_set_mode;
	#define GET_comsw_set_mode(fl)  s_pfCMGetAPI2( "comsw_set_mode", (RTS_VOID_FCTPTR *)&pfcomsw_set_mode, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x97ADF18E, 0x01000004)
	#define CAL_comsw_set_mode  pfcomsw_set_mode
	#define CHK_comsw_set_mode  (pfcomsw_set_mode != NULL)
	#define EXP_comsw_set_mode   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"comsw_set_mode", (RTS_UINTPTR)comsw_set_mode, 1, 0x97ADF18E, 0x01000004) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ITscComSwitch_C;

#ifdef CPLUSPLUS
class ITscComSwitch : public IBase
{
	public:
};
	#ifndef ITF_TscComSwitch
		#define ITF_TscComSwitch static ITscComSwitch *pITscComSwitch = NULL;
	#endif
	#define EXTITF_TscComSwitch
#else	/*CPLUSPLUS*/
	typedef ITscComSwitch_C		ITscComSwitch;
	#ifndef ITF_TscComSwitch
		#define ITF_TscComSwitch
	#endif
	#define EXTITF_TscComSwitch
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCCOMSWITCHITF_H_*/
