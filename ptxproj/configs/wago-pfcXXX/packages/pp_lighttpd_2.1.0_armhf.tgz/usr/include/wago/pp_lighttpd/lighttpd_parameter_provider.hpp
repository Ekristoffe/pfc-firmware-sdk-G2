//------------------------------------------------------------------------------
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
// This file is part of project parameter service (PTXdist package pp_lighttpd).
//
// Copyright (c) 2021 - 2022 WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file
///
///  \brief    Parameter provider for lighttpd webserver.
///
///  \author   PEn: WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_WAGO_PP_LIGHTTPD_LIGHTTPD_PARAMETER_PROVIDER_HPP_
#define INC_WAGO_PP_LIGHTTPD_LIGHTTPD_PARAMETER_PROVIDER_HPP_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include <wago/wdx/base_parameter_provider.hpp>

#include <memory>
#include <mutex>
#include <wc/structuring.h>
//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
class lighttpd_provider_fixture;

namespace wago {
namespace pp_lighttpd {

class parameter_handler_i;

class lighttpd_parameter_provider final
: public wdx::base_parameter_provider
{
    WC_DISBALE_CLASS_COPY_ASSIGN_AND_MOVE_ASSIGN(lighttpd_parameter_provider)

private:
    // Internal implementation for domain specific functionality
    std::shared_ptr<parameter_handler_i> handler_m;
    std::shared_ptr<std::mutex>          handler_mutex_m;

private:
    // Fixture as friend class for dependency injection in unit tests (inject mock)
    friend lighttpd_provider_fixture;
    explicit lighttpd_parameter_provider(std::shared_ptr<parameter_handler_i> handler) noexcept;

public:
    lighttpd_parameter_provider() noexcept;
    ~lighttpd_parameter_provider() noexcept override;

    // Parameter provider interface
    wdx::parameter_selector_response get_provided_parameters() override;
    wago::future<std::vector<wdx::value_response>> get_parameter_values(std::vector<wdx::parameter_instance_id> const parameter_ids) override;
    wago::future<std::vector<wdx::set_parameter_response>> set_parameter_values(std::vector<wdx::value_request> const value_requests) override;
    wago::future<std::vector<wdx::set_parameter_response>> set_parameter_values_connection_aware(std::vector<wdx::value_request> value_requests, bool defer_wda_web_connection_changes) override;

};

} // Namespace pp_lighttpd
} // Namespace wago


#endif /* INC_WAGO_PP_LIGHTTPD_LIGHTTPD_PARAMETER_PROVIDER_HPP_ */
//---- End of source file ------------------------------------------------------
