 /**
 * <interfacename>WagoTscSysExt</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOTSCSYSEXTITF_H_
#define _WAGOTSCSYSEXTITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: eFileType</description>
 */
#define EFILETYPE_UNKNOWN    0	
#define EFILETYPE_REGULAR    1	
#define EFILETYPE_DIR    2	
#define EFILETYPE_FIFO    3	
#define EFILETYPE_CHAR    4	
#define EFILETYPE_BLOCK    5	
/* Typed enum definition */
#define EFILETYPE    RTS_IEC_INT

/**
 * <description>typFileStat</description>
 */
typedef struct tagtypFileStat
{
	RTS_IEC_DATE_AND_TIME change;		/* time stamp of last change */
	RTS_IEC_INT filetype;		/* type of file */
	RTS_IEC_ULINT size;		/* size of file in case of dir the value is always zero */
} typFileStat;

/**
 * Reports the information about a file or a directory
 *
 *If the resource is a directory, the name may or may not contain a trailing slash ('/'), both variants are valid.
 *
 *If the resource is a symbolic link, that link will be silently followed and the link status will be completely hidden from the caller.
 *
 *When the returned RTS_IEC_RESULT is any other than '0=OK', the output (including the field 'filetype') is an undefined state.
 *Thus, evaluation of the result code is strictly mandatory when using this function.    
 *
 *======  =====================  ==================================================================================
 *Return values of **SysExt_FileGetStat** (RTS_IEC_RESULT)
 *-----------------------------------------------------------------------------------------------------------------
 *0       = ERR_OK               sucessful operation
 *16      = ERR_NO_OBJECT        A component of the path does not exist, or a component of the path prefix is not a directory, or the path is an empty string.
 *50      = ERR_FILE_ERROR       the path is too long.
 *other   ...                    other internal errors 
 *?       EACCES                 Search permission is denied for one of the directories in the path prefix                       
 *?       ELOOP                  Too many symbolic links encountered while traversing the path.
 *?       ENOMEM                 Out of memory (i.e., kernel memory).
 *?       EOVERFLOW              path or fd refers to a file whose size, inode number, or number of blocks cannot be represented [...] 
 *======  =====================  ==================================================================================
 *
 */
typedef struct tagsysext_filegetstat_struct
{
	RTS_IEC_STRING szName[256];			/* VAR_INPUT */	/* name of the resource to be investigated */
	RTS_IEC_RESULT SysExt_FileGetStat;	/* VAR_OUTPUT */	
	typFileStat stat;					/* VAR_OUTPUT */	/* structure containing resource information */
} sysext_filegetstat_struct;

void CDECL CDECL_EXT sysext_filegetstat(sysext_filegetstat_struct *p);
typedef void (CDECL CDECL_EXT* PFSYSEXT_FILEGETSTAT_IEC) (sysext_filegetstat_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(SYSEXT_FILEGETSTAT_NOTIMPLEMENTED)
	#define USE_sysext_filegetstat
	#define EXT_sysext_filegetstat
	#define GET_sysext_filegetstat(fl)  ERR_NOTIMPLEMENTED
	#define CAL_sysext_filegetstat(p0) 
	#define CHK_sysext_filegetstat  FALSE
	#define EXP_sysext_filegetstat  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_sysext_filegetstat
	#define EXT_sysext_filegetstat
	#define GET_sysext_filegetstat(fl)  CAL_CMGETAPI( "sysext_filegetstat" ) 
	#define CAL_sysext_filegetstat  sysext_filegetstat
	#define CHK_sysext_filegetstat  TRUE
	#define EXP_sysext_filegetstat  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_filegetstat", (RTS_UINTPTR)sysext_filegetstat, 1, 0x78D745D6, 0x01000200) 
	#define EXTREF_ITF_sysext_filegetstat {(RTS_VOID_FCTPTR)sysext_filegetstat, "sysext_filegetstat", 0x78D745D6, 0x01000200}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_sysext_filegetstat
	#define EXT_sysext_filegetstat
	#define GET_sysext_filegetstat(fl)  CAL_CMGETAPI( "sysext_filegetstat" ) 
	#define CAL_sysext_filegetstat  sysext_filegetstat
	#define CHK_sysext_filegetstat  TRUE
	#define EXP_sysext_filegetstat  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_filegetstat", (RTS_UINTPTR)sysext_filegetstat, 1, 0x78D745D6, 0x01000200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtsysext_filegetstat
	#define EXT_WagoTscSysExtsysext_filegetstat
	#define GET_WagoTscSysExtsysext_filegetstat  ERR_OK
	#define CAL_WagoTscSysExtsysext_filegetstat  sysext_filegetstat
	#define CHK_WagoTscSysExtsysext_filegetstat  TRUE
	#define EXP_WagoTscSysExtsysext_filegetstat  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_filegetstat", (RTS_UINTPTR)sysext_filegetstat, 1, 0x78D745D6, 0x01000200) 
#elif defined(CPLUSPLUS)
	#define USE_sysext_filegetstat
	#define EXT_sysext_filegetstat
	#define GET_sysext_filegetstat(fl)  CAL_CMGETAPI( "sysext_filegetstat" ) 
	#define CAL_sysext_filegetstat  sysext_filegetstat
	#define CHK_sysext_filegetstat  TRUE
	#define EXP_sysext_filegetstat  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_filegetstat", (RTS_UINTPTR)sysext_filegetstat, 1, 0x78D745D6, 0x01000200) 
#else /* DYNAMIC_LINK */
	#define USE_sysext_filegetstat  PFSYSEXT_FILEGETSTAT_IEC pfsysext_filegetstat;
	#define EXT_sysext_filegetstat  extern PFSYSEXT_FILEGETSTAT_IEC pfsysext_filegetstat;
	#define GET_sysext_filegetstat(fl)  s_pfCMGetAPI2( "sysext_filegetstat", (RTS_VOID_FCTPTR *)&pfsysext_filegetstat, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x78D745D6, 0x01000200)
	#define CAL_sysext_filegetstat  pfsysext_filegetstat
	#define CHK_sysext_filegetstat  (pfsysext_filegetstat != NULL)
	#define EXP_sysext_filegetstat   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_filegetstat", (RTS_UINTPTR)sysext_filegetstat, 1, 0x78D745D6, 0x01000200) 
#endif


/**
 * SysExt_GetFreeSize() reports the free space in the filesystem which contains the directory named by the input parameter.
 *
 *The named directory may or may not contain a trailing slash ('/'), both variants are valid.
 *
 *If the name denotes a regular file instead of a directory, the prefix path to that file will be used for calculation.
 *
 *If a directory contains mountpoints to other file systems, the free space in these other file systems will be ignored for the calculation.
 *
 *If the resource is a link to another file system, that link will be followed and the
 *free space in the other FS will be reported.
 *
 *When the returned RTS_IEC_RESULT is any other than '0=OK', the output variables are in undefined states.
 *Thus, evaluation of the return value is strictly mandatory when using this function.    
 *
 *======  =====================  ===========================================================
 *Return values of **SysExt_GetFreeSize** (RTS_IEC_RESULT)
 *------------------------------------------------------------------------------------------
 *0       = ERR_OK               sucessful operation
 *16      = ERR_NO_OBJECT        named directory does not exist or invalid argument is given
 *other   [...]                  internal errors    
 *======  =====================  ===========================================================
 *
 */
typedef struct tagsysext_getfreesize_struct
{
	RTS_IEC_STRING szName[256];			/* VAR_INPUT */	/* Name of the directory which is to be investigated */
	RTS_IEC_RESULT SysExt_GetFreeSize;	/* VAR_OUTPUT */	
	RTS_IEC_UDINT udiBlockSize;			/* VAR_OUTPUT */	/* Block size of the given directory (bytes) */
	RTS_IEC_UDINT udiAmountOfBlocks;	/* VAR_OUTPUT */	/* Number of free blocks in the directory (bytes) */
} sysext_getfreesize_struct;

void CDECL CDECL_EXT sysext_getfreesize(sysext_getfreesize_struct *p);
typedef void (CDECL CDECL_EXT* PFSYSEXT_GETFREESIZE_IEC) (sysext_getfreesize_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(SYSEXT_GETFREESIZE_NOTIMPLEMENTED)
	#define USE_sysext_getfreesize
	#define EXT_sysext_getfreesize
	#define GET_sysext_getfreesize(fl)  ERR_NOTIMPLEMENTED
	#define CAL_sysext_getfreesize(p0) 
	#define CHK_sysext_getfreesize  FALSE
	#define EXP_sysext_getfreesize  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_sysext_getfreesize
	#define EXT_sysext_getfreesize
	#define GET_sysext_getfreesize(fl)  CAL_CMGETAPI( "sysext_getfreesize" ) 
	#define CAL_sysext_getfreesize  sysext_getfreesize
	#define CHK_sysext_getfreesize  TRUE
	#define EXP_sysext_getfreesize  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_getfreesize", (RTS_UINTPTR)sysext_getfreesize, 1, 0x3BB3D489, 0x01000200) 
	#define EXTREF_ITF_sysext_getfreesize {(RTS_VOID_FCTPTR)sysext_getfreesize, "sysext_getfreesize", 0x3BB3D489, 0x01000200}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_sysext_getfreesize
	#define EXT_sysext_getfreesize
	#define GET_sysext_getfreesize(fl)  CAL_CMGETAPI( "sysext_getfreesize" ) 
	#define CAL_sysext_getfreesize  sysext_getfreesize
	#define CHK_sysext_getfreesize  TRUE
	#define EXP_sysext_getfreesize  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_getfreesize", (RTS_UINTPTR)sysext_getfreesize, 1, 0x3BB3D489, 0x01000200) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtsysext_getfreesize
	#define EXT_WagoTscSysExtsysext_getfreesize
	#define GET_WagoTscSysExtsysext_getfreesize  ERR_OK
	#define CAL_WagoTscSysExtsysext_getfreesize  sysext_getfreesize
	#define CHK_WagoTscSysExtsysext_getfreesize  TRUE
	#define EXP_WagoTscSysExtsysext_getfreesize  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_getfreesize", (RTS_UINTPTR)sysext_getfreesize, 1, 0x3BB3D489, 0x01000200) 
#elif defined(CPLUSPLUS)
	#define USE_sysext_getfreesize
	#define EXT_sysext_getfreesize
	#define GET_sysext_getfreesize(fl)  CAL_CMGETAPI( "sysext_getfreesize" ) 
	#define CAL_sysext_getfreesize  sysext_getfreesize
	#define CHK_sysext_getfreesize  TRUE
	#define EXP_sysext_getfreesize  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_getfreesize", (RTS_UINTPTR)sysext_getfreesize, 1, 0x3BB3D489, 0x01000200) 
#else /* DYNAMIC_LINK */
	#define USE_sysext_getfreesize  PFSYSEXT_GETFREESIZE_IEC pfsysext_getfreesize;
	#define EXT_sysext_getfreesize  extern PFSYSEXT_GETFREESIZE_IEC pfsysext_getfreesize;
	#define GET_sysext_getfreesize(fl)  s_pfCMGetAPI2( "sysext_getfreesize", (RTS_VOID_FCTPTR *)&pfsysext_getfreesize, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3BB3D489, 0x01000200)
	#define CAL_sysext_getfreesize  pfsysext_getfreesize
	#define CHK_sysext_getfreesize  (pfsysext_getfreesize != NULL)
	#define EXP_sysext_getfreesize   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"sysext_getfreesize", (RTS_UINTPTR)sysext_getfreesize, 1, 0x3BB3D489, 0x01000200) 
#endif



/**
 * <description>internal_atomic_add_32</description>
 */
typedef struct taginternal_atomic_add_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_DINT diValue;       /* VAR_INPUT */ /* adding value */
  RTS_IEC_UDINT Internal_Atomic_ADD_32; /* VAR_OUTPUT */  
} internal_atomic_add_32_struct;

void CDECL CDECL_EXT internal_atomic_add_32(internal_atomic_add_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_ADD_32_IEC) (internal_atomic_add_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_ADD_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_add_32
	#define EXT_internal_atomic_add_32
	#define GET_internal_atomic_add_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_add_32(p0) 
	#define CHK_internal_atomic_add_32  FALSE
	#define EXP_internal_atomic_add_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_add_32
	#define EXT_internal_atomic_add_32
	#define GET_internal_atomic_add_32(fl)  CAL_CMGETAPI( "internal_atomic_add_32" ) 
	#define CAL_internal_atomic_add_32  internal_atomic_add_32
	#define CHK_internal_atomic_add_32  TRUE
	#define EXP_internal_atomic_add_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_32", (RTS_UINTPTR)internal_atomic_add_32, 1, 0x4553D542, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_add_32 {(RTS_VOID_FCTPTR)internal_atomic_add_32, "internal_atomic_add_32", 0x4553D542, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_add_32
	#define EXT_internal_atomic_add_32
	#define GET_internal_atomic_add_32(fl)  CAL_CMGETAPI( "internal_atomic_add_32" ) 
	#define CAL_internal_atomic_add_32  internal_atomic_add_32
	#define CHK_internal_atomic_add_32  TRUE
	#define EXP_internal_atomic_add_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_32", (RTS_UINTPTR)internal_atomic_add_32, 1, 0x4553D542, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_add_32
	#define EXT_WagoTscSysExtinternal_atomic_add_32
	#define GET_WagoTscSysExtinternal_atomic_add_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_add_32  internal_atomic_add_32
	#define CHK_WagoTscSysExtinternal_atomic_add_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_add_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_32", (RTS_UINTPTR)internal_atomic_add_32, 1, 0x4553D542, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_add_32
	#define EXT_internal_atomic_add_32
	#define GET_internal_atomic_add_32(fl)  CAL_CMGETAPI( "internal_atomic_add_32" ) 
	#define CAL_internal_atomic_add_32  internal_atomic_add_32
	#define CHK_internal_atomic_add_32  TRUE
	#define EXP_internal_atomic_add_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_32", (RTS_UINTPTR)internal_atomic_add_32, 1, 0x4553D542, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_add_32  PFINTERNAL_ATOMIC_ADD_32_IEC pfinternal_atomic_add_32;
	#define EXT_internal_atomic_add_32  extern PFINTERNAL_ATOMIC_ADD_32_IEC pfinternal_atomic_add_32;
	#define GET_internal_atomic_add_32(fl)  s_pfCMGetAPI2( "internal_atomic_add_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_add_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x4553D542, 0x01000000)
	#define CAL_internal_atomic_add_32  pfinternal_atomic_add_32
	#define CHK_internal_atomic_add_32  (pfinternal_atomic_add_32 != NULL)
	#define EXP_internal_atomic_add_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_32", (RTS_UINTPTR)internal_atomic_add_32, 1, 0x4553D542, 0x01000000) 
#endif


/**
 * <description>internal_atomic_add_ptr</description>
 */
typedef struct taginternal_atomic_add_ptr_struct
{
  RTS_IEC_BYTE **pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_DINT diValue;       /* VAR_INPUT */ /* adding value */
  RTS_IEC_BYTE *Internal_Atomic_ADD_ptr;  /* VAR_OUTPUT */  
} internal_atomic_add_ptr_struct;

void CDECL CDECL_EXT internal_atomic_add_ptr(internal_atomic_add_ptr_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_ADD_PTR_IEC) (internal_atomic_add_ptr_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_ADD_PTR_NOTIMPLEMENTED)
	#define USE_internal_atomic_add_ptr
	#define EXT_internal_atomic_add_ptr
	#define GET_internal_atomic_add_ptr(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_add_ptr(p0) 
	#define CHK_internal_atomic_add_ptr  FALSE
	#define EXP_internal_atomic_add_ptr  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_add_ptr
	#define EXT_internal_atomic_add_ptr
	#define GET_internal_atomic_add_ptr(fl)  CAL_CMGETAPI( "internal_atomic_add_ptr" ) 
	#define CAL_internal_atomic_add_ptr  internal_atomic_add_ptr
	#define CHK_internal_atomic_add_ptr  TRUE
	#define EXP_internal_atomic_add_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_ptr", (RTS_UINTPTR)internal_atomic_add_ptr, 1, 0xC32754DC, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_add_ptr {(RTS_VOID_FCTPTR)internal_atomic_add_ptr, "internal_atomic_add_ptr", 0xC32754DC, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_add_ptr
	#define EXT_internal_atomic_add_ptr
	#define GET_internal_atomic_add_ptr(fl)  CAL_CMGETAPI( "internal_atomic_add_ptr" ) 
	#define CAL_internal_atomic_add_ptr  internal_atomic_add_ptr
	#define CHK_internal_atomic_add_ptr  TRUE
	#define EXP_internal_atomic_add_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_ptr", (RTS_UINTPTR)internal_atomic_add_ptr, 1, 0xC32754DC, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_add_ptr
	#define EXT_WagoTscSysExtinternal_atomic_add_ptr
	#define GET_WagoTscSysExtinternal_atomic_add_ptr  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_add_ptr  internal_atomic_add_ptr
	#define CHK_WagoTscSysExtinternal_atomic_add_ptr  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_add_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_ptr", (RTS_UINTPTR)internal_atomic_add_ptr, 1, 0xC32754DC, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_add_ptr
	#define EXT_internal_atomic_add_ptr
	#define GET_internal_atomic_add_ptr(fl)  CAL_CMGETAPI( "internal_atomic_add_ptr" ) 
	#define CAL_internal_atomic_add_ptr  internal_atomic_add_ptr
	#define CHK_internal_atomic_add_ptr  TRUE
	#define EXP_internal_atomic_add_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_ptr", (RTS_UINTPTR)internal_atomic_add_ptr, 1, 0xC32754DC, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_add_ptr  PFINTERNAL_ATOMIC_ADD_PTR_IEC pfinternal_atomic_add_ptr;
	#define EXT_internal_atomic_add_ptr  extern PFINTERNAL_ATOMIC_ADD_PTR_IEC pfinternal_atomic_add_ptr;
	#define GET_internal_atomic_add_ptr(fl)  s_pfCMGetAPI2( "internal_atomic_add_ptr", (RTS_VOID_FCTPTR *)&pfinternal_atomic_add_ptr, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC32754DC, 0x01000000)
	#define CAL_internal_atomic_add_ptr  pfinternal_atomic_add_ptr
	#define CHK_internal_atomic_add_ptr  (pfinternal_atomic_add_ptr != NULL)
	#define EXP_internal_atomic_add_ptr   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_add_ptr", (RTS_UINTPTR)internal_atomic_add_ptr, 1, 0xC32754DC, 0x01000000) 
#endif


/**
 * <description>internal_atomic_and_32</description>
 */
typedef struct taginternal_atomic_and_32_struct
{
  RTS_IEC_DWORD *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_DWORD dwValue;        /* VAR_INPUT */ /* set value */
  RTS_IEC_DWORD Internal_Atomic_AND_32; /* VAR_OUTPUT */  
} internal_atomic_and_32_struct;

void CDECL CDECL_EXT internal_atomic_and_32(internal_atomic_and_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_AND_32_IEC) (internal_atomic_and_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_AND_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_and_32
	#define EXT_internal_atomic_and_32
	#define GET_internal_atomic_and_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_and_32(p0) 
	#define CHK_internal_atomic_and_32  FALSE
	#define EXP_internal_atomic_and_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_and_32
	#define EXT_internal_atomic_and_32
	#define GET_internal_atomic_and_32(fl)  CAL_CMGETAPI( "internal_atomic_and_32" ) 
	#define CAL_internal_atomic_and_32  internal_atomic_and_32
	#define CHK_internal_atomic_and_32  TRUE
	#define EXP_internal_atomic_and_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_and_32", (RTS_UINTPTR)internal_atomic_and_32, 1, 0x0C258DD7, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_and_32 {(RTS_VOID_FCTPTR)internal_atomic_and_32, "internal_atomic_and_32", 0x0C258DD7, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_and_32
	#define EXT_internal_atomic_and_32
	#define GET_internal_atomic_and_32(fl)  CAL_CMGETAPI( "internal_atomic_and_32" ) 
	#define CAL_internal_atomic_and_32  internal_atomic_and_32
	#define CHK_internal_atomic_and_32  TRUE
	#define EXP_internal_atomic_and_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_and_32", (RTS_UINTPTR)internal_atomic_and_32, 1, 0x0C258DD7, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_and_32
	#define EXT_WagoTscSysExtinternal_atomic_and_32
	#define GET_WagoTscSysExtinternal_atomic_and_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_and_32  internal_atomic_and_32
	#define CHK_WagoTscSysExtinternal_atomic_and_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_and_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_and_32", (RTS_UINTPTR)internal_atomic_and_32, 1, 0x0C258DD7, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_and_32
	#define EXT_internal_atomic_and_32
	#define GET_internal_atomic_and_32(fl)  CAL_CMGETAPI( "internal_atomic_and_32" ) 
	#define CAL_internal_atomic_and_32  internal_atomic_and_32
	#define CHK_internal_atomic_and_32  TRUE
	#define EXP_internal_atomic_and_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_and_32", (RTS_UINTPTR)internal_atomic_and_32, 1, 0x0C258DD7, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_and_32  PFINTERNAL_ATOMIC_AND_32_IEC pfinternal_atomic_and_32;
	#define EXT_internal_atomic_and_32  extern PFINTERNAL_ATOMIC_AND_32_IEC pfinternal_atomic_and_32;
	#define GET_internal_atomic_and_32(fl)  s_pfCMGetAPI2( "internal_atomic_and_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_and_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0C258DD7, 0x01000000)
	#define CAL_internal_atomic_and_32  pfinternal_atomic_and_32
	#define CHK_internal_atomic_and_32  (pfinternal_atomic_and_32 != NULL)
	#define EXP_internal_atomic_and_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_and_32", (RTS_UINTPTR)internal_atomic_and_32, 1, 0x0C258DD7, 0x01000000) 
#endif


/**
 * <description>internal_atomic_cas_32</description>
 */
typedef struct taginternal_atomic_cas_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_UDINT udiProbe;       /* VAR_INPUT */ /* probe value */
  RTS_IEC_UDINT udiValue;       /* VAR_INPUT */ /* set value */
  RTS_IEC_BOOL Internal_Atomic_CAS_32;  /* VAR_OUTPUT */  /* 1 = EXECUTED */
} internal_atomic_cas_32_struct;

void CDECL CDECL_EXT internal_atomic_cas_32(internal_atomic_cas_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_CAS_32_IEC) (internal_atomic_cas_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_CAS_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_cas_32
	#define EXT_internal_atomic_cas_32
	#define GET_internal_atomic_cas_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_cas_32(p0) 
	#define CHK_internal_atomic_cas_32  FALSE
	#define EXP_internal_atomic_cas_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_cas_32
	#define EXT_internal_atomic_cas_32
	#define GET_internal_atomic_cas_32(fl)  CAL_CMGETAPI( "internal_atomic_cas_32" ) 
	#define CAL_internal_atomic_cas_32  internal_atomic_cas_32
	#define CHK_internal_atomic_cas_32  TRUE
	#define EXP_internal_atomic_cas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_32", (RTS_UINTPTR)internal_atomic_cas_32, 1, 0x33C6F648, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_cas_32 {(RTS_VOID_FCTPTR)internal_atomic_cas_32, "internal_atomic_cas_32", 0x33C6F648, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_cas_32
	#define EXT_internal_atomic_cas_32
	#define GET_internal_atomic_cas_32(fl)  CAL_CMGETAPI( "internal_atomic_cas_32" ) 
	#define CAL_internal_atomic_cas_32  internal_atomic_cas_32
	#define CHK_internal_atomic_cas_32  TRUE
	#define EXP_internal_atomic_cas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_32", (RTS_UINTPTR)internal_atomic_cas_32, 1, 0x33C6F648, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_cas_32
	#define EXT_WagoTscSysExtinternal_atomic_cas_32
	#define GET_WagoTscSysExtinternal_atomic_cas_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_cas_32  internal_atomic_cas_32
	#define CHK_WagoTscSysExtinternal_atomic_cas_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_cas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_32", (RTS_UINTPTR)internal_atomic_cas_32, 1, 0x33C6F648, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_cas_32
	#define EXT_internal_atomic_cas_32
	#define GET_internal_atomic_cas_32(fl)  CAL_CMGETAPI( "internal_atomic_cas_32" ) 
	#define CAL_internal_atomic_cas_32  internal_atomic_cas_32
	#define CHK_internal_atomic_cas_32  TRUE
	#define EXP_internal_atomic_cas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_32", (RTS_UINTPTR)internal_atomic_cas_32, 1, 0x33C6F648, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_cas_32  PFINTERNAL_ATOMIC_CAS_32_IEC pfinternal_atomic_cas_32;
	#define EXT_internal_atomic_cas_32  extern PFINTERNAL_ATOMIC_CAS_32_IEC pfinternal_atomic_cas_32;
	#define GET_internal_atomic_cas_32(fl)  s_pfCMGetAPI2( "internal_atomic_cas_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_cas_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x33C6F648, 0x01000000)
	#define CAL_internal_atomic_cas_32  pfinternal_atomic_cas_32
	#define CHK_internal_atomic_cas_32  (pfinternal_atomic_cas_32 != NULL)
	#define EXP_internal_atomic_cas_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_32", (RTS_UINTPTR)internal_atomic_cas_32, 1, 0x33C6F648, 0x01000000) 
#endif


/**
 * <description>internal_atomic_cas_64</description>
 */
typedef struct taginternal_atomic_cas_64_struct
{
  RTS_IEC_ULINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_ULINT uliProbe;       /* VAR_INPUT */ /* probe value */
  RTS_IEC_ULINT uliValue;       /* VAR_INPUT */ /* set value */
  RTS_IEC_BOOL Internal_Atomic_CAS_64;  /* VAR_OUTPUT */  /* 1 = EXECUTED */
} internal_atomic_cas_64_struct;

void CDECL CDECL_EXT internal_atomic_cas_64(internal_atomic_cas_64_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_CAS_64_IEC) (internal_atomic_cas_64_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_CAS_64_NOTIMPLEMENTED)
	#define USE_internal_atomic_cas_64
	#define EXT_internal_atomic_cas_64
	#define GET_internal_atomic_cas_64(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_cas_64(p0) 
	#define CHK_internal_atomic_cas_64  FALSE
	#define EXP_internal_atomic_cas_64  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_cas_64
	#define EXT_internal_atomic_cas_64
	#define GET_internal_atomic_cas_64(fl)  CAL_CMGETAPI( "internal_atomic_cas_64" ) 
	#define CAL_internal_atomic_cas_64  internal_atomic_cas_64
	#define CHK_internal_atomic_cas_64  TRUE
	#define EXP_internal_atomic_cas_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_64", (RTS_UINTPTR)internal_atomic_cas_64, 1, 0x754AACCB, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_cas_64 {(RTS_VOID_FCTPTR)internal_atomic_cas_64, "internal_atomic_cas_64", 0x754AACCB, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_cas_64
	#define EXT_internal_atomic_cas_64
	#define GET_internal_atomic_cas_64(fl)  CAL_CMGETAPI( "internal_atomic_cas_64" ) 
	#define CAL_internal_atomic_cas_64  internal_atomic_cas_64
	#define CHK_internal_atomic_cas_64  TRUE
	#define EXP_internal_atomic_cas_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_64", (RTS_UINTPTR)internal_atomic_cas_64, 1, 0x754AACCB, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_cas_64
	#define EXT_WagoTscSysExtinternal_atomic_cas_64
	#define GET_WagoTscSysExtinternal_atomic_cas_64  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_cas_64  internal_atomic_cas_64
	#define CHK_WagoTscSysExtinternal_atomic_cas_64  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_cas_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_64", (RTS_UINTPTR)internal_atomic_cas_64, 1, 0x754AACCB, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_cas_64
	#define EXT_internal_atomic_cas_64
	#define GET_internal_atomic_cas_64(fl)  CAL_CMGETAPI( "internal_atomic_cas_64" ) 
	#define CAL_internal_atomic_cas_64  internal_atomic_cas_64
	#define CHK_internal_atomic_cas_64  TRUE
	#define EXP_internal_atomic_cas_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_64", (RTS_UINTPTR)internal_atomic_cas_64, 1, 0x754AACCB, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_cas_64  PFINTERNAL_ATOMIC_CAS_64_IEC pfinternal_atomic_cas_64;
	#define EXT_internal_atomic_cas_64  extern PFINTERNAL_ATOMIC_CAS_64_IEC pfinternal_atomic_cas_64;
	#define GET_internal_atomic_cas_64(fl)  s_pfCMGetAPI2( "internal_atomic_cas_64", (RTS_VOID_FCTPTR *)&pfinternal_atomic_cas_64, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x754AACCB, 0x01000000)
	#define CAL_internal_atomic_cas_64  pfinternal_atomic_cas_64
	#define CHK_internal_atomic_cas_64  (pfinternal_atomic_cas_64 != NULL)
	#define EXP_internal_atomic_cas_64   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_64", (RTS_UINTPTR)internal_atomic_cas_64, 1, 0x754AACCB, 0x01000000) 
#endif


/**
 * <description>internal_atomic_cas_ptr</description>
 */
typedef struct taginternal_atomic_cas_ptr_struct
{
  RTS_IEC_BYTE **pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_BYTE *pProbe;       /* VAR_INPUT */ /* probe value */
  RTS_IEC_BYTE *pValue;       /* VAR_INPUT */ /* set value */
  RTS_IEC_BOOL Internal_Atomic_CAS_ptr; /* VAR_OUTPUT */  /* 1 = EXECUTED */
} internal_atomic_cas_ptr_struct;

void CDECL CDECL_EXT internal_atomic_cas_ptr(internal_atomic_cas_ptr_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_CAS_PTR_IEC) (internal_atomic_cas_ptr_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_CAS_PTR_NOTIMPLEMENTED)
	#define USE_internal_atomic_cas_ptr
	#define EXT_internal_atomic_cas_ptr
	#define GET_internal_atomic_cas_ptr(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_cas_ptr(p0) 
	#define CHK_internal_atomic_cas_ptr  FALSE
	#define EXP_internal_atomic_cas_ptr  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_cas_ptr
	#define EXT_internal_atomic_cas_ptr
	#define GET_internal_atomic_cas_ptr(fl)  CAL_CMGETAPI( "internal_atomic_cas_ptr" ) 
	#define CAL_internal_atomic_cas_ptr  internal_atomic_cas_ptr
	#define CHK_internal_atomic_cas_ptr  TRUE
	#define EXP_internal_atomic_cas_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_ptr", (RTS_UINTPTR)internal_atomic_cas_ptr, 1, 0x0419BF66, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_cas_ptr {(RTS_VOID_FCTPTR)internal_atomic_cas_ptr, "internal_atomic_cas_ptr", 0x0419BF66, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_cas_ptr
	#define EXT_internal_atomic_cas_ptr
	#define GET_internal_atomic_cas_ptr(fl)  CAL_CMGETAPI( "internal_atomic_cas_ptr" ) 
	#define CAL_internal_atomic_cas_ptr  internal_atomic_cas_ptr
	#define CHK_internal_atomic_cas_ptr  TRUE
	#define EXP_internal_atomic_cas_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_ptr", (RTS_UINTPTR)internal_atomic_cas_ptr, 1, 0x0419BF66, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_cas_ptr
	#define EXT_WagoTscSysExtinternal_atomic_cas_ptr
	#define GET_WagoTscSysExtinternal_atomic_cas_ptr  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_cas_ptr  internal_atomic_cas_ptr
	#define CHK_WagoTscSysExtinternal_atomic_cas_ptr  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_cas_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_ptr", (RTS_UINTPTR)internal_atomic_cas_ptr, 1, 0x0419BF66, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_cas_ptr
	#define EXT_internal_atomic_cas_ptr
	#define GET_internal_atomic_cas_ptr(fl)  CAL_CMGETAPI( "internal_atomic_cas_ptr" ) 
	#define CAL_internal_atomic_cas_ptr  internal_atomic_cas_ptr
	#define CHK_internal_atomic_cas_ptr  TRUE
	#define EXP_internal_atomic_cas_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_ptr", (RTS_UINTPTR)internal_atomic_cas_ptr, 1, 0x0419BF66, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_cas_ptr  PFINTERNAL_ATOMIC_CAS_PTR_IEC pfinternal_atomic_cas_ptr;
	#define EXT_internal_atomic_cas_ptr  extern PFINTERNAL_ATOMIC_CAS_PTR_IEC pfinternal_atomic_cas_ptr;
	#define GET_internal_atomic_cas_ptr(fl)  s_pfCMGetAPI2( "internal_atomic_cas_ptr", (RTS_VOID_FCTPTR *)&pfinternal_atomic_cas_ptr, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0419BF66, 0x01000000)
	#define CAL_internal_atomic_cas_ptr  pfinternal_atomic_cas_ptr
	#define CHK_internal_atomic_cas_ptr  (pfinternal_atomic_cas_ptr != NULL)
	#define EXP_internal_atomic_cas_ptr   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_cas_ptr", (RTS_UINTPTR)internal_atomic_cas_ptr, 1, 0x0419BF66, 0x01000000) 
#endif


/**
 * <description>internal_atomic_or_32</description>
 */
typedef struct taginternal_atomic_or_32_struct
{
  RTS_IEC_DWORD *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_DWORD dwValue;        /* VAR_INPUT */ /* set value */
  RTS_IEC_DWORD Internal_Atomic_OR_32;  /* VAR_OUTPUT */  
} internal_atomic_or_32_struct;

void CDECL CDECL_EXT internal_atomic_or_32(internal_atomic_or_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_OR_32_IEC) (internal_atomic_or_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_OR_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_or_32
	#define EXT_internal_atomic_or_32
	#define GET_internal_atomic_or_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_or_32(p0) 
	#define CHK_internal_atomic_or_32  FALSE
	#define EXP_internal_atomic_or_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_or_32
	#define EXT_internal_atomic_or_32
	#define GET_internal_atomic_or_32(fl)  CAL_CMGETAPI( "internal_atomic_or_32" ) 
	#define CAL_internal_atomic_or_32  internal_atomic_or_32
	#define CHK_internal_atomic_or_32  TRUE
	#define EXP_internal_atomic_or_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_or_32", (RTS_UINTPTR)internal_atomic_or_32, 1, 0x3B260D64, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_or_32 {(RTS_VOID_FCTPTR)internal_atomic_or_32, "internal_atomic_or_32", 0x3B260D64, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_or_32
	#define EXT_internal_atomic_or_32
	#define GET_internal_atomic_or_32(fl)  CAL_CMGETAPI( "internal_atomic_or_32" ) 
	#define CAL_internal_atomic_or_32  internal_atomic_or_32
	#define CHK_internal_atomic_or_32  TRUE
	#define EXP_internal_atomic_or_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_or_32", (RTS_UINTPTR)internal_atomic_or_32, 1, 0x3B260D64, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_or_32
	#define EXT_WagoTscSysExtinternal_atomic_or_32
	#define GET_WagoTscSysExtinternal_atomic_or_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_or_32  internal_atomic_or_32
	#define CHK_WagoTscSysExtinternal_atomic_or_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_or_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_or_32", (RTS_UINTPTR)internal_atomic_or_32, 1, 0x3B260D64, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_or_32
	#define EXT_internal_atomic_or_32
	#define GET_internal_atomic_or_32(fl)  CAL_CMGETAPI( "internal_atomic_or_32" ) 
	#define CAL_internal_atomic_or_32  internal_atomic_or_32
	#define CHK_internal_atomic_or_32  TRUE
	#define EXP_internal_atomic_or_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_or_32", (RTS_UINTPTR)internal_atomic_or_32, 1, 0x3B260D64, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_or_32  PFINTERNAL_ATOMIC_OR_32_IEC pfinternal_atomic_or_32;
	#define EXT_internal_atomic_or_32  extern PFINTERNAL_ATOMIC_OR_32_IEC pfinternal_atomic_or_32;
	#define GET_internal_atomic_or_32(fl)  s_pfCMGetAPI2( "internal_atomic_or_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_or_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3B260D64, 0x01000000)
	#define CAL_internal_atomic_or_32  pfinternal_atomic_or_32
	#define CHK_internal_atomic_or_32  (pfinternal_atomic_or_32 != NULL)
	#define EXP_internal_atomic_or_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_or_32", (RTS_UINTPTR)internal_atomic_or_32, 1, 0x3B260D64, 0x01000000) 
#endif


/**
 * <description>internal_atomic_read_32</description>
 */
typedef struct taginternal_atomic_read_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_UDINT Internal_Atomic_READ_32;  /* VAR_OUTPUT */  
} internal_atomic_read_32_struct;

void CDECL CDECL_EXT internal_atomic_read_32(internal_atomic_read_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_READ_32_IEC) (internal_atomic_read_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_READ_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_read_32
	#define EXT_internal_atomic_read_32
	#define GET_internal_atomic_read_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_read_32(p0) 
	#define CHK_internal_atomic_read_32  FALSE
	#define EXP_internal_atomic_read_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_read_32
	#define EXT_internal_atomic_read_32
	#define GET_internal_atomic_read_32(fl)  CAL_CMGETAPI( "internal_atomic_read_32" ) 
	#define CAL_internal_atomic_read_32  internal_atomic_read_32
	#define CHK_internal_atomic_read_32  TRUE
	#define EXP_internal_atomic_read_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_32", (RTS_UINTPTR)internal_atomic_read_32, 1, 0x49EF1EB6, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_read_32 {(RTS_VOID_FCTPTR)internal_atomic_read_32, "internal_atomic_read_32", 0x49EF1EB6, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_read_32
	#define EXT_internal_atomic_read_32
	#define GET_internal_atomic_read_32(fl)  CAL_CMGETAPI( "internal_atomic_read_32" ) 
	#define CAL_internal_atomic_read_32  internal_atomic_read_32
	#define CHK_internal_atomic_read_32  TRUE
	#define EXP_internal_atomic_read_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_32", (RTS_UINTPTR)internal_atomic_read_32, 1, 0x49EF1EB6, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_read_32
	#define EXT_WagoTscSysExtinternal_atomic_read_32
	#define GET_WagoTscSysExtinternal_atomic_read_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_read_32  internal_atomic_read_32
	#define CHK_WagoTscSysExtinternal_atomic_read_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_read_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_32", (RTS_UINTPTR)internal_atomic_read_32, 1, 0x49EF1EB6, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_read_32
	#define EXT_internal_atomic_read_32
	#define GET_internal_atomic_read_32(fl)  CAL_CMGETAPI( "internal_atomic_read_32" ) 
	#define CAL_internal_atomic_read_32  internal_atomic_read_32
	#define CHK_internal_atomic_read_32  TRUE
	#define EXP_internal_atomic_read_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_32", (RTS_UINTPTR)internal_atomic_read_32, 1, 0x49EF1EB6, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_read_32  PFINTERNAL_ATOMIC_READ_32_IEC pfinternal_atomic_read_32;
	#define EXT_internal_atomic_read_32  extern PFINTERNAL_ATOMIC_READ_32_IEC pfinternal_atomic_read_32;
	#define GET_internal_atomic_read_32(fl)  s_pfCMGetAPI2( "internal_atomic_read_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_read_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x49EF1EB6, 0x01000000)
	#define CAL_internal_atomic_read_32  pfinternal_atomic_read_32
	#define CHK_internal_atomic_read_32  (pfinternal_atomic_read_32 != NULL)
	#define EXP_internal_atomic_read_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_32", (RTS_UINTPTR)internal_atomic_read_32, 1, 0x49EF1EB6, 0x01000000) 
#endif


/**
 * <description>internal_atomic_read_64</description>
 */
typedef struct taginternal_atomic_read_64_struct
{
  RTS_IEC_ULINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_ULINT Internal_Atomic_READ_64;  /* VAR_OUTPUT */  
} internal_atomic_read_64_struct;

void CDECL CDECL_EXT internal_atomic_read_64(internal_atomic_read_64_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_READ_64_IEC) (internal_atomic_read_64_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_READ_64_NOTIMPLEMENTED)
	#define USE_internal_atomic_read_64
	#define EXT_internal_atomic_read_64
	#define GET_internal_atomic_read_64(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_read_64(p0) 
	#define CHK_internal_atomic_read_64  FALSE
	#define EXP_internal_atomic_read_64  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_read_64
	#define EXT_internal_atomic_read_64
	#define GET_internal_atomic_read_64(fl)  CAL_CMGETAPI( "internal_atomic_read_64" ) 
	#define CAL_internal_atomic_read_64  internal_atomic_read_64
	#define CHK_internal_atomic_read_64  TRUE
	#define EXP_internal_atomic_read_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_64", (RTS_UINTPTR)internal_atomic_read_64, 1, 0xDB1BA57B, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_read_64 {(RTS_VOID_FCTPTR)internal_atomic_read_64, "internal_atomic_read_64", 0xDB1BA57B, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_read_64
	#define EXT_internal_atomic_read_64
	#define GET_internal_atomic_read_64(fl)  CAL_CMGETAPI( "internal_atomic_read_64" ) 
	#define CAL_internal_atomic_read_64  internal_atomic_read_64
	#define CHK_internal_atomic_read_64  TRUE
	#define EXP_internal_atomic_read_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_64", (RTS_UINTPTR)internal_atomic_read_64, 1, 0xDB1BA57B, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_read_64
	#define EXT_WagoTscSysExtinternal_atomic_read_64
	#define GET_WagoTscSysExtinternal_atomic_read_64  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_read_64  internal_atomic_read_64
	#define CHK_WagoTscSysExtinternal_atomic_read_64  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_read_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_64", (RTS_UINTPTR)internal_atomic_read_64, 1, 0xDB1BA57B, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_read_64
	#define EXT_internal_atomic_read_64
	#define GET_internal_atomic_read_64(fl)  CAL_CMGETAPI( "internal_atomic_read_64" ) 
	#define CAL_internal_atomic_read_64  internal_atomic_read_64
	#define CHK_internal_atomic_read_64  TRUE
	#define EXP_internal_atomic_read_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_64", (RTS_UINTPTR)internal_atomic_read_64, 1, 0xDB1BA57B, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_read_64  PFINTERNAL_ATOMIC_READ_64_IEC pfinternal_atomic_read_64;
	#define EXT_internal_atomic_read_64  extern PFINTERNAL_ATOMIC_READ_64_IEC pfinternal_atomic_read_64;
	#define GET_internal_atomic_read_64(fl)  s_pfCMGetAPI2( "internal_atomic_read_64", (RTS_VOID_FCTPTR *)&pfinternal_atomic_read_64, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDB1BA57B, 0x01000000)
	#define CAL_internal_atomic_read_64  pfinternal_atomic_read_64
	#define CHK_internal_atomic_read_64  (pfinternal_atomic_read_64 != NULL)
	#define EXP_internal_atomic_read_64   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_64", (RTS_UINTPTR)internal_atomic_read_64, 1, 0xDB1BA57B, 0x01000000) 
#endif


/**
 * <description>internal_atomic_read_ptr</description>
 */
typedef struct taginternal_atomic_read_ptr_struct
{
  RTS_IEC_BYTE **pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_BYTE *Internal_Atomic_READ_ptr; /* VAR_OUTPUT */  
} internal_atomic_read_ptr_struct;

void CDECL CDECL_EXT internal_atomic_read_ptr(internal_atomic_read_ptr_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_READ_PTR_IEC) (internal_atomic_read_ptr_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_READ_PTR_NOTIMPLEMENTED)
	#define USE_internal_atomic_read_ptr
	#define EXT_internal_atomic_read_ptr
	#define GET_internal_atomic_read_ptr(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_read_ptr(p0) 
	#define CHK_internal_atomic_read_ptr  FALSE
	#define EXP_internal_atomic_read_ptr  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_read_ptr
	#define EXT_internal_atomic_read_ptr
	#define GET_internal_atomic_read_ptr(fl)  CAL_CMGETAPI( "internal_atomic_read_ptr" ) 
	#define CAL_internal_atomic_read_ptr  internal_atomic_read_ptr
	#define CHK_internal_atomic_read_ptr  TRUE
	#define EXP_internal_atomic_read_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_ptr", (RTS_UINTPTR)internal_atomic_read_ptr, 1, 0x897AEAD6, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_read_ptr {(RTS_VOID_FCTPTR)internal_atomic_read_ptr, "internal_atomic_read_ptr", 0x897AEAD6, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_read_ptr
	#define EXT_internal_atomic_read_ptr
	#define GET_internal_atomic_read_ptr(fl)  CAL_CMGETAPI( "internal_atomic_read_ptr" ) 
	#define CAL_internal_atomic_read_ptr  internal_atomic_read_ptr
	#define CHK_internal_atomic_read_ptr  TRUE
	#define EXP_internal_atomic_read_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_ptr", (RTS_UINTPTR)internal_atomic_read_ptr, 1, 0x897AEAD6, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_read_ptr
	#define EXT_WagoTscSysExtinternal_atomic_read_ptr
	#define GET_WagoTscSysExtinternal_atomic_read_ptr  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_read_ptr  internal_atomic_read_ptr
	#define CHK_WagoTscSysExtinternal_atomic_read_ptr  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_read_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_ptr", (RTS_UINTPTR)internal_atomic_read_ptr, 1, 0x897AEAD6, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_read_ptr
	#define EXT_internal_atomic_read_ptr
	#define GET_internal_atomic_read_ptr(fl)  CAL_CMGETAPI( "internal_atomic_read_ptr" ) 
	#define CAL_internal_atomic_read_ptr  internal_atomic_read_ptr
	#define CHK_internal_atomic_read_ptr  TRUE
	#define EXP_internal_atomic_read_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_ptr", (RTS_UINTPTR)internal_atomic_read_ptr, 1, 0x897AEAD6, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_read_ptr  PFINTERNAL_ATOMIC_READ_PTR_IEC pfinternal_atomic_read_ptr;
	#define EXT_internal_atomic_read_ptr  extern PFINTERNAL_ATOMIC_READ_PTR_IEC pfinternal_atomic_read_ptr;
	#define GET_internal_atomic_read_ptr(fl)  s_pfCMGetAPI2( "internal_atomic_read_ptr", (RTS_VOID_FCTPTR *)&pfinternal_atomic_read_ptr, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x897AEAD6, 0x01000000)
	#define CAL_internal_atomic_read_ptr  pfinternal_atomic_read_ptr
	#define CHK_internal_atomic_read_ptr  (pfinternal_atomic_read_ptr != NULL)
	#define EXP_internal_atomic_read_ptr   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_read_ptr", (RTS_UINTPTR)internal_atomic_read_ptr, 1, 0x897AEAD6, 0x01000000) 
#endif


/**
 * <description>internal_atomic_swap_32</description>
 */
typedef struct taginternal_atomic_swap_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_UDINT udiValue;       /* VAR_INPUT */ /* set calue */
  RTS_IEC_UDINT Internal_Atomic_SWAP_32;  /* VAR_OUTPUT */  
} internal_atomic_swap_32_struct;

void CDECL CDECL_EXT internal_atomic_swap_32(internal_atomic_swap_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_SWAP_32_IEC) (internal_atomic_swap_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_SWAP_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_swap_32
	#define EXT_internal_atomic_swap_32
	#define GET_internal_atomic_swap_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_swap_32(p0) 
	#define CHK_internal_atomic_swap_32  FALSE
	#define EXP_internal_atomic_swap_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_swap_32
	#define EXT_internal_atomic_swap_32
	#define GET_internal_atomic_swap_32(fl)  CAL_CMGETAPI( "internal_atomic_swap_32" ) 
	#define CAL_internal_atomic_swap_32  internal_atomic_swap_32
	#define CHK_internal_atomic_swap_32  TRUE
	#define EXP_internal_atomic_swap_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_32", (RTS_UINTPTR)internal_atomic_swap_32, 1, 0x74B9BA02, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_swap_32 {(RTS_VOID_FCTPTR)internal_atomic_swap_32, "internal_atomic_swap_32", 0x74B9BA02, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_swap_32
	#define EXT_internal_atomic_swap_32
	#define GET_internal_atomic_swap_32(fl)  CAL_CMGETAPI( "internal_atomic_swap_32" ) 
	#define CAL_internal_atomic_swap_32  internal_atomic_swap_32
	#define CHK_internal_atomic_swap_32  TRUE
	#define EXP_internal_atomic_swap_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_32", (RTS_UINTPTR)internal_atomic_swap_32, 1, 0x74B9BA02, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_swap_32
	#define EXT_WagoTscSysExtinternal_atomic_swap_32
	#define GET_WagoTscSysExtinternal_atomic_swap_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_swap_32  internal_atomic_swap_32
	#define CHK_WagoTscSysExtinternal_atomic_swap_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_swap_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_32", (RTS_UINTPTR)internal_atomic_swap_32, 1, 0x74B9BA02, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_swap_32
	#define EXT_internal_atomic_swap_32
	#define GET_internal_atomic_swap_32(fl)  CAL_CMGETAPI( "internal_atomic_swap_32" ) 
	#define CAL_internal_atomic_swap_32  internal_atomic_swap_32
	#define CHK_internal_atomic_swap_32  TRUE
	#define EXP_internal_atomic_swap_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_32", (RTS_UINTPTR)internal_atomic_swap_32, 1, 0x74B9BA02, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_swap_32  PFINTERNAL_ATOMIC_SWAP_32_IEC pfinternal_atomic_swap_32;
	#define EXT_internal_atomic_swap_32  extern PFINTERNAL_ATOMIC_SWAP_32_IEC pfinternal_atomic_swap_32;
	#define GET_internal_atomic_swap_32(fl)  s_pfCMGetAPI2( "internal_atomic_swap_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_swap_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x74B9BA02, 0x01000000)
	#define CAL_internal_atomic_swap_32  pfinternal_atomic_swap_32
	#define CHK_internal_atomic_swap_32  (pfinternal_atomic_swap_32 != NULL)
	#define EXP_internal_atomic_swap_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_32", (RTS_UINTPTR)internal_atomic_swap_32, 1, 0x74B9BA02, 0x01000000) 
#endif


/**
 * <description>internal_atomic_swap_64</description>
 */
typedef struct taginternal_atomic_swap_64_struct
{
  RTS_IEC_ULINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_ULINT uliValue;       /* VAR_INPUT */ /* set calue */
  RTS_IEC_ULINT Internal_Atomic_SWAP_64;  /* VAR_OUTPUT */  
} internal_atomic_swap_64_struct;

void CDECL CDECL_EXT internal_atomic_swap_64(internal_atomic_swap_64_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_SWAP_64_IEC) (internal_atomic_swap_64_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_SWAP_64_NOTIMPLEMENTED)
	#define USE_internal_atomic_swap_64
	#define EXT_internal_atomic_swap_64
	#define GET_internal_atomic_swap_64(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_swap_64(p0) 
	#define CHK_internal_atomic_swap_64  FALSE
	#define EXP_internal_atomic_swap_64  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_swap_64
	#define EXT_internal_atomic_swap_64
	#define GET_internal_atomic_swap_64(fl)  CAL_CMGETAPI( "internal_atomic_swap_64" ) 
	#define CAL_internal_atomic_swap_64  internal_atomic_swap_64
	#define CHK_internal_atomic_swap_64  TRUE
	#define EXP_internal_atomic_swap_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_64", (RTS_UINTPTR)internal_atomic_swap_64, 1, 0xC5263B22, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_swap_64 {(RTS_VOID_FCTPTR)internal_atomic_swap_64, "internal_atomic_swap_64", 0xC5263B22, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_swap_64
	#define EXT_internal_atomic_swap_64
	#define GET_internal_atomic_swap_64(fl)  CAL_CMGETAPI( "internal_atomic_swap_64" ) 
	#define CAL_internal_atomic_swap_64  internal_atomic_swap_64
	#define CHK_internal_atomic_swap_64  TRUE
	#define EXP_internal_atomic_swap_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_64", (RTS_UINTPTR)internal_atomic_swap_64, 1, 0xC5263B22, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_swap_64
	#define EXT_WagoTscSysExtinternal_atomic_swap_64
	#define GET_WagoTscSysExtinternal_atomic_swap_64  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_swap_64  internal_atomic_swap_64
	#define CHK_WagoTscSysExtinternal_atomic_swap_64  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_swap_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_64", (RTS_UINTPTR)internal_atomic_swap_64, 1, 0xC5263B22, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_swap_64
	#define EXT_internal_atomic_swap_64
	#define GET_internal_atomic_swap_64(fl)  CAL_CMGETAPI( "internal_atomic_swap_64" ) 
	#define CAL_internal_atomic_swap_64  internal_atomic_swap_64
	#define CHK_internal_atomic_swap_64  TRUE
	#define EXP_internal_atomic_swap_64  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_64", (RTS_UINTPTR)internal_atomic_swap_64, 1, 0xC5263B22, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_swap_64  PFINTERNAL_ATOMIC_SWAP_64_IEC pfinternal_atomic_swap_64;
	#define EXT_internal_atomic_swap_64  extern PFINTERNAL_ATOMIC_SWAP_64_IEC pfinternal_atomic_swap_64;
	#define GET_internal_atomic_swap_64(fl)  s_pfCMGetAPI2( "internal_atomic_swap_64", (RTS_VOID_FCTPTR *)&pfinternal_atomic_swap_64, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xC5263B22, 0x01000000)
	#define CAL_internal_atomic_swap_64  pfinternal_atomic_swap_64
	#define CHK_internal_atomic_swap_64  (pfinternal_atomic_swap_64 != NULL)
	#define EXP_internal_atomic_swap_64   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_64", (RTS_UINTPTR)internal_atomic_swap_64, 1, 0xC5263B22, 0x01000000) 
#endif


/**
 * <description>internal_atomic_swap_ptr</description>
 */
typedef struct taginternal_atomic_swap_ptr_struct
{
  RTS_IEC_BYTE **pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_BYTE *pValue;       /* VAR_INPUT */ /* set calue */
  RTS_IEC_BYTE *Internal_Atomic_SWAP_ptr; /* VAR_OUTPUT */  
} internal_atomic_swap_ptr_struct;

void CDECL CDECL_EXT internal_atomic_swap_ptr(internal_atomic_swap_ptr_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_SWAP_PTR_IEC) (internal_atomic_swap_ptr_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_SWAP_PTR_NOTIMPLEMENTED)
	#define USE_internal_atomic_swap_ptr
	#define EXT_internal_atomic_swap_ptr
	#define GET_internal_atomic_swap_ptr(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_swap_ptr(p0) 
	#define CHK_internal_atomic_swap_ptr  FALSE
	#define EXP_internal_atomic_swap_ptr  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_swap_ptr
	#define EXT_internal_atomic_swap_ptr
	#define GET_internal_atomic_swap_ptr(fl)  CAL_CMGETAPI( "internal_atomic_swap_ptr" ) 
	#define CAL_internal_atomic_swap_ptr  internal_atomic_swap_ptr
	#define CHK_internal_atomic_swap_ptr  TRUE
	#define EXP_internal_atomic_swap_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_ptr", (RTS_UINTPTR)internal_atomic_swap_ptr, 1, 0x9406527A, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_swap_ptr {(RTS_VOID_FCTPTR)internal_atomic_swap_ptr, "internal_atomic_swap_ptr", 0x9406527A, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_swap_ptr
	#define EXT_internal_atomic_swap_ptr
	#define GET_internal_atomic_swap_ptr(fl)  CAL_CMGETAPI( "internal_atomic_swap_ptr" ) 
	#define CAL_internal_atomic_swap_ptr  internal_atomic_swap_ptr
	#define CHK_internal_atomic_swap_ptr  TRUE
	#define EXP_internal_atomic_swap_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_ptr", (RTS_UINTPTR)internal_atomic_swap_ptr, 1, 0x9406527A, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_swap_ptr
	#define EXT_WagoTscSysExtinternal_atomic_swap_ptr
	#define GET_WagoTscSysExtinternal_atomic_swap_ptr  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_swap_ptr  internal_atomic_swap_ptr
	#define CHK_WagoTscSysExtinternal_atomic_swap_ptr  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_swap_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_ptr", (RTS_UINTPTR)internal_atomic_swap_ptr, 1, 0x9406527A, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_swap_ptr
	#define EXT_internal_atomic_swap_ptr
	#define GET_internal_atomic_swap_ptr(fl)  CAL_CMGETAPI( "internal_atomic_swap_ptr" ) 
	#define CAL_internal_atomic_swap_ptr  internal_atomic_swap_ptr
	#define CHK_internal_atomic_swap_ptr  TRUE
	#define EXP_internal_atomic_swap_ptr  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_ptr", (RTS_UINTPTR)internal_atomic_swap_ptr, 1, 0x9406527A, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_swap_ptr  PFINTERNAL_ATOMIC_SWAP_PTR_IEC pfinternal_atomic_swap_ptr;
	#define EXT_internal_atomic_swap_ptr  extern PFINTERNAL_ATOMIC_SWAP_PTR_IEC pfinternal_atomic_swap_ptr;
	#define GET_internal_atomic_swap_ptr(fl)  s_pfCMGetAPI2( "internal_atomic_swap_ptr", (RTS_VOID_FCTPTR *)&pfinternal_atomic_swap_ptr, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9406527A, 0x01000000)
	#define CAL_internal_atomic_swap_ptr  pfinternal_atomic_swap_ptr
	#define CHK_internal_atomic_swap_ptr  (pfinternal_atomic_swap_ptr != NULL)
	#define EXP_internal_atomic_swap_ptr   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_swap_ptr", (RTS_UINTPTR)internal_atomic_swap_ptr, 1, 0x9406527A, 0x01000000) 
#endif


/**
 * <description>internal_atomic_tar_32</description>
 */
typedef struct taginternal_atomic_tar_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_UDINT udiBitNo;       /* VAR_INPUT */ 
  RTS_IEC_BOOL Internal_Atomic_TAR_32;  /* VAR_OUTPUT */  
} internal_atomic_tar_32_struct;

void CDECL CDECL_EXT internal_atomic_tar_32(internal_atomic_tar_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_TAR_32_IEC) (internal_atomic_tar_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_TAR_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_tar_32
	#define EXT_internal_atomic_tar_32
	#define GET_internal_atomic_tar_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_tar_32(p0) 
	#define CHK_internal_atomic_tar_32  FALSE
	#define EXP_internal_atomic_tar_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_tar_32
	#define EXT_internal_atomic_tar_32
	#define GET_internal_atomic_tar_32(fl)  CAL_CMGETAPI( "internal_atomic_tar_32" ) 
	#define CAL_internal_atomic_tar_32  internal_atomic_tar_32
	#define CHK_internal_atomic_tar_32  TRUE
	#define EXP_internal_atomic_tar_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tar_32", (RTS_UINTPTR)internal_atomic_tar_32, 1, 0x0FD26AEF, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_tar_32 {(RTS_VOID_FCTPTR)internal_atomic_tar_32, "internal_atomic_tar_32", 0x0FD26AEF, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_tar_32
	#define EXT_internal_atomic_tar_32
	#define GET_internal_atomic_tar_32(fl)  CAL_CMGETAPI( "internal_atomic_tar_32" ) 
	#define CAL_internal_atomic_tar_32  internal_atomic_tar_32
	#define CHK_internal_atomic_tar_32  TRUE
	#define EXP_internal_atomic_tar_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tar_32", (RTS_UINTPTR)internal_atomic_tar_32, 1, 0x0FD26AEF, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_tar_32
	#define EXT_WagoTscSysExtinternal_atomic_tar_32
	#define GET_WagoTscSysExtinternal_atomic_tar_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_tar_32  internal_atomic_tar_32
	#define CHK_WagoTscSysExtinternal_atomic_tar_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_tar_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tar_32", (RTS_UINTPTR)internal_atomic_tar_32, 1, 0x0FD26AEF, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_tar_32
	#define EXT_internal_atomic_tar_32
	#define GET_internal_atomic_tar_32(fl)  CAL_CMGETAPI( "internal_atomic_tar_32" ) 
	#define CAL_internal_atomic_tar_32  internal_atomic_tar_32
	#define CHK_internal_atomic_tar_32  TRUE
	#define EXP_internal_atomic_tar_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tar_32", (RTS_UINTPTR)internal_atomic_tar_32, 1, 0x0FD26AEF, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_tar_32  PFINTERNAL_ATOMIC_TAR_32_IEC pfinternal_atomic_tar_32;
	#define EXT_internal_atomic_tar_32  extern PFINTERNAL_ATOMIC_TAR_32_IEC pfinternal_atomic_tar_32;
	#define GET_internal_atomic_tar_32(fl)  s_pfCMGetAPI2( "internal_atomic_tar_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_tar_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x0FD26AEF, 0x01000000)
	#define CAL_internal_atomic_tar_32  pfinternal_atomic_tar_32
	#define CHK_internal_atomic_tar_32  (pfinternal_atomic_tar_32 != NULL)
	#define EXP_internal_atomic_tar_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tar_32", (RTS_UINTPTR)internal_atomic_tar_32, 1, 0x0FD26AEF, 0x01000000) 
#endif


/**
 * <description>internal_atomic_tas_32</description>
 */
typedef struct taginternal_atomic_tas_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_UDINT udiBitNo;       /* VAR_INPUT */ 
  RTS_IEC_BOOL Internal_Atomic_TAS_32;  /* VAR_OUTPUT */  
} internal_atomic_tas_32_struct;

void CDECL CDECL_EXT internal_atomic_tas_32(internal_atomic_tas_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_TAS_32_IEC) (internal_atomic_tas_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_TAS_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_tas_32
	#define EXT_internal_atomic_tas_32
	#define GET_internal_atomic_tas_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_tas_32(p0) 
	#define CHK_internal_atomic_tas_32  FALSE
	#define EXP_internal_atomic_tas_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_tas_32
	#define EXT_internal_atomic_tas_32
	#define GET_internal_atomic_tas_32(fl)  CAL_CMGETAPI( "internal_atomic_tas_32" ) 
	#define CAL_internal_atomic_tas_32  internal_atomic_tas_32
	#define CHK_internal_atomic_tas_32  TRUE
	#define EXP_internal_atomic_tas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tas_32", (RTS_UINTPTR)internal_atomic_tas_32, 1, 0x1B037469, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_tas_32 {(RTS_VOID_FCTPTR)internal_atomic_tas_32, "internal_atomic_tas_32", 0x1B037469, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_tas_32
	#define EXT_internal_atomic_tas_32
	#define GET_internal_atomic_tas_32(fl)  CAL_CMGETAPI( "internal_atomic_tas_32" ) 
	#define CAL_internal_atomic_tas_32  internal_atomic_tas_32
	#define CHK_internal_atomic_tas_32  TRUE
	#define EXP_internal_atomic_tas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tas_32", (RTS_UINTPTR)internal_atomic_tas_32, 1, 0x1B037469, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_tas_32
	#define EXT_WagoTscSysExtinternal_atomic_tas_32
	#define GET_WagoTscSysExtinternal_atomic_tas_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_tas_32  internal_atomic_tas_32
	#define CHK_WagoTscSysExtinternal_atomic_tas_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_tas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tas_32", (RTS_UINTPTR)internal_atomic_tas_32, 1, 0x1B037469, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_tas_32
	#define EXT_internal_atomic_tas_32
	#define GET_internal_atomic_tas_32(fl)  CAL_CMGETAPI( "internal_atomic_tas_32" ) 
	#define CAL_internal_atomic_tas_32  internal_atomic_tas_32
	#define CHK_internal_atomic_tas_32  TRUE
	#define EXP_internal_atomic_tas_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tas_32", (RTS_UINTPTR)internal_atomic_tas_32, 1, 0x1B037469, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_tas_32  PFINTERNAL_ATOMIC_TAS_32_IEC pfinternal_atomic_tas_32;
	#define EXT_internal_atomic_tas_32  extern PFINTERNAL_ATOMIC_TAS_32_IEC pfinternal_atomic_tas_32;
	#define GET_internal_atomic_tas_32(fl)  s_pfCMGetAPI2( "internal_atomic_tas_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_tas_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1B037469, 0x01000000)
	#define CAL_internal_atomic_tas_32  pfinternal_atomic_tas_32
	#define CHK_internal_atomic_tas_32  (pfinternal_atomic_tas_32 != NULL)
	#define EXP_internal_atomic_tas_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tas_32", (RTS_UINTPTR)internal_atomic_tas_32, 1, 0x1B037469, 0x01000000) 
#endif


/**
 * test and decrement 
 */
typedef struct taginternal_atomic_tdec_32_struct
{
  RTS_IEC_UDINT *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_UDINT Internal_Atomic_TDEC_32;  /* VAR_OUTPUT */  
} internal_atomic_tdec_32_struct;

void CDECL CDECL_EXT internal_atomic_tdec_32(internal_atomic_tdec_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_TDEC_32_IEC) (internal_atomic_tdec_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_TDEC_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_tdec_32
	#define EXT_internal_atomic_tdec_32
	#define GET_internal_atomic_tdec_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_tdec_32(p0) 
	#define CHK_internal_atomic_tdec_32  FALSE
	#define EXP_internal_atomic_tdec_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_tdec_32
	#define EXT_internal_atomic_tdec_32
	#define GET_internal_atomic_tdec_32(fl)  CAL_CMGETAPI( "internal_atomic_tdec_32" ) 
	#define CAL_internal_atomic_tdec_32  internal_atomic_tdec_32
	#define CHK_internal_atomic_tdec_32  TRUE
	#define EXP_internal_atomic_tdec_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tdec_32", (RTS_UINTPTR)internal_atomic_tdec_32, 1, 0x71B327DB, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_tdec_32 {(RTS_VOID_FCTPTR)internal_atomic_tdec_32, "internal_atomic_tdec_32", 0x71B327DB, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_tdec_32
	#define EXT_internal_atomic_tdec_32
	#define GET_internal_atomic_tdec_32(fl)  CAL_CMGETAPI( "internal_atomic_tdec_32" ) 
	#define CAL_internal_atomic_tdec_32  internal_atomic_tdec_32
	#define CHK_internal_atomic_tdec_32  TRUE
	#define EXP_internal_atomic_tdec_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tdec_32", (RTS_UINTPTR)internal_atomic_tdec_32, 1, 0x71B327DB, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_tdec_32
	#define EXT_WagoTscSysExtinternal_atomic_tdec_32
	#define GET_WagoTscSysExtinternal_atomic_tdec_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_tdec_32  internal_atomic_tdec_32
	#define CHK_WagoTscSysExtinternal_atomic_tdec_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_tdec_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tdec_32", (RTS_UINTPTR)internal_atomic_tdec_32, 1, 0x71B327DB, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_tdec_32
	#define EXT_internal_atomic_tdec_32
	#define GET_internal_atomic_tdec_32(fl)  CAL_CMGETAPI( "internal_atomic_tdec_32" ) 
	#define CAL_internal_atomic_tdec_32  internal_atomic_tdec_32
	#define CHK_internal_atomic_tdec_32  TRUE
	#define EXP_internal_atomic_tdec_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tdec_32", (RTS_UINTPTR)internal_atomic_tdec_32, 1, 0x71B327DB, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_tdec_32  PFINTERNAL_ATOMIC_TDEC_32_IEC pfinternal_atomic_tdec_32;
	#define EXT_internal_atomic_tdec_32  extern PFINTERNAL_ATOMIC_TDEC_32_IEC pfinternal_atomic_tdec_32;
	#define GET_internal_atomic_tdec_32(fl)  s_pfCMGetAPI2( "internal_atomic_tdec_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_tdec_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x71B327DB, 0x01000000)
	#define CAL_internal_atomic_tdec_32  pfinternal_atomic_tdec_32
	#define CHK_internal_atomic_tdec_32  (pfinternal_atomic_tdec_32 != NULL)
	#define EXP_internal_atomic_tdec_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_tdec_32", (RTS_UINTPTR)internal_atomic_tdec_32, 1, 0x71B327DB, 0x01000000) 
#endif


/**
 * <description>internal_atomic_xor_32</description>
 */
typedef struct taginternal_atomic_xor_32_struct
{
  RTS_IEC_DWORD *pVar;        /* VAR_INPUT */ /* variable with atomic access */
  RTS_IEC_DWORD dwValue;        /* VAR_INPUT */ /* set value */
  RTS_IEC_DWORD Internal_Atomic_XOR_32; /* VAR_OUTPUT */  
} internal_atomic_xor_32_struct;

void CDECL CDECL_EXT internal_atomic_xor_32(internal_atomic_xor_32_struct *p);
typedef void (CDECL CDECL_EXT* PFINTERNAL_ATOMIC_XOR_32_IEC) (internal_atomic_xor_32_struct *p);
#if defined(WAGOTSCSYSEXT_NOTIMPLEMENTED) || defined(INTERNAL_ATOMIC_XOR_32_NOTIMPLEMENTED)
	#define USE_internal_atomic_xor_32
	#define EXT_internal_atomic_xor_32
	#define GET_internal_atomic_xor_32(fl)  ERR_NOTIMPLEMENTED
	#define CAL_internal_atomic_xor_32(p0) 
	#define CHK_internal_atomic_xor_32  FALSE
	#define EXP_internal_atomic_xor_32  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_internal_atomic_xor_32
	#define EXT_internal_atomic_xor_32
	#define GET_internal_atomic_xor_32(fl)  CAL_CMGETAPI( "internal_atomic_xor_32" ) 
	#define CAL_internal_atomic_xor_32  internal_atomic_xor_32
	#define CHK_internal_atomic_xor_32  TRUE
	#define EXP_internal_atomic_xor_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_xor_32", (RTS_UINTPTR)internal_atomic_xor_32, 1, 0xDD012F14, 0x01000000) 
	#define EXTREF_ITF_internal_atomic_xor_32 {(RTS_VOID_FCTPTR)internal_atomic_xor_32, "internal_atomic_xor_32", 0xDD012F14, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOTSCSYSEXT_EXTERNAL)
	#define USE_internal_atomic_xor_32
	#define EXT_internal_atomic_xor_32
	#define GET_internal_atomic_xor_32(fl)  CAL_CMGETAPI( "internal_atomic_xor_32" ) 
	#define CAL_internal_atomic_xor_32  internal_atomic_xor_32
	#define CHK_internal_atomic_xor_32  TRUE
	#define EXP_internal_atomic_xor_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_xor_32", (RTS_UINTPTR)internal_atomic_xor_32, 1, 0xDD012F14, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoTscSysExtinternal_atomic_xor_32
	#define EXT_WagoTscSysExtinternal_atomic_xor_32
	#define GET_WagoTscSysExtinternal_atomic_xor_32  ERR_OK
	#define CAL_WagoTscSysExtinternal_atomic_xor_32  internal_atomic_xor_32
	#define CHK_WagoTscSysExtinternal_atomic_xor_32  TRUE
	#define EXP_WagoTscSysExtinternal_atomic_xor_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_xor_32", (RTS_UINTPTR)internal_atomic_xor_32, 1, 0xDD012F14, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_internal_atomic_xor_32
	#define EXT_internal_atomic_xor_32
	#define GET_internal_atomic_xor_32(fl)  CAL_CMGETAPI( "internal_atomic_xor_32" ) 
	#define CAL_internal_atomic_xor_32  internal_atomic_xor_32
	#define CHK_internal_atomic_xor_32  TRUE
	#define EXP_internal_atomic_xor_32  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_xor_32", (RTS_UINTPTR)internal_atomic_xor_32, 1, 0xDD012F14, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_internal_atomic_xor_32  PFINTERNAL_ATOMIC_XOR_32_IEC pfinternal_atomic_xor_32;
	#define EXT_internal_atomic_xor_32  extern PFINTERNAL_ATOMIC_XOR_32_IEC pfinternal_atomic_xor_32;
	#define GET_internal_atomic_xor_32(fl)  s_pfCMGetAPI2( "internal_atomic_xor_32", (RTS_VOID_FCTPTR *)&pfinternal_atomic_xor_32, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDD012F14, 0x01000000)
	#define CAL_internal_atomic_xor_32  pfinternal_atomic_xor_32
	#define CHK_internal_atomic_xor_32  (pfinternal_atomic_xor_32 != NULL)
	#define EXP_internal_atomic_xor_32   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"internal_atomic_xor_32", (RTS_UINTPTR)internal_atomic_xor_32, 1, 0xDD012F14, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoTscSysExt_C;

#ifdef CPLUSPLUS
class IWagoTscSysExt : public IBase
{
	public:
};
	#ifndef ITF_WagoTscSysExt
		#define ITF_WagoTscSysExt static IWagoTscSysExt *pIWagoTscSysExt = NULL;
	#endif
	#define EXTITF_WagoTscSysExt
#else	/*CPLUSPLUS*/
	typedef IWagoTscSysExt_C		IWagoTscSysExt;
	#ifndef ITF_WagoTscSysExt
		#define ITF_WagoTscSysExt
	#endif
	#define EXTITF_WagoTscSysExt
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOTSCSYSEXTITF_H_*/
