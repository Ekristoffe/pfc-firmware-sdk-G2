 /**
 * <interfacename>TscDrmIecInterface</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCDRMIECINTERFACEITF_H_
#define _TSCDRMIECINTERFACEITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: WagoDrmErrno</description>
 */
#define WAGODRMERRNO_SUCCESS    RTS_IEC_INT_C(0x0)	
#define WAGODRMERRNO_NULLPOINTERERROR    RTS_IEC_INT_C(0x1)	/* libwagodrm function error 1-99 */
#define WAGODRMERRNO_INTERNALERROR    RTS_IEC_INT_C(0x64)	/* DRM errors 100-199 */
#define WAGODRMERRNO_LICENSEKEYALREADYEXISTS    RTS_IEC_INT_C(0x65) 
#define WAGODRMERRNO_LICENSEKEYNOTTRANSFERABLE    RTS_IEC_INT_C(0x66) 
#define WAGODRMERRNO_STORAGETARGETNOTAVAILABLE    RTS_IEC_INT_C(0x67) 
#define WAGODRMERRNO_LICENSEKEYNOTVALID    RTS_IEC_INT_C(0x68)  
#define WAGODRMERRNO_EVALUATIONMODENOTEXTENDABLE    RTS_IEC_INT_C(0x69) 
#define WAGODRMERRNO_MAXIMUMLICENSEREACHED    RTS_IEC_INT_C(0x6A) 
#define WAGODRMERRNO_LICENSEINUSE    RTS_IEC_INT_C(0x6B)  
#define WAGODRMERRNO_LICENSELOCKED    RTS_IEC_INT_C(0x6C) 
#define WAGODRMERRNO_LICENSENOTFOUND    RTS_IEC_INT_C(0x6D) 
#define WAGODRMERRNO_INVALIDSTATE    RTS_IEC_INT_C(0x6E)  
#define WAGODRMERRNO_LICENSENOTCOVERED    RTS_IEC_INT_C(0x6F) 
#define WAGODRMERRNO_NOTENOUGHCREDITSAVAILABLE    RTS_IEC_INT_C(0x70) 
#define WAGODRMERRNO_FILEOPENFAILED    RTS_IEC_INT_C(0xC8)	/* System functions errors 200-299 */
#define WAGODRMERRNO_FILECLOSEFAILED    RTS_IEC_INT_C(0xC9) 
#define WAGODRMERRNO_IOCTLERROR    RTS_IEC_INT_C(0xCA)  
/* Typed enum definition */
#define WAGODRMERRNO    RTS_IEC_INT

/**
 *
 *
 ***Function**
 *
 *External function to allocate the given amount of credits of the given credit type.
 *
 */
typedef struct tagfuallocatecredits_struct
{
	RTS_IEC_BYTE bCreditType;			/* VAR_INPUT */	
	RTS_IEC_DWORD dwCreditAmount;		/* VAR_INPUT */	
	RTS_IEC_LWORD *lwGeneratedHandleNumber;	/* VAR_IN_OUT */	
	RTS_IEC_INT FuAllocateCredits;		/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fuallocatecredits_struct;

void CDECL CDECL_EXT fuallocatecredits(fuallocatecredits_struct *p);
typedef void (CDECL CDECL_EXT* PFFUALLOCATECREDITS_IEC) (fuallocatecredits_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FUALLOCATECREDITS_NOTIMPLEMENTED)
	#define USE_fuallocatecredits
	#define EXT_fuallocatecredits
	#define GET_fuallocatecredits(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuallocatecredits(p0) 
	#define CHK_fuallocatecredits  FALSE
	#define EXP_fuallocatecredits  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuallocatecredits
	#define EXT_fuallocatecredits
	#define GET_fuallocatecredits(fl)  CAL_CMGETAPI( "fuallocatecredits" ) 
	#define CAL_fuallocatecredits  fuallocatecredits
	#define CHK_fuallocatecredits  TRUE
	#define EXP_fuallocatecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuallocatecredits", (RTS_UINTPTR)fuallocatecredits, 1, 0x8DAF6873, 0x01000000) 
	#define EXTREF_ITF_fuallocatecredits {(RTS_VOID_FCTPTR)fuallocatecredits, "fuallocatecredits", 0x8DAF6873, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fuallocatecredits
	#define EXT_fuallocatecredits
	#define GET_fuallocatecredits(fl)  CAL_CMGETAPI( "fuallocatecredits" ) 
	#define CAL_fuallocatecredits  fuallocatecredits
	#define CHK_fuallocatecredits  TRUE
	#define EXP_fuallocatecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuallocatecredits", (RTS_UINTPTR)fuallocatecredits, 1, 0x8DAF6873, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefuallocatecredits
	#define EXT_TscDrmIecInterfacefuallocatecredits
	#define GET_TscDrmIecInterfacefuallocatecredits  ERR_OK
	#define CAL_TscDrmIecInterfacefuallocatecredits  fuallocatecredits
	#define CHK_TscDrmIecInterfacefuallocatecredits  TRUE
	#define EXP_TscDrmIecInterfacefuallocatecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuallocatecredits", (RTS_UINTPTR)fuallocatecredits, 1, 0x8DAF6873, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fuallocatecredits
	#define EXT_fuallocatecredits
	#define GET_fuallocatecredits(fl)  CAL_CMGETAPI( "fuallocatecredits" ) 
	#define CAL_fuallocatecredits  fuallocatecredits
	#define CHK_fuallocatecredits  TRUE
	#define EXP_fuallocatecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuallocatecredits", (RTS_UINTPTR)fuallocatecredits, 1, 0x8DAF6873, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fuallocatecredits  PFFUALLOCATECREDITS_IEC pffuallocatecredits;
	#define EXT_fuallocatecredits  extern PFFUALLOCATECREDITS_IEC pffuallocatecredits;
	#define GET_fuallocatecredits(fl)  s_pfCMGetAPI2( "fuallocatecredits", (RTS_VOID_FCTPTR *)&pffuallocatecredits, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8DAF6873, 0x01000000)
	#define CAL_fuallocatecredits  pffuallocatecredits
	#define CHK_fuallocatecredits  (pffuallocatecredits != NULL)
	#define EXP_fuallocatecredits   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuallocatecredits", (RTS_UINTPTR)fuallocatecredits, 1, 0x8DAF6873, 0x01000000) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to check if the given explicit license is covered or not
 *
 */
typedef struct tagfucheckexplicitlicense_struct
{
	RTS_IEC_BYTE bLicenseType;			/* VAR_INPUT */	
	RTS_IEC_WORD wLicenseCode;			/* VAR_INPUT */	
	RTS_IEC_LWORD *lwHandleNumber;		/* VAR_IN_OUT */	
	RTS_IEC_INT FuCheckExplicitLicense;	/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fucheckexplicitlicense_struct;

void CDECL CDECL_EXT fucheckexplicitlicense(fucheckexplicitlicense_struct *p);
typedef void (CDECL CDECL_EXT* PFFUCHECKEXPLICITLICENSE_IEC) (fucheckexplicitlicense_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FUCHECKEXPLICITLICENSE_NOTIMPLEMENTED)
	#define USE_fucheckexplicitlicense
	#define EXT_fucheckexplicitlicense
	#define GET_fucheckexplicitlicense(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fucheckexplicitlicense(p0) 
	#define CHK_fucheckexplicitlicense  FALSE
	#define EXP_fucheckexplicitlicense  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fucheckexplicitlicense
	#define EXT_fucheckexplicitlicense
	#define GET_fucheckexplicitlicense(fl)  CAL_CMGETAPI( "fucheckexplicitlicense" ) 
	#define CAL_fucheckexplicitlicense  fucheckexplicitlicense
	#define CHK_fucheckexplicitlicense  TRUE
	#define EXP_fucheckexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucheckexplicitlicense", (RTS_UINTPTR)fucheckexplicitlicense, 1, 0x7A6FE9B8, 0x01000000) 
	#define EXTREF_ITF_fucheckexplicitlicense {(RTS_VOID_FCTPTR)fucheckexplicitlicense, "fucheckexplicitlicense", 0x7A6FE9B8, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fucheckexplicitlicense
	#define EXT_fucheckexplicitlicense
	#define GET_fucheckexplicitlicense(fl)  CAL_CMGETAPI( "fucheckexplicitlicense" ) 
	#define CAL_fucheckexplicitlicense  fucheckexplicitlicense
	#define CHK_fucheckexplicitlicense  TRUE
	#define EXP_fucheckexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucheckexplicitlicense", (RTS_UINTPTR)fucheckexplicitlicense, 1, 0x7A6FE9B8, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefucheckexplicitlicense
	#define EXT_TscDrmIecInterfacefucheckexplicitlicense
	#define GET_TscDrmIecInterfacefucheckexplicitlicense  ERR_OK
	#define CAL_TscDrmIecInterfacefucheckexplicitlicense  fucheckexplicitlicense
	#define CHK_TscDrmIecInterfacefucheckexplicitlicense  TRUE
	#define EXP_TscDrmIecInterfacefucheckexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucheckexplicitlicense", (RTS_UINTPTR)fucheckexplicitlicense, 1, 0x7A6FE9B8, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fucheckexplicitlicense
	#define EXT_fucheckexplicitlicense
	#define GET_fucheckexplicitlicense(fl)  CAL_CMGETAPI( "fucheckexplicitlicense" ) 
	#define CAL_fucheckexplicitlicense  fucheckexplicitlicense
	#define CHK_fucheckexplicitlicense  TRUE
	#define EXP_fucheckexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucheckexplicitlicense", (RTS_UINTPTR)fucheckexplicitlicense, 1, 0x7A6FE9B8, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fucheckexplicitlicense  PFFUCHECKEXPLICITLICENSE_IEC pffucheckexplicitlicense;
	#define EXT_fucheckexplicitlicense  extern PFFUCHECKEXPLICITLICENSE_IEC pffucheckexplicitlicense;
	#define GET_fucheckexplicitlicense(fl)  s_pfCMGetAPI2( "fucheckexplicitlicense", (RTS_VOID_FCTPTR *)&pffucheckexplicitlicense, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7A6FE9B8, 0x01000000)
	#define CAL_fucheckexplicitlicense  pffucheckexplicitlicense
	#define CHK_fucheckexplicitlicense  (pffucheckexplicitlicense != NULL)
	#define EXP_fucheckexplicitlicense   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fucheckexplicitlicense", (RTS_UINTPTR)fucheckexplicitlicense, 1, 0x7A6FE9B8, 0x01000000) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to find if the given explicit license is covered or not
 *
 */
typedef struct tagfufindexplicitlicense_struct
{
	RTS_IEC_BYTE bLicenseType;			/* VAR_INPUT */	
	RTS_IEC_WORD wLicenseCode;			/* VAR_INPUT */	
	RTS_IEC_INT FuFindExplicitLicense;	/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fufindexplicitlicense_struct;

void CDECL CDECL_EXT fufindexplicitlicense(fufindexplicitlicense_struct *p);
typedef void (CDECL CDECL_EXT* PFFUFINDEXPLICITLICENSE_IEC) (fufindexplicitlicense_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FUFINDEXPLICITLICENSE_NOTIMPLEMENTED)
	#define USE_fufindexplicitlicense
	#define EXT_fufindexplicitlicense
	#define GET_fufindexplicitlicense(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fufindexplicitlicense(p0) 
	#define CHK_fufindexplicitlicense  FALSE
	#define EXP_fufindexplicitlicense  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fufindexplicitlicense
	#define EXT_fufindexplicitlicense
	#define GET_fufindexplicitlicense(fl)  CAL_CMGETAPI( "fufindexplicitlicense" ) 
	#define CAL_fufindexplicitlicense  fufindexplicitlicense
	#define CHK_fufindexplicitlicense  TRUE
	#define EXP_fufindexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fufindexplicitlicense", (RTS_UINTPTR)fufindexplicitlicense, 1, 0x5C49A561, 0x01000000) 
	#define EXTREF_ITF_fufindexplicitlicense {(RTS_VOID_FCTPTR)fufindexplicitlicense, "fufindexplicitlicense", 0x5C49A561, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fufindexplicitlicense
	#define EXT_fufindexplicitlicense
	#define GET_fufindexplicitlicense(fl)  CAL_CMGETAPI( "fufindexplicitlicense" ) 
	#define CAL_fufindexplicitlicense  fufindexplicitlicense
	#define CHK_fufindexplicitlicense  TRUE
	#define EXP_fufindexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fufindexplicitlicense", (RTS_UINTPTR)fufindexplicitlicense, 1, 0x5C49A561, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefufindexplicitlicense
	#define EXT_TscDrmIecInterfacefufindexplicitlicense
	#define GET_TscDrmIecInterfacefufindexplicitlicense  ERR_OK
	#define CAL_TscDrmIecInterfacefufindexplicitlicense  fufindexplicitlicense
	#define CHK_TscDrmIecInterfacefufindexplicitlicense  TRUE
	#define EXP_TscDrmIecInterfacefufindexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fufindexplicitlicense", (RTS_UINTPTR)fufindexplicitlicense, 1, 0x5C49A561, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fufindexplicitlicense
	#define EXT_fufindexplicitlicense
	#define GET_fufindexplicitlicense(fl)  CAL_CMGETAPI( "fufindexplicitlicense" ) 
	#define CAL_fufindexplicitlicense  fufindexplicitlicense
	#define CHK_fufindexplicitlicense  TRUE
	#define EXP_fufindexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fufindexplicitlicense", (RTS_UINTPTR)fufindexplicitlicense, 1, 0x5C49A561, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fufindexplicitlicense  PFFUFINDEXPLICITLICENSE_IEC pffufindexplicitlicense;
	#define EXT_fufindexplicitlicense  extern PFFUFINDEXPLICITLICENSE_IEC pffufindexplicitlicense;
	#define GET_fufindexplicitlicense(fl)  s_pfCMGetAPI2( "fufindexplicitlicense", (RTS_VOID_FCTPTR *)&pffufindexplicitlicense, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5C49A561, 0x01000000)
	#define CAL_fufindexplicitlicense  pffufindexplicitlicense
	#define CHK_fufindexplicitlicense  (pffufindexplicitlicense != NULL)
	#define EXP_fufindexplicitlicense   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fufindexplicitlicense", (RTS_UINTPTR)fufindexplicitlicense, 1, 0x5C49A561, 0x01000000) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to get the current balance from a specific credit type
 *returns DRMreturns DRM error code
 */
typedef struct tagfugetfreecredits_struct
{
	RTS_IEC_BYTE bCreditType;			/* VAR_INPUT */	
	RTS_IEC_DINT *dwFreeCredits;		/* VAR_IN_OUT */	
	RTS_IEC_INT FuGetFreeCredits;		/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fugetfreecredits_struct;

void CDECL CDECL_EXT fugetfreecredits(fugetfreecredits_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETFREECREDITS_IEC) (fugetfreecredits_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FUGETFREECREDITS_NOTIMPLEMENTED)
	#define USE_fugetfreecredits
	#define EXT_fugetfreecredits
	#define GET_fugetfreecredits(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetfreecredits(p0) 
	#define CHK_fugetfreecredits  FALSE
	#define EXP_fugetfreecredits  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetfreecredits
	#define EXT_fugetfreecredits
	#define GET_fugetfreecredits(fl)  CAL_CMGETAPI( "fugetfreecredits" ) 
	#define CAL_fugetfreecredits  fugetfreecredits
	#define CHK_fugetfreecredits  TRUE
	#define EXP_fugetfreecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetfreecredits", (RTS_UINTPTR)fugetfreecredits, 1, 0x3C22DF04, 0x01000000) 
	#define EXTREF_ITF_fugetfreecredits {(RTS_VOID_FCTPTR)fugetfreecredits, "fugetfreecredits", 0x3C22DF04, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fugetfreecredits
	#define EXT_fugetfreecredits
	#define GET_fugetfreecredits(fl)  CAL_CMGETAPI( "fugetfreecredits" ) 
	#define CAL_fugetfreecredits  fugetfreecredits
	#define CHK_fugetfreecredits  TRUE
	#define EXP_fugetfreecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetfreecredits", (RTS_UINTPTR)fugetfreecredits, 1, 0x3C22DF04, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefugetfreecredits
	#define EXT_TscDrmIecInterfacefugetfreecredits
	#define GET_TscDrmIecInterfacefugetfreecredits  ERR_OK
	#define CAL_TscDrmIecInterfacefugetfreecredits  fugetfreecredits
	#define CHK_TscDrmIecInterfacefugetfreecredits  TRUE
	#define EXP_TscDrmIecInterfacefugetfreecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetfreecredits", (RTS_UINTPTR)fugetfreecredits, 1, 0x3C22DF04, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fugetfreecredits
	#define EXT_fugetfreecredits
	#define GET_fugetfreecredits(fl)  CAL_CMGETAPI( "fugetfreecredits" ) 
	#define CAL_fugetfreecredits  fugetfreecredits
	#define CHK_fugetfreecredits  TRUE
	#define EXP_fugetfreecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetfreecredits", (RTS_UINTPTR)fugetfreecredits, 1, 0x3C22DF04, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fugetfreecredits  PFFUGETFREECREDITS_IEC pffugetfreecredits;
	#define EXT_fugetfreecredits  extern PFFUGETFREECREDITS_IEC pffugetfreecredits;
	#define GET_fugetfreecredits(fl)  s_pfCMGetAPI2( "fugetfreecredits", (RTS_VOID_FCTPTR *)&pffugetfreecredits, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x3C22DF04, 0x01000000)
	#define CAL_fugetfreecredits  pffugetfreecredits
	#define CHK_fugetfreecredits  (pffugetfreecredits != NULL)
	#define EXP_fugetfreecredits   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetfreecredits", (RTS_UINTPTR)fugetfreecredits, 1, 0x3C22DF04, 0x01000000) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to get the actual state of the device regarding the license management
 *
 */
typedef struct tagfugetlicensestate_struct
{
	RTS_IEC_WORD *wLicenseState;		/* VAR_IN_OUT */	
	RTS_IEC_DWORD *dwEvalTime;			/* VAR_IN_OUT */	
	RTS_IEC_INT FuGetLicenseState;		/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fugetlicensestate_struct;

void CDECL CDECL_EXT fugetlicensestate(fugetlicensestate_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETLICENSESTATE_IEC) (fugetlicensestate_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FUGETLICENSESTATE_NOTIMPLEMENTED)
	#define USE_fugetlicensestate
	#define EXT_fugetlicensestate
	#define GET_fugetlicensestate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetlicensestate(p0) 
	#define CHK_fugetlicensestate  FALSE
	#define EXP_fugetlicensestate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetlicensestate
	#define EXT_fugetlicensestate
	#define GET_fugetlicensestate(fl)  CAL_CMGETAPI( "fugetlicensestate" ) 
	#define CAL_fugetlicensestate  fugetlicensestate
	#define CHK_fugetlicensestate  TRUE
	#define EXP_fugetlicensestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlicensestate", (RTS_UINTPTR)fugetlicensestate, 1, 0xCF845D4E, 0x01000000) 
	#define EXTREF_ITF_fugetlicensestate {(RTS_VOID_FCTPTR)fugetlicensestate, "fugetlicensestate", 0xCF845D4E, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fugetlicensestate
	#define EXT_fugetlicensestate
	#define GET_fugetlicensestate(fl)  CAL_CMGETAPI( "fugetlicensestate" ) 
	#define CAL_fugetlicensestate  fugetlicensestate
	#define CHK_fugetlicensestate  TRUE
	#define EXP_fugetlicensestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlicensestate", (RTS_UINTPTR)fugetlicensestate, 1, 0xCF845D4E, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefugetlicensestate
	#define EXT_TscDrmIecInterfacefugetlicensestate
	#define GET_TscDrmIecInterfacefugetlicensestate  ERR_OK
	#define CAL_TscDrmIecInterfacefugetlicensestate  fugetlicensestate
	#define CHK_TscDrmIecInterfacefugetlicensestate  TRUE
	#define EXP_TscDrmIecInterfacefugetlicensestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlicensestate", (RTS_UINTPTR)fugetlicensestate, 1, 0xCF845D4E, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fugetlicensestate
	#define EXT_fugetlicensestate
	#define GET_fugetlicensestate(fl)  CAL_CMGETAPI( "fugetlicensestate" ) 
	#define CAL_fugetlicensestate  fugetlicensestate
	#define CHK_fugetlicensestate  TRUE
	#define EXP_fugetlicensestate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlicensestate", (RTS_UINTPTR)fugetlicensestate, 1, 0xCF845D4E, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fugetlicensestate  PFFUGETLICENSESTATE_IEC pffugetlicensestate;
	#define EXT_fugetlicensestate  extern PFFUGETLICENSESTATE_IEC pffugetlicensestate;
	#define GET_fugetlicensestate(fl)  s_pfCMGetAPI2( "fugetlicensestate", (RTS_VOID_FCTPTR *)&pffugetlicensestate, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCF845D4E, 0x01000000)
	#define CAL_fugetlicensestate  pffugetlicensestate
	#define CHK_fugetlicensestate  (pffugetlicensestate != NULL)
	#define EXP_fugetlicensestate   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetlicensestate", (RTS_UINTPTR)fugetlicensestate, 1, 0xCF845D4E, 0x01000000) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to release the specific amount of credits with the generated handle number
 *
 */
typedef struct tagfureleasecredits_struct
{
	RTS_IEC_LWORD lwHandleNumber;		/* VAR_INPUT */	
	RTS_IEC_INT FuReleaseCredits;		/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fureleasecredits_struct;

void CDECL CDECL_EXT fureleasecredits(fureleasecredits_struct *p);
typedef void (CDECL CDECL_EXT* PFFURELEASECREDITS_IEC) (fureleasecredits_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FURELEASECREDITS_NOTIMPLEMENTED)
	#define USE_fureleasecredits
	#define EXT_fureleasecredits
	#define GET_fureleasecredits(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fureleasecredits(p0) 
	#define CHK_fureleasecredits  FALSE
	#define EXP_fureleasecredits  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fureleasecredits
	#define EXT_fureleasecredits
	#define GET_fureleasecredits(fl)  CAL_CMGETAPI( "fureleasecredits" ) 
	#define CAL_fureleasecredits  fureleasecredits
	#define CHK_fureleasecredits  TRUE
	#define EXP_fureleasecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleasecredits", (RTS_UINTPTR)fureleasecredits, 1, 0x231650C8, 0x01000000) 
	#define EXTREF_ITF_fureleasecredits {(RTS_VOID_FCTPTR)fureleasecredits, "fureleasecredits", 0x231650C8, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fureleasecredits
	#define EXT_fureleasecredits
	#define GET_fureleasecredits(fl)  CAL_CMGETAPI( "fureleasecredits" ) 
	#define CAL_fureleasecredits  fureleasecredits
	#define CHK_fureleasecredits  TRUE
	#define EXP_fureleasecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleasecredits", (RTS_UINTPTR)fureleasecredits, 1, 0x231650C8, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefureleasecredits
	#define EXT_TscDrmIecInterfacefureleasecredits
	#define GET_TscDrmIecInterfacefureleasecredits  ERR_OK
	#define CAL_TscDrmIecInterfacefureleasecredits  fureleasecredits
	#define CHK_TscDrmIecInterfacefureleasecredits  TRUE
	#define EXP_TscDrmIecInterfacefureleasecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleasecredits", (RTS_UINTPTR)fureleasecredits, 1, 0x231650C8, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fureleasecredits
	#define EXT_fureleasecredits
	#define GET_fureleasecredits(fl)  CAL_CMGETAPI( "fureleasecredits" ) 
	#define CAL_fureleasecredits  fureleasecredits
	#define CHK_fureleasecredits  TRUE
	#define EXP_fureleasecredits  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleasecredits", (RTS_UINTPTR)fureleasecredits, 1, 0x231650C8, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fureleasecredits  PFFURELEASECREDITS_IEC pffureleasecredits;
	#define EXT_fureleasecredits  extern PFFURELEASECREDITS_IEC pffureleasecredits;
	#define GET_fureleasecredits(fl)  s_pfCMGetAPI2( "fureleasecredits", (RTS_VOID_FCTPTR *)&pffureleasecredits, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x231650C8, 0x01000000)
	#define CAL_fureleasecredits  pffureleasecredits
	#define CHK_fureleasecredits  (pffureleasecredits != NULL)
	#define EXP_fureleasecredits   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleasecredits", (RTS_UINTPTR)fureleasecredits, 1, 0x231650C8, 0x01000000) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to release the requested explicit license
 *
 */
typedef struct tagfureleaseexplicitlicense_struct
{
	RTS_IEC_BYTE bLicenseType;			/* VAR_INPUT */	
	RTS_IEC_WORD wLicenseCode;			/* VAR_INPUT */	
	RTS_IEC_LWORD lwHandleNumber;		/* VAR_INPUT */	
	RTS_IEC_INT FuReleaseExplicitLicense;	/* VAR_OUTPUT, Enum: WAGODRMERRNO */
} fureleaseexplicitlicense_struct;

void CDECL CDECL_EXT fureleaseexplicitlicense(fureleaseexplicitlicense_struct *p);
typedef void (CDECL CDECL_EXT* PFFURELEASEEXPLICITLICENSE_IEC) (fureleaseexplicitlicense_struct *p);
#if defined(TSCDRMIECINTERFACE_NOTIMPLEMENTED) || defined(FURELEASEEXPLICITLICENSE_NOTIMPLEMENTED)
	#define USE_fureleaseexplicitlicense
	#define EXT_fureleaseexplicitlicense
	#define GET_fureleaseexplicitlicense(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fureleaseexplicitlicense(p0) 
	#define CHK_fureleaseexplicitlicense  FALSE
	#define EXP_fureleaseexplicitlicense  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fureleaseexplicitlicense
	#define EXT_fureleaseexplicitlicense
	#define GET_fureleaseexplicitlicense(fl)  CAL_CMGETAPI( "fureleaseexplicitlicense" ) 
	#define CAL_fureleaseexplicitlicense  fureleaseexplicitlicense
	#define CHK_fureleaseexplicitlicense  TRUE
	#define EXP_fureleaseexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleaseexplicitlicense", (RTS_UINTPTR)fureleaseexplicitlicense, 1, 0x62E4726D, 0x01000000) 
	#define EXTREF_ITF_fureleaseexplicitlicense {(RTS_VOID_FCTPTR)fureleaseexplicitlicense, "fureleaseexplicitlicense", 0x62E4726D, 0x01000000}
#elif defined(MIXED_LINK) && !defined(TSCDRMIECINTERFACE_EXTERNAL)
	#define USE_fureleaseexplicitlicense
	#define EXT_fureleaseexplicitlicense
	#define GET_fureleaseexplicitlicense(fl)  CAL_CMGETAPI( "fureleaseexplicitlicense" ) 
	#define CAL_fureleaseexplicitlicense  fureleaseexplicitlicense
	#define CHK_fureleaseexplicitlicense  TRUE
	#define EXP_fureleaseexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleaseexplicitlicense", (RTS_UINTPTR)fureleaseexplicitlicense, 1, 0x62E4726D, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscDrmIecInterfacefureleaseexplicitlicense
	#define EXT_TscDrmIecInterfacefureleaseexplicitlicense
	#define GET_TscDrmIecInterfacefureleaseexplicitlicense  ERR_OK
	#define CAL_TscDrmIecInterfacefureleaseexplicitlicense  fureleaseexplicitlicense
	#define CHK_TscDrmIecInterfacefureleaseexplicitlicense  TRUE
	#define EXP_TscDrmIecInterfacefureleaseexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleaseexplicitlicense", (RTS_UINTPTR)fureleaseexplicitlicense, 1, 0x62E4726D, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fureleaseexplicitlicense
	#define EXT_fureleaseexplicitlicense
	#define GET_fureleaseexplicitlicense(fl)  CAL_CMGETAPI( "fureleaseexplicitlicense" ) 
	#define CAL_fureleaseexplicitlicense  fureleaseexplicitlicense
	#define CHK_fureleaseexplicitlicense  TRUE
	#define EXP_fureleaseexplicitlicense  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleaseexplicitlicense", (RTS_UINTPTR)fureleaseexplicitlicense, 1, 0x62E4726D, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fureleaseexplicitlicense  PFFURELEASEEXPLICITLICENSE_IEC pffureleaseexplicitlicense;
	#define EXT_fureleaseexplicitlicense  extern PFFURELEASEEXPLICITLICENSE_IEC pffureleaseexplicitlicense;
	#define GET_fureleaseexplicitlicense(fl)  s_pfCMGetAPI2( "fureleaseexplicitlicense", (RTS_VOID_FCTPTR *)&pffureleaseexplicitlicense, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x62E4726D, 0x01000000)
	#define CAL_fureleaseexplicitlicense  pffureleaseexplicitlicense
	#define CHK_fureleaseexplicitlicense  (pffureleaseexplicitlicense != NULL)
	#define EXP_fureleaseexplicitlicense   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fureleaseexplicitlicense", (RTS_UINTPTR)fureleaseexplicitlicense, 1, 0x62E4726D, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ITscDrmIecInterface_C;

#ifdef CPLUSPLUS
class ITscDrmIecInterface : public IBase
{
	public:
};
	#ifndef ITF_TscDrmIecInterface
		#define ITF_TscDrmIecInterface static ITscDrmIecInterface *pITscDrmIecInterface = NULL;
	#endif
	#define EXTITF_TscDrmIecInterface
#else	/*CPLUSPLUS*/
	typedef ITscDrmIecInterface_C		ITscDrmIecInterface;
	#ifndef ITF_TscDrmIecInterface
		#define ITF_TscDrmIecInterface
	#endif
	#define EXTITF_TscDrmIecInterface
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCDRMIECINTERFACEITF_H_*/
