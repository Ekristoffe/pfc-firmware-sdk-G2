//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dps_SYSI.h
///
///  \defgroup page_dps_sysi System Interface (SYSI)
///  \ingroup  page_dps_component
///
///  \version  $Id:
///
///  \brief    This module is the common interface of this component. It is possible to create and destroy objects of
///             the VIMO dpsMsgEngine. Before using of the created object is possible the activation after the
///             initialization is necessary.
///
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPS_SYSI_H
#define DPS_SYSI_H

//----------------------------------------------------------------------------------------------------------------------
// Global includes
//----------------------------------------------------------------------------------------------------------------------

#include "os_api.h"

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Macros
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup page_dps_sysi_definitions Definitions
///  \ingroup page_dps_sysi
///
///  These are the definitions of this module.
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_sysi_definitions
///
/// To create an extended error code the following macro can be used.
//----------------------------------------------------------------------------------------------------------------------
#define DPS_EXT_CODE(x) (((x) & 0x3FU) << 16U)

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup page_dps_sysi_data_types Data Types
///  \ingroup page_dps_sysi
///
///  These are the data types of this module.
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_sysi_data_types
///
/// The \ref dpsSettings_t structure describes the PROFIBUS DP application component settings.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /* priority of the dpsMsgEngine thread */
    uint32_t ulThreadPrio;
    /* maximum number of pending messages */
    uint32_t ulMaxNoOfMsgEntries;
    /* maximum number of supported slots */
    uint32_t ulNoOfSuppSlots;
    /** data length of the input process image in bytes */
    uint32_t ulMaxFbInpPiDataLenght;
    /** data length of the output process image in bytes */
    uint32_t ulMaxFbOutpPiDataLenght;
    /** configuration file path (e.g. /etc/specific/dps.conf) */
    char acConfigFilePath[50];
}dpsSettings_t;

//----------------------------------------------------------------------------------------------------------------------
// Global Variables
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dps_sysi_functions Functions
///  \ingroup page_dps_sysi
///
///   These are the functions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//-- Function: dps_Initialise ------------------------------------------------------------------------------------------
///  \ingroup page_dps_sysi_functions
///
///  This function creates a new object of the PROFIBUS DP application. The memory is allocated here. Additionally all
///   necessary internal initialisation are processed in this function. If something went wrong the handle is NULL
///   and no memory has been allocated.
///
///  \param   pstDpsSettings    settings of the component context
///
///  \return  object handle
//----------------------------------------------------------------------------------------------------------------------
status_t dps_Initialise (dpsSettings_t* pstDpsSettings);

//-- Function: dps_Activate --------------------------------------------------------------------------------------------
///  \ingroup page_dps_sysi_functions
///
///  This function activates the object functionality.
///
///  \return  \ref DPS_SUCCESS                 no error has occurred
///  \return  \ref DPS_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  \ref DPS_ERROR_NULL_POINTER      the object handle is invalid
///
//----------------------------------------------------------------------------------------------------------------------
status_t dps_Activate (void);

//-- Function: dps_Deactivate ------------------------------------------------------------------------------------------
///  \ingroup page_dps_sysi_functions
///
///  This function deactivates the object functionality.
///
///  \return  \ref DPS_SUCCESS                 no error has occurred
///  \return  \ref DPS_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  \ref DPS_ERROR_NULL_POINTER      the object handle is invalid
//----------------------------------------------------------------------------------------------------------------------
status_t dps_Deactivate (void);

//-- Function: dps_Release ---------------------------------------------------------------------------------------------
///  \ingroup page_dps_sysi_functions
///
///  This function destroys the object. The memory is released as well.
///
///  \return  \ref DPS_SUCCESS                 no error has occurred
///  \return  \ref DPS_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  \ref DPS_ERROR_NULL_POINTER      the object handle is invalid
//----------------------------------------------------------------------------------------------------------------------
status_t dps_Release (void);

#endif
//---- End of header ---------------------------------------------------------------------------------------------------
