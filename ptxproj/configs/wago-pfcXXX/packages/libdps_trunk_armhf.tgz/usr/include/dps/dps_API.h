//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dps_API.h
///
///  \defgroup page_dps_dps_api Application Programming Interface (API)
///  \ingroup  page_dps_component
///
///  \version  $Id:
///
///  \brief    This module is the API of the PROFIBUS DP application software component.
///
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPS_API_H
#define DPS_API_H

//----------------------------------------------------------------------------------------------------------------------
// Includes
//----------------------------------------------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>

#include <dal/sdi_stack_interface.h>

#include "os_api.h"

#include "dpsTypes.h"

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Global Variables
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup page_dps_dps_api_functions Functions
///  \ingroup page_dps_dps_api
///
///   These are the functions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//-- Function: libdps_open ---------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function initialises and activates the PROFIBUS DP slave application. By calling this functions the
///   interface functions "Initialise" and "Activate" are called automatically. Calling this function is mandatory
///   before using the API functions.
///
///  \param   pstSdiInterface        return pointer for the slave device interface description structure
///  \param   pstDalInterface        DAL interface description structure
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t libdps_open (tStackDeviceInterface* pstSdiInterface,
                     tDalSystemInterface* pstDalInterface);

//-- Function: dps_Close -----------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function deactivate and releases the PROFIBUS DP slave application. By calling this functions the
///   interface functions "Deactivate" and "Release" are called automatically.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_Close (void);


//-- Function: dps_ConfigureDevice -------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function configures the PROFIBUS DP slave application with the specified configuration data.
///
///  \param   confData    pointer to the configuration data structure
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_ConfigureDevice (void *confData);

//-- Function: dps_ReadStart -------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function indicates the start of reading fieldbus process image data. This is necessary to make the access to
///   the process data thread safe.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_ReadStart (void);

//-- Function: dps_ReadBit ---------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function reads the bit at the specified offset position out of the fieldbus output process image.
///   Only the specified bit will be manipulated in the specified data buffer.
///
///  \param   ulBitOffset   offset position in the fieldbus output process image of the bit to be read
///  \param   pucBuffer     pointer to the destination data buffer
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_ReadBit (uint32_t ulBitOffset,
                     uint8_t* pucBuffer);

//-- Function: dps_ReadBytes -------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function reads the byte at the specified offset position out of the fieldbus output process image.
///
///  \param   ulByteOffset  offset position in the fieldbus output process image of the byte to be read
///  \param   ulSize        number of bytes to be read
///  \param   pucBuffer     pointer to the destination data buffer
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_ReadBytes (uint32_t ulByteOffset,
                       uint32_t ulSize,
                       uint8_t* pucBuffer);

//-- Function: dps_ReadEnd ---------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function indicates the end of reading fieldbus process image data. This is necessary to release the access to
///   the process data for other threads.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_ReadEnd (void);

//-- Function: dps_WriteLock -------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function indicates the start of writing fieldbus process image data. This is necessary to make the access to
///   the process data thread safe.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WriteStart (void);

//-- Function: dps_WriteBit --------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function writes the bit at the specified offset position of the fieldbus input process image.
///
///  \param   ulBitOffset   offset position in the fieldbus input process image of the bit to be written
///  \param   pucBuffer     pointer to the source data buffer
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WriteBit (uint32_t ulBitOffset,
                      uint8_t* pucBuffer);

//-- Function: dps_WriteBytes ------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function writes the byte at the specified offset position of the fieldbus input process image.
///
///  \param   ulByteOffset  offset position in the fieldbus output process image of the byte to be written
///  \param   ulSize        number of bytes to be written
///  \param   pucBuffer     pointer to the source data buffer
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WriteBytes (uint32_t ulByteOffset,
                        uint32_t ulSize,
                        uint8_t* pucBuffer);

//-- Function: dps_WriteEnd --------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function indicates the end of writing fieldbus process image data. This is necessary to release the access to
///   the process data for other threads.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WriteEnd (void);

//-- Function: dps_WatchdogSetTime -------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function sets the watchdog timer properties.
///
///  \param   ulFactor      specifies the count of watchdog timeouts until an error should be recognized
///  \param   ulTimeoutUs   timeout time of the watchdog timer
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WatchdogSetTime (uint32_t ulFactor,
                             uint32_t ulTimeoutUs);

//-- Function: dps_WatchdogStart ---------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function starts the watchdog.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WatchdogStart (void);

//-- Function: dps_WatchdogStop ----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function stops the watchdog.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WatchdogStop (void);

//-- Function: dps_WatchdogTrigger -------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function triggers the watchdog.
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_WatchdogTrigger (void);

//-- Function: dps_ReportUserAppState ----------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function reports the user application state to PROFIBUS DP slave application. Depending on the reported state
///   the state of the device will change also.
///
///   The PROFIBUS DP slave application reactions are as follows:
///
///   - ApplicationState_Unconfigured -> device will be reseted
///   - ApplicationState_Running      -> PROFIBUS data exchange will be started (if it is possible)
///   - ApplicationState_Stoped       -> PROFIBUS data exchange will be stopped
///
///  \param   stApplicationStateChangedEvent      user application state
///
///  \return  The function returns 'DAL_SUCCESS' on success. The return value 'DAL_FAILURE' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
int32_t dps_ReportUserAppState (tApplicationStateChangedEvent stApplicationStateChangedEvent);

//-- Function: dps_GetDeviceSpecificFnList -----------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the device specific function description. This means the pointer to the relevant API
///   functions.
///
///  \return  The function returns the device specific function description.
//----------------------------------------------------------------------------------------------------------------------
tFnDescr* dps_GetDeviceSpecificFnList (void);

//-- Function: dps_GetDeviceState --------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the current device state.
///
///  \param   pucDevState      pointer to the memory where the current device state should be stored.
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetDeviceState (uint8_t* pucDevState);

//-- Function: dps_GetSysDiag ------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the currently active WAGO system diagnostic.
///
///  \param   pucSlot           pointer to the memory where the slot should be stored
///  \param   pucCode           pointer to the memory where the code should be stored
///  \param   pucArgument       pointer to the memory where the argument should be stored
///  \param   pucExtArgument    pointer to the memory where the extended error should be stored
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetSysDiag (uint8_t* pucSlot,
                         uint8_t* pucCode,
                         uint8_t* pucArgument,
                         uint8_t* pucExtArgument);

//-- Function: dps_GetIamDataset ---------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the I&M dataset specified by the dataset identification.
///
///  \param   ulDsId    identification of the dataset to be read
///  \param   pData     destination memory where the dataset data should be copied
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetIamDataset (uint32_t ulDsId,
                            void* pData);

//-- Function: dps_SetIamDataset ---------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function sets the data of the specified I&M data set. It is only possible to set the data of the I&M
///   datasets 1-4.
///
///  \param   ulDsId      identification number of the I&M data
///  \param   pData       pointer to the data to be written
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetIamDataset (uint32_t ulDsId,
                            void* pData);

//-- Function: dps_SendDiag --------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function sends the content of the station diagnostic telegram out of the diagnostic management to the
///   PROFIBUS master in the case that the parameter 'ucReq' is not 0. Additionally the function returns the
///   current diagnostic engine state by the parameter 'penmCurDiagEngState' as well as the diagnostic overflow
///   state.
///   If the parameter 'ucReq' is 0 only the current diagnostic engine state will be returned.
///
///  \param   ucReq                     unequal 0 performs a sending of the diagnostic telegram
///  \param   penmCurDiagEngState       return pointer for the current diagnostic engine state
///  \param   pucDiagOverflowState      return pointer for the diagnostics overflow state
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SendDiag (uint8_t ucReq,
                       diagEngState_t* penmCurDiagEngState,
                       uint8_t* pucDiagOverflowState);

//-- Function: dps_SetIdDiag -------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function sets the specified module state of the specified slot in the identification related diagnostic
///   object.
///
///  \param   ulSlot                    slot number
///  \param   enmIdRelDiagModState      module state
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetIdDiag (uint32_t ulSlot,
                        idRelDiagModState_t enmIdRelDiagModState);

//-- Function: dps_SetModuleStateDiag ----------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function sets the specified module state of the specified slot in the module status diagnostic
///   object.
///
///  \param   ulSlot                    slot number
///  \param   enmModuleState            module state
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetModStatDiag (uint32_t ulSlot,
                             modStatDiag_t enmModuleState);

//-- Function: dps_SetChanDiag -----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function generates a channel related diagnostic object with the specified properties in the diagnostic
///   management. With the returned diagnostic entry header it is possible to delete the entry later.
///
///  \param   ulSlot                    slot number
///  \param   ulChannel                 channel number
///  \param   enmChannelType            channel type
///  \param   enmChannelSize            channel size
///  \param   enmErrorType              error type
///  \param   enmDiagEntrySev           diagnostic entry severity
///  \param   ppDiagEntryHdl            return pointer for the diagnostic entry header
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetChanRelDiag (uint32_t ulSlot,
                             uint32_t ulChannel,
                             chanType_t enmChannelType,
                             chanSize_t enmChannelSize,
                             chanDiagErroType_t enmErrorType,
                             diagEntrySev_t enmDiagEntrySev,
                             void** ppDiagEntryHdl);

//-- Function: dps_RemoveChanRelDiag -----------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function removes the specified channel related diagnostic object out of the diagnostic management.
///   The object is specified by the entry handle.
///
///  \param   pDiagEntryHdl      handle of the channel related diagnostic object
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_RemoveChanRelDiag (void* pDiagEntryHdl);

//-- Function: dps_SetStatusMsg ----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function generates a status message diagnostic object in the diagnostic management. With the returned
///   diagnostic entry header it is possible to delete the entry later.
///
///  \param   ulSlot                    slot number
///  \param   enmStatusMsgType          status message type
///  \param   enmStatusMsgSpec          status message specifier
///  \param   pUsrData                  status message user data
///  \param   ulUsrDataLen              status message user data length (max. length is 4 byte)
///  \param   enmDiagEntrySev           diagnostic entry severity
///  \param   ppDiagEntryHdl            return pointer for the diagnostic entry header
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetStatusMsg (uint32_t ulSlot,
                           statusMsgType_t enmStatusMsgType,
                           statusMsgSpec_t enmStatusMsgSpec,
                           void* pUsrData,
                           uint32_t ulUsrDataLen,
                           diagEntrySev_t enmDiagEntrySev,
                           void** ppDiagEntryHdl);

//-- Function: dps_RemoveStatusMsg -------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function removes the specified status message diagnostic object out of the diagnostic management.
///   The object is specified by the entry handle.
///
///  \param   pDiagEntryHdl      handle of the status message diagnostic object
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_RemoveStatusMsg (void* pDiagEntryHdl);

//-- Function: dps_SetAlarm --------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function generates an alarm diagnostic object in the diagnostic management with the specified properties.
///   With the returned diagnostic entry header it is possible to delete the entry later.
///
///  \param   ulSlot                slot number
///  \param   enmAlarmType          alarm type
///  \param   enmAlarmSpec          alarm specifier
///  \param   bAddAck               additional acknowledge requested
///  \param   pUsrData              pointer to the user data memory
///  \param   ulUsrDataLen          status message user data length (max. length is 4 byte)
///  \param   ppDiagEntryHdl        return pointer for the diagnostic entry header
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetAlarm (uint32_t ulSlot,
                       alarmType_t enmAlarmType,
                       alarmSpec_t enmAlarmSpec,
                       bool bAddAck,
                       void* pUsrData,
                       uint32_t ulUsrDataLen,
                       void** ppDiagEntryHdl);

//-- Function: dps_RemoveAlarm -----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function removes the specified alarm diagnostic object out of the diagnostic management.
///   The object is specified by the entry handle.
///
///  \param   pDiagEntryHdl      handle of the alarm diagnostic object
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_RemoveAlarm (void* pDiagEntryHdl);

//-- Function: dps_GetEntryState ---------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the state of the specified diagnostic entry. The entry is specified by the
///   diagnostic ID and the diagnostic entry handle.
///
///  \param   pDiagEntryHdl      handle of diagnostic entry
///  \param   penmState          return pointer where the entry state should be stored
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetDiagEntryState  (void* pDiagEntryHdl,
                                 entryState_t* penmState);

//-- Function: dps_GetNextDsJob ----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the data of the next dataset job generated by a DS_Write access.
///
///  \param   pData                 return pointer to the memory where the dataset data should be stored
///  \param   ulMaxDataLen          maximum data length of the destination memory
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetNextDsJob (void* pData,
                           uint32_t ulMaxDataLen);

//-- Function: dps_GetSpecDsJob ----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function returns the data of the specified dataset job generated by a DS_Write access. The dataset is
///   specified by the slot and the index.
///
///  \param   ulSlot           slot number of the DS_Write telegram
///  \param   ulIndex          index number of the DS_Write telegram
///  \param   pData            return pointer to the memory where the dataset data should be stored
///  \param   ulMaxDataLen     maximum data length of the destination memory
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetSpecDsJob (uint32_t ulSlot,
                           uint32_t ulIndex,
                           void* pData,
                           uint32_t ulMaxDataLen);

//-- Function: dps_SetDsJobAck -----------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function sets the acknowledge data of the specified DS_Write job. The job is specified by the job ID.
///
///  \param   ulJobId          ID of the DS_Write job
///  \param   pData            pointer to the source data memory
///  \param   ulDataLen        length of the source data
///
///  \return  The function returns \ref DPS_SUCCESS on success. Another value indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetDsJobAck (uint32_t ulJobId,
                          void* pData,
                          uint32_t ulDataLen);

//-- Function: dps_GetDtData -------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function reads the data out of the PROFIBUS data transport buffer input buffer.
///
///  \param   pData            return pointer to the memory where the dataset data should be stored
///  \param   ulMaxDataLen     maximum data length of the destination memory
///
///  \return  The function returns 'true' on success. The return value Another value 'false' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_GetDtData (void* pData,
                        uint32_t ulMaxDataLen);

//-- Function: dps_SetDtData -------------------------------------------------------------------------------------------
///  \ingroup page_dps_dps_api_functions
///
///  This function writes the data into the PROFIBUS data transport buffer output buffer.
///
///  \param   pData            return pointer to the memory where the dataset data should be stored
///  \param   ulDataLen        maximum data length of the destination memory
///
///  \return  The function returns 'true' on success. The return value Another value 'false' indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dps_SetDtData (void* pData,
                        uint32_t ulDataLen);

#endif
//---- End of header ---------------------------------------------------------------------------------------------------
