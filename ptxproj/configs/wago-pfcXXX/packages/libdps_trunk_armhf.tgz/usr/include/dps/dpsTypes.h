//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dpsTypes.h
///
///  \version  $Id:
///
///  \brief    This header file collects all data types necessary for the use of the API.
///
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPSTYPES_API_H
#define DPSTYPES_API_H

//----------------------------------------------------------------------------------------------------------------------
// Includes
//----------------------------------------------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>

#include <dal/sdi_stack_interface.h>

#include "os_api.h"

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dps_dps_api_definitions Definitions
///  \ingroup page_dps_dps_api
///
///  These are the definitions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \defgroup dpsStatus Status codes
/// \ingroup page_dps_dps_api_definitions
///
/// The return value defines are 32 bit values and have the following format:
///
/// \code
///   3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0
///   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
///  +---+---------------------------+--------------------------------+
///  |Sev|      extended Code        |               Code             |
///  +---+---------------------------+--------------------------------+
/// \endcode
///
///  - Sev is the severity code
///   - 00 - Success
///   - 01 - Informational
///   - 10 - Warning
///   - 11 - Error
///  - extended Code describes the code more detailed (for further information see error code definitions)
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** the processing of the function has been successfully finished */
#define DPS_SUCCESS                                        0x00000000U
/** an undefined error has occurred during the processing of the function */
#define DPS_ERROR_UNDEFINED                                0xC0000000U
/** the pointer of a parameter is invalid */
#define DPS_ERROR_NULL_POINTER                             0xC0000001U
/** the object state is not valid */
#define DPS_ERROR_INVALID_OBJ_STATE                        0xC0000002U
/** the function was called in the wrong sequence */
#define DPS_ERROR_INVALID_SEQUENCE                         0xC0000003U
/** the requested resource is not available */
#define DPS_ERROR_RESSOURCE_FAULT                          0xC0000004U
/** the requested resource is not available */
#define DPS_ERROR_DATA_NOT_AVAILABLE                       0xC0000005U
/** the specified data are invalid */
#define DPS_ERROR_DATA_INVALID                             0xC0000006U
/** the specified data length is invalid */
#define DPS_ERROR_DATA_LENGTH                              0xC0000006U
/** the requested resource is not available */
#define DPS_ERROR_INVALID_SM_STATE                         0xC0000007U
/** the expected and real configuration don't match */
#define DPS_ERROR_INVALID_SLOT_CFG                         0xC0000008U
/** the specified timeout value is invalid */
#define DPS_ERROR_INVALID_TIMEOUT_VALUE                    0xC0000009U
/** the access to the requested data is denied */
#define DPS_ERROR_ACCESS_DENIED                            0xC000000AU
/** the specified extended function is not supported */
#define DPS_ERROR_EXT_FUNC_NOT_SUPP                        0xC000000BU
/** the specified extended function is not supported */
#define DPS_ERROR_FI_INDEX_NOT_SUPP                        0xC000000CU
/** the specified I&M index is not supported */
#define DPS_ERROR_IAM_INDEX_NOT_SUPP                       0xC000000DU
/** the requested resource is busy */
#define DPS_ERROR_RESSOURCE_BUSY                           0xC000000EU
/** the requested feature is not supported */
#define DPS_ERROR_FEATURE_NOT_SUPP                         0xC000000FU
/** the requested error reaction is invalid */
#define DPS_ERROR_INV_ERROR_REACTION                       0xC0000010U
/** the specified parameter is invalid */
#define DPS_ERROR_INV_PARAMETER                            0xC0000011U
/** there is not enough memory available */
#define DPS_ERROR_NO_FREE_MEM_AVAIL                        0xC0000012U
/** the specified slot is invalid */
#define DPS_ERROR_INV_SLOT                                 0xC0000013U
/** the specified channel is invalid */
#define DPS_ERROR_INV_CHANNEL                              0xC0000014U
/** the specified status message specifier is invalid */
#define DPS_ERROR_INV_STAT_MSG_SPEC                        0xC0000015U
/** the specified channel type of the channel related diagnostics entry is invalid */
#define DPS_ERROR_INV_CHAN_REL_DIAG_CHAN_TYPE              0xC0000016U
/** the specified channel size of the channel related diagnostics entry is invalid */
#define DPS_ERROR_INV_CHAN_REL_DIAG_CHAN_SIZE              0xC0000017U
/** the specified error type of the channel related diagnostics entry is invalid */
#define DPS_ERROR_INV_CHAN_REL_DIAG_ERR_TYPE               0xC0000018U
/** the specified alarm type of the alarm entry is invalid */
#define DPS_ERROR_INV_ALARM_TYPE                           0xC0000019U
/** the specified alarm specifier of the alarm entry is invalid */
#define DPS_ERROR_INV_ALARM_SPEC                           0xC000001AU
/** the specified diagnostics telegram data length is invalid */
#define DPS_ERROR_INV_DIAG_TGM_DATA_LEN                    0xC000001BU
/** invalid PROFIBUS alarm release in DP-V0 mode */
#define DPS_ERROR_INV_DPV0_ALARM_RELEASE                   0xC000001CU
/** invalid diagnostics entry state */
#define DPS_ERROR_INV_DIAG_ENTRY_STATE                     0xC000001DU
/** reading the manufacturer ID failed */
#define DPS_ERROR_READ_IAM0_MANUF_ID                       0xC000001EU
/** reading the order ID failed */
#define DPS_ERROR_READ_IAM0_ORDER_ID                       0xC000001FU
/** reading the software revision failed */
#define DPS_ERROR_READ_IAM0_SW_REV                         0xC0000020U
/** reading the hardware revision failed */
#define DPS_ERROR_READ_IAM0_HW_REV                         0xC0000021U
/** the application is in the error state */
#define DPS_ERROR_INTERNAL                                 0xC0000022U
/** the PROFIBUS DP-V1 status bytes are invalid */
#define DPS_ERROR_INV_DPV1_STAT_BYTES                      0xC0000023U
/** the specified watchdog timeout is invalid */
#define DPS_ERROR_INV_WATCHDOG_TIMEOUT                     0xC0000024U
/** the specified module status is invalid */
#define DPS_ERROR_INV_MOD_STAT                             0xC0000025U
/** reading the serial number failed */
#define DPS_ERROR_INV_SERIAL_NO                            0xC0000026U
/** the specified status message type is invalid */
#define DPS_ERROR_INV_STAT_MSG_TYPE                        0xC0000027U
///  \}

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dps_dps_api_data_types Data Types
///  \ingroup page_dps_dps_api
///
///  These are the data types of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref enmDpsSmStates_t enumeration describes the states of the PROFIBUS DP slave application
///  state machine.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** state is not defined because state machine not initialised yet */
  C0_STATE_NOT_DEFINED                      = 0,
  /** waiting for new configuration */
  C0_STATE_WAIT_FOR_CONFIGURATION           = 1,
  /** opening the PROFIBUS C0 channel */
  C0_STATE_OPENING_C0_CHAN                  = 2,
  /** C0 channel is open */
  C0_STATE_C0_CHAN_OPEN                     = 3,
  /** setting real configuration */
  C0_STATE_SETTING_REAL_CONFIG              = 4,
  /** opening the PROFIBUS C2 channel */
  C0_STATE_OPENING_C2_CHAN                  = 5,
  /** starting the PROFIBUS C0 channel */
  C0_STATE_STARTING_C0_CHAN                 = 6,
  /** waiting for PROFIBUS parameter */
  C0_STATE_WAIT_PRM                         = 7,
  /** waiting for changed PROFIBUS parameter or configuration telegram*/
  C0_STATE_WAIT_CHG_PRM_OR_CFG              = 8,
  /** waiting for PROFIBUS configuration */
  C0_STATE_WAIT_CFG                         = 9,
  /** checking the expected PROFIBUS configuration against the real configuration */
  C0_STATE_CHECK_CFG                        = 10,
  /** processing the PROFIBUS parameter and configuration */
  C0_STATE_PRC_PARAM                        = 11,
  /** starting the PROFIBUS data exchange */
  C0_STATE_STARTING_DXCH                    = 12,
  /** monitoring the PROFIBUS data exchange */
  C0_STATE_MONITORING_DXCH                  = 13,
  /** stop the C0 channel */
  C0_STATE_STOP_C0_CHANNEL                  = 14,
  /** withdraw the C0 channel */
  C0_STATE_WITHDRAW_C0                      = 15,
  /** close the C0 channel */
  C0_STATE_CLOSE_C0_CHANNEL                 = 16,
  /** close the C2 channel */
  C0_STATE_CLOSE_C2_CHANNEL                 = 17,
  /** close the PROFIBUS controller */
  C0_STATE_CLOSE_PBC                        = 18,
  /** unrecoverable error state */
  C0_STATE_ERROR                            = 19,
  /** default state witch can process not supported events */
  C0_STATE_DEFAULT                          = 20,
  /** this is the end mark of the state machine state defines */
  C0_STATE_END_MARK                         = 21
}enmDpsC0SmStates_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref slotDataTypes_t enumeration describes the process image data type.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** data type is undefined */
  DPS_UNDEFINED                 = 0,
  /** data type is BOOL */
  DPS_BOOL                      = 1,
  /** data type is INT8 */
  DPS_INT8                      = 2,
  /** data type is INT16 */
  DPS_INT16                     = 3,
  /** data type is INT32 */
  DPS_INT32                     = 4,
  /** data type is UINT8 */
  DPS_UINT8                     = 5,
  /** data type is UINT16 */
  DPS_UINT16                    = 6,
  /** data type is UINT32 */
  DPS_UINT32                    = 7,
  /** data type is FLOAT */
  DPS_FLOAT                     = 8,
  /** data type is VISIBLE STRING */
  DPS_VISIBLE_STRING            = 9,
  /** data type is OCTED STRING */
  DPS_OCTET_STRING              = 10,
  /** data type is ARRAY OF BOOL */
  DPS_ARRAY_OF_BOOL             = 32,
  /** data type is ARRAY OF INT8 */
  DPS_ARRAY_OF_INT8             = 33,
  /** data type is ARRAY OF INT16 */
  DPS_ARRAY_OF_INT16            = 34,
  /** data type is ARRAY OF INT32 */
  DPS_ARRAY_OF_INT32            = 35,
  /** data type is ARRAY OF UINT8 */
  DPS_ARRAY_OF_UINT8            = 36,
  /** data type is ARRAY OF UINT16 */
  DPS_ARRAY_OF_UINT16           = 37,
  /** data type is ARRAY OF UINT32 */
  DPS_ARRAY_OF_UINT32           = 38,
  /** data type is ARRAY OF FLOAT */
  DPS_ARRAY_OF_FLOAT            = 39,
  /** data type is ARRAY OF BYTE */
  DPS_ARRAY_OF_BYTE             = 40,
  /** data type is ARRAY OF WORD */
  DPS_ARRAY_OF_WORD             = 41,
  /** data type is ARRAY OF DWORD */
  DPS_ARRAY_OF_DWORD            = 42,
  /** reserved data type */
  DPS_RES1                      = 43,
  /** reserved data type */
  DPS_RES2                      = 44,
  /** reserved data type */
  DPS_RES3                      = 45,
  /** reserved data type */
  DPS_RES4                      = 46,
  /** data type is DWORD */
  DPS_DWORD                     = 47,
  /** data type is WORD */
  DPS_WORD                      = 48,
  /** data type is BYTE */
  DPS_BYTE                      = 49,
  /** end marker */
  DPS_DATA_TYPE_END_MARKER      = 50
} slotDataTypes_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref pbSlotCfgDesc_t structure describes the slot specific PROFIBUS parameter.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** process image input data offset in bits */
    uint32_t ulPiInpDataBitOffset;
    /** process image output data offset in bits */
    uint32_t ulPiOutpDataBitOffset;
    /** process image input data length in bits */
    uint32_t ulPiInpDataBitLen;
    /** process image output data length in bits */
    uint32_t ulPiOutpDataBitLen;
    /** data type of the process image data */
    slotDataTypes_t enmDataType;
}pbSlotCfgDesc_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref realConfigDesc_t structure describes the PROFIBUS real configuration.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** real configuration static mode */
    bool bRealCfgModeStatic;
    /** number of slots defined in the real configuration description list */
    uint32_t ulNoOfSlots;
    /** real configuration slot description list */
    pbSlotCfgDesc_t* pastRealSlotConfig;
}realConfigDesc_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref realConfigDesc_t structure describes the PROFIBUS device configuration.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** DAL device identification */
    tDeviceId lDeviceId;
    /** PROFIBUS DP slave station address */
    uint32_t ulDpSlaveAdress;
    /** real configuration description */
    realConfigDesc_t stRealConfigDesc;
}dpsDeviceConfig_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref diagEntrySev_t enumeration describes the diagnostics entry severity.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** diagnostic entry severity is undefined */
  DIAG_ENTRY_SEV_UNDEF  = 0,
  /** the diagnostic entry is an information */
  DIAG_ENTRY_SEV_INF    = 1,
  /** the diagnostic entry is a warning */
  DIAG_ENTRY_SEV_WAR    = 2,
  /** the diagnostic entry is an error */
  DIAG_ENTRY_SEV_ERR    = 3
}diagEntrySev_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref dpsDiagAction_t enumeration describes the diagnostics processing action.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** insert a diagnostic entry */
  DIAG_ACTION_INSERT  = 0,
  /** change a diagnostic entry */
  DIAG_ACTION_CHANGE  = 1,
  /** remove a diagnostic entry */
  DIAG_ACTION_REMOVE  = 2
}dpsDiagAction_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref entryState_t enumeration describes the diagnostic entry state.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** the entry state is undefined */
  ENTRY_STATE_UNDEFINED     = 0,
  /** the entry is in the "NEW" state */
  ENTRY_STATE_NEW           = 1,
  /** the entry is in the "PENDING" state */
  ENTRY_STATE_PENDING       = 2,
  /** the entry is in the "BUSY" state */
  ENTRY_STATE_BUSY          = 3,
  /** the entry is in the "ACKNOWLEDGED" state */
  ENTRY_STATE_ACKNOWLEDGED  = 4,
  /** the entry is in the "ERROR" state */
  ENTRY_STATE_ERROR         = 5,
  /** the entry is in the "FINISHED" state */
  ENTRY_STATE_FINISHED      = 6
}entryState_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref idRelDiagModState_t enumeration describes the ID related diagnostic module state.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** no error at the specified slot */
  MODULE_STATE_OK      = 0,
  /** the module at the specified slot has an error */
  MODULE_STATE_FAULTY  = 1
}idRelDiagModState_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref idRelDiagModState_t enumeration describes the module status module state.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** the process data of the specified slot are valid */
  MOD_STAT_DATA_VALID      = 0,
  /** the process data of the specified slot are invalid */
  MOD_STAT_DATA_INVALID    = 1,
  /** the module at the specified slot is wrong */
  MOD_STAT_WRONG_IO_MODULE = 2,
  /** there is no module at the specified slot */
  MOD_STAT_NO_IO_MODULE    = 3,
  /** enumeration end ID (only for internal use) */
  MOD_STAT_INV_STAT        = 4
}modStatDiag_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref chanType_t enumeration describes the channel diagnostics signal type.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** channel data direction type is "RESERVED" */
  CHAN_DIAG_CHAN_TYPE_RESERVED   = 0,
  /** input channel */
  CHAN_DIAG_CHAN_TYPE_INPUT      = 1,
  /** output channel */
  CHAN_DIAG_CHAN_TYPE_OUTPUT     = 2,
  /** input and output channel */
  CHAN_DIAG_CHAN_TYPE_IN_OUTPUT  = 3
}chanType_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref chanSize_t enumeration describes the channel diagnostics channel data length.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** channel data length is not defined */
  CHAN_DIAG_CHAN_TYPE_NOT_DEF     = 0,
  /** channel data length is 1 bit */
  CHAN_DIAG_CHAN_TYPE_1_BIT       = 1,
  /** channel data length is 2 bits */
  CHAN_DIAG_CHAN_TYPE_2_BIT       = 2,
  /** channel data length is 4 bits */
  CHAN_DIAG_CHAN_TYPE_4_BIT       = 3,
  /** channel data length is 1 byte */
  CHAN_DIAG_CHAN_TYPE_1_BYTE      = 4,
  /** channel data length is 1 word */
  CHAN_DIAG_CHAN_TYPE_1_WORD      = 5,
  /** channel data length is 2 words */
  CHAN_DIAG_CHAN_TYPE_2_WORDS     = 6,
  /** reserved channel type */
  CHAN_DIAG_CHAN_TYPE_RESERVED_1  = 7
}chanSize_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref chanDiagErroType_t enumeration describes the channel diagnostics error type.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** reserved channel error type */
  CHAN_DIAG_ERR_TYPE_RES_1            = 0,
  /** there is a short circuit error at the channel  */
  CHAN_DIAG_ERR_TYPE_SHORT_CIRCUIT    = 1,
  /** there is an under voltage error at the channel  */
  CHAN_DIAG_ERR_TYPE_UNDERVOLTAGE     = 2,
  /** there is an over voltage error at the channel  */
  CHAN_DIAG_ERR_TYPE_OVERVOLTAGE      = 3,
  /** there is an overload error at the channel  */
  CHAN_DIAG_ERR_TYPE_OVERLOAD         = 4,
  /** there is an over temperature error at the channel  */
  CHAN_DIAG_ERR_TYPE_OVER_TEMP        = 5,
  /** there is a line break error at the channel  */
  CHAN_DIAG_ERR_TYPE_LINE_BREAK       = 6,
  /** there is an upper limit exceeded error at the channel  */
  CHAN_DIAG_ERR_TYPE_UPPER_LIMIT_EXC  = 7,
  /** there is a lower limit exceeded error at the channel  */
  CHAN_DIAG_ERR_TYPE_LOWER_LIMIT_EXC  = 8,
  /** there is a not specified error at the channel  */
  CHAN_DIAG_ERR_TYPE_ERROR            = 9,
  /** start of the reserved error types */
  CHAN_DIAG_ERR_TYPE_RES_2_START      = 10,
  /** end of the reserved error types */
  CHAN_DIAG_ERR_TYPE_RES_2_END        = 15,
  /** start of the user defined error types */
  CHAN_DIAG_ERR_TYPE_USER_START       = 16,
  /** end of the user defined error types */
  CHAN_DIAG_ERR_TYPE_USER_END         = 31
}chanDiagErroType_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref statusMsgType_t enumeration describes the status massage type.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** reserved status message type */
  STATUS_TYPE_RES_1               = 0,
  /** it is a status message */
  STATUS_TYPE_STATUS_MSG          = 1,
  /** it is a module status */
  STATUS_TYPE_MODULE_STATUS       = 2,
  /** it is a data exchange broadcast link status */
  STATUS_TYPE_DXB_LINK_STATUS     = 3,
  /** start of the reserved status message types */
  STATUS_TYPE_RES_2_START         = 4,
  /** end of the reserved status message types */
  STATUS_TYPE_RES_2_END           = 29,
  /** it is a parameter command acknowledge */
  STATUS_TYPE_PRM_CMD_ACK         = 30,
  /** it is a read status acknowledge */
  STATUS_TYPE_READ_STATUS_ACK     = 31,
  /** start of the user defined status messages types */
  STATUS_TYPE_USR_START           = 32,
  /** WAGO system diagnostic */
  STATUS_TYPE_WAGO_SYS_DIAG       = 64,
  /** end of the user defined status messages types */
  STATUS_TYPE_USR_END             = 126,
  /** reserved status message type */
  STATUS_TYPE_RES_3               = 127
}statusMsgType_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref statusMsgType_t enumeration describes the status massage specifier.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** status message specifier is not specified */
  STATUS_MSG_SPEC_NO_SPEC       = 0,
  /** it is an appearing status message */
  STATUS_MSG_SPEC_APPEARING     = 1,
  /** it is an disappearing status message */
  STATUS_MSG_SPEC_DISAPPEARING  = 2,
  /** reserved status message specifier */
  STATUS_MSG_SPEC_RESERVED      = 3
}statusMsgSpec_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref alarmType_t enumeration describes the alarm type.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** reserved alarm type */
  ALARM_TYPE_RES_1          = 0,
  /** diagnostic alarm */
  ALARM_TYPE_DIAG_ALARM     = 1,
  /** process alarm */
  ALARM_TYPE_PROCESS_ALARM  = 2,
  /** pull alarm */
  ALARM_TYPE_PULL_ALARM     = 3,
  /** plug alarm */
  ALARM_TYPE_PLUG_ALARM     = 4,
  /** status alarm */
  ALARM_TYPE_STATUS_ALARM   = 5,
  /** update alarm */
  ALARM_TYPE_UPDATE_ALARM   = 6,
  /** start of the user defined alarms */
  ALARM_TYPE_USER_START     = 32,
  /** end of the user defined alarms */
  ALARM_TYPE_USER_END       = 126
}alarmType_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref alarmSpec_t enumeration describes the alarm specifier.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** alarm is not specified */
  ALARM_SPEC_UNSPECIFIED           = 0,
  /** error has appeared and slot is faulty */
  ALARM_SPEC_ERR_APP_SLOT_FAULT    = 1,
  /** error has disappeared and slot is ok */
  ALARM_SPEC_ERR_DISAPP_SLOT_OK    = 2,
  /** error has disappeared but slot is still faulty */
  ALARM_SPEC_ERR_DISAPP_SLOT_FAULT = 3
}alarmSpec_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dps_dps_api_data_types
///
/// The \ref diagEngState_t enumeration describes the diagnostic engine states.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** the diagnostics engine state is undefined */
  DIAG_ENG_STATE_UNDEFINED    = 0,
  /** the diagnostics engine is in the IDLE state */
  DIAG_ENG_STATE_IDLE         = 1,
  /** the diagnostics engine is in the WAITING state */
  DIAG_ENG_STATE_WAITING      = 2,
  /** the diagnostics engine is in the SENDING state */
  DIAG_ENG_STATE_SENDING      = 3,
  /** the diagnostics engine is in the FINISHED state */
  DIAG_ENG_STATE_FINISHED     = 4,
  /** the diagnostics engine is in the ERROR state */
  DIAG_ENG_STATE_ERROR        = 5
}diagEngState_t;

#endif
//---- End of header ---------------------------------------------------------------------------------------------------

