//-----------------------------------------------------------------------------
//  Copyright (c) WAGO GmbH & Co. KG
//
//  PROPRIETARY RIGHTS are involved in the subject matter of this material.
//  All manufacturing, reproduction, use and sales rights pertaining to this
//  subject matter are governed by the license agreement. The recipient of this
//  software implicitly accepts the terms of the license.
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
///  \file     canopen_types.h
///
///  \version  $Id:
///
///  \brief    fieldbus specific types for WAGO ADI interface
///
///  \author   <wue> : WAGO GmbH & Co. KG
//-----------------------------------------------------------------------------

#ifndef _CANOPENTYPES_H
#define _CANOPENTYPES_H

//-----------------------------------------------------------------------------
// full diagnostics of the CANopen stack
//-----------------------------------------------------------------------------
typedef struct CANOPEN_DIAG_MASTER
{
  uint8_t   COMM_State;                // state of the state machine
  uint8_t   COMM_CommunicationStatus;  // state of the communication with
                                       // the network
  uint16_t  global_events;             // global event bits
  uint16_t  config_bits;               // configuration bits: master, sync enabled,..
} canopen_diag_master;

//-----------------------------------------------------------------------------
// diagnostics of the can interfaces
//-----------------------------------------------------------------------------
typedef struct CANOPEN_COM_STATUS
{
  uint16_t bus_state;
  uint16_t bus_diag;

  uint16_t rx_l2_overflows;
  uint16_t tx_l2_overflows;
  uint16_t tx_l2_timeouts;

  uint16_t rx_overflows;
  uint16_t tx_timeouts;

  uint16_t bus_offs;
  uint16_t bus_warns;

  uint16_t bus_errors;


} canopen_com_status;

//-----------------------------------------------------------------------------
// compact diagnostics of the CANopen stack
//-----------------------------------------------------------------------------
typedef struct CANOPEN_CSTATUS
  {
  uint8_t BusState;     // the main canopen state
  struct
  {
    uint8_t Run     :1; // the canopen task is running
    uint8_t NewData :1; // new data from server
    uint8_t BusOff  :1; // the bus ist offline /short
    uint8_t BusWarn :1; // warning level reached on bus
    uint8_t ONodeErr:1; // optional/unexpected node error
    uint8_t MNodeErr:1; // mandatory node error
    uint8_t SlaveOp :1; // at least one slave is operational
    uint8_t MasterOp:1; // the CANopen manager is operational
  } Flags;

} canopen_cstatus;

//-----------------------------------------------------------------------------
// diagnostics of the slaves: slave bitflags
//-----------------------------------------------------------------------------
#define  CANOPEN_SLAVE_FLAG_ASG   0x0001  // node configuration: assigned slave
#define  CANOPEN_SLAVE_FLAG_CFG   0x0002  // node assigned and configured
#define  CANOPEN_SLAVE_FLAG_ASF   0x0004  // node configuration mismatch
#define  CANOPEN_SLAVE_FLAG_ERR   0x0008  // node diagnostic: emergency message present
#define  CANOPEN_SLAVE_FLAG_OPER  0x0010  // node state operational
#define  CANOPEN_SLAVE_FLAG_STOP  0x0020  // node is set to stopped
#define  CANOPEN_SLAVE_FLAG_PREOP 0x0040  // node is set to preoperational
#define  CANOPEN_SLAVE_FLAG_ICDCF 0x0080  // inconsistent cDCF
#define  CANOPEN_SLAVE_FLAG_MCDCF 0x0100  // mismatch cDFC and slave`s object dictionary
#define  CANOPEN_SLAVE_FLAG_IDE   0x0200  // identity error


//-----------------------------------------------------------------------------
// prototypes for CANopen parameter
//-----------------------------------------------------------------------------

// CANopen node parameter for use in master / slave must be configured via SDO List
typedef struct CANOPEN_NODE_HEADER
{
  uint8_t  NodeId;
  uint16_t Len;
  uint16_t AddTypeInfo;
  uint16_t DevProfNum;
  uint16_t COBIdEmcy;
  uint16_t GuardTime;        // info for codesys configurator
  uint8_t  LifeTime;         // info for codesys configurator
  uint8_t  LifeTimeFactor;   // info for codesys configurator
  uint16_t HeartbeatPeriod;  // info for codesys configurator
  uint16_t SDOCount;
  uint16_t PDOCount;

  struct
  {
    uint16_t SendResetNode          :1; // send reset node prior to start node
    uint16_t DeviceProfile          :1; // test device profile
    uint16_t GuardingParameter      :1; // guarding parameter present / not used
    uint16_t SyncCOBId              :1; // Sync COB ID present
    uint16_t EmergencyCOBId         :1; // EMX COB ID present
    uint16_t SendAllSDOData         :1; // not used / processed in configurator
    uint16_t DisableStartNode       :1; // startup node
    uint16_t SendFirstRXPdo         :1; // not used
    uint16_t Heartbeat              :1; // heartbeat present
    uint16_t DisableCANopenStartup  :1; // disable configuration and startup node

    // new for codesys 3.5
    uint16_t DCFWrite               :1; // not used
    uint16_t Mandantory             :1; // slave is mandantory / no start if not present
    uint16_t DisableInit  			:1; // disable configuration
    uint16_t Reserved               :4; // was 6
  } ConfigState;

  uint16_t DiagSegment;     // reserved for for future use
  uint16_t DiagOffset;      // reserved for for future use

  // new for codesys 3.5
  uint8_t  ResetNodeSubIndex; // was reserved
  uint32_t VendorID;
  uint32_t ProductCode;
  uint32_t RevisionNumber;
  uint32_t SerialNumber;
} __attribute__ ((packed)) canopen_node_header;


// CANopen SDO list entry (= CoDeSys CAN_sdo)
typedef struct CANOPEN_SDO
{
  uint16_t index;
  uint8_t  sub_index;
  uint16_t len;
  uint8_t  *value;
} __attribute__ ((packed)) canopen_sdo;
#define CAN_SDO_HDR_SIZE 5


// CANopen SDO list  (= CoDeSys Canm_sdo_cfg)
typedef struct CANOPEN_SDO_CFG
{
  uint16_t      len;
  canopen_sdo * sdos;
} __attribute__ ((packed)) canopen_sdo_cfg;


// predefined SDO list entry
typedef struct CANOPEN_SDO_TABLE
{
  uint16_t index;
  uint8_t  sub_index;
  uint16_t len;
  uint32_t value;
} canopen_sdo_table ;

typedef struct CAN_PDOCHANNEL
{
  unsigned char  offset_pdo;
  unsigned short id;
  unsigned long  offset;
  unsigned char  len;
} canopen_pdo_channel;

// CANopen PDO list entry (= CoDeSys Can_pdo)
typedef struct CANOPEN_PDO
{
  uint8_t  type; // 1=  output for master  2 = input for master
  uint8_t  len;
  uint32_t cob_id;
  uint8_t  trans_type;
  uint16_t inhibit_time;
  uint16_t event_time;
  unsigned char channel_count;
  canopen_pdo_channel  * channel;
} __attribute__ ((packed)) canopen_pdo;



// CANopen PDO list  (= CoDeSys Canm_pdo_cfg)
typedef struct CANOPEN_PDO_CFG
{
  uint16_t len;
  canopen_pdo * pdos;
} __attribute__ ((packed)) canopen_pdo_cfg;


// CANopen process data info (= CoDeSys Canm_add_tab)
typedef struct CANOPEN_ADDTAB
{
  uint16_t len;
  uint8_t input_count;
  uint8_t output_count;
  uint16_t *io_offsets;
} __attribute__ ((packed)) canopen_addtab;

// CANopen node config (= CoDeSys Can_parameter)
typedef struct CANOPEN_NODE_CONFIG
{
  canopen_node_header tab;
  canopen_sdo_cfg sdo_cfg;
  canopen_pdo_cfg pdo_cfg;
  canopen_addtab add_tab; // reserved / not used
} canopen_node_config;


// CANopen bus parameter
typedef struct CANOPEN_BUS_CONFIG
{
  uint16_t    NodeId;           // node-Id of the master
  uint8_t     Baudrate;         // baudrate of CAN-bus
  uint32_t    CommCyclePeriod;  // communication cycle period
  uint32_t    SyncWindowLength; // synchronisation window length
  uint32_t    SyncCobId;        // synchronisation CobId
  uint8_t     NumOfNodes;       // number of nodes
  uint32_t    HeartbeatPeriod;  // heartbeat Cycle period
  int8_t      Prio;             // priority of CANOpen-task

  struct
  {
    uint8_t AutoClear      :1;
    uint8_t AutoStart      :1;
    uint8_t intel_motorola :1;

    // new for codesys 3.5
    uint8_t SyncProducer       :1;
    uint8_t SyncConsumer       :1;
    uint8_t PollOptionalSlaves :1;
    uint8_t ScanAllNodes       :1;
    uint8_t StopOnPLCStop      :1;

  } ConfigState;

  uint16_t DiagSegment;       // reserved for for future use
  uint16_t DiagOffset;        // reserved for for future use
  uint32_t TimeStampId;
  uint32_t EmergencyId;
  uint16_t GuardTime;
  uint8_t  LifeTime;
  uint32_t DeviceType;
  uint8_t  DevName[32];
  uint8_t  HW_Ver[12];
  uint8_t  SW_Ver[8];
  uint32_t Vendor_ID;
  uint32_t Product_code;
  uint32_t Revision_number;
  uint32_t Serial_number;
  uint32_t StartFlags;      // user defined entry for object 1F80 to start master

  // new for codesys 3.5
  uint32_t TimeStampIntervall;
  uint32_t HeartbeatID;

  // new for extended PDO error handling
  uint16_t PDOCount;

} canopen_bus_config;

typedef struct CANOPEN_PDO_INFO
{
  uint8_t type; // 1=  output for master  2 = input for master
  uint8_t len;
  uint8_t node;
  uint8_t status;
  uint32_t cob_id;
  uint16_t offset;
} __attribute__ ((packed)) canopen_pdo_info;

typedef struct CANOPEN_DEVICE_INFO
{
  uint16_t DeviceLock;
  uint16_t DeviceMode;
  uint16_t InitMode;
  uint16_t Interface;
  uint32_t Baudrate;
  uint32_t Flags;
  uint32_t BusNr;
  uint32_t ExtraInfo;
}  canopen_device_info;

typedef struct CANOPEN_DEVICE_TIMESTAMP
{
  uint32_t Time;
  uint16_t Day;
  uint16_t Flags;
}  canopen_device_timestamp;


//-----------------------------------------------------------------------------
// defines for CANopen stack states
//-----------------------------------------------------------------------------

#define CANOPEN_STATE_INIT                  0x00  // initialization
#define CANOPEN_STATE_RESET_REQUEST         0x01  // reset has been requested
#define CANOPEN_SEND_TIME_STAMP             0x02  // send time stamp
#define CANOPEN_BAUDRATE_TEST               0x04  // baudrate test running
#define CANOPEN_STATE_MASTER_STATE_RESET    0x40  // after successful initialization

// states of the slave mode
#define CANOPEN_STATE_SLAVE_STOPPED         0x41  // slave mode: stopped
#define CANOPEN_STATE_SLAVE_PREOP           0x42  // slave mode: preoperational
#define CANOPEN_STATE_SLAVE_OP              0x43  // slave mode: operational

// states of the configuration procedure
#define CANOPEN_STATE_PREPARE_NET_INIT      0x60
#define CANOPEN_STATE_NTW_RESET             0x61  // reset communication all nodes
#define CANOPEN_STATE_NTW_WAIT              0x62  // wait state
#define CANOPEN_STATE_BOOT_CONF             0x64  // bootup configuration mode

#define CANOPEN_STATE_CLEAR                 0x80  // configuration matches
#define CANOPEN_STATE_FATAL_ERROR           0x90  // serious configuration mismatch or bus off
#define CANOPEN_STATE_RUN                   0xA0  // network is set to operational
#define CANOPEN_STATE_STOP                  0xC0  // network is set to stopped by request
#define CANOPEN_STATE_PREOPERATIONAL        0xE0  // network is set to preop. by request
#define CANOPEN_STATE_BOOT_END_MISSING_MAND 0x70  // network has been scanned but there are missing mandatory nodes

#define CANOPEN_MAINSTATES                  0xF0  // filter for error flags
                                                  // errorinfo bits if State > 0x80:
                                                  // bit 0 = 1: optional/unexpected node error
                                                  // bit 1 = 1: mandatory node error
                                                  // bit 2 = 1: at least one slave is operational
                                                  // bit 3 = 1: the CANopen Manager is operational


//-----------------------------------------------------------------------------
// bus states for SetDeviceState
//-----------------------------------------------------------------------------

#define  CANOPEN_START_BOOTUP_CONF        0x11
#define  CANOPEN_GOTO_RUN                 0x60
#define  CANOPEN_GOTO_PREOPERATIONAL      0x61
#define  CANOPEN_GOTO_STOPPED             0x62
#define  CANOPEN_GOTO_RESETNODE           0x63
#define  CANOPEN_GOTO_RESETCOM            0x64


//-----------------------------------------------------------------------------
// error numbers
//-----------------------------------------------------------------------------

#define  CANOPEN_ERR         0x4000     // error flag
#define  CANOPEN_ERR_INIT    0x5000     // error Init
#define  CANOPEN_ERR_SDO     0x6000     // error on SDO interface
#define  CANOPEN_ERR_CMD     0x7000     // error on command interface

#define  CANOPEN_ERR_DATATYPE_LENGTH_TO_LOW  9
#define  CANOPEN_ERR_TIMEOUT 29         // timeout = COP_k_TIMEOUT
#define  CANOPEN_ERR_SDO_BUSY 40        // SDO interface is processing a command

#define  CANOPEN_ERR_THREAD  101        // error in start thread

#define  CANOPEN_SDO_STARTED  0x8000    // SDO call is accepted
#define  CANOPEN_SDO_WORKING  0x8001    // SDO call is waiting

//-----------------------------------------------------------------------------
// flags for the communication state
//-----------------------------------------------------------------------------
#define CANOPEN_COM_NOERR       0u  // 0x00 no error
#define CANOPEN_COM_LPRXOVR     1u  // 0x01 software overrun (lp-rx-queue)
#define CANOPEN_COM_HPRXOVR    64u  // 0x40 software overrun (hp-rx-queue)
#define CANOPEN_COM_COVR        2u  // 0x02 CAN: overrun
#define CANOPEN_COM_BOFF        4u  // 0x04 CAN: bus off
#define CANOPEN_COM_ESET        8u  // 0x08 CAN: error-status-bit set
#define CANOPEN_COM_ERESET     16u  // 0x10 CAN: error-status-bit reset
#define CANOPEN_COM_LPTXOVR    32u  // 0x20 lp-tx-queue full
#define CANOPEN_COM_HPTXOVR   128u  // 0x80 hp-tx-queue full == NMS_k_EV_HPTXOVR
#define CANOPEN_COM_GUARDERR  256u // 0x100 Guarding or Heartbeat error as slave
#define CANOPEN_COM_SYNCERR   512u // 0x200 Sync error as slave


//-----------------------------------------------------------------------------
// flags for the short diagnostic
//-----------------------------------------------------------------------------

#define CANOPEN_COM_RUN     1   // CANopen tread running
#define CANOPEN_COM_NEWDATA 2   // new data from bus


//-----------------------------------------------------------------------------
// flags for error counter reset
//-----------------------------------------------------------------------------

#define CANOPEN_RESET_L2_RXOVFL 1u
#define CANOPEN_RESET_L2_TXOVFL 2u
#define CANOPEN_RESET_ALL_ERR  0xFF
#define CANOPEN_L2_RX_OVERFLOW  0x1000

//-----------------------------------------------------------------------------
// error numbers for can layer2 interface
//-----------------------------------------------------------------------------

#define CANOPEN_ERR_RXOVFL    1u
#define CANOPEN_ERR_TXERR     2u
#define CANOPEN_ERR_BUSOFF    3u
#define CANOPEN_ERR_BUSWARN   4u
#define CANOPEN_ERR_L2_RXOVFL 5u
#define CANOPEN_ERR_L2_TXOVFL 6u
#define CANOPEN_ERR_BAUDRATE  7u

//-----------------------------------------------------------------------------
// returns for interface to layer2 functions
//-----------------------------------------------------------------------------

#define CANOPEN_L2_OK                          0 // = DAL_SUCCESS
#define CANOPEN_L2_ERR                        -1 // = DAL_FAILURE
#define CANOPEN_L2_NO_IDX                     -2
#define CANOPEN_L2_TIMEOUT                    -3
#define CANOPEN_L2_NODATA                     -4
#define CANOPEN_L2_TXOVERFLOW                 -5

//-----------------------------------------------------------------------------
// size of arrays for can layer2 interface
//-----------------------------------------------------------------------------

#define CANOPEN_L2_MASK_IDS    127     // mask size for layer2 messages
#define CANOPEN_L2_MESSAGES    127     // buffer size for layer2 messages
#define CANOPEN_L2_RX_MAX      8       // max messages per id in buffer

//-----------------------------------------------------------------------------
//    data type definitions
//-----------------------------------------------------------------------------

#define CANOPEN_BOOLEAN             1
#define CANOPEN_INTEGER8            2
#define CANOPEN_INTEGER16           3
#define CANOPEN_INTEGER32           4
#define CANOPEN_UNSIGNED8           5
#define CANOPEN_UNSIGNED16          6
#define CANOPEN_UNSIGNED32          7
#define CANOPEN_REAL32              8
#define CANOPEN_VISIBLE_STRING      9
#define CANOPEN_OCTET_STRING        10

#define CANOPEN_UNSIGNED24          11
#define CANOPEN_UNSIGNED40          12
#define CANOPEN_UNSIGNED48          13
#define CANOPEN_UNSIGNED56          14
#define CANOPEN_UNSIGNED64          16

#define CANOPEN_DOMAIN              15

#define CANOPEN_INTEGER24           17
#define CANOPEN_INTEGER40           18
#define CANOPEN_INTEGER48           19
#define CANOPEN_INTEGER56           20
#define CANOPEN_INTEGER64           21

#endif
