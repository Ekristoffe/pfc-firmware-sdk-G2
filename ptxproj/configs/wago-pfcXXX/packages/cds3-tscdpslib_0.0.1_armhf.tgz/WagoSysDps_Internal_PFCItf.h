 /**
 * <interfacename>WagoSysDps_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSDPS_INTERNAL_PFCITF_H_
#define _WAGOSYSDPS_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>fudpsgetdevstate</description>
 */
typedef struct tagfudpsgetdevstate_struct
{
	RTS_IEC_DWORD FuDpsGetDevState;		/* VAR_OUTPUT */	
	RTS_IEC_BYTE DEV_STATE;				/* VAR_OUTPUT */	/* Current state of the PROFIBUS interface */
} fudpsgetdevstate_struct;

void CDECL CDECL_EXT fudpsgetdevstate(fudpsgetdevstate_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSGETDEVSTATE_IEC) (fudpsgetdevstate_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSGETDEVSTATE_NOTIMPLEMENTED)
	#define USE_fudpsgetdevstate
	#define EXT_fudpsgetdevstate
	#define GET_fudpsgetdevstate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpsgetdevstate(p0) 
	#define CHK_fudpsgetdevstate  FALSE
	#define EXP_fudpsgetdevstate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpsgetdevstate
	#define EXT_fudpsgetdevstate
	#define GET_fudpsgetdevstate(fl)  CAL_CMGETAPI( "fudpsgetdevstate" ) 
	#define CAL_fudpsgetdevstate  fudpsgetdevstate
	#define CHK_fudpsgetdevstate  TRUE
	#define EXP_fudpsgetdevstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetdevstate", (RTS_UINTPTR)fudpsgetdevstate, 1, 0xBC3B5A06, 0x01000000) 
	#define EXTREF_ITF_fudpsgetdevstate {(RTS_VOID_FCTPTR)fudpsgetdevstate, "fudpsgetdevstate", 0xBC3B5A06, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpsgetdevstate
	#define EXT_fudpsgetdevstate
	#define GET_fudpsgetdevstate(fl)  CAL_CMGETAPI( "fudpsgetdevstate" ) 
	#define CAL_fudpsgetdevstate  fudpsgetdevstate
	#define CHK_fudpsgetdevstate  TRUE
	#define EXP_fudpsgetdevstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetdevstate", (RTS_UINTPTR)fudpsgetdevstate, 1, 0xBC3B5A06, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpsgetdevstate
	#define EXT_WagoSysDps_Internal_PFCfudpsgetdevstate
	#define GET_WagoSysDps_Internal_PFCfudpsgetdevstate  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpsgetdevstate  fudpsgetdevstate
	#define CHK_WagoSysDps_Internal_PFCfudpsgetdevstate  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpsgetdevstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetdevstate", (RTS_UINTPTR)fudpsgetdevstate, 1, 0xBC3B5A06, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpsgetdevstate
	#define EXT_fudpsgetdevstate
	#define GET_fudpsgetdevstate(fl)  CAL_CMGETAPI( "fudpsgetdevstate" ) 
	#define CAL_fudpsgetdevstate  fudpsgetdevstate
	#define CHK_fudpsgetdevstate  TRUE
	#define EXP_fudpsgetdevstate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetdevstate", (RTS_UINTPTR)fudpsgetdevstate, 1, 0xBC3B5A06, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpsgetdevstate  PFFUDPSGETDEVSTATE_IEC pffudpsgetdevstate;
	#define EXT_fudpsgetdevstate  extern PFFUDPSGETDEVSTATE_IEC pffudpsgetdevstate;
	#define GET_fudpsgetdevstate(fl)  s_pfCMGetAPI2( "fudpsgetdevstate", (RTS_VOID_FCTPTR *)&pffudpsgetdevstate, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xBC3B5A06, 0x01000000)
	#define CAL_fudpsgetdevstate  pffudpsgetdevstate
	#define CHK_fudpsgetdevstate  (pffudpsgetdevstate != NULL)
	#define EXP_fudpsgetdevstate   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetdevstate", (RTS_UINTPTR)fudpsgetdevstate, 1, 0xBC3B5A06, 0x01000000) 
#endif


/**
 * <description>fudpsgetimds</description>
 */
typedef struct tagfudpsgetimds_struct
{
	RTS_IEC_USINT DS_ID;				/* VAR_INPUT */	/* Specifies the number of the I & M data set. Records 0-4 are supported */
	RTS_IEC_BYTE *DATA;					/* VAR_INPUT */	/* Returns the pointer to the memory area for the record data */
	RTS_IEC_DWORD FuDpsGetImDs;			/* VAR_OUTPUT */	
} fudpsgetimds_struct;

void CDECL CDECL_EXT fudpsgetimds(fudpsgetimds_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSGETIMDS_IEC) (fudpsgetimds_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSGETIMDS_NOTIMPLEMENTED)
	#define USE_fudpsgetimds
	#define EXT_fudpsgetimds
	#define GET_fudpsgetimds(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpsgetimds(p0) 
	#define CHK_fudpsgetimds  FALSE
	#define EXP_fudpsgetimds  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpsgetimds
	#define EXT_fudpsgetimds
	#define GET_fudpsgetimds(fl)  CAL_CMGETAPI( "fudpsgetimds" ) 
	#define CAL_fudpsgetimds  fudpsgetimds
	#define CHK_fudpsgetimds  TRUE
	#define EXP_fudpsgetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetimds", (RTS_UINTPTR)fudpsgetimds, 1, 0xCBF12534, 0x01000000) 
	#define EXTREF_ITF_fudpsgetimds {(RTS_VOID_FCTPTR)fudpsgetimds, "fudpsgetimds", 0xCBF12534, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpsgetimds
	#define EXT_fudpsgetimds
	#define GET_fudpsgetimds(fl)  CAL_CMGETAPI( "fudpsgetimds" ) 
	#define CAL_fudpsgetimds  fudpsgetimds
	#define CHK_fudpsgetimds  TRUE
	#define EXP_fudpsgetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetimds", (RTS_UINTPTR)fudpsgetimds, 1, 0xCBF12534, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpsgetimds
	#define EXT_WagoSysDps_Internal_PFCfudpsgetimds
	#define GET_WagoSysDps_Internal_PFCfudpsgetimds  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpsgetimds  fudpsgetimds
	#define CHK_WagoSysDps_Internal_PFCfudpsgetimds  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpsgetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetimds", (RTS_UINTPTR)fudpsgetimds, 1, 0xCBF12534, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpsgetimds
	#define EXT_fudpsgetimds
	#define GET_fudpsgetimds(fl)  CAL_CMGETAPI( "fudpsgetimds" ) 
	#define CAL_fudpsgetimds  fudpsgetimds
	#define CHK_fudpsgetimds  TRUE
	#define EXP_fudpsgetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetimds", (RTS_UINTPTR)fudpsgetimds, 1, 0xCBF12534, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpsgetimds  PFFUDPSGETIMDS_IEC pffudpsgetimds;
	#define EXT_fudpsgetimds  extern PFFUDPSGETIMDS_IEC pffudpsgetimds;
	#define GET_fudpsgetimds(fl)  s_pfCMGetAPI2( "fudpsgetimds", (RTS_VOID_FCTPTR *)&pffudpsgetimds, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCBF12534, 0x01000000)
	#define CAL_fudpsgetimds  pffudpsgetimds
	#define CHK_fudpsgetimds  (pffudpsgetimds != NULL)
	#define EXP_fudpsgetimds   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetimds", (RTS_UINTPTR)fudpsgetimds, 1, 0xCBF12534, 0x01000000) 
#endif


/**
 * <description>fudpsgetsysdiag</description>
 */
typedef struct tagfudpsgetsysdiag_struct
{
	RTS_IEC_DWORD FuDpsGetSysDiag;		/* VAR_OUTPUT */	
	RTS_IEC_BYTE SLOT;					/* VAR_OUTPUT */	/* Slot */
	RTS_IEC_BYTE CODE;					/* VAR_OUTPUT */	/* error code */
	RTS_IEC_BYTE ARG;					/* VAR_OUTPUT */	/* error argument */
	RTS_IEC_BYTE EXT_ARG;				/* VAR_OUTPUT */	/* Advanced error argument */
} fudpsgetsysdiag_struct;

void CDECL CDECL_EXT fudpsgetsysdiag(fudpsgetsysdiag_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSGETSYSDIAG_IEC) (fudpsgetsysdiag_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSGETSYSDIAG_NOTIMPLEMENTED)
	#define USE_fudpsgetsysdiag
	#define EXT_fudpsgetsysdiag
	#define GET_fudpsgetsysdiag(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpsgetsysdiag(p0) 
	#define CHK_fudpsgetsysdiag  FALSE
	#define EXP_fudpsgetsysdiag  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpsgetsysdiag
	#define EXT_fudpsgetsysdiag
	#define GET_fudpsgetsysdiag(fl)  CAL_CMGETAPI( "fudpsgetsysdiag" ) 
	#define CAL_fudpsgetsysdiag  fudpsgetsysdiag
	#define CHK_fudpsgetsysdiag  TRUE
	#define EXP_fudpsgetsysdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetsysdiag", (RTS_UINTPTR)fudpsgetsysdiag, 1, 0xE86AD1E4, 0x01000000) 
	#define EXTREF_ITF_fudpsgetsysdiag {(RTS_VOID_FCTPTR)fudpsgetsysdiag, "fudpsgetsysdiag", 0xE86AD1E4, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpsgetsysdiag
	#define EXT_fudpsgetsysdiag
	#define GET_fudpsgetsysdiag(fl)  CAL_CMGETAPI( "fudpsgetsysdiag" ) 
	#define CAL_fudpsgetsysdiag  fudpsgetsysdiag
	#define CHK_fudpsgetsysdiag  TRUE
	#define EXP_fudpsgetsysdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetsysdiag", (RTS_UINTPTR)fudpsgetsysdiag, 1, 0xE86AD1E4, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpsgetsysdiag
	#define EXT_WagoSysDps_Internal_PFCfudpsgetsysdiag
	#define GET_WagoSysDps_Internal_PFCfudpsgetsysdiag  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpsgetsysdiag  fudpsgetsysdiag
	#define CHK_WagoSysDps_Internal_PFCfudpsgetsysdiag  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpsgetsysdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetsysdiag", (RTS_UINTPTR)fudpsgetsysdiag, 1, 0xE86AD1E4, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpsgetsysdiag
	#define EXT_fudpsgetsysdiag
	#define GET_fudpsgetsysdiag(fl)  CAL_CMGETAPI( "fudpsgetsysdiag" ) 
	#define CAL_fudpsgetsysdiag  fudpsgetsysdiag
	#define CHK_fudpsgetsysdiag  TRUE
	#define EXP_fudpsgetsysdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetsysdiag", (RTS_UINTPTR)fudpsgetsysdiag, 1, 0xE86AD1E4, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpsgetsysdiag  PFFUDPSGETSYSDIAG_IEC pffudpsgetsysdiag;
	#define EXT_fudpsgetsysdiag  extern PFFUDPSGETSYSDIAG_IEC pffudpsgetsysdiag;
	#define GET_fudpsgetsysdiag(fl)  s_pfCMGetAPI2( "fudpsgetsysdiag", (RTS_VOID_FCTPTR *)&pffudpsgetsysdiag, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xE86AD1E4, 0x01000000)
	#define CAL_fudpsgetsysdiag  pffudpsgetsysdiag
	#define CHK_fudpsgetsysdiag  (pffudpsgetsysdiag != NULL)
	#define EXP_fudpsgetsysdiag   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpsgetsysdiag", (RTS_UINTPTR)fudpsgetsysdiag, 1, 0xE86AD1E4, 0x01000000) 
#endif


/**
 * <description>fudpssenddiag</description>
 */
typedef struct tagfudpssenddiag_struct
{
	RTS_IEC_BOOL REQ;					/* VAR_INPUT */	/* Controls the transmission process:
	                                	TRUE: Starts sending the station diagnosis.
	                                	FALSE: Just call the state of the transmission process. */
	RTS_IEC_DWORD FuDpsSendDiag;		/* VAR_OUTPUT */	
	RTS_IEC_BOOL BUSY;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process back:
	                                	TRUE:	Transmission is in progress
	                                	FALSE:  Sending completed */
	RTS_IEC_BOOL DONE;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process:
	                                	TRUE:	Sending completed
	                                	FALSE:	Transmission is in progress */
	RTS_IEC_BOOL DIAG_OVL;				/* VAR_OUTPUT */	/* Indicates an overflow of the diagnostic data:
	                                	TRUE: There are more diagnostic data than can fit in the available diagnostic data area.
	                                	FALSE: The diagnostic data can fit in the available diagnostic data area. */
} fudpssenddiag_struct;

void CDECL CDECL_EXT fudpssenddiag(fudpssenddiag_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSENDDIAG_IEC) (fudpssenddiag_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSENDDIAG_NOTIMPLEMENTED)
	#define USE_fudpssenddiag
	#define EXT_fudpssenddiag
	#define GET_fudpssenddiag(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssenddiag(p0) 
	#define CHK_fudpssenddiag  FALSE
	#define EXP_fudpssenddiag  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssenddiag
	#define EXT_fudpssenddiag
	#define GET_fudpssenddiag(fl)  CAL_CMGETAPI( "fudpssenddiag" ) 
	#define CAL_fudpssenddiag  fudpssenddiag
	#define CHK_fudpssenddiag  TRUE
	#define EXP_fudpssenddiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssenddiag", (RTS_UINTPTR)fudpssenddiag, 1, 0xA09A95DB, 0x01000000) 
	#define EXTREF_ITF_fudpssenddiag {(RTS_VOID_FCTPTR)fudpssenddiag, "fudpssenddiag", 0xA09A95DB, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssenddiag
	#define EXT_fudpssenddiag
	#define GET_fudpssenddiag(fl)  CAL_CMGETAPI( "fudpssenddiag" ) 
	#define CAL_fudpssenddiag  fudpssenddiag
	#define CHK_fudpssenddiag  TRUE
	#define EXP_fudpssenddiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssenddiag", (RTS_UINTPTR)fudpssenddiag, 1, 0xA09A95DB, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssenddiag
	#define EXT_WagoSysDps_Internal_PFCfudpssenddiag
	#define GET_WagoSysDps_Internal_PFCfudpssenddiag  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssenddiag  fudpssenddiag
	#define CHK_WagoSysDps_Internal_PFCfudpssenddiag  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssenddiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssenddiag", (RTS_UINTPTR)fudpssenddiag, 1, 0xA09A95DB, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssenddiag
	#define EXT_fudpssenddiag
	#define GET_fudpssenddiag(fl)  CAL_CMGETAPI( "fudpssenddiag" ) 
	#define CAL_fudpssenddiag  fudpssenddiag
	#define CHK_fudpssenddiag  TRUE
	#define EXP_fudpssenddiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssenddiag", (RTS_UINTPTR)fudpssenddiag, 1, 0xA09A95DB, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssenddiag  PFFUDPSSENDDIAG_IEC pffudpssenddiag;
	#define EXT_fudpssenddiag  extern PFFUDPSSENDDIAG_IEC pffudpssenddiag;
	#define GET_fudpssenddiag(fl)  s_pfCMGetAPI2( "fudpssenddiag", (RTS_VOID_FCTPTR *)&pffudpssenddiag, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xA09A95DB, 0x01000000)
	#define CAL_fudpssenddiag  pffudpssenddiag
	#define CHK_fudpssenddiag  (pffudpssenddiag != NULL)
	#define EXP_fudpssenddiag   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssenddiag", (RTS_UINTPTR)fudpssenddiag, 1, 0xA09A95DB, 0x01000000) 
#endif


/**
 * <description>fudpssetalarm</description>
 */
typedef struct tagfudpssetalarm_struct
{
	RTS_IEC_BOOL REQ;					/* VAR_INPUT */	/* Controls the transmission process:
	                                        	TRUE: Starts sending the station diagnosis.
	                                        	FALSE: Just call the state of the transmission process. */
	RTS_IEC_BOOL SET_DIAG;				/* VAR_INPUT */	/* Controls the diagnostic object processing:
	                                        	TRUE: Diagnostic object is created. At the output of "DIAG_ID" the 
	                                        		  identification number of the new diagnostic object is output
	                                        	FALSE: Diagnostic object is deleted. At the entrance "DIAG_ID" the 
	                                        		identification number of the erased diagnostic object must be specified */
	RTS_IEC_USINT SLOT;					/* VAR_INPUT */	/* Specifies the slot information to the diagnostic objec */
	RTS_IEC_BYTE ALARM_TYPE;			/* VAR_INPUT */	/* Specifies the type of the alarm */
	RTS_IEC_BYTE ALRAM_SPEC;			/* VAR_INPUT */	/* "Specifier" of the alarm. */
	RTS_IEC_BOOL ADD_ACK;				/* VAR_INPUT */	
	RTS_IEC_BYTE *USR_DATA;				/* VAR_INPUT */	/* Pointer to the memory area of the user data */
	RTS_IEC_USINT USR_DATA_LEN;			/* VAR_INPUT */	/* Specifies the length of the user data in number of bytes. 
		                                   		Supports user data with a maximum length of 4 bytes */
	RTS_IEC_DWORD *DIAG_ID;				/* VAR_IN_OUT */	/* Identification of the diagnostic object. When you create a diagnostic  
	                                        	object the identification number is returned. When you delete a diagnostic 
	                                       		object the corresponding identification number must be passed */
	RTS_IEC_DWORD FuDpsSetAlarm;		/* VAR_OUTPUT */	
	RTS_IEC_BOOL BUSY;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process back: 
												TRUE:	Transmission is in progress 
												FALSE:  Sending completed */
	RTS_IEC_BOOL DONE;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process:
	                                        	TRUE:	Sending completed
	                                        	FALSE:	Transmission is in progress */
} fudpssetalarm_struct;

void CDECL CDECL_EXT fudpssetalarm(fudpssetalarm_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSETALARM_IEC) (fudpssetalarm_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSETALARM_NOTIMPLEMENTED)
	#define USE_fudpssetalarm
	#define EXT_fudpssetalarm
	#define GET_fudpssetalarm(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssetalarm(p0) 
	#define CHK_fudpssetalarm  FALSE
	#define EXP_fudpssetalarm  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssetalarm
	#define EXT_fudpssetalarm
	#define GET_fudpssetalarm(fl)  CAL_CMGETAPI( "fudpssetalarm" ) 
	#define CAL_fudpssetalarm  fudpssetalarm
	#define CHK_fudpssetalarm  TRUE
	#define EXP_fudpssetalarm  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetalarm", (RTS_UINTPTR)fudpssetalarm, 1, 0xFBC478E4, 0x01000000) 
	#define EXTREF_ITF_fudpssetalarm {(RTS_VOID_FCTPTR)fudpssetalarm, "fudpssetalarm", 0xFBC478E4, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssetalarm
	#define EXT_fudpssetalarm
	#define GET_fudpssetalarm(fl)  CAL_CMGETAPI( "fudpssetalarm" ) 
	#define CAL_fudpssetalarm  fudpssetalarm
	#define CHK_fudpssetalarm  TRUE
	#define EXP_fudpssetalarm  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetalarm", (RTS_UINTPTR)fudpssetalarm, 1, 0xFBC478E4, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssetalarm
	#define EXT_WagoSysDps_Internal_PFCfudpssetalarm
	#define GET_WagoSysDps_Internal_PFCfudpssetalarm  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssetalarm  fudpssetalarm
	#define CHK_WagoSysDps_Internal_PFCfudpssetalarm  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssetalarm  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetalarm", (RTS_UINTPTR)fudpssetalarm, 1, 0xFBC478E4, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssetalarm
	#define EXT_fudpssetalarm
	#define GET_fudpssetalarm(fl)  CAL_CMGETAPI( "fudpssetalarm" ) 
	#define CAL_fudpssetalarm  fudpssetalarm
	#define CHK_fudpssetalarm  TRUE
	#define EXP_fudpssetalarm  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetalarm", (RTS_UINTPTR)fudpssetalarm, 1, 0xFBC478E4, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssetalarm  PFFUDPSSETALARM_IEC pffudpssetalarm;
	#define EXT_fudpssetalarm  extern PFFUDPSSETALARM_IEC pffudpssetalarm;
	#define GET_fudpssetalarm(fl)  s_pfCMGetAPI2( "fudpssetalarm", (RTS_VOID_FCTPTR *)&pffudpssetalarm, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xFBC478E4, 0x01000000)
	#define CAL_fudpssetalarm  pffudpssetalarm
	#define CHK_fudpssetalarm  (pffudpssetalarm != NULL)
	#define EXP_fudpssetalarm   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetalarm", (RTS_UINTPTR)fudpssetalarm, 1, 0xFBC478E4, 0x01000000) 
#endif


/**
 * <description>fudpssetchanreldiag</description>
 */
typedef struct tagfudpssetchanreldiag_struct
{
	RTS_IEC_BOOL REQ;					/* VAR_INPUT */	/* Controls the transmission process:
	                                	TRUE: Starts sending the station diagnosis.
	                                	FALSE: Just call the state of the transmission process. */
	RTS_IEC_BOOL SET_DIAG;				/* VAR_INPUT */	/* Controls the diagnostic object processing:
	                                	TRUE: Diagnostic object is created. At the output of "DIAG_ID" the 
	                                		  identification number of the new diagnostic object is output
	                                	FALSE: Diagnostic object is deleted. At the entrance "DIAG_ID" the 
	                                		identification number of the erased diagnostic object must be specified */
	RTS_IEC_USINT SLOT;					/* VAR_INPUT */	/* Specifies the slot information to the diagnostic objec */
	RTS_IEC_USINT CHAN;					/* VAR_INPUT */	/* Specifies the channel number in the diagnostic object */
	RTS_IEC_BYTE CHAN_TYPE;				/* VAR_INPUT */	/* Specifies the channel type of the diagnostic object */
	RTS_IEC_BYTE CHAN_SIZE;				/* VAR_INPUT */	/* Indicates the channel size on the diagnostic object */
	RTS_IEC_BYTE ERR_TYPE;				/* VAR_INPUT */	/* Specifies the type of error in the diagnostic object */
	RTS_IEC_DWORD *DIAG_ID;				/* VAR_IN_OUT */	/* Identification OF the diagnostic object. When you create a diagnostic object, here the 
	                                	identification number is returned. When you delete a diagnostic object here the corresponding 
	                                	identification number must be passed. */
	RTS_IEC_DWORD FuDpsSetChanRelDiag;	/* VAR_OUTPUT */	
	RTS_IEC_BOOL BUSY;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process back:
	                                	TRUE:	Transmission is in progress
	                                	FALSE:  Sending completed */
	RTS_IEC_BOOL DONE;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process:
	                                	TRUE:	Sending completed
	                                	FALSE:	Transmission is in progress */
} fudpssetchanreldiag_struct;

void CDECL CDECL_EXT fudpssetchanreldiag(fudpssetchanreldiag_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSETCHANRELDIAG_IEC) (fudpssetchanreldiag_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSETCHANRELDIAG_NOTIMPLEMENTED)
	#define USE_fudpssetchanreldiag
	#define EXT_fudpssetchanreldiag
	#define GET_fudpssetchanreldiag(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssetchanreldiag(p0) 
	#define CHK_fudpssetchanreldiag  FALSE
	#define EXP_fudpssetchanreldiag  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssetchanreldiag
	#define EXT_fudpssetchanreldiag
	#define GET_fudpssetchanreldiag(fl)  CAL_CMGETAPI( "fudpssetchanreldiag" ) 
	#define CAL_fudpssetchanreldiag  fudpssetchanreldiag
	#define CHK_fudpssetchanreldiag  TRUE
	#define EXP_fudpssetchanreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetchanreldiag", (RTS_UINTPTR)fudpssetchanreldiag, 1, 0xE7704876, 0x01000000) 
	#define EXTREF_ITF_fudpssetchanreldiag {(RTS_VOID_FCTPTR)fudpssetchanreldiag, "fudpssetchanreldiag", 0xE7704876, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssetchanreldiag
	#define EXT_fudpssetchanreldiag
	#define GET_fudpssetchanreldiag(fl)  CAL_CMGETAPI( "fudpssetchanreldiag" ) 
	#define CAL_fudpssetchanreldiag  fudpssetchanreldiag
	#define CHK_fudpssetchanreldiag  TRUE
	#define EXP_fudpssetchanreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetchanreldiag", (RTS_UINTPTR)fudpssetchanreldiag, 1, 0xE7704876, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssetchanreldiag
	#define EXT_WagoSysDps_Internal_PFCfudpssetchanreldiag
	#define GET_WagoSysDps_Internal_PFCfudpssetchanreldiag  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssetchanreldiag  fudpssetchanreldiag
	#define CHK_WagoSysDps_Internal_PFCfudpssetchanreldiag  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssetchanreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetchanreldiag", (RTS_UINTPTR)fudpssetchanreldiag, 1, 0xE7704876, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssetchanreldiag
	#define EXT_fudpssetchanreldiag
	#define GET_fudpssetchanreldiag(fl)  CAL_CMGETAPI( "fudpssetchanreldiag" ) 
	#define CAL_fudpssetchanreldiag  fudpssetchanreldiag
	#define CHK_fudpssetchanreldiag  TRUE
	#define EXP_fudpssetchanreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetchanreldiag", (RTS_UINTPTR)fudpssetchanreldiag, 1, 0xE7704876, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssetchanreldiag  PFFUDPSSETCHANRELDIAG_IEC pffudpssetchanreldiag;
	#define EXT_fudpssetchanreldiag  extern PFFUDPSSETCHANRELDIAG_IEC pffudpssetchanreldiag;
	#define GET_fudpssetchanreldiag(fl)  s_pfCMGetAPI2( "fudpssetchanreldiag", (RTS_VOID_FCTPTR *)&pffudpssetchanreldiag, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xE7704876, 0x01000000)
	#define CAL_fudpssetchanreldiag  pffudpssetchanreldiag
	#define CHK_fudpssetchanreldiag  (pffudpssetchanreldiag != NULL)
	#define EXP_fudpssetchanreldiag   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetchanreldiag", (RTS_UINTPTR)fudpssetchanreldiag, 1, 0xE7704876, 0x01000000) 
#endif


/**
 * <description>fudpssetidreldiag</description>
 */
typedef struct tagfudpssetidreldiag_struct
{
	RTS_IEC_USINT SLOT;					/* VAR_INPUT */	/* Specifies the slot information to the diagnostic objec */
	RTS_IEC_BOOL ERR_FLAG;				/* VAR_INPUT */	/* Error status OF the slot:
		                                	TRUE: Error is present
                                        	FALSE: No fault present */
	RTS_IEC_DWORD FuDpsSetIdRelDiag;	/* VAR_OUTPUT */	
} fudpssetidreldiag_struct;

void CDECL CDECL_EXT fudpssetidreldiag(fudpssetidreldiag_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSETIDRELDIAG_IEC) (fudpssetidreldiag_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSETIDRELDIAG_NOTIMPLEMENTED)
	#define USE_fudpssetidreldiag
	#define EXT_fudpssetidreldiag
	#define GET_fudpssetidreldiag(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssetidreldiag(p0) 
	#define CHK_fudpssetidreldiag  FALSE
	#define EXP_fudpssetidreldiag  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssetidreldiag
	#define EXT_fudpssetidreldiag
	#define GET_fudpssetidreldiag(fl)  CAL_CMGETAPI( "fudpssetidreldiag" ) 
	#define CAL_fudpssetidreldiag  fudpssetidreldiag
	#define CHK_fudpssetidreldiag  TRUE
	#define EXP_fudpssetidreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetidreldiag", (RTS_UINTPTR)fudpssetidreldiag, 1, 0x7DEAA4A3, 0x01000000) 
	#define EXTREF_ITF_fudpssetidreldiag {(RTS_VOID_FCTPTR)fudpssetidreldiag, "fudpssetidreldiag", 0x7DEAA4A3, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssetidreldiag
	#define EXT_fudpssetidreldiag
	#define GET_fudpssetidreldiag(fl)  CAL_CMGETAPI( "fudpssetidreldiag" ) 
	#define CAL_fudpssetidreldiag  fudpssetidreldiag
	#define CHK_fudpssetidreldiag  TRUE
	#define EXP_fudpssetidreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetidreldiag", (RTS_UINTPTR)fudpssetidreldiag, 1, 0x7DEAA4A3, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssetidreldiag
	#define EXT_WagoSysDps_Internal_PFCfudpssetidreldiag
	#define GET_WagoSysDps_Internal_PFCfudpssetidreldiag  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssetidreldiag  fudpssetidreldiag
	#define CHK_WagoSysDps_Internal_PFCfudpssetidreldiag  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssetidreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetidreldiag", (RTS_UINTPTR)fudpssetidreldiag, 1, 0x7DEAA4A3, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssetidreldiag
	#define EXT_fudpssetidreldiag
	#define GET_fudpssetidreldiag(fl)  CAL_CMGETAPI( "fudpssetidreldiag" ) 
	#define CAL_fudpssetidreldiag  fudpssetidreldiag
	#define CHK_fudpssetidreldiag  TRUE
	#define EXP_fudpssetidreldiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetidreldiag", (RTS_UINTPTR)fudpssetidreldiag, 1, 0x7DEAA4A3, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssetidreldiag  PFFUDPSSETIDRELDIAG_IEC pffudpssetidreldiag;
	#define EXT_fudpssetidreldiag  extern PFFUDPSSETIDRELDIAG_IEC pffudpssetidreldiag;
	#define GET_fudpssetidreldiag(fl)  s_pfCMGetAPI2( "fudpssetidreldiag", (RTS_VOID_FCTPTR *)&pffudpssetidreldiag, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7DEAA4A3, 0x01000000)
	#define CAL_fudpssetidreldiag  pffudpssetidreldiag
	#define CHK_fudpssetidreldiag  (pffudpssetidreldiag != NULL)
	#define EXP_fudpssetidreldiag   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetidreldiag", (RTS_UINTPTR)fudpssetidreldiag, 1, 0x7DEAA4A3, 0x01000000) 
#endif


/**
 * <description>fudpssetimds</description>
 */
typedef struct tagfudpssetimds_struct
{
	RTS_IEC_USINT DS_ID;				/* VAR_INPUT */	/* Specifies the number OF the I & M data set. Records 0-4 are supported */
	RTS_IEC_BYTE *DATA;					/* VAR_INPUT */	/* Returns the pointer to the memory area for the record data */
	RTS_IEC_DWORD FuDpsSetImDs;			/* VAR_OUTPUT */	
} fudpssetimds_struct;

void CDECL CDECL_EXT fudpssetimds(fudpssetimds_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSETIMDS_IEC) (fudpssetimds_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSETIMDS_NOTIMPLEMENTED)
	#define USE_fudpssetimds
	#define EXT_fudpssetimds
	#define GET_fudpssetimds(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssetimds(p0) 
	#define CHK_fudpssetimds  FALSE
	#define EXP_fudpssetimds  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssetimds
	#define EXT_fudpssetimds
	#define GET_fudpssetimds(fl)  CAL_CMGETAPI( "fudpssetimds" ) 
	#define CAL_fudpssetimds  fudpssetimds
	#define CHK_fudpssetimds  TRUE
	#define EXP_fudpssetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetimds", (RTS_UINTPTR)fudpssetimds, 1, 0x7BBED9FF, 0x01000000) 
	#define EXTREF_ITF_fudpssetimds {(RTS_VOID_FCTPTR)fudpssetimds, "fudpssetimds", 0x7BBED9FF, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssetimds
	#define EXT_fudpssetimds
	#define GET_fudpssetimds(fl)  CAL_CMGETAPI( "fudpssetimds" ) 
	#define CAL_fudpssetimds  fudpssetimds
	#define CHK_fudpssetimds  TRUE
	#define EXP_fudpssetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetimds", (RTS_UINTPTR)fudpssetimds, 1, 0x7BBED9FF, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssetimds
	#define EXT_WagoSysDps_Internal_PFCfudpssetimds
	#define GET_WagoSysDps_Internal_PFCfudpssetimds  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssetimds  fudpssetimds
	#define CHK_WagoSysDps_Internal_PFCfudpssetimds  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetimds", (RTS_UINTPTR)fudpssetimds, 1, 0x7BBED9FF, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssetimds
	#define EXT_fudpssetimds
	#define GET_fudpssetimds(fl)  CAL_CMGETAPI( "fudpssetimds" ) 
	#define CAL_fudpssetimds  fudpssetimds
	#define CHK_fudpssetimds  TRUE
	#define EXP_fudpssetimds  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetimds", (RTS_UINTPTR)fudpssetimds, 1, 0x7BBED9FF, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssetimds  PFFUDPSSETIMDS_IEC pffudpssetimds;
	#define EXT_fudpssetimds  extern PFFUDPSSETIMDS_IEC pffudpssetimds;
	#define GET_fudpssetimds(fl)  s_pfCMGetAPI2( "fudpssetimds", (RTS_VOID_FCTPTR *)&pffudpssetimds, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7BBED9FF, 0x01000000)
	#define CAL_fudpssetimds  pffudpssetimds
	#define CHK_fudpssetimds  (pffudpssetimds != NULL)
	#define EXP_fudpssetimds   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetimds", (RTS_UINTPTR)fudpssetimds, 1, 0x7BBED9FF, 0x01000000) 
#endif


/**
 * <description>fudpssetmodstatdiag</description>
 */
typedef struct tagfudpssetmodstatdiag_struct
{
	RTS_IEC_USINT SLOT;					/* VAR_INPUT */	/* Specifies the slot information to the diagnostic objec */
	RTS_IEC_BYTE MODE_STAT;				/* VAR_INPUT */	/* Error status of the slot:
	                                    	0x00	data valid
	                                    	0x01	data invalid
	                                    	0x10	incorrect Feldbusvariable
	                                    	0x11	no Feldbusvariable */
	RTS_IEC_DWORD FuDpsSetModStatDiag;	/* VAR_OUTPUT */	
} fudpssetmodstatdiag_struct;

void CDECL CDECL_EXT fudpssetmodstatdiag(fudpssetmodstatdiag_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSETMODSTATDIAG_IEC) (fudpssetmodstatdiag_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSETMODSTATDIAG_NOTIMPLEMENTED)
	#define USE_fudpssetmodstatdiag
	#define EXT_fudpssetmodstatdiag
	#define GET_fudpssetmodstatdiag(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssetmodstatdiag(p0) 
	#define CHK_fudpssetmodstatdiag  FALSE
	#define EXP_fudpssetmodstatdiag  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssetmodstatdiag
	#define EXT_fudpssetmodstatdiag
	#define GET_fudpssetmodstatdiag(fl)  CAL_CMGETAPI( "fudpssetmodstatdiag" ) 
	#define CAL_fudpssetmodstatdiag  fudpssetmodstatdiag
	#define CHK_fudpssetmodstatdiag  TRUE
	#define EXP_fudpssetmodstatdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetmodstatdiag", (RTS_UINTPTR)fudpssetmodstatdiag, 1, 0x21F8C96F, 0x01000000) 
	#define EXTREF_ITF_fudpssetmodstatdiag {(RTS_VOID_FCTPTR)fudpssetmodstatdiag, "fudpssetmodstatdiag", 0x21F8C96F, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssetmodstatdiag
	#define EXT_fudpssetmodstatdiag
	#define GET_fudpssetmodstatdiag(fl)  CAL_CMGETAPI( "fudpssetmodstatdiag" ) 
	#define CAL_fudpssetmodstatdiag  fudpssetmodstatdiag
	#define CHK_fudpssetmodstatdiag  TRUE
	#define EXP_fudpssetmodstatdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetmodstatdiag", (RTS_UINTPTR)fudpssetmodstatdiag, 1, 0x21F8C96F, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssetmodstatdiag
	#define EXT_WagoSysDps_Internal_PFCfudpssetmodstatdiag
	#define GET_WagoSysDps_Internal_PFCfudpssetmodstatdiag  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssetmodstatdiag  fudpssetmodstatdiag
	#define CHK_WagoSysDps_Internal_PFCfudpssetmodstatdiag  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssetmodstatdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetmodstatdiag", (RTS_UINTPTR)fudpssetmodstatdiag, 1, 0x21F8C96F, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssetmodstatdiag
	#define EXT_fudpssetmodstatdiag
	#define GET_fudpssetmodstatdiag(fl)  CAL_CMGETAPI( "fudpssetmodstatdiag" ) 
	#define CAL_fudpssetmodstatdiag  fudpssetmodstatdiag
	#define CHK_fudpssetmodstatdiag  TRUE
	#define EXP_fudpssetmodstatdiag  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetmodstatdiag", (RTS_UINTPTR)fudpssetmodstatdiag, 1, 0x21F8C96F, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssetmodstatdiag  PFFUDPSSETMODSTATDIAG_IEC pffudpssetmodstatdiag;
	#define EXT_fudpssetmodstatdiag  extern PFFUDPSSETMODSTATDIAG_IEC pffudpssetmodstatdiag;
	#define GET_fudpssetmodstatdiag(fl)  s_pfCMGetAPI2( "fudpssetmodstatdiag", (RTS_VOID_FCTPTR *)&pffudpssetmodstatdiag, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x21F8C96F, 0x01000000)
	#define CAL_fudpssetmodstatdiag  pffudpssetmodstatdiag
	#define CHK_fudpssetmodstatdiag  (pffudpssetmodstatdiag != NULL)
	#define EXP_fudpssetmodstatdiag   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetmodstatdiag", (RTS_UINTPTR)fudpssetmodstatdiag, 1, 0x21F8C96F, 0x01000000) 
#endif


/**
 * <description>fudpssetstatusmsg</description>
 */
typedef struct tagfudpssetstatusmsg_struct
{
	RTS_IEC_BOOL REQ;					/* VAR_INPUT */	/* Controls the transmission process:
	                                        		TRUE: Starts sending the station diagnosis.
	                                        		FALSE: Just call the state of the transmission process. */
	RTS_IEC_BOOL SET_DIAG;				/* VAR_INPUT */	/* Controls the diagnostic object processing:
	                                        		TRUE: 	Diagnostic object is created. At the output of "DIAG_ID" the identification 
	                                        				number of the new diagnostic object is output.
	                                        		FALSE:  Diagnostic object is deleted. At the entrance "DIAG_ID" the 
	                                        				identification number of the erased diagnostic object must be specified */
	RTS_IEC_USINT SLOT;					/* VAR_INPUT */	/* Specifies the slot information to the diagnostic objec */
	RTS_IEC_BYTE STATUS_TYPE;			/* VAR_INPUT */	/* Indicates the type of status message */
	RTS_IEC_BYTE STATUS_SPEC;			/* VAR_INPUT */	/* Specifies the "specifier" of the status message. */
	RTS_IEC_BYTE *USR_DATA;				/* VAR_INPUT */	/* Pointer to the memory area of the user data. */
	RTS_IEC_USINT USR_DATA_LEN;			/* VAR_INPUT */	/* Specifies the length OF the user data in number OF bytes TO. User data 
	                                        		with a maximum length of 4 bytes are supported. */
	RTS_IEC_DWORD *DIAG_ID;				/* VAR_IN_OUT */	/* Identification of the diagnostic object. When you create a diagnostic 
	                                        	object the identification number is returned. When you delete a diagnostic 
	                                        	object the corresponding identification number must be passed */
	RTS_IEC_DWORD FuDpsSetStatusMsg;	/* VAR_OUTPUT */	
	RTS_IEC_BOOL BUSY;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process back:
	                                        	TRUE:	Transmission is in progress
	                                        	FALSE:  Sending completed */
	RTS_IEC_BOOL DONE;					/* VAR_OUTPUT */	/* Returns the state OF the transmission process:
	                                        	TRUE:	Sending completed
	                                        	FALSE:	Transmission is in progress */
} fudpssetstatusmsg_struct;

void CDECL CDECL_EXT fudpssetstatusmsg(fudpssetstatusmsg_struct *p);
typedef void (CDECL CDECL_EXT* PFFUDPSSETSTATUSMSG_IEC) (fudpssetstatusmsg_struct *p);
#if defined(WAGOSYSDPS_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUDPSSETSTATUSMSG_NOTIMPLEMENTED)
	#define USE_fudpssetstatusmsg
	#define EXT_fudpssetstatusmsg
	#define GET_fudpssetstatusmsg(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fudpssetstatusmsg(p0) 
	#define CHK_fudpssetstatusmsg  FALSE
	#define EXP_fudpssetstatusmsg  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fudpssetstatusmsg
	#define EXT_fudpssetstatusmsg
	#define GET_fudpssetstatusmsg(fl)  CAL_CMGETAPI( "fudpssetstatusmsg" ) 
	#define CAL_fudpssetstatusmsg  fudpssetstatusmsg
	#define CHK_fudpssetstatusmsg  TRUE
	#define EXP_fudpssetstatusmsg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetstatusmsg", (RTS_UINTPTR)fudpssetstatusmsg, 1, 0x60A04941, 0x01000000) 
	#define EXTREF_ITF_fudpssetstatusmsg {(RTS_VOID_FCTPTR)fudpssetstatusmsg, "fudpssetstatusmsg", 0x60A04941, 0x01000000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSDPS_INTERNAL_PFC_EXTERNAL)
	#define USE_fudpssetstatusmsg
	#define EXT_fudpssetstatusmsg
	#define GET_fudpssetstatusmsg(fl)  CAL_CMGETAPI( "fudpssetstatusmsg" ) 
	#define CAL_fudpssetstatusmsg  fudpssetstatusmsg
	#define CHK_fudpssetstatusmsg  TRUE
	#define EXP_fudpssetstatusmsg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetstatusmsg", (RTS_UINTPTR)fudpssetstatusmsg, 1, 0x60A04941, 0x01000000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysDps_Internal_PFCfudpssetstatusmsg
	#define EXT_WagoSysDps_Internal_PFCfudpssetstatusmsg
	#define GET_WagoSysDps_Internal_PFCfudpssetstatusmsg  ERR_OK
	#define CAL_WagoSysDps_Internal_PFCfudpssetstatusmsg  fudpssetstatusmsg
	#define CHK_WagoSysDps_Internal_PFCfudpssetstatusmsg  TRUE
	#define EXP_WagoSysDps_Internal_PFCfudpssetstatusmsg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetstatusmsg", (RTS_UINTPTR)fudpssetstatusmsg, 1, 0x60A04941, 0x01000000) 
#elif defined(CPLUSPLUS)
	#define USE_fudpssetstatusmsg
	#define EXT_fudpssetstatusmsg
	#define GET_fudpssetstatusmsg(fl)  CAL_CMGETAPI( "fudpssetstatusmsg" ) 
	#define CAL_fudpssetstatusmsg  fudpssetstatusmsg
	#define CHK_fudpssetstatusmsg  TRUE
	#define EXP_fudpssetstatusmsg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetstatusmsg", (RTS_UINTPTR)fudpssetstatusmsg, 1, 0x60A04941, 0x01000000) 
#else /* DYNAMIC_LINK */
	#define USE_fudpssetstatusmsg  PFFUDPSSETSTATUSMSG_IEC pffudpssetstatusmsg;
	#define EXT_fudpssetstatusmsg  extern PFFUDPSSETSTATUSMSG_IEC pffudpssetstatusmsg;
	#define GET_fudpssetstatusmsg(fl)  s_pfCMGetAPI2( "fudpssetstatusmsg", (RTS_VOID_FCTPTR *)&pffudpssetstatusmsg, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x60A04941, 0x01000000)
	#define CAL_fudpssetstatusmsg  pffudpssetstatusmsg
	#define CHK_fudpssetstatusmsg  (pffudpssetstatusmsg != NULL)
	#define EXP_fudpssetstatusmsg   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fudpssetstatusmsg", (RTS_UINTPTR)fudpssetstatusmsg, 1, 0x60A04941, 0x01000000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/





typedef struct
{
	IBase_C *pBase;
} IWagoSysDps_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysDps_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysDps_Internal_PFC
		#define ITF_WagoSysDps_Internal_PFC static IWagoSysDps_Internal_PFC *pIWagoSysDps_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysDps_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysDps_Internal_PFC_C		IWagoSysDps_Internal_PFC;
	#ifndef ITF_WagoSysDps_Internal_PFC
		#define ITF_WagoSysDps_Internal_PFC
	#endif
	#define EXTITF_WagoSysDps_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSDPS_INTERNAL_PFCITF_H_*/
