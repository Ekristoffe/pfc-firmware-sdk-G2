/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component Processor Load</name>
 *  <description>
 *      Small RTS library to determine the current processor load.
 *  </description>
 *  <copyright>
 *  (c) WAGO
 *  </copyright>
 */
#ifndef _TSCSYSPROCESSORLOADDEP_H_
#define _TSCSYSPROCESSORLOADDEP_H_

#define COMPONENT_NAME "TscSysProcessorLoad" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscSysProcessorLoad)
#define COMPONENT_NAME_UNQUOTED TscSysProcessorLoad





#include "CmpItf.h"
#include <sysdefines.h>
#include <setjmp.h>
#include <WagoSysdefines.h>

#define CLASSID_CTscSysProcessorLoad   ADDVENDORID(CMP_VENDORID, CLASSID_CTSCSYSPROCESSORLOAD)
#define CMPID_TscSysProcessorLoad      CMPID_TSCSYSPROCESSORLOAD

#define ERR_WAGO_SETTINGS_KEY_NOT_FOUND      (ERR_OEM_START +1)
#define ERR_WAGO_PROCESSORLOAD               (ERR_OEM_START +2)

#define LOGID_TscSysProcessorLoad_ProcessorLoadException       0x0001
#define LOGID_TscSysProcessorLoad_ProcessorLoad                0x0002
#define LOGID_CmpTscSysProcessorLoad_CgroupPathSettingsFailed  0x0003


#define CMP_VERSION         UINT32_C(0x02000000)
#define CMP_VERSION_STRING "2.0.0.0"
#define CMP_VERSION_RC      2,0,0,0
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"







/**
 * \file WagoSysProcessorLoadItf.h
 */
#include "WagoSysProcessorLoadItf.h"







#include "SysTaskItf.h"


#include "SysCpuHandlingItf.h"


#include "CmpSettingsItf.h"


#include "CMItf.h"


#include "SysExceptItf.h"


#include "CmpIecTaskItf.h"


#include "CmpEventMgrItf.h"


#include "WagoTypesProcessorLoadItf.h"



#ifndef RTS_TASKNAME_PROCESSORLOADWATCHDOG
    #define RTS_TASKNAME_PROCESSORLOADWATCHDOG           "ProcessorLoadWatchdog"
#endif
#ifndef RTS_TASKPRIO_PROCESSORLOADWATCHDOG
    #define RTS_TASKPRIO_PROCESSORLOADWATCHDOG           TASKPRIO_SYSTEM_BASE+10
#endif



        


      


      


        










     










     




#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pIWagoTypesProcessorLoad == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CWagoTypesProcessorLoad, &initResult); \
            if (pIBase != NULL) \
            { \
                pIWagoTypesProcessorLoad = (IWagoTypesProcessorLoad *)pIBase->QueryInterface(pIBase, ITFID_IWagoTypesProcessorLoad, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpEventMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpEventMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpEventMgr = (ICmpEventMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpEventMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpIecTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpIecTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpIecTask = (ICmpIecTask *)pIBase->QueryInterface(pIBase, ITFID_ICmpIecTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysExcept == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysExcept, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysExcept = (ISysExcept *)pIBase->QueryInterface(pIBase, ITFID_ISysExcept, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpSettings == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpSettings, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpSettings = (ICmpSettings *)pIBase->QueryInterface(pIBase, ITFID_ICmpSettings, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysCpuHandling == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysCpuHandling, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysCpuHandling = (ISysCpuHandling *)pIBase->QueryInterface(pIBase, ITFID_ISysCpuHandling, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysTask == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysTask, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysTask = (ISysTask *)pIBase->QueryInterface(pIBase, ITFID_ISysTask, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pIWagoTypesProcessorLoad = NULL; \
          pICmpEventMgr = NULL; \
          pICmpIecTask = NULL; \
          pISysExcept = NULL; \
          pICM = NULL; \
          pICmpSettings = NULL; \
          pISysCpuHandling = NULL; \
          pISysTask = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pIWagoTypesProcessorLoad != NULL) \
        { \
            pIBase = (IBase *)pIWagoTypesProcessorLoad->QueryInterface(pIWagoTypesProcessorLoad, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pIWagoTypesProcessorLoad = NULL; \
            } \
        } \
          if (pICmpEventMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpEventMgr->QueryInterface(pICmpEventMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpEventMgr = NULL; \
            } \
        } \
          if (pICmpIecTask != NULL) \
        { \
            pIBase = (IBase *)pICmpIecTask->QueryInterface(pICmpIecTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpIecTask = NULL; \
            } \
        } \
          if (pISysExcept != NULL) \
        { \
            pIBase = (IBase *)pISysExcept->QueryInterface(pISysExcept, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysExcept = NULL; \
            } \
        } \
          if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
          if (pICmpSettings != NULL) \
        { \
            pIBase = (IBase *)pICmpSettings->QueryInterface(pICmpSettings, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpSettings = NULL; \
            } \
        } \
          if (pISysCpuHandling != NULL) \
        { \
            pIBase = (IBase *)pISysCpuHandling->QueryInterface(pISysCpuHandling, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysCpuHandling = NULL; \
            } \
        } \
          if (pISysTask != NULL) \
        { \
            pIBase = (IBase *)pISysTask->QueryInterface(pISysTask, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysTask = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_CMExit(0);\
          if (ERR_OK == importResult ) importResult = GET_IecTaskExceptionHandler(0);\
          if (ERR_OK == importResult ) importResult = GET_SettgGetStringValue(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnd(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskResume(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskLeave(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskExit(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskSetExit(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskWaitInterval(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskEnter(0);\
          if (ERR_OK == importResult ) importResult = GET_SysTaskCreate(0);\
          if (ERR_OK == importResult ) TempResult = GET_EventPost2(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_EventDelete(CM_IMPORT_OPTIONAL_FUNCTION);\
          if (ERR_OK == importResult ) TempResult = GET_EventCreate(CM_IMPORT_OPTIONAL_FUNCTION);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCSYSPROCESSORLOAD_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)fbsysprocessorload__main, "fbsysprocessorload__main", 0x00C0FDA1, 0x02000102 },\
          { (RTS_VOID_FCTPTR)fbsysprocessorload__fb_exit, "fbsysprocessorload__fb_exit", 0x3DBBB01D, 0x02000102 },\
          { (RTS_VOID_FCTPTR)fbsysprocessorload__initload, "fbsysprocessorload__initload", 0x925CF62B, 0x02000102 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCSYSPROCESSORLOAD_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
              
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCSYSPROCESSORLOAD_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
              \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysTask     \
	ITF_SysCpuHandling     \
	ITF_CmpSettings     \
	ITF_CM     \
	ITF_SysExcept     \
	ITF_CmpIecTask     \
	ITF_CmpEventMgr      \
    USE_EventCreate      \
    USE_EventDelete      \
    USE_EventPost2      \
    USE_SysTaskCreate      \
    USE_SysTaskEnter      \
    USE_SysTaskWaitInterval      \
    USE_SysTaskSetExit      \
    USE_SysTaskExit      \
    USE_SysTaskLeave      \
    USE_SysTaskResume      \
    USE_SysTaskEnd      \
    USE_SettgGetStringValue      \
    USE_IecTaskExceptionHandler      \
    USE_CMExit     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysTask    \
	ITF_SysCpuHandling    \
	ITF_CmpSettings    \
	ITF_CM    \
	ITF_SysExcept    \
	ITF_CmpIecTask    \
	ITF_CmpEventMgr     \
    USE_EventCreate      \
    USE_EventDelete      \
    USE_EventPost2      \
    USE_SysTaskCreate      \
    USE_SysTaskEnter      \
    USE_SysTaskWaitInterval      \
    USE_SysTaskSetExit      \
    USE_SysTaskExit      \
    USE_SysTaskLeave      \
    USE_SysTaskResume      \
    USE_SysTaskEnd      \
    USE_SettgGetStringValue      \
    USE_IecTaskExceptionHandler      \
    USE_CMExit     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysTask    \
	EXTITF_SysCpuHandling    \
	EXTITF_CmpSettings    \
	EXTITF_CM    \
	EXTITF_SysExcept    \
	EXTITF_CmpIecTask    \
	EXTITF_CmpEventMgr     \
    EXT_EventCreate  \
    EXT_EventDelete  \
    EXT_EventPost2  \
    EXT_SysTaskCreate  \
    EXT_SysTaskEnter  \
    EXT_SysTaskWaitInterval  \
    EXT_SysTaskSetExit  \
    EXT_SysTaskExit  \
    EXT_SysTaskLeave  \
    EXT_SysTaskResume  \
    EXT_SysTaskEnd  \
    EXT_SettgGetStringValue  \
    EXT_IecTaskExceptionHandler  \
    EXT_CMExit 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscSysProcessorLoad__Entry
#endif


#ifdef CPLUSPLUS

class CTscSysProcessorLoad : public IWagoSysProcessorLoad 
{
    public:
        CTscSysProcessorLoad() : hTscSysProcessorLoad(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscSysProcessorLoad()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoSysProcessorLoad *)this);            
            else if (iid == ITFID_IWagoSysProcessorLoad)
                pItf = dynamic_cast<IWagoSysProcessorLoad *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hTscSysProcessorLoad;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
