 /**
 * <interfacename>WagoTypesProcessorLoad</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>GCL</description>
 */
#define EVTPARAMID_ProcessorLoadChanged     1
#define EVTVERSION_ProcessorLoadChanged     1
#define EVT_ProcessorLoadChanged		    MAKE_EVENTID(EVTCLASS_INFO, 1)


/**
 * Specifies how processor load changes are logged.
 */
#define ELOGLEVEL_OVERLOAD    0	/* Only log when overload is detected. */
#define ELOGLEVEL_NONE    1	/* Don't create any log entries. */
#define ELOGLEVEL_ALL    2	/* Create log entries for all events. */
/* Typed enum definition */
#define ELOGLEVEL    RTS_IEC_INT

/**
 * Reaction to overload detection
 */
#define EOVERLOADACTION_NONE    0	/* No reaction, just keep on working */
#define EOVERLOADACTION_THROWPROCESSORLOADEXCEPTION    1	/* Throw ProcessorLoadWatchdog_Exception -> immediately stops all tasks. */
/* Typed enum definition */
#define EOVERLOADACTION    RTS_IEC_INT

/**
 * <description>EVTPARAM_ProcessorLoadChanged</description>
 */
typedef struct tagEVTPARAM_ProcessorLoadChanged
{
	RTS_IEC_USINT usiLoad;
	RTS_IEC_BOOL IsThreshold1Reached;
	RTS_IEC_BOOL IsThreshold2Reached;
	RTS_IEC_BOOL IsOverload;
} EVTPARAM_ProcessorLoadChanged;

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/

