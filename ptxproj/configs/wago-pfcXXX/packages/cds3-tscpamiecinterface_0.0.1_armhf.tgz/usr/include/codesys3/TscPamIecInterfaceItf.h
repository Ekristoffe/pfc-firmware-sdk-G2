 /**
 * <interfacename>TscPamIecInterface</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _TSCPAMIECINTERFACEITF_H_
#define _TSCPAMIECINTERFACEITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>Enum: WagoPamErrno</description>
 */
#define WAGOPAMERRNO_PAM_SUCCESS    RTS_IEC_INT_C(0x0)	/* Successful FUNCTION RETURN */
#define WAGOPAMERRNO_PAM_OPEN_ERR    RTS_IEC_INT_C(0x1)	/* dlopen() failure when dynamically */
#define WAGOPAMERRNO_PAM_SYMBOL_ERR    RTS_IEC_INT_C(0x2)	/* Symbol NOT found */
#define WAGOPAMERRNO_PAM_SERVICE_ERR    RTS_IEC_INT_C(0x3)	/* Error in service module */
#define WAGOPAMERRNO_PAM_SYSTEM_ERR    RTS_IEC_INT_C(0x4)	/* System error */
#define WAGOPAMERRNO_PAM_BUF_ERR    RTS_IEC_INT_C(0x5)	/* Memory buffer error */
#define WAGOPAMERRNO_PAM_PERM_DENIED    RTS_IEC_INT_C(0x6)	/* Permission denied */
#define WAGOPAMERRNO_PAM_AUTH_ERR    RTS_IEC_INT_C(0x7)	/* Authentication failure */
#define WAGOPAMERRNO_PAM_CRED_INSUFFICIENT    RTS_IEC_INT_C(0x8)	/* Can NOT access authentication data */
#define WAGOPAMERRNO_PAM_AUTHINFO_UNAVAIL    RTS_IEC_INT_C(0x9)	/* Underlying authentication service */
#define WAGOPAMERRNO_PAM_USER_UNKNOWN    RTS_IEC_INT_C(0xA)	/* User NOT known TO the underlying */
#define WAGOPAMERRNO_PAM_MAXTRIES    RTS_IEC_INT_C(0xB)	/* An authentication service has */
#define WAGOPAMERRNO_PAM_NEW_AUTHTOK_REQD    RTS_IEC_INT_C(0xC)	/* New authentication token required. */
#define WAGOPAMERRNO_PAM_ACCT_EXPIRED    RTS_IEC_INT_C(0xD)	/* User account has expired */
#define WAGOPAMERRNO_PAM_SESSION_ERR    RTS_IEC_INT_C(0xE)	/* Can NOT make/remove an entry FOR */
#define WAGOPAMERRNO_PAM_CRED_UNAVAIL    RTS_IEC_INT_C(0xF)	/* Underlying authentication service */
#define WAGOPAMERRNO_PAM_CRED_EXPIRED    RTS_IEC_INT_C(0x10)	/* User credentials expired */
#define WAGOPAMERRNO_PAM_CRED_ERR    RTS_IEC_INT_C(0x11)	/* Failure setting user credentials */
#define WAGOPAMERRNO_PAM_NO_MODULE_DATA    RTS_IEC_INT_C(0x12)	/* No module specific data is present */
#define WAGOPAMERRNO_PAM_CONV_ERR    RTS_IEC_INT_C(0x13)	/* Conversation error */
#define WAGOPAMERRNO_PAM_AUTHTOK_ERR    RTS_IEC_INT_C(0x14)	/* Authentication token manipulation error */
#define WAGOPAMERRNO_PAM_AUTHTOK_RECOVERY_ERR    RTS_IEC_INT_C(0x15)	/* Authentication information */
#define WAGOPAMERRNO_PAM_AUTHTOK_LOCK_BUSY    RTS_IEC_INT_C(0x16)	/* Authentication token lock busy */
#define WAGOPAMERRNO_PAM_AUTHTOK_DISABLE_AGING    RTS_IEC_INT_C(0x17)	/* Authentication token aging disabled */
#define WAGOPAMERRNO_PAM_TRY_AGAIN    RTS_IEC_INT_C(0x18)	/* Preliminary check BY password service */
#define WAGOPAMERRNO_PAM_IGNORE    RTS_IEC_INT_C(0x19)	/* Ignore underlying account module */
#define WAGOPAMERRNO_PAM_ABORT    RTS_IEC_INT_C(0x1A)	/* Critical error (?module fail now request) */
#define WAGOPAMERRNO_PAM_AUTHTOK_EXPIRED    RTS_IEC_INT_C(0x1B)	/* user's authentication token has expired */
#define WAGOPAMERRNO_PAM_MODULE_UNKNOWN    RTS_IEC_INT_C(0x1C)	/* module is not known */
#define WAGOPAMERRNO_PAM_BAD_ITEM    RTS_IEC_INT_C(0x1D)	/* Bad item passed to pam_*_item() */
#define WAGOPAMERRNO_PAM_CONV_AGAIN    RTS_IEC_INT_C(0x1E)	/* conversation function is event driven */
#define WAGOPAMERRNO_PAM_INCOMPLETE    RTS_IEC_INT_C(0x1F)	/* and data is not available yet
 please call THIS FUNCTION again TO
 complete authentication stack. Before
 calling again, verify that conversation
 is completed */
/* Typed enum definition */
#define WAGOPAMERRNO    RTS_IEC_INT

/**
 *
 *
 ***Function**
 *
 *External function to determine if the users account is valid.
 *
 */
typedef struct tagfulinuxpamacctmgmt_struct
{
	RTS_IEC_WORD iFlags;				/* VAR_INPUT */	/* used for special modes */
	RTS_IEC_INT FuLinuxPamAcctMgmt;		/* VAR_OUTPUT, Enum: WAGOPAMERRNO */
} fulinuxpamacctmgmt_struct;

void CDECL CDECL_EXT fulinuxpamacctmgmt(fulinuxpamacctmgmt_struct *p);
typedef void (CDECL CDECL_EXT* PFFULINUXPAMACCTMGMT_IEC) (fulinuxpamacctmgmt_struct *p);
#if defined(TSCPAMIECINTERFACE_NOTIMPLEMENTED) || defined(FULINUXPAMACCTMGMT_NOTIMPLEMENTED)
	#define USE_fulinuxpamacctmgmt
	#define EXT_fulinuxpamacctmgmt
	#define GET_fulinuxpamacctmgmt(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fulinuxpamacctmgmt(p0) 
	#define CHK_fulinuxpamacctmgmt  FALSE
	#define EXP_fulinuxpamacctmgmt  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fulinuxpamacctmgmt
	#define EXT_fulinuxpamacctmgmt
	#define GET_fulinuxpamacctmgmt(fl)  CAL_CMGETAPI( "fulinuxpamacctmgmt" ) 
	#define CAL_fulinuxpamacctmgmt  fulinuxpamacctmgmt
	#define CHK_fulinuxpamacctmgmt  TRUE
	#define EXP_fulinuxpamacctmgmt  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamacctmgmt", (RTS_UINTPTR)fulinuxpamacctmgmt, 1, 0xDD6DB73E, 0x00000001) 
	#define EXTREF_ITF_fulinuxpamacctmgmt {(RTS_VOID_FCTPTR)fulinuxpamacctmgmt, "fulinuxpamacctmgmt", 0xDD6DB73E, 0x00000001}
#elif defined(MIXED_LINK) && !defined(TSCPAMIECINTERFACE_EXTERNAL)
	#define USE_fulinuxpamacctmgmt
	#define EXT_fulinuxpamacctmgmt
	#define GET_fulinuxpamacctmgmt(fl)  CAL_CMGETAPI( "fulinuxpamacctmgmt" ) 
	#define CAL_fulinuxpamacctmgmt  fulinuxpamacctmgmt
	#define CHK_fulinuxpamacctmgmt  TRUE
	#define EXP_fulinuxpamacctmgmt  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamacctmgmt", (RTS_UINTPTR)fulinuxpamacctmgmt, 1, 0xDD6DB73E, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscPamIecInterfacefulinuxpamacctmgmt
	#define EXT_TscPamIecInterfacefulinuxpamacctmgmt
	#define GET_TscPamIecInterfacefulinuxpamacctmgmt  ERR_OK
	#define CAL_TscPamIecInterfacefulinuxpamacctmgmt  fulinuxpamacctmgmt
	#define CHK_TscPamIecInterfacefulinuxpamacctmgmt  TRUE
	#define EXP_TscPamIecInterfacefulinuxpamacctmgmt  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamacctmgmt", (RTS_UINTPTR)fulinuxpamacctmgmt, 1, 0xDD6DB73E, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fulinuxpamacctmgmt
	#define EXT_fulinuxpamacctmgmt
	#define GET_fulinuxpamacctmgmt(fl)  CAL_CMGETAPI( "fulinuxpamacctmgmt" ) 
	#define CAL_fulinuxpamacctmgmt  fulinuxpamacctmgmt
	#define CHK_fulinuxpamacctmgmt  TRUE
	#define EXP_fulinuxpamacctmgmt  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamacctmgmt", (RTS_UINTPTR)fulinuxpamacctmgmt, 1, 0xDD6DB73E, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fulinuxpamacctmgmt  PFFULINUXPAMACCTMGMT_IEC pffulinuxpamacctmgmt;
	#define EXT_fulinuxpamacctmgmt  extern PFFULINUXPAMACCTMGMT_IEC pffulinuxpamacctmgmt;
	#define GET_fulinuxpamacctmgmt(fl)  s_pfCMGetAPI2( "fulinuxpamacctmgmt", (RTS_VOID_FCTPTR *)&pffulinuxpamacctmgmt, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xDD6DB73E, 0x00000001)
	#define CAL_fulinuxpamacctmgmt  pffulinuxpamacctmgmt
	#define CHK_fulinuxpamacctmgmt  (pffulinuxpamacctmgmt != NULL)
	#define EXP_fulinuxpamacctmgmt   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamacctmgmt", (RTS_UINTPTR)fulinuxpamacctmgmt, 1, 0xDD6DB73E, 0x00000001) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to authenticate the user
 *
 */
typedef struct tagfulinuxpamauthenticate_struct
{
	RTS_IEC_WORD iFlags;				/* VAR_INPUT */	/* used for special modes */
	RTS_IEC_INT FuLinuxPamAuthenticate;	/* VAR_OUTPUT, Enum: WAGOPAMERRNO */
} fulinuxpamauthenticate_struct;

void CDECL CDECL_EXT fulinuxpamauthenticate(fulinuxpamauthenticate_struct *p);
typedef void (CDECL CDECL_EXT* PFFULINUXPAMAUTHENTICATE_IEC) (fulinuxpamauthenticate_struct *p);
#if defined(TSCPAMIECINTERFACE_NOTIMPLEMENTED) || defined(FULINUXPAMAUTHENTICATE_NOTIMPLEMENTED)
	#define USE_fulinuxpamauthenticate
	#define EXT_fulinuxpamauthenticate
	#define GET_fulinuxpamauthenticate(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fulinuxpamauthenticate(p0) 
	#define CHK_fulinuxpamauthenticate  FALSE
	#define EXP_fulinuxpamauthenticate  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fulinuxpamauthenticate
	#define EXT_fulinuxpamauthenticate
	#define GET_fulinuxpamauthenticate(fl)  CAL_CMGETAPI( "fulinuxpamauthenticate" ) 
	#define CAL_fulinuxpamauthenticate  fulinuxpamauthenticate
	#define CHK_fulinuxpamauthenticate  TRUE
	#define EXP_fulinuxpamauthenticate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamauthenticate", (RTS_UINTPTR)fulinuxpamauthenticate, 1, 0x64DFA5BC, 0x00000001) 
	#define EXTREF_ITF_fulinuxpamauthenticate {(RTS_VOID_FCTPTR)fulinuxpamauthenticate, "fulinuxpamauthenticate", 0x64DFA5BC, 0x00000001}
#elif defined(MIXED_LINK) && !defined(TSCPAMIECINTERFACE_EXTERNAL)
	#define USE_fulinuxpamauthenticate
	#define EXT_fulinuxpamauthenticate
	#define GET_fulinuxpamauthenticate(fl)  CAL_CMGETAPI( "fulinuxpamauthenticate" ) 
	#define CAL_fulinuxpamauthenticate  fulinuxpamauthenticate
	#define CHK_fulinuxpamauthenticate  TRUE
	#define EXP_fulinuxpamauthenticate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamauthenticate", (RTS_UINTPTR)fulinuxpamauthenticate, 1, 0x64DFA5BC, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscPamIecInterfacefulinuxpamauthenticate
	#define EXT_TscPamIecInterfacefulinuxpamauthenticate
	#define GET_TscPamIecInterfacefulinuxpamauthenticate  ERR_OK
	#define CAL_TscPamIecInterfacefulinuxpamauthenticate  fulinuxpamauthenticate
	#define CHK_TscPamIecInterfacefulinuxpamauthenticate  TRUE
	#define EXP_TscPamIecInterfacefulinuxpamauthenticate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamauthenticate", (RTS_UINTPTR)fulinuxpamauthenticate, 1, 0x64DFA5BC, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fulinuxpamauthenticate
	#define EXT_fulinuxpamauthenticate
	#define GET_fulinuxpamauthenticate(fl)  CAL_CMGETAPI( "fulinuxpamauthenticate" ) 
	#define CAL_fulinuxpamauthenticate  fulinuxpamauthenticate
	#define CHK_fulinuxpamauthenticate  TRUE
	#define EXP_fulinuxpamauthenticate  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamauthenticate", (RTS_UINTPTR)fulinuxpamauthenticate, 1, 0x64DFA5BC, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fulinuxpamauthenticate  PFFULINUXPAMAUTHENTICATE_IEC pffulinuxpamauthenticate;
	#define EXT_fulinuxpamauthenticate  extern PFFULINUXPAMAUTHENTICATE_IEC pffulinuxpamauthenticate;
	#define GET_fulinuxpamauthenticate(fl)  s_pfCMGetAPI2( "fulinuxpamauthenticate", (RTS_VOID_FCTPTR *)&pffulinuxpamauthenticate, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x64DFA5BC, 0x00000001)
	#define CAL_fulinuxpamauthenticate  pffulinuxpamauthenticate
	#define CHK_fulinuxpamauthenticate  (pffulinuxpamauthenticate != NULL)
	#define EXP_fulinuxpamauthenticate   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamauthenticate", (RTS_UINTPTR)fulinuxpamauthenticate, 1, 0x64DFA5BC, 0x00000001) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to
 *
 */
typedef struct tagfulinuxpamend_struct
{
	RTS_IEC_INT iStatus;				/* VAR_INPUT */	
	RTS_IEC_INT FuLinuxPamEnd;			/* VAR_OUTPUT, Enum: WAGOPAMERRNO */
} fulinuxpamend_struct;

void CDECL CDECL_EXT fulinuxpamend(fulinuxpamend_struct *p);
typedef void (CDECL CDECL_EXT* PFFULINUXPAMEND_IEC) (fulinuxpamend_struct *p);
#if defined(TSCPAMIECINTERFACE_NOTIMPLEMENTED) || defined(FULINUXPAMEND_NOTIMPLEMENTED)
	#define USE_fulinuxpamend
	#define EXT_fulinuxpamend
	#define GET_fulinuxpamend(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fulinuxpamend(p0) 
	#define CHK_fulinuxpamend  FALSE
	#define EXP_fulinuxpamend  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fulinuxpamend
	#define EXT_fulinuxpamend
	#define GET_fulinuxpamend(fl)  CAL_CMGETAPI( "fulinuxpamend" ) 
	#define CAL_fulinuxpamend  fulinuxpamend
	#define CHK_fulinuxpamend  TRUE
	#define EXP_fulinuxpamend  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamend", (RTS_UINTPTR)fulinuxpamend, 1, 0xECC4276A, 0x00000001) 
	#define EXTREF_ITF_fulinuxpamend {(RTS_VOID_FCTPTR)fulinuxpamend, "fulinuxpamend", 0xECC4276A, 0x00000001}
#elif defined(MIXED_LINK) && !defined(TSCPAMIECINTERFACE_EXTERNAL)
	#define USE_fulinuxpamend
	#define EXT_fulinuxpamend
	#define GET_fulinuxpamend(fl)  CAL_CMGETAPI( "fulinuxpamend" ) 
	#define CAL_fulinuxpamend  fulinuxpamend
	#define CHK_fulinuxpamend  TRUE
	#define EXP_fulinuxpamend  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamend", (RTS_UINTPTR)fulinuxpamend, 1, 0xECC4276A, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscPamIecInterfacefulinuxpamend
	#define EXT_TscPamIecInterfacefulinuxpamend
	#define GET_TscPamIecInterfacefulinuxpamend  ERR_OK
	#define CAL_TscPamIecInterfacefulinuxpamend  fulinuxpamend
	#define CHK_TscPamIecInterfacefulinuxpamend  TRUE
	#define EXP_TscPamIecInterfacefulinuxpamend  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamend", (RTS_UINTPTR)fulinuxpamend, 1, 0xECC4276A, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fulinuxpamend
	#define EXT_fulinuxpamend
	#define GET_fulinuxpamend(fl)  CAL_CMGETAPI( "fulinuxpamend" ) 
	#define CAL_fulinuxpamend  fulinuxpamend
	#define CHK_fulinuxpamend  TRUE
	#define EXP_fulinuxpamend  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamend", (RTS_UINTPTR)fulinuxpamend, 1, 0xECC4276A, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fulinuxpamend  PFFULINUXPAMEND_IEC pffulinuxpamend;
	#define EXT_fulinuxpamend  extern PFFULINUXPAMEND_IEC pffulinuxpamend;
	#define GET_fulinuxpamend(fl)  s_pfCMGetAPI2( "fulinuxpamend", (RTS_VOID_FCTPTR *)&pffulinuxpamend, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xECC4276A, 0x00000001)
	#define CAL_fulinuxpamend  pffulinuxpamend
	#define CHK_fulinuxpamend  (pffulinuxpamend != NULL)
	#define EXP_fulinuxpamend   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamend", (RTS_UINTPTR)fulinuxpamend, 1, 0xECC4276A, 0x00000001) 
#endif


/**
 *
 *
 ***Function**
 *
 *External function to create the PAM context and initiate the PAM transaction
 *
 */
typedef struct tagfulinuxpamstart_struct
{
	RTS_IEC_STRING *pServiceName;		/* VAR_INPUT */	
	RTS_IEC_STRING *pUser;				/* VAR_INPUT */	
	RTS_IEC_STRING *pParameter;			/* VAR_INPUT */	/* i.e. Password */
	RTS_IEC_INT FuLinuxPamStart;		/* VAR_OUTPUT, Enum: WAGOPAMERRNO */
} fulinuxpamstart_struct;

void CDECL CDECL_EXT fulinuxpamstart(fulinuxpamstart_struct *p);
typedef void (CDECL CDECL_EXT* PFFULINUXPAMSTART_IEC) (fulinuxpamstart_struct *p);
#if defined(TSCPAMIECINTERFACE_NOTIMPLEMENTED) || defined(FULINUXPAMSTART_NOTIMPLEMENTED)
	#define USE_fulinuxpamstart
	#define EXT_fulinuxpamstart
	#define GET_fulinuxpamstart(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fulinuxpamstart(p0) 
	#define CHK_fulinuxpamstart  FALSE
	#define EXP_fulinuxpamstart  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fulinuxpamstart
	#define EXT_fulinuxpamstart
	#define GET_fulinuxpamstart(fl)  CAL_CMGETAPI( "fulinuxpamstart" ) 
	#define CAL_fulinuxpamstart  fulinuxpamstart
	#define CHK_fulinuxpamstart  TRUE
	#define EXP_fulinuxpamstart  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamstart", (RTS_UINTPTR)fulinuxpamstart, 1, 0x8D6976E0, 0x00000001) 
	#define EXTREF_ITF_fulinuxpamstart {(RTS_VOID_FCTPTR)fulinuxpamstart, "fulinuxpamstart", 0x8D6976E0, 0x00000001}
#elif defined(MIXED_LINK) && !defined(TSCPAMIECINTERFACE_EXTERNAL)
	#define USE_fulinuxpamstart
	#define EXT_fulinuxpamstart
	#define GET_fulinuxpamstart(fl)  CAL_CMGETAPI( "fulinuxpamstart" ) 
	#define CAL_fulinuxpamstart  fulinuxpamstart
	#define CHK_fulinuxpamstart  TRUE
	#define EXP_fulinuxpamstart  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamstart", (RTS_UINTPTR)fulinuxpamstart, 1, 0x8D6976E0, 0x00000001) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_TscPamIecInterfacefulinuxpamstart
	#define EXT_TscPamIecInterfacefulinuxpamstart
	#define GET_TscPamIecInterfacefulinuxpamstart  ERR_OK
	#define CAL_TscPamIecInterfacefulinuxpamstart  fulinuxpamstart
	#define CHK_TscPamIecInterfacefulinuxpamstart  TRUE
	#define EXP_TscPamIecInterfacefulinuxpamstart  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamstart", (RTS_UINTPTR)fulinuxpamstart, 1, 0x8D6976E0, 0x00000001) 
#elif defined(CPLUSPLUS)
	#define USE_fulinuxpamstart
	#define EXT_fulinuxpamstart
	#define GET_fulinuxpamstart(fl)  CAL_CMGETAPI( "fulinuxpamstart" ) 
	#define CAL_fulinuxpamstart  fulinuxpamstart
	#define CHK_fulinuxpamstart  TRUE
	#define EXP_fulinuxpamstart  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamstart", (RTS_UINTPTR)fulinuxpamstart, 1, 0x8D6976E0, 0x00000001) 
#else /* DYNAMIC_LINK */
	#define USE_fulinuxpamstart  PFFULINUXPAMSTART_IEC pffulinuxpamstart;
	#define EXT_fulinuxpamstart  extern PFFULINUXPAMSTART_IEC pffulinuxpamstart;
	#define GET_fulinuxpamstart(fl)  s_pfCMGetAPI2( "fulinuxpamstart", (RTS_VOID_FCTPTR *)&pffulinuxpamstart, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x8D6976E0, 0x00000001)
	#define CAL_fulinuxpamstart  pffulinuxpamstart
	#define CHK_fulinuxpamstart  (pffulinuxpamstart != NULL)
	#define EXP_fulinuxpamstart   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fulinuxpamstart", (RTS_UINTPTR)fulinuxpamstart, 1, 0x8D6976E0, 0x00000001) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} ITscPamIecInterface_C;

#ifdef CPLUSPLUS
class ITscPamIecInterface : public IBase
{
	public:
};
	#ifndef ITF_TscPamIecInterface
		#define ITF_TscPamIecInterface static ITscPamIecInterface *pITscPamIecInterface = NULL;
	#endif
	#define EXTITF_TscPamIecInterface
#else	/*CPLUSPLUS*/
	typedef ITscPamIecInterface_C		ITscPamIecInterface;
	#ifndef ITF_TscPamIecInterface
		#define ITF_TscPamIecInterface
	#endif
	#define EXTITF_TscPamIecInterface
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_TSCPAMIECINTERFACEITF_H_*/
