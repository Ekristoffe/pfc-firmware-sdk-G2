//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libmdmd-ng.h
///
///  \brief    C-API of WAGO Modem Manager Daemon - Next Gen
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef _INC_WAGO_MDMD_NG_LIBMDMD_NG_H_
#define _INC_WAGO_MDMD_NG_LIBMDMD_NG_H_
#include <stddef.h>

#define LIBMDMD_NG_IMEI_SIZE 16 ///Includes null character
#define LIBMDMD_NG_MODEL_MAX_NAME_SIZE 50  ///Includes null character
#define LIBMDMD_NG_MANUFACTURER_MAX_NAME_SIZE 50 ///Includes null character
#define LIBMDMD_NG_VERSION_MAX_NAME_SIZE 50 ///Includes null character


typedef struct
{
    char imei_number[LIBMDMD_NG_IMEI_SIZE];
    size_t length; /// Without null character
}t_imei;

typedef struct
{
  struct
  {
      char name[LIBMDMD_NG_MANUFACTURER_MAX_NAME_SIZE];
      size_t length; /// Without null character
  }manufacturer;

  struct
  {
      char name[LIBMDMD_NG_MODEL_MAX_NAME_SIZE];
      size_t length; /// Without null character
  }model;

  struct
  {
      char name[LIBMDMD_NG_MODEL_MAX_NAME_SIZE];
      size_t length; /// Without null character
  }version;

  t_imei imei;

}t_modem_info;

typedef enum
{
  debug = 0,
  info,
  warning,
  error,
  critical
}t_severity_level;

typedef enum
{
  SUCCESS = 0,
  ERROR = -1,
} libmdmd_ng_errno;

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

/**
 * @brief Get the IMEI of the current modem device.
 * @param imei Stores the IMEI without null character at the end. Size should be equal or greater than 15 bytes.
 * @return libmdmd-ng error code. 0 if succeed, -1 if an error occurred (See modem log for more information)
 */
  libmdmd_ng_errno get_imei(t_imei * imei_st);

/**
 * @brief Get manufacturer and model
 * @param modem_info Structure which will store the modem informations
 * @return libmdmd-ng error code. 0 if succeed, -1 if an error occurred (See modem log for more information)
 */
  libmdmd_ng_errno get_modem_info(t_modem_info * modem_info_st);

  /**
   * @brief Set the selected severity level of the logging mechanism.
   * @param severity level which will be set for the logging mechanism
   * @return libmdmd-ng error code. 0 if succeed, -1 if an error occurred (See modem log for more information)
   */
  libmdmd_ng_errno set_logging_severity_level(t_severity_level severity_level);

  /**
   * @brief Get the severity level of the logging mechanism.
   * @param severity level which will store the current severity level of the logging mechanism
   * @return libmdmd-ng error code. 0 if succeed, -1 if an error occurred (See modem log for more information)
   */
  libmdmd_ng_errno get_logging_severity_level(t_severity_level *severity_level);
#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus




#endif /* _INC_WAGO_MDMD_NG_LIBMDMD_NG_H_ */
//---- End of source file ------------------------------------------------------

