//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file    severity_level.hpp
///
///  \brief   Serverity level of the logger
///
///  \author  Dietrich Derksen :  WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------

#ifndef _INC_WAGO_MDMD_NG_SEVERITY_LEVEL_H_
#define _INC_WAGO_MDMD_NG_SEVERITY_LEVEL_H_

namespace wago {
namespace mdmdng {

enum class severity_level {
    debug, info, warning, error, critical
};

} // namespace mdmdng
} // namespace wago

#endif // _INC_WAGO_MDMD_NG_SEVERITY_LEVEL_H_
