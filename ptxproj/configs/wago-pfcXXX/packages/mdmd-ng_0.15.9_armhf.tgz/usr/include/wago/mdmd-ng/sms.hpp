//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     sms.hpp
///
///  \brief    SMS objects
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef SRC_MDMD_NG_SMS_HPP_
#define SRC_MDMD_NG_SMS_HPP_

#include <boost/serialization/serialization.hpp>

#include <string>
#include <ctime>
#include <cstring>
#include <cstdint>

namespace wago {
namespace mdmdng {

constexpr size_t max_pdu_size = 256;

class pdu
{
  public:
    pdu() = default;
    pdu(const uint8_t* pdu_data, const size_t& pdu_length)
    {
      m_pdu_length = (pdu_length < max_pdu_size) ? pdu_length : max_pdu_size-1;
      memcpy(static_cast<uint8_t*>(m_pdu_data), pdu_data, m_pdu_length);
    }

    const uint8_t* get_pdu_data() const
    {
      return static_cast<const uint8_t*>(m_pdu_data);
    }

    size_t get_pdu_length() const
    {
      return m_pdu_length;
    }

  private:
    uint8_t m_pdu_data[max_pdu_size] = {0};
    size_t m_pdu_length = 0;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/)
    {
      ar & m_pdu_data;
      ar & m_pdu_length;
    }
};

/**
 * SMS meta object which contains meta information of the SMS
 * @param phone_number Phone number of sender beginning with +"country code"
 * @param time Receiving time as epoch in seconds of the SMS
 * @param idx Index number the SMS in storage, will be used for read_sms function
 */
class sms_meta
{
  public:
    sms_meta() = default;
    sms_meta(const std::string& phone_number, const std::time_t& time, const int& idx):
      m_phone_number(phone_number),
      m_receving_time(time),
      m_storage_index(idx){}

    std::string get_phone_number()
    {
      return m_phone_number;
    }

    std::time_t get_receving_time()
    {
      return m_receving_time;
    }

    int get_storage_index()
    {
      return m_storage_index;
    }

  private:
    std::string m_phone_number = "";
    std::time_t m_receving_time = 0;
    int m_storage_index = 0;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/)
    {
      ar & m_phone_number;
      ar & m_receving_time;
      ar & m_storage_index;
    }
};

/**
 * SMS message object which contains either the message as text or in PDU format
 * @param m_is_pdu Bool which presents whether the message is in PDU format or not
 * @param m_has_meta Bool which presents whether the message has SMS meta information or not
 * @param m_text String which contains sms text message
 * @param m_pdu PDU object which contains the pdu data and length
 * @param m_meta @see sms_meta
 */
class sms_message
{
  public:
    sms_message() = default;
    sms_message(const std::string& text): m_text(text){}

    sms_message(const std::string& text, const sms_meta& meta): m_has_meta(true),
                                                                m_text(text),
                                                                m_meta(meta){}

    sms_message(const uint8_t* pdu_data, const size_t& pdulen): m_is_pdu(true),
                                                                m_pdu(pdu_data, pdulen){}

    sms_message(const uint8_t* pdu_data, const size_t& pdulen, const sms_meta& meta): m_is_pdu(true),
                                                                                      m_has_meta(true),
                                                                                      m_pdu(pdu_data, pdulen),
                                                                                      m_meta(meta){}

    bool is_pdu()
    {
      return m_is_pdu;
    }

    bool has_meta()
    {
      return m_has_meta;
    }

    pdu get_pdu()
    {
      return m_pdu;
    }

    std::string get_text()
    {
      return m_text;
    }

    sms_meta get_sms_meta()
    {
      return m_meta;
    }

  private:
    bool m_is_pdu = false;
    bool m_has_meta = false;
    std::string m_text = "";
    pdu m_pdu;
    sms_meta m_meta;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/)
    {
      ar & m_is_pdu;
      ar & m_has_meta;
      ar & m_text;
      ar & m_pdu;
      ar & m_meta;
    }
};


}
}
#endif /* SRC_MDMD_NG_SMS_HPP_ */
//---- End of source file ------------------------------------------------------

