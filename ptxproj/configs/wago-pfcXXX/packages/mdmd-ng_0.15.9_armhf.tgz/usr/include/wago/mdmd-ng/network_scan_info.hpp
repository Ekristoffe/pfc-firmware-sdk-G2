//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     network_scan_info.hpp
///
///  \brief    Network operator information from network scan
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_WAGO_MDMD_NG_NETWORK_SCAN_INFO_HPP_
#define INC_WAGO_MDMD_NG_NETWORK_SCAN_INFO_HPP_

#include "network_operator.hpp"
#include "network_technology.hpp"
#include <boost/serialization/serialization.hpp>
#include <string>
#include <utility>

namespace wago{
namespace mdmdng{

enum class operator_status
{
  UNKNOWN = 0,
  AVAILABLE,
  CURRENT,
  FORBIDDEN
};

class network_scan_info
{
  public:
    explicit network_scan_info() = default;
    explicit network_scan_info(std::string operator_name,
                               std::string operator_name_short,
                               std::string operator_code,
                               network_technology technology,
                               operator_status status): m_operator(std::move(operator_name),
                                                                   std::move(operator_name_short),
                                                                   std::move(operator_code)),
                                                        m_technology(technology),
                                                        m_status(status){};

    operator_status get_operator_status() const noexcept
    {
      return m_status;
    }

    void set_operator_status(operator_status status) noexcept
    {
      m_status = status;
    }

    network_technology get_technology() const noexcept
    {
      return m_technology;
    }

    void set_technology(network_technology technology)
    {
      m_technology = technology;
    }

    network_operator get_network_operator() const noexcept
    {
      return m_operator;
    }

    void set_network_operator(const network_operator& oper)
    {
      m_operator = oper;
    }

    void set_network_operator(const std::string& name, const std::string& name_short, const std::string& code)
    {
      m_operator = network_operator{name, name_short, code};
    }

  private:
    network_operator m_operator;
    network_technology m_technology = network_technology::UNKNOWN;
    operator_status m_status = operator_status::UNKNOWN;

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/)
    {
      ar & m_operator;
      ar & m_technology;
      ar & m_status;
    }
};
}
}
#endif /* INC_WAGO_MDMD_NG_NETWORK_OPERATOR_INFO_HPP_ */
//---- End of source file ------------------------------------------------------

