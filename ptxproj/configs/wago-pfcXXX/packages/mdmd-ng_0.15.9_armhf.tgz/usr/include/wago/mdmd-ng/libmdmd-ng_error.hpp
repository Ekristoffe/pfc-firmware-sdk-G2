//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file    libmdmd-ng_error.hpp
///
///  \brief   Exception handling for errors in libmdm-ng.
///
///  \author  MMy:  WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------

#ifndef SRC_MDMD_NG_LIBMODEM_ERROR_HPP
#define SRC_MDMD_NG_LIBMODEM_ERROR_HPP

#include <exception>
#include <string>

namespace wago {
namespace libmdmdng {

///
/// Handles an exception from libmdmdng.
///
class libmdmdng_error : public std::exception {
public:
  explicit libmdmdng_error(std::string error_message_) noexcept
      : error_message(std::move(error_message_)) {}
  const char *what() const noexcept override { return error_message.c_str(); }

private:
  std::string error_message;
};

class libmdmdng_invalid_state : public libmdmdng_error {
public:
  explicit libmdmdng_invalid_state(std::string error_message_) noexcept
      : libmdmdng_error(std::move(error_message_)) {}
};

class libmdmdng_invalid_pin_puk : public libmdmdng_error {
public:
  explicit libmdmdng_invalid_pin_puk(std::string error_message_) noexcept
      : libmdmdng_error(std::move(error_message_)) {}
};

class libmdmdng_modem_busy : public libmdmdng_error {
public:
  explicit libmdmdng_modem_busy(std::string error_message_) noexcept
      : libmdmdng_error(std::move(error_message_)) {}
};


} // namespace libmdmdng
} // namespace wago

#endif // SRC_MDMD_NG_LIBMODEM_ERROR_HPP
