//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     update_info.hpp
///
///  \brief    Update informations and flags
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_WAGO_MDMD_NG_UPDATE_INFO_HPP_
#define INC_WAGO_MDMD_NG_UPDATE_INFO_HPP_

#include <string>
#include <utility>

namespace wago{
namespace mdmdng{

enum class update_flag
{
  NONE,
  FORCE,
  REPLACE,
  DOWNGRADE
};

enum class update_state
{
  INACTIVE,
  IN_PROGRESS,
  FINISHED,
  ERROR
};

class update_info
{
  public:
    explicit update_info(update_state state = update_state::INACTIVE,
                         uint8_t progress = 0,
                         std::string error_msg = ""): m_state(state),
                                                      m_progress(progress),
                                                      m_error_msg(std::move(error_msg)){};

    update_state get_state()
    {
      return m_state;
    }

    uint8_t get_progress()
    {
      return m_progress;
    }

    std::string get_error_message()
    {
      return m_error_msg;
    }

    void set_state(const update_state& state)
    {
      m_state = state;
    }

    void set_progress(const uint8_t& progress)
    {
      m_progress = progress;
    }

    void set_error_msg(const std::string& msg)
    {
      m_error_msg = msg;
    }

    void set_update_start()
    {
      m_error_msg = "";
      m_state = update_state::IN_PROGRESS;
      m_progress = 0;
    }

    void set_update_finished()
    {
      m_error_msg = "";
      m_state = update_state::FINISHED;
      m_progress = 100;
    }

    void set_update_error(const std::string& error_message)
    {
      m_error_msg = error_message;
      m_state = update_state::ERROR;
      m_progress = 0;
    }

  private:
    update_state m_state;
    uint8_t m_progress;
    std::string m_error_msg;
};

}
}
#endif /* INC_WAGO_MDMD_NG_UPDATE_INFO_HPP_ */
//---- End of source file ------------------------------------------------------

