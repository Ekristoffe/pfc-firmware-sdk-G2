//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file    network_access_info.hpp
///
///  \brief   General information about the network access service.
///
///  \author  Jens Mueller :  WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------


#ifndef _INC_WAGO_MDMD_NG_NETWORK_ACCESS_INFO_H_
#define _INC_WAGO_MDMD_NG_NETWORK_ACCESS_INFO_H_

#include "network_operator.hpp"
#include "network_technology.hpp"
#include <string>

namespace wago{
namespace mdmdng{

enum class network_state
{
    NOT_REGISTERED      = 0,
    REGISTERED_HOME     = 1,
    SEARCHING           = 2,
    REGISTRATION_DENIED = 3,
    UNKNOWN             = 4,
    REGISTERED_ROAMING = 5,
    REGISTERED_SMS_ONLY_HOME = 6,
    REGISTERED_SMS_ONLY_ROAMING = 7,
    EMERGENCY_SERVICE   = 8
};

class network_access_info
{
  public:

    explicit network_access_info(network_state state = network_state::NOT_REGISTERED,
                                 std::string oper = "",
                                 network_technology technology=network_technology::UNKNOWN,
                                 int signal_rssi = 0,
                                 int signal_ber = 99): m_state(state),
                                                      m_operator(std::move(oper)),
                                                      m_technology(technology),
                                                      m_signal_rssi(signal_rssi),
                                                      m_signal_ber(signal_ber){};

    explicit network_access_info(network_state state,
                                 network_operator oper,
                                 network_technology technology,
                                 int signal_rssi,
                                 int signal_ber,
                                 std::string local_area_code,
                                 std::string cell_id): m_state(state),
                                                       m_operator(std::move(oper)),
                                                       m_technology(technology),
                                                       m_signal_rssi(signal_rssi),
                                                       m_signal_ber(signal_ber),
                                                       m_local_area_code(std::move(local_area_code)),
                                                       m_cell_id(std::move(cell_id)){};

    network_state get_state() const noexcept
    {
      return m_state;
    }

    std::string get_operator() const noexcept
    {
      return m_operator.get_operator();
    }

    network_operator get_operator_info() const noexcept
    {
      return m_operator;
    }

    network_technology get_technology() const noexcept
    {
      return m_technology;
    }

    int get_signal_strength() const noexcept
    {
      if (m_signal_rssi == 0)
      {
        return 0;
      }

      ///Calculate signal strength
      int signal_strength = 0;
      switch (m_technology)
      {
        case network_technology::GSM:// -113..-51 dBm
        {
          signal_strength = (100 * (m_signal_rssi + 113)) / (113-51);
          break;
        }
        case network_technology::UMTS:// -116..-54 dBm
        {
          signal_strength = (100 * (m_signal_rssi + 116)) / (116-54);
          break;
        }
        case network_technology::LTE: // -120..-25 dBm
        {
          signal_strength = (100 * (m_signal_rssi + 120)) / (120-25);
          break;
        }
        default:
        {
          signal_strength = (100 * (m_signal_rssi + 113)) / (113-51);
          break;
        }
      }
      if (signal_strength > 100)
      {
        signal_strength = 100;
      }
      else if (signal_strength < 0)
      {
       signal_strength = 0;
      }
      return signal_strength;
    }

    int get_signal_rssi() const noexcept
    {
      return m_signal_rssi;
    }

    int get_signal_ber() const noexcept
    {
      return m_signal_ber;
    }

    std::string get_local_area_code()
    {
      return m_local_area_code;
    }

    std::string get_cell_id()
    {
      return m_cell_id;
    }

    void set_state(network_state state) noexcept
    {
      m_state = state;
    }

    void set_operator(std::string oper) noexcept
    {
      m_operator.set_operator(std::move(oper));
    }

    void set_operator_info(network_operator oper)
    {
      m_operator = std::move(oper);
    }

    void set_technology(network_technology technology) noexcept
    {
      m_technology = technology;
    }

    void set_signal_rssi(const int rssi) noexcept
    {
      m_signal_rssi = rssi;
    }

    void set_signal_ber(const int ber) noexcept
    {
      m_signal_ber = ber;
    }

    void set_local_area_code(std::string lac)
    {
      m_local_area_code = std::move(lac);
    }

    void set_cell_id(std::string cid)
    {
      m_cell_id = std::move(cid);
    }

  private:
    network_state m_state;
    network_operator m_operator;
    network_technology m_technology;
    int m_signal_rssi;
    int m_signal_ber;
    std::string m_local_area_code = "";
    std::string m_cell_id = "";

};

}
}

#endif /* _INC_WAGO_MDMD_NG_NETWORK_ACCESS_INFO_H_ */
//---- End of source file ------------------------------------------------------
