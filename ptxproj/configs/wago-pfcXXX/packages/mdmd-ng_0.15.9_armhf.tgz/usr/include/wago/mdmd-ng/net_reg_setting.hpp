//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     net_con_settings.hpp
///
///  \brief    <short description of the file contents>
///
///  \author   <author> : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef SRC_MDMD_NG_NET_REG_SETTING_HPP_
#define SRC_MDMD_NG_NET_REG_SETTING_HPP_

#include <utility>
#include <string>

namespace wago{
namespace mdmdng{

enum class net_registration_mode
{
  OFF = 0,
  AUTO = 1,
  MANUAL = 2,
};

enum class net_access_technology_mode
{
    AUTO = 0,
    GSM = 1,
    UMTS = 2,
    LTE = 3,
};

class net_reg_setting
{
  public:
    explicit net_reg_setting(net_registration_mode registration_mode = net_registration_mode::AUTO,
                             net_access_technology_mode act_mode = net_access_technology_mode::AUTO,
                             std::string operator_identifier = "",
                             bool fallback_to_auto = false)
                             : m_registration_mode(registration_mode),
                               m_act_mode(act_mode),
                               m_operator_identifier(std::move(operator_identifier)),
                               m_fallback_to_auto(fallback_to_auto){};

    net_registration_mode get_registration_mode() const
    {
      return m_registration_mode;
    }

    void set_registration_mode(net_registration_mode registration_mode)
    {
      m_registration_mode = registration_mode;
    }

    net_access_technology_mode get_act_mode() const
    {
      return m_act_mode;
    }

    void set_act_mode(net_access_technology_mode act_mode)
    {
      m_act_mode = act_mode;
    }

    void set_operator_identifier(std::string identifier)
    {
      m_operator_identifier = std::move(identifier);
    }

    std::string get_operator_identifier() const
    {
      return m_operator_identifier;
    }

    void set_fallback_to_auto(bool fallback_to_auto)
    {
      m_fallback_to_auto = fallback_to_auto;
    }

    bool get_fallback_to_auto() const
    {
      return m_fallback_to_auto;
    }

    friend bool operator==(const net_reg_setting& lhs, const net_reg_setting& rhs)
    {
      return lhs.m_registration_mode == rhs.m_registration_mode &&
             lhs.m_act_mode == rhs.m_act_mode &&
             lhs.m_operator_identifier == rhs.m_operator_identifier &&
             lhs.m_fallback_to_auto == rhs.m_fallback_to_auto;
    }

    friend bool operator!=(const net_reg_setting& lhs, const net_reg_setting& rhs)
    {
      return !(lhs == rhs);
    }

  private:
    net_registration_mode m_registration_mode;
    net_access_technology_mode m_act_mode;
    std::string m_operator_identifier;
    bool m_fallback_to_auto;
};

}
}

#endif /* SRC_MDMD_NG_NET_CON_SETTINGS_HPP_ */
//---- End of source file ------------------------------------------------------

