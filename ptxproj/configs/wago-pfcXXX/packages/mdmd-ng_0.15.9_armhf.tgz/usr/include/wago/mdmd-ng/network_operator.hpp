//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     network_operator.hpp
///
///  \brief    Network operator defintion
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_WAGO_MDMD_NG_NETWORK_OPERATOR_HPP_
#define INC_WAGO_MDMD_NG_NETWORK_OPERATOR_HPP_

#include <boost/serialization/serialization.hpp>
#include <string>
#include <utility>

namespace wago{
namespace mdmdng{

class network_operator
{
public:
    explicit network_operator() = default;
    explicit network_operator(std::string name,
                              std::string name_short = "",
                              std::string code = ""):
                              m_operator_name(std::move(name)),
                              m_operator_name_short(std::move(name_short)),
                              m_operator_code(std::move(code)){};

    std::string get_operator() const noexcept
    {
      return m_operator_name;
    }

    std::string get_operator_short() const noexcept
    {
      return m_operator_name_short;
    }

    std::string get_operator_code() const noexcept
    {
      return m_operator_code;
    }

    void set_operator(std::string name) noexcept
    {
      m_operator_name = std::move(name);
    }

    void set_operator_short(std::string name_short) noexcept
    {
      m_operator_name_short = std::move(name_short);
    }

    /**
     * Set operator code
     * @param code - Defined as MCC+MNC, example for Telekom.de "26201"(MCC 262 MNC 01)
     */
    void set_operator_code(std::string code) noexcept
    {
      m_operator_code = std::move(code);
    }

private:
    std::string m_operator_name;
    std::string m_operator_name_short;
    std::string m_operator_code; // MCC + MNC

    friend class boost::serialization::access;
    template<class Archive>
    void serialize(Archive & ar, const unsigned int /*version*/)
    {
      ar & m_operator_name;
      ar & m_operator_name_short;
      ar & m_operator_code;
    }
};

}
}
#endif /* INC_WAGO_MDMD_NG_NETWORK_OPERATOR_HPP_ */
//---- End of source file ------------------------------------------------------

