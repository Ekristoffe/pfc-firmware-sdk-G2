//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     wireless_data_service_settings.hpp
///
///  \brief    Wireless data service settings class
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef SRC_MDMD_NG_WIRELESS_DATA_SERVICE_SETTINGS_HPP_
#define SRC_MDMD_NG_WIRELESS_DATA_SERVICE_SETTINGS_HPP_

#include <string>
#include <utility>

namespace wago{
namespace mdmdng{

enum class data_auth_type
{
  NONE = 0,
  PAP = 1,
  CHAP = 2,
  PAP_OR_CHAP = 3
};

class wds_settings
{
  public:
    explicit wds_settings(std::string apn="",
                              std::string user="",
                              std::string password="",
                              data_auth_type auth=data_auth_type::NONE):m_apn(std::move(apn)),
                                                                                  m_user(std::move(user)),
                                                                                  m_password(std::move(password)),
                                                                                  m_auth(auth){};
    std::string get_apn() const
    {
      return m_apn;
    }

    std::string get_password() const
    {
      return m_password;
    }

    std::string get_user() const
    {
      return m_user;
    }
    data_auth_type get_auth_type() const
    {
      return m_auth;
    }

    void set_apn(std::string apn)
    {
      m_apn = std::move(apn);
    }

    void set_password(std::string password)
    {
      m_password = std::move(password);
    }

    void set_user(std::string user)
    {
      m_user = std::move(user);
    }

    void set_auth_type(data_auth_type auth)
    {
      m_auth = auth;
    }

    friend bool operator==(const wds_settings& lhs, const wds_settings& rhs)
    {
      return lhs.m_apn == rhs.m_apn &&
             lhs.m_password == rhs.m_password &&
             lhs.m_user == rhs.m_user &&
             lhs.m_auth == rhs.m_auth;
    }

    friend bool operator!=(const wds_settings& lhs, const wds_settings& rhs)
    {
      return !(lhs == rhs);
    }

  private:
    std::string m_apn;
    std::string m_user;
    std::string m_password;
    data_auth_type m_auth;
};



}
}

#endif /* SRC_MDMD_NG_WIRELESS_DATA_SERVICE_SETTINGS_HPP_ */
//---- End of source file ------------------------------------------------------

