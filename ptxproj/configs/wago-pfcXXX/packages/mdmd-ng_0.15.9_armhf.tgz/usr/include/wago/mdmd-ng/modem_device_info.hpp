//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     modem_device_information.hpp
///
///  \brief    Contains device informations of the modem
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef SRC_MDMD_NG_MODEM_DEVICE_INFO_HPP_
#define SRC_MDMD_NG_MODEM_DEVICE_INFO_HPP_

#include <utility>
#include <string>

namespace wago{
namespace mdmdng{

enum class modem_state
{
    UNKNOWN = 0,
    NOT_READY,
    DETECTION_FAILED,
    READY,
    UPDATING
};

class modem_device_info
{
  public:
    explicit modem_device_info(modem_state state=modem_state::UNKNOWN,
                               std::string manufacturer="",
                               std::string model="",
                               std::string version="",
                               std::string imei = ""):m_state(state),
                                                      m_manufacturer(std::move(manufacturer)),
                                                      m_model(std::move(model)),
                                                      m_version(std::move(version)),
                                                      m_imei(std::move(imei)){};

    std::string get_manufacturer() const noexcept
    {
      return m_manufacturer;
    };

    void set_manufacturer(std::string new_manufacturer) noexcept
    {
      m_manufacturer = std::move(new_manufacturer);
    };

    std::string get_model() const noexcept
    {
      return m_model;
    };

    void set_model(std::string new_model) noexcept
    {
      m_model = std::move(new_model);
    };

    std::string get_imei() const noexcept
    {
      return m_imei;
    };

    void set_imei(std::string new_imei) noexcept
    {
      m_imei = std::move(new_imei);
    };

    std::string get_version() const noexcept
    {
      return m_version;
    };

    void set_version(std::string new_version) noexcept
    {
      m_version = std::move(new_version);
    };

    modem_state get_state() const noexcept
    {
      return m_state;
    };

    void set_state(modem_state new_state) noexcept
    {
      m_state = new_state;
    };

  private:
    modem_state m_state;
    std::string m_manufacturer;
    std::string m_model;
    std::string m_version;
    std::string m_imei;
};

}
}
#endif /* SRC_MDMD_NG_MODEM_DEVICE_INFO_HPP_ */
//---- End of source file ------------------------------------------------------

