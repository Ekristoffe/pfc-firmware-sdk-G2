//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     sim_credentials.hpp
///
///  \brief    SIM credentials class
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef SRC_MDMD_NG_SIM_CREDENTIALS_HPP_
#define SRC_MDMD_NG_SIM_CREDENTIALS_HPP_

#include <string>
#include <utility>

namespace wago {
namespace mdmdng {

class sim_credentials
{
  public:
    explicit sim_credentials(std::string pin = "", std::string iccid = ""):
      m_pin(std::move(pin)),
      m_iccid(std::move(iccid)){};

    void set_credentials(const std::string& pin, const std::string& iccid)
    {
      m_pin = pin;
      m_iccid = iccid;
    }

    std::string get_pin() const
    {
      return m_pin;
    }

    std::string get_iccid() const
    {
      return m_iccid;
    }

    bool empty()
    {
      return (m_pin.empty() && m_iccid.empty());
    }

    bool valid()
    {
      return (!m_pin.empty() && !m_iccid.empty());
    }

    friend bool operator==(const sim_credentials& lhs, const sim_credentials& rhs)
    {
      return lhs.m_iccid == rhs.m_iccid &&
             lhs.m_pin == rhs.m_pin;
    }

    friend bool operator!=(const sim_credentials& lhs, const sim_credentials& rhs)
    {
      return !(lhs == rhs);
    }

  private:
    std::string m_pin;
    std::string m_iccid;
};

}
}
#endif /* SRC_MDMD_NG_SIM_CREDENTIALS_HPP_ */
//---- End of source file ------------------------------------------------------

