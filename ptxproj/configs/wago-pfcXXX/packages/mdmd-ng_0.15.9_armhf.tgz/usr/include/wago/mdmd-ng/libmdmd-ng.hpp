//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     libmdmd-ng.hpp
///
///  \brief    C++ API of WAGO Modem Manager Daemon - Next Gen
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef _INC_WAGO_MDMD_NG_LIBMDMD_NG_HPP_
#define _INC_WAGO_MDMD_NG_LIBMDMD_NG_HPP_

#include "wago/mdmd-ng/modem_device_info.hpp"
#include "wago/mdmd-ng/severity_level.hpp"
#include "wago/mdmd-ng/sim_info.hpp"
#include "wago/mdmd-ng/sim_credentials.hpp"
#include "wago/mdmd-ng/network_access_info.hpp"
#include "wago/mdmd-ng/network_scan_info.hpp"
#include "wago/mdmd-ng/wireless_data_service_info.hpp"
#include "wago/mdmd-ng/wireless_data_service_settings.hpp"
#include "wago/mdmd-ng/libmdmd-ng_error.hpp"
#include "wago/mdmd-ng/sms.hpp"
#include "wago/mdmd-ng/net_reg_setting.hpp"
#include "wago/mdmd-ng/update_info.hpp"

#include <string>
#include <cstdint>
#include <list>

namespace wago {
namespace libmdmdng{

  /**
   * @brief Set the selected severity level of the logging mechanism.
   */
  void set_logging_severity_level(mdmdng::severity_level new_severity_level);

  /**
   * @brief Get the severity level of the logging mechanism.
   */
  mdmdng::severity_level get_logging_severity_level();

  /**
   * @brief Get the modem information of the current modem device as an modem_device_info object.
   * @return Return a modem_device_info object. A libmdmd-ng_error will be thrown if an error occurred.
   */
  mdmdng::modem_device_info get_modem_device_info();

  /**
   * @brief Get general information of the sim card.
   * @return Return a sim_info object.
   */
  mdmdng::sim_info get_sim_info();

  /**
   * @brief Set the PIN to unlock the sim card.
   */
  void set_sim_pin(const std::string& pin, const bool& save_pin);

  /**
   * @brief Set the PUK to unlock the sim card and set a new pin.
   */
  void set_sim_puk(const std::string& puk, const std::string& new_pin, const bool& save_pin);

  /**
   * @brief Clear the stored pin.
   */
  void forget_sim_pin();

  /**
   * @brief Get the ICCID from the currently saved SIM credentials
   * @return Returns a string, which contains the ICCID from the currently saved SIM credentials
   */
  std::string get_saved_iccid();

  /**
   * @brief Get the currently saved SIM credentials
   * @return Returns a sim_credentials object, which contains the current saved credentials
   */
  mdmdng::sim_credentials get_saved_sim_credentials();

  /**
   * @brief Set SIM credentials which will be saved to unlock the SIM automatically
   * @param iccid ICCID of the SIM card
   * @param pin PIN of the SIM card which belongs to the given ICCID
   * @throws libmdmdng::libmdmdng_error if an unexpected error occurs
   * @throws std::invalid_argument if PIN verification fails
   */
  void set_saved_sim_credentials(const std::string& iccid, const std::string& pin);

  /**
   * @brief Get general information of the network access service.
   * @return Returns a network_access_info object.
   */
  mdmdng::network_access_info get_network_access_info();

  /**
   * @brief Get the registration settings of the network access service.
   * @return Retruns a net_reg_setting object
   */
  mdmdng::net_reg_setting get_network_registration_settings();

  /**
   * @brief Set the registration settings of the network access service.
   * @param settings net_reg_setting object
   */
  void set_network_registration_settings(const mdmdng::net_reg_setting& settings);

  /**
   * @brief Get general information of the wireless data service.
   * @return Returns a wds_info object.
   */
  mdmdng::wds_info get_wds_info();

  /**
   * @brief Get current settings of the wireless data service.
   * @return Returns a wds_settings object.
   */
  mdmdng::wds_settings get_wds_settings();

  /**
   * @brief Get current SMS meta information from all stored SMS messages
   * @return Returns a std::list which contains sms_meta objects
   */
  std::list<mdmdng::sms_meta> get_sms_meta_list();

  /**
   * @brief Set settings for the wireless data service. Changes will take effect immediately
   * @param settings wds_settings object
   */
  void set_wds_settings(const wago::mdmdng::wds_settings& settings);

  /**
   * @brief Get the current status if wireless data service is enabled
   * @return true - WDS is on, false - WDS is off
   */
  bool get_wds_enable();

  /**
   * @brief Enable/Disable wireless data service. Changes will take effect immediately.
   * @param status true - enable, false - disable
   */
  void set_wds_enable(const bool& status);

  /**
   * @brief Reset the modem. Reset is only available if modem state is 'ready'. Otherwise an exception will be thrown
   */
  void reset_modem();

  /**
   * @brief Scan network - Data connection will be temporarily disabled during mobile network scan
   * @return Returns a list of found mobile networks as std::list which contains network_scan_info objects
   */
  std::list<mdmdng::network_scan_info> scan_network();

  /**
   * @brief Send SMS as text
   * @param text message text
   * @param dest destination phone number
   * @param smsc SMS service center ID ("" = default)
   */
  void send_sms_text(const std::string& text, const std::string& dest, const std::string& smsc);

  /**
   * @brief Send SMS in PDU format
   * @param pdu_data PDU data
   * @param pdu_length length of PDU data. Length is limited to 255.
   */
  void send_sms_pdu(const uint8_t* pdu_data, const size_t& pdu_length);

  /**
   * @brief Send SMS in PDU format
   * @param pdu_message PDU structure which contains pdu data and length
   */
  void send_sms_pdu(const mdmdng::pdu& pdu_message);

  /**
   * @brief Delete SMS from storage
   * @param index Index of SMS in storage that will be deleted
   */
  void delete_sms(const int& index);

  /**
   * @brief Read SMS message
   * @param index Index number of the SMS message
   * @param read_as_pdu If true, SMS message will be presented as PDU
   * @return Returns object of type @see sms_message
   */
  mdmdng::sms_message read_sms(const int& index, const bool& read_as_pdu);

  /**
   * @brief Get general information about modem fw-update process.
   * @return Returns an update_info object.
   */
  mdmdng::update_info get_update_info();

  /**
   * @brief Start modem fw-update process.
   * @param path Path to mfw-file
   * @param flags Flags to control modem fw-update process [Optional].
   *              F - Force fw-update (no checks, use with caution)
   *              R - Replace firmware with same version
   *              D - Downgrade firmware with older version
   */
  void start_update(const std::string& path, mdmdng::update_flag flags);
}
}

#endif /* _INC_WAGO_MDMD_NG_LIBMDMD_NG_HPP_ */
//---- End of source file ------------------------------------------------------

