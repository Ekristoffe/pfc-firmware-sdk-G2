//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     network_technology.hpp
///
///  \brief    Network technology
///
///  \author   MMy : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_WAGO_MDMD_NG_NETWORK_TECHNOLOGY_HPP_
#define INC_WAGO_MDMD_NG_NETWORK_TECHNOLOGY_HPP_

namespace wago{
namespace mdmdng{

  enum class network_technology
  {
      GSM           = 0,
      GSM_Compact   = 1,
      UMTS          = 2,
      GSM_EGPRS     = 3,
      HSDPA         = 4,
      HSUPA         = 5,
      HSDPA_HSUPA   = 6,
      LTE           = 7,
      LTE_ADVANCED,

      UNKNOWN = 99
  };

}
}
#endif /* INC_WAGO_MDMD_NG_NETWORK_TECHNOLOGY_HPP_ */
//---- End of source file ------------------------------------------------------

