//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     sim_info.hpp
///
///  \brief    General SIM information like state etc.
///
///  \author   MMy :  WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------

#ifndef _INC_WAGO_MDMD_NG_SIM_INFO_H_
#define _INC_WAGO_MDMD_NG_SIM_INFO_H_

#include <string>
#include <utility>

namespace wago {
namespace mdmdng {

enum class sim_state
{
    NOT_INITIALIZED = 0,
    PIN_READY,
    SMS_READY,
    PB_READY,
    READY,
    NOT_PRESENT,
    LOCKED,
    ERROR
};

enum class sim_lock_type
{
    UNKNOWN = 0,
    UNLOCKED,
    PIN ,
    PIN2,
    PUK,
    PUK2
};

class sim_info {
public:
  explicit sim_info(sim_state state = sim_state::NOT_PRESENT,
                    sim_lock_type type = sim_lock_type::UNKNOWN,
                    int remaining = -1,
                    std::string iccid = "") noexcept
                   :m_state(state),
                    m_lock_type(type),
                    m_remaining_attempts(remaining),
                    m_iccid(std::move(iccid)){}

  sim_state get_state() const noexcept
  {
    return m_state;
  }

  sim_lock_type get_lock_type() const noexcept
  {
    return m_lock_type;
  }

  int get_remaining_attempts() const noexcept
  {
    return m_remaining_attempts;
  }

  std::string get_iccid() const noexcept
  {
    return m_iccid;
  }

  void set_state(const sim_state& state) noexcept
  {
    m_state = state;
  }

  void set_lock_type(const sim_lock_type& type) noexcept
  {
    m_lock_type = type;
  }

  void set_remaining_attempts(const int& remaining_attempts)
  {
    m_remaining_attempts = remaining_attempts;
  }

  void set_iccid(const std::string& iccid)
  {
    m_iccid = iccid;
  }

private:
  sim_state m_state;
  sim_lock_type m_lock_type;
  int m_remaining_attempts;
  std::string m_iccid;
};

} // namespace mdmdng
} // namespace wago

#endif // _INC_WAGO_MDMD_NG_SIM_INFO_H_
