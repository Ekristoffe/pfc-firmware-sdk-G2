//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file    wireless_data_service_info.hpp
///
///  \brief   General information about the wireless data service.
///
///  \author  Jens Mueller :  WAGO GmbH & Co. KG
///
//------------------------------------------------------------------------------


#ifndef _INC_WAGO_MDMD_NG_WIRELESS_DATA_SERVICE_H_
#define _INC_WAGO_MDMD_NG_WIRELESS_DATA_SERVICE_H_

#include <string>

namespace wago{
namespace mdmdng{

enum class wds_state
{
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    DISCONNECTED,
    ERROR
};

class wds_info
{
  public:
    explicit wds_info(wds_state state=wds_state::DISCONNECTED,
                      std::string ip=""):m_state(state),
                                         m_ip(std::move(ip)){};
    wds_state get_state() const noexcept
    {
      return m_state;
    }

    std::string get_ip() const noexcept
    {
      return m_ip;
    }

    void set_state(wds_state state) noexcept
    {
      m_state = state;
    }

    void set_ip(std::string ip) noexcept
    {
      m_ip = std::move(ip);
    }

  private:
    wds_state m_state;
    std::string m_ip;
};

}
}

#endif /* _INC_WAGO_MDMD_NG_WIRELESS_DATA_SERVICE_H_ */
//---- End of source file ------------------------------------------------------
