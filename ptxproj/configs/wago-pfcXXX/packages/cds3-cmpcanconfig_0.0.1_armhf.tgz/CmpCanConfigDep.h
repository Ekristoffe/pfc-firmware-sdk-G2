/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

//---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2014-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     CmpCanConfig.m4 resp. CmpCanConfigDep.h
///
/// \version  $Id: 
///
/// \brief    contains dependencies of CDS component CmpCanConfig; component provides access for
///           RTS library 'WagoCanConfig.Library' 
///
/// \author   Axel Wueste : WAGO GmbH & Co. KG
///
/// \copydoc  Copyright
///
//---------------------------------------------------------------------------------------------------------------------
#ifndef _CMPCANCONFIGDEP_H_
#define _CMPCANCONFIGDEP_H_

#define COMPONENT_NAME "CmpCanConfig" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_CmpCanConfig)
#define COMPONENT_NAME_UNQUOTED CmpCanConfig





#define CMP_VERSION         UINT32_C(0x00000003)
#define CMP_VERSION_STRING "0.0.0.3"
#define CMP_VERSION_RC      0,0,0,3

#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"

#include "WagoSysdefines.h"
#include "WagoTypesCanItf.h"
#include "WagoSysCan_Internal_PFCItf.h"

#define CMPID_CmpCanConfig  CMPCANCONFIG_CMPID
#define CLASSID_CmpCanConfig  ADDVENDORID(CMP_VENDORID, CMPCANCONFIG_CLASSID_C)
#define ITFID_ICmpCanConfig   ADDVENDORID(CMP_VENDORID, CMPCANCONFIG_ITFID_I)






/**
 * \file WagoSysCan_Internal_PFCItf.h
 */
#include "WagoSysCan_Internal_PFCItf.h"







#include "CMItf.h"


#include "CmpDalItf.h"


#include "CmpEventMgrItf.h"


#include "CmpAppItf.h"


#include "SysOutItf.h"




        




     




     





#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pISysOut == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysOut, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysOut = (ISysOut *)pIBase->QueryInterface(pIBase, ITFID_ISysOut, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpApp == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpApp, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpApp = (ICmpApp *)pIBase->QueryInterface(pIBase, ITFID_ICmpApp, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpEventMgr == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpEventMgr, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpEventMgr = (ICmpEventMgr *)pIBase->QueryInterface(pIBase, ITFID_ICmpEventMgr, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICmpDal == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpDal, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpDal = (ICmpDal *)pIBase->QueryInterface(pIBase, ITFID_ICmpDal, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pISysOut = NULL; \
          pICmpApp = NULL; \
          pICmpEventMgr = NULL; \
          pICmpDal = NULL; \
          pICM = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pISysOut != NULL) \
        { \
            pIBase = (IBase *)pISysOut->QueryInterface(pISysOut, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysOut = NULL; \
            } \
        } \
          if (pICmpApp != NULL) \
        { \
            pIBase = (IBase *)pICmpApp->QueryInterface(pICmpApp, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpApp = NULL; \
            } \
        } \
          if (pICmpEventMgr != NULL) \
        { \
            pIBase = (IBase *)pICmpEventMgr->QueryInterface(pICmpEventMgr, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpEventMgr = NULL; \
            } \
        } \
          if (pICmpDal != NULL) \
        { \
            pIBase = (IBase *)pICmpDal->QueryInterface(pICmpDal, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpDal = NULL; \
            } \
        } \
          if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_CMExit(0);\
          if (ERR_OK == importResult ) importResult = GET_EventUnregisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventRegisterCallbackFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_EventClose(0);\
          if (ERR_OK == importResult ) importResult = GET_EventOpen(0);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef CMPCANCONFIG_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)fusetdeviceinfo, "fusetdeviceinfo", 0x9E9948F7, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusetcanled, "fusetcanled", 0x5D91571F, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusendtimestamp, "fusendtimestamp", 0xB662E864, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusendframe, "fusendframe", 0xEB340615, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusendemcy, "fusendemcy", 0xA31BDF57, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdowritesync, "fusdowritesync", 0x1A10820B, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdowritedata, "fusdowritedata", 0xC661E226, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdowriteasync, "fusdowriteasync", 0x9D2AC1AA, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdoreadsync, "fusdoreadsync", 0x8D537ACA, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdoreaddata, "fusdoreaddata", 0x85C7E288, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdoreadasync, "fusdoreadasync", 0xD9C2B47F, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fusdoadd, "fusdoadd", 0x6C60EC7B, 0x01000100 },\
          { (RTS_VOID_FCTPTR)furesetlayer2, "furesetlayer2", 0x830BB7FB, 0x01000100 },\
          { (RTS_VOID_FCTPTR)furegisterid, "furegisterid", 0xB124099C, 0x01000100 },\
          { (RTS_VOID_FCTPTR)furegisterall, "furegisterall", 0x311E4F14, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fuopenlayer2, "fuopenlayer2", 0x82ECA0D4, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fulibversion, "fulibversion", 0x9C09B289, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fuguarderrornode, "fuguarderrornode", 0x5E0A6790, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fuguarderror, "fuguarderror", 0x6EE20B18, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugettimestamp, "fugettimestamp", 0x5513B97F, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetnodeid, "fugetnodeid", 0x3602BC4E, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetnodeemcy, "fugetnodeemcy", 0xD2CBB8BB, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetnodediag, "fugetnodediag", 0xBCBBFB0A, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetlastnode, "fugetlastnode", 0x88CEB240, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetframecounter, "fugetframecounter", 0xB942F3CF, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetframebuffer, "fugetframebuffer", 0x4E31EF22, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetframe, "fugetframe", 0xC6A41AA7, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetemcy, "fugetemcy", 0x7A6C44BC, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetdeviceinfo, "fugetdeviceinfo", 0x78E8C4E4, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetcanmode, "fugetcanmode", 0x80B510EF, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fugetbusinfo, "fugetbusinfo", 0xDA027792, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fucloselayer2, "fucloselayer2", 0x90BBADF9, 0x01000100 },\
          { (RTS_VOID_FCTPTR)fuchangestate, "fuchangestate", 0xE669D591, 0x01000100 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef CMPCANCONFIG_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                                                          
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(CMPCANCONFIG_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                                                          \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CM     \
	ITF_CmpDal     \
	ITF_CmpEventMgr     \
	ITF_CmpApp     \
	ITF_SysOut      \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_CMExit     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CM    \
	ITF_CmpDal    \
	ITF_CmpEventMgr    \
	ITF_CmpApp    \
	ITF_SysOut     \
    USE_EventOpen      \
    USE_EventClose      \
    USE_EventRegisterCallbackFunction      \
    USE_EventUnregisterCallbackFunction      \
    USE_CMExit     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CM    \
	EXTITF_CmpDal    \
	EXTITF_CmpEventMgr    \
	EXTITF_CmpApp    \
	EXTITF_SysOut     \
    EXT_EventOpen  \
    EXT_EventClose  \
    EXT_EventRegisterCallbackFunction  \
    EXT_EventUnregisterCallbackFunction  \
    EXT_CMExit 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry CmpCanConfig__Entry
#endif


#ifdef CPLUSPLUS

class CCmpCanConfig : public IWagoSysCan_Internal_PFC 
{
    public:
        CCmpCanConfig() : hCmpCanConfig(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CCmpCanConfig()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoSysCan_Internal_PFC *)this);            
            else if (iid == ITFID_IWagoSysCan_Internal_PFC)
                pItf = dynamic_cast<IWagoSysCan_Internal_PFC *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hCmpCanConfig;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
