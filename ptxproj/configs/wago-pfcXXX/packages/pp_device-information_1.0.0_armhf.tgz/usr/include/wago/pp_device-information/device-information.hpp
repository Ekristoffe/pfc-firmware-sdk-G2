//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     device-information.hpp
///
///  \brief    Header of device-info parameter provider
///
///  \author   LHe, OG : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef INC_WAGO_PP_DEVICE_INFORMATION_DEVICE_INFORMATION_HPP_
#define INC_WAGO_PP_DEVICE_INFORMATION_DEVICE_INFORMATION_HPP_

#include <wago/wdx/base_parameter_provider.hpp>

namespace wago {
namespace pp_device_information {

  constexpr wago::wdx::parameter_id_t PARAMETER_ID_ORDERNUMBER    = 1;
  constexpr wago::wdx::parameter_id_t PARAMETER_ID_DESCRIPTION    = 2;
  constexpr wago::wdx::parameter_id_t PARAMETER_ID_SERIALNUMBER   = 3;
  constexpr wago::wdx::parameter_id_t PARAMETER_ID_FWRELEASEINDEX = 4;
  constexpr wago::wdx::parameter_id_t PARAMETER_ID_HWRELEASEINDEX = 5;
  constexpr wago::wdx::parameter_id_t PARAMETER_ID_FWVERSION      = 6;

  class device_information final : public ::wago::wdx::base_parameter_provider
  {
    public:
      std::string display_name() override;
      wago::wdx::parameter_selector_response get_provided_parameters() override;

      wago::future<std::vector<wago::wdx::value_response>> get_parameter_values(std::vector<
          wago::wdx::parameter_instance_id> parameter_ids) override;
  };
}
}
#endif /* INC_WAGO_PP_DEVICE_INFORMATION_DEVICE_INFORMATION_HPP_ */
//---- End of source file ------------------------------------------------------

