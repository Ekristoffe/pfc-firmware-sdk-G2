 /**
 * <interfacename>WagoTypesCommon</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOTYPESCOMMONITF_H_
#define _WAGOTYPESCOMMONITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 *  
 *
 ***Function**
 *
 *Standard ASCII definitions for assigments to BYTE like  b := Char.Slash;
 *
 */
#define CHAR_NULL    0x0	
#define CHAR_BELL    0x7	
#define CHAR_BACKSPACE    0x8	
#define CHAR_TAB    0x9	
#define CHAR_LINEFEED    0xA	
#define CHAR_FORMFEED    0xC	
#define CHAR_CARRIAGERETURN    0xD	
#define CHAR_DC1    0x11	
#define CHAR_DC2    0x12	
#define CHAR_DC3    0x13	
#define CHAR_DC4    0x14	
#define CHAR_ESCAPE    0x1B	
#define CHAR_SPACE    0x20	
#define CHAR_EXCLAMATION    0x21	
#define CHAR_QUOTATION    0x22	
#define CHAR_NUMBER    0x23	
#define CHAR_DOLLAR    0x24	
#define CHAR_PERCENT    0x25	
#define CHAR_AMPERSAND    0x26	
#define CHAR_APOSTROPHE    0x27	
#define CHAR_LEFTPARENTHESIS    0x28	
#define CHAR_RIGHTPARENTHESIS    0x29	
#define CHAR_ASTERISK    0x2A	
#define CHAR_PLUS    0x2B	
#define CHAR_COMMA    0x2C	
#define CHAR_MINUS    0x2D	
#define CHAR_DOT    0x2E	
#define CHAR_SLASH    0x2F	
#define CHAR_NUM0    0x30	
#define CHAR_NUM1    0x31	
#define CHAR_NUM2    0x32	
#define CHAR_NUM3    0x33	
#define CHAR_NUM4    0x34	
#define CHAR_NUM5    0x35	
#define CHAR_NUM6    0x36	
#define CHAR_NUM7    0x37	
#define CHAR_NUM8    0x38	
#define CHAR_NUM9    0x39	
#define CHAR_COLON    0x3A	
#define CHAR_SEMICOLON    0x3B	
#define CHAR_LESSTHAN    0x3C	
#define CHAR_EQUAL    0x3D	
#define CHAR_GREATERTHAN    0x3E	
#define CHAR_QUESTION    0x3F	
#define CHAR_COMMERCIALAT    0x40	
#define CHAR_CAPA    0x41	
#define CHAR_CAPB    0x42	
#define CHAR_CAPC    0x43	
#define CHAR_CAPD    0x44	
#define CHAR_CAPE    0x45	
#define CHAR_CAPF    0x46	
#define CHAR_CAPG    0x47	
#define CHAR_CAPH    0x48	
#define CHAR_CAPI    0x49	
#define CHAR_CAPJ    0x4A	
#define CHAR_CAPK    0x4B	
#define CHAR_CAPL    0x4C	
#define CHAR_CAPM    0x4D	
#define CHAR_CAPN    0x4E	
#define CHAR_CAPO    0x4F	
#define CHAR_CAPP    0x50	
#define CHAR_CAPQ    0x51	
#define CHAR_CAPR    0x52	
#define CHAR_CAPS    0x53	
#define CHAR_CAPT    0x54	
#define CHAR_CAPU    0x55	
#define CHAR_CAPV    0x56	
#define CHAR_CAPW    0x57	
#define CHAR_CAPX    0x58	
#define CHAR_CAPY    0x59	
#define CHAR_CAPZ    0x5A	
#define CHAR_LEFTSQUAREBRACKET    0x5B	
#define CHAR_BACKSLASH    0x5C	
#define CHAR_RIGHTSQUAREBRACKET    0x5D	
#define CHAR_CIRCUMFLEX    0x5E	
#define CHAR_UNDERLINE    0x5F	
#define CHAR_GRAVE    0x60	
#define CHAR_SMALLA    0x61	
#define CHAR_SMALLB    0x62	
#define CHAR_SMALLC    0x63	
#define CHAR_SMALLD    0x64	
#define CHAR_SMALLE    0x65	
#define CHAR_SMALLF    0x66	
#define CHAR_SMALLG    0x67	
#define CHAR_SMALLH    0x68	
#define CHAR_SMALLI    0x69	
#define CHAR_SMALLJ    0x6A	
#define CHAR_SMALLK    0x6B	
#define CHAR_SMALLL    0x6C	
#define CHAR_SMALLM    0x6D	
#define CHAR_SMALLN    0x6E	
#define CHAR_SMALLO    0x6F	
#define CHAR_SMALLP    0x70	
#define CHAR_SMALLQ    0x71	
#define CHAR_SMALLR    0x72	
#define CHAR_SMALLS    0x73	
#define CHAR_SMALLT    0x74	
#define CHAR_SMALLU    0x75	
#define CHAR_SMALLV    0x76	
#define CHAR_SMALLW    0x77	
#define CHAR_SMALLX    0x78	
#define CHAR_SMALLY    0x79	
#define CHAR_SMALLZ    0x7A	
#define CHAR_LEFTCURLYBRACKET    0x7B	
#define CHAR_VERTICALLINE    0x7C	
#define CHAR_RIGHTCURLYBRACKET    0x7D	
#define CHAR_TILDE    0x7E	
#define CHAR_DELETE    0x7F	
#define CHAR_LAST    0xFF	
/* Typed enum definition */
#define CHAR    RTS_IEC_BYTE

/**
 *  
 *
 ***Function**
 *
 *collection of properties of a device, the system can be asked about 
 *
 *These numbers of "FileSystemProperties" (FSP) serve as input to IWagoSysFsInternal.GetProperty()
 * 
 *For binary semantics, it is generally meant: 0 = "No", 1 = "yes", -1 = "unknown" (i.e. property not implemented)
 *
 *.. note:: This seems to be quite obsolete and might be removed soon.
 *
 */
#define EDEVICEPROPERTY_PROP_NONE    0	
#define EDEVICEPROPERTY_PROP_RENAMEDIR    1	/* boolean :  Method RenameDir implemented? */
#define EDEVICEPROPERTY_PROP_RENAMEFILE    2	/* boolean :  Method RenameFile implemented? */
#define EDEVICEPROPERTY_PROP_FILECOPY    3	/* boolean :  Method FileCopy implemented? */
#define EDEVICEPROPERTY_PROP_SETATTRIBUTES    4	/* boolean :  Method SetAttributes supported? */
#define EDEVICEPROPERTY_PROP_FILENAME83    100	/* boolean : Restriction to 8.3 Filenames? */
#define EDEVICEPROPERTY_PROP_FILENAMECAPITAL    101	/* boolean : Restriction to capital letters? */
#define EDEVICEPROPERTY_PROP_ABSOLUTEPATHREQ    200	/* boolean : Restriction to absolute Paths only? */
#define EDEVICEPROPERTY_PROP_DRIVELETTER    201	/* boolean : Support of drive letters "C:/" */
#define EDEVICEPROPERTY_PROP_RESOLVER    210	/* boolean : "Resolver" syntax supported? */
#define EDEVICEPROPERTY_PROP_FTPSUPPORTED    211	/* boolean : FTP client supported? */
#define EDEVICEPROPERTY_PROP_HTTPSUPPORTED    212	/* boolean : HTTP client supported? */
#define EDEVICEPROPERTY_PROP_NETDRIVES    300	/* boolean : Netdrives supported? */
#define EDEVICEPROPERTY_PROP_MAX    301	/* last property identifyer */
/* Typed enum definition */
#define EDEVICEPROPERTY    RTS_IEC_WORD

/**
 *
 *
 ***Function**
 *
 *Different modes of access (read, write, ... ) for opening files. 
 *
 ***Function Description**
 *
 *When opening a file, the application has to specify the mode of access for further operation.
 *Four modes are defined: 
 *
 *
 *FAM_Write: 
 *	Open write-only. The file will be truncated to zero (if exists) or newly created 
 *	(if it does not exist)
 *
 *FAM_Read:
 *    Open read-only. File must exist.
 *
 *FAM_ReadWrite:
 *    Open for random access. File will be overwritten and pointer set to zero-pos 
 *	(if exists) or file will be newly created (if it does not exist)
 *
 *FAM_Append:
 *    Open write-only. Filepointer will be set to End-Of-File if the file exists or the file will
 *    be newly created if it does not exist.
 *	
 *
 *      
 *		
 *Please note: These access modes may not match directly to linux or windows access modes.
 */
#define EFILEACCESSMODE_FAM_NONE    0	/* No file access (internal use only) */
#define EFILEACCESSMODE_FAM_WRITE    1	/* Open write-only. */
#define EFILEACCESSMODE_FAM_READ    2	/* Open read-only. File must exist. */
#define EFILEACCESSMODE_FAM_READWRITE    3	/* Open for random access. */
#define EFILEACCESSMODE_FAM_APPEND    4	/* Open write-only, existing file will be appended. */
/* Typed enum definition */
#define EFILEACCESSMODE    RTS_IEC_INT

/**
 * 
 *
 ***Function**
 *
 *Controls when data is actually written to the physical media.
 *
 */
#define EFILESYNCMODE_FSM_REGULAR    0	/* No explicit synchronization. */
#define EFILESYNCMODE_FSM_SAFECLOSE    1	/* Close() waits for final writing of data. */
#define EFILESYNCMODE_FSM_SYNCEDWRITE    2	/* Each write() leaves the media in a consistent state. */
/* Typed enum definition */
#define EFILESYNCMODE    RTS_IEC_INT

/**
 *
 ***Function**
 *
 *Name of the Ftp connection mode. 
 *
 */
#define EFTPCONNECTIONMODE_PASSIVE    0	
#define EFTPCONNECTIONMODE_ACTIVE    1	/* Auto    := 0, //Try both Modes to connect to the Server */
/* Typed enum definition */
#define EFTPCONNECTIONMODE    RTS_IEC_INT

/**
 *
 ***Function**
 *
 *Name of the Ftp transfer mode. 
 *
 */
#define EFTPTRANSFERMODE_STREAM    0	
#define EFTPTRANSFERMODE_BLOCK    1	
#define EFTPTRANSFERMODE_COMPRESSED    2	
/* Typed enum definition */
#define EFTPTRANSFERMODE    RTS_IEC_INT

/**
 *
 ***Function**
 *
 *Name of the Ftp transfer type. 
 *
 */
#define EFTPTRANSFERTYPE_IMAGE    0	/* Binary */
#define EFTPTRANSFERTYPE_ASCII    1	
#define EFTPTRANSFERTYPE_EBCDIC    2	/* Extended Binary Coded Decimals Interchange Code - NOT supported by LibCurl */
/* Typed enum definition */
#define EFTPTRANSFERTYPE    RTS_IEC_INT

/**
 *  
 *
 ***Function**
 *
 *Operation return status, according to POSIX.1 (1996 edition).
 *
 *This list closely reflects the Posix definitions of error symbols which are used 
 *commonly in lots of situations and which should more or less cover a majority of
 *standard situations. They are used here for the sake of international standardization.
 *
 *When functions report errors, however, typically only a small subset of these
 *codes are used by a single function or function block. 
 *So, although the general meaning of these codes is listed here, the header of 
 *each function SHOULD contain a list of the result codes which are actually used there
 *together with a description of the circumstances in which that function will 
 *return a specific code. 
 *    
 *When a function gets result codes from other functions, it is normally very bad style
 *to pass this result code upwards without further analysis of the code, because the 
 *results might be not well-specified. 
 *Instead, the result code SHOULD be analyzed internally and mapped to that result code set
 *which is specified in the header. 
 *
 ***Returning Result Codes**
 *
 *A large variety of different methods for returning status codes could be found in 
 *existing Codesys-code. For the sake of uniform handling, however, when a result 
 *code is involved in functions or methods, it should be returned as primary return value: ::
 * 
 *
 *    METHOD DoTheWork(VAR_OUTPUT Data : MyDataType) : eResultCode
 *    :
 *    IF DotheWork(Data=>Buffer) <> OK THEN
 *        DoErrorProcessing()
 *    END_IF
 *	
 *Other results of the function are to be returned via VAR_OUTPUT or VAR_IN_OUT, 
 *whereas the information about failure or success is given by standard via the 
 *primary return value.
 *
 ***Deprecated style:** Another frequently seen sheme which involves pointers
 *to a result variable is strongly deprecated: ::
 *
 *    FUNCTION oldstyle(VAR_INPUT pResult : POINTER TO UDINT) : MyDataType // DO NOT USE!
 *	
 *Reason: When using this sheme, it remains pretty unclear, 
 *
 *(a) if the previous result of pResult^ possibly  serves as input and thus would have to be initialized and 
 *(b) it remains unclear if pResult^ is written at all in certain situations.
 * 
 *This style SHOULD NOT be used in new code. 
 *It is strongly encouraged to port legacy code to standard behaviour.
 *
 ***Note:** There are lots of situations where handling of a result code in simple functions 
 *is not necessary. In these cases the primary return value may carry the processed value 
 *directly, while minor error conditions would lead to certain default values of the result: ::
 *
 *    FUNCTION ConvertMemBlockToString(VAR INPUT pMem, udiBlockSize) : STRING
 *    
 *In case of passing a nullpointer, just an empty string might be returned and a result code 
 *is not necessary in most applications.
 *
 *
 ***Documentation of Result Codes**
 *
 *When result codes are returned, typically only a small fraction of the possible range of 
 *codes is used by a single function. For the object which returns error codes, it **must** be
 *individually documented, which error codes could be expected at all (a general reference
 *to the list of all codes, although that is common practice in Codesys, is not sufficient). 
 *E.g.: ::
 *
 *    ======  ============================================================
 *    **Result Codes** of CopyFile() 
 *    --------------------------------------------------------------------
 *    0       Success
 *    EINVAL  Bad prefix or invalid filename
 *    ENOENT  The addressed entity or source file does not exist
 *    EISDIR  The addressed source is a directory, not a file as expected
 *    EEXIST  The destination file exists and must not be overwritten
 *    ======  ============================================================
 *	
 *	
 *
 ***Application specific result codes**
 *
 *While the standard codes are expected to cover most standard situations, specialized 
 *libraries might need individual result codes. For this purpose, the code range 200..999
 *is reserved for local individual extentions.
 *
 *The result code EAPP (=200) denotes the begin of the application specific code range.
 *
 ***Note:** Codes in this range are specific to the library which introduce it. 
 *These codes will not be registered centrally, so other libraries may use the 
 *same range of numbers if their authors do not cooperate. 
 *If global uniqueness of user defined result codes would be required, it
 *would be apprropriate, to embed the resultcodes into an **FbError**-Object 
 *(WagoAppErrorBase.library) 
 *
 *Unfortunately, actual Codesys compilers do not allow "EXTENDS" to an enumeration, but 
 *a number of feasible ways exist to smoothly integrate individual codes into 
 *eResultCodes as shown below.
 *
 *(see example_typedefs.project in the repository for reference)
 * 
 *::
 *
 *  //////////////////////////////////////////////////////////////////////////////////////
 *  // (a) standard codes only
 *  VAR eResult_.. : eResultCode; 
 *  
 *  eResult_01 := OK;           // standard code
 *  eResult_02 := EINVAL;       // standard code
 *  eResult_03 := 202;          // possible, but avoid this! hard coding is highly deprecated!
 *  
 *  //////////////////////////////////////////////////////////////////////////////////////
 *  // (b) definition of individual codes by offset
 *  TYPE eIndividualOffsets :
 *    (
 *	ofsElevatorDefect  := 0,
 *	ofsBuildingOnFire  := 1,
 *	ofsNoWater         := 2,
 *	ofsEarthquake      := 3,
 *	ofsNoElectricity   := 4	
 *   ) WORD;
 *  END_TYPE
 *  
 *  eResult_04 := EAPP + eIndividualOffsets.ofsNoWater; // definition of individual offsets 
 *
 *  //////////////////////////////////////////////////////////////////////////////////////
 *  // (c) definition of individual codes by real result code numbers
 *  TYPE eIndividualCodes :
 *    (
 *	ElevatorDefect  := 200,
 *	BuildingOnFire  := 201,
 *	NoWater         := 202,
 *	Earthquake      := 203,
 *    NoElectricity   := 204
 *    ) WORD;
 *  END_TYPE
 *
 *  eResult_05 := OK + eIndividualCodes.NoWater;      // definition of individual result codes 
 *
 *  //////////////////////////////////////////////////////////////////////////////////////
 *  // (d) usage of wrapping function
 *  FUNCTION BuildingCodes : eResultCode
 *  VAR_INPUT e : eIndividualCodes; END_VAR
 *  BuildingCodes := OK + e;                          // workaround to avoid warnings
 *
 *  eResult_06 := BuildingCodes(ElevatorDefect);      // converter function to avoid warnings
 *
 *  //////////////////////////////////////////////////////////////////////////////////////
 *  // (d) usage of global constants
 *  VAR_GLOBAL CONSTANT
 *	ELEVATOR_DEFECT  : WORD := 200;
 *	BUILDING_ON_FIRE : WORD := 201;
 *	NO_WATER         : WORD := 202;
 *	EARTHQUAKE       : WORD := 203;
 *	NO_ELECTRICITY   : WORD := 204;	
 *  END_VAR
 *
 *  eResult_07 := NO_ELECTRICITY;                     // usage of global constants
 *
 *  //////////////////////////////////////////////////////////////////////////////////////
 *  // (e) standard eResults can be mixed with individual codes
 *
 *  IF eResult_07 = eIndividualCodes.BuildingOnFire THEN // attn: comparison of different types 
 *    panic();
 *  END_IF
 *
 *  
 *------------------------------------------ 
 *  
 ***note (1)** This entry was changed from original EBADFD to overcome confusion with EBADF
 *
 */
#define ERESULTCODE_OK    0	/* Operation successfull finished, no error   (Not Posix but useful) */
#define ERESULTCODE_EPERM    1	/* Operation NOT permitted */
#define ERESULTCODE_ENOENT    2	/* No such file or directory */
#define ERESULTCODE_ESRCH    3	/* No such process */
#define ERESULTCODE_EINTR    4	/* Interrupted system call */
#define ERESULTCODE_EIO    5	/* I/O error */
#define ERESULTCODE_ENXIO    6	/* No such device or address */
#define ERESULTCODE_E2BIG    7	/* Argument list too long */
#define ERESULTCODE_ENOEXEC    8	/* Exec format error */
#define ERESULTCODE_EBADF    9	/* Bad file number / File not open */
#define ERESULTCODE_ECHILD    10	/* No child processes */
#define ERESULTCODE_EAGAIN    11	/* Try again */
#define ERESULTCODE_ENOMEM    12	/* Out of memory */
#define ERESULTCODE_EACCES    13	/* Permission denied */
#define ERESULTCODE_EFAULT    14	/* Bad address */
#define ERESULTCODE_ENOTBLK    15	/* Block device required */
#define ERESULTCODE_EBUSY    16	/* Device or resource busy */
#define ERESULTCODE_EEXIST    17	/* File exists */
#define ERESULTCODE_EXDEV    18	/* Cross-device link */
#define ERESULTCODE_ENODEV    19	/* No such device */
#define ERESULTCODE_ENOTDIR    20	/* Not a directory */
#define ERESULTCODE_EISDIR    21	/* Is a directory */
#define ERESULTCODE_EINVAL    22	/* Invalid argument */
#define ERESULTCODE_ENFILE    23	/* File table overflow */
#define ERESULTCODE_EMFILE    24	/* Too many open files */
#define ERESULTCODE_ENOTTY    25	/* Not a typewriter */
#define ERESULTCODE_ETXTBSY    26	/* Text file busy */
#define ERESULTCODE_EFBIG    27	/* File too large */
#define ERESULTCODE_ENOSPC    28	/* No space left on device */
#define ERESULTCODE_ESPIPE    29	/* Illegal seek */
#define ERESULTCODE_EROFS    30	/* Read-only file system */
#define ERESULTCODE_EMLINK    31	/* Too many links */
#define ERESULTCODE_EPIPE    32	/* Broken pipe */
#define ERESULTCODE_EDOM    33	/* Math argument out of domain of func */
#define ERESULTCODE_ERANGE    34	/* Math result not representable */
#define ERESULTCODE_EDEADLK    35	/* Resource deadlock would occur */
#define ERESULTCODE_ENAMETOOLONG    36	/* File name too long */
#define ERESULTCODE_ENOLCK    37	/* No record locks available */
#define ERESULTCODE_ENOSYS    38	/* Function not implemented */
#define ERESULTCODE_ENOTEMPTY    39	/* Directory not empty */
#define ERESULTCODE_ELOOP    40	/* Operation seems to be in a deadlock */
#define ERESULTCODE_EWOULDBLOCK    41	/* Operation would block */
#define ERESULTCODE_ENOMSG    42	/* No message of desired type */
#define ERESULTCODE_EIDRM    43	/* Identifier removed */
#define ERESULTCODE_ECHRNG    44	/* Channel number out of range */
#define ERESULTCODE_EL2NSYNC    45	/* Level 2 not synchronized */
#define ERESULTCODE_EL3HLT    46	/* Level 3 halted */
#define ERESULTCODE_EL3RST    47	/* Level 3 reset */
#define ERESULTCODE_ELNRNG    48	/* Link number out of range */
#define ERESULTCODE_EUNATCH    49	/* Protocol driver not attached */
#define ERESULTCODE_ENOCSI    50	/* No CSI structure available */
#define ERESULTCODE_EL2HLT    51	/* Level 2 halted */
#define ERESULTCODE_EBADE    52	/* Invalid exchange */
#define ERESULTCODE_EBADR    53	/* Invalid request descriptor */
#define ERESULTCODE_EXFULL    54	/* Exchange full */
#define ERESULTCODE_ENOANO    55	/* No anode */
#define ERESULTCODE_EBADRQC    56	/* Invalid request code */
#define ERESULTCODE_EBADSLT    57	/* Invalid slot */
#define ERESULTCODE_EBFONT    59	/* Bad font file format */
#define ERESULTCODE_ENOSTR    60	/* Device not a stream */
#define ERESULTCODE_ENODATA    61	/* No data available */
#define ERESULTCODE_ETIME    62	/* Timer expired */
#define ERESULTCODE_ENOSR    63	/* Out of streams resources */
#define ERESULTCODE_ENONET    64	/* Machine is not on the network */
#define ERESULTCODE_ENOPKG    65	/* Package not installed */
#define ERESULTCODE_EREMOTE    66	/* Object is remote */
#define ERESULTCODE_ENOLINK    67	/* Link has been severed */
#define ERESULTCODE_EADV    68	/* Advertise error */
#define ERESULTCODE_ESRMNT    69	/* Srmount error */
#define ERESULTCODE_ECOMM    70	/* Communication error on send */
#define ERESULTCODE_EPROTO    71	/* Protocol error */
#define ERESULTCODE_EMULTIHOP    72	/* Multihop attempted */
#define ERESULTCODE_EDOTDOT    73	/* RFS specific error */
#define ERESULTCODE_EBADMSG    74	/* Not a data message */
#define ERESULTCODE_EOVERFLOW    75	/* Value too large for defined data type */
#define ERESULTCODE_ENOTUNIQ    76	/* Name not unique on network */
#define ERESULTCODE_EBADSTATE    77	/* File descriptor in bad state  (see note 1) */
#define ERESULTCODE_EREMCHG    78	/* Remote address changed */
#define ERESULTCODE_ELIBACC    79	/* Can not access a needed shared library */
#define ERESULTCODE_ELIBBAD    80	/* Accessing a corrupted shared library */
#define ERESULTCODE_ELIBSCN    81	/* .lib section in a.out corrupted */
#define ERESULTCODE_ELIBMAX    82	/* Attempting to link in too many shared libraries */
#define ERESULTCODE_ELIBEXEC    83	/* Cannot exec a shared library directly */
#define ERESULTCODE_EILSEQ    84	/* Illegal byte sequence */
#define ERESULTCODE_ERESTART    85	/* Interrupted system call should be restarted */
#define ERESULTCODE_ESTRPIPE    86	/* Streams pipe error */
#define ERESULTCODE_EUSERS    87	/* Too many users */
#define ERESULTCODE_ENOTSOCK    88	/* Socket operation on non-socket */
#define ERESULTCODE_EDESTADDRREQ    89	/* Destination address required */
#define ERESULTCODE_EMSGSIZE    90	/* Message too long */
#define ERESULTCODE_EPROTOTYPE    91	/* Protocol wrong type for socket */
#define ERESULTCODE_ENOPROTOOPT    92	/* Protocol not available */
#define ERESULTCODE_EPROTONOSUPPORT    93	/* Protocol not supported */
#define ERESULTCODE_ESOCKTNOSUPPORT    94	/* Socket type not supported */
#define ERESULTCODE_EOPNOTSUPP    95	/* Operation not supported on transport endpoint */
#define ERESULTCODE_EPFNOSUPPORT    96	/* Protocol family not supported */
#define ERESULTCODE_EAFNOSUPPORT    97	/* Address family not supported by protocol */
#define ERESULTCODE_EADDRINUSE    98	/* Address already in use */
#define ERESULTCODE_EADDRNOTAVAIL    99	/* Cannot assign requested address */
#define ERESULTCODE_ENETDOWN    100	/* Network is down */
#define ERESULTCODE_ENETUNREACH    101	/* Network is unreachable */
#define ERESULTCODE_ENETRESET    102	/* Network dropped connection because OF reset */
#define ERESULTCODE_ECONNABORTED    103	/* Software caused connection abort */
#define ERESULTCODE_ECONNRESET    104	/* Connection reset BY peer */
#define ERESULTCODE_ENOBUFS    105	/* No buffer space available */
#define ERESULTCODE_EISCONN    106	/* Transport endpoint is already connected */
#define ERESULTCODE_ENOTCONN    107	/* Transport endpoint is NOT connected */
#define ERESULTCODE_ESHUTDOWN    108	/* Cannot send after transport endpoint shutdown */
#define ERESULTCODE_ETOOMANYREFS    109	/* Too many references: cannot splice */
#define ERESULTCODE_ETIMEDOUT    110	/* Connection timed out */
#define ERESULTCODE_ECONNREFUSED    111	/* Connection refused */
#define ERESULTCODE_EHOSTDOWN    112	/* Host is down */
#define ERESULTCODE_EHOSTUNREACH    113	/* No route TO host */
#define ERESULTCODE_EALREADY    114	/* Operation already in progress */
#define ERESULTCODE_EINPROGRESS    115	/* Operation now in progress */
#define ERESULTCODE_ESTALE    116	/* Stale NFS file handle */
#define ERESULTCODE_EUCLEAN    117	/* Structure needs cleaning */
#define ERESULTCODE_ENOTNAM    118	/* not a XENIX named TYPE file */
#define ERESULTCODE_ENAVAIL    119	/* No XENIX semaphores available */
#define ERESULTCODE_EISNAM    120	/* Is a named TYPE file */
#define ERESULTCODE_EREMOTEIO    121	/* Remote I/O error */
#define ERESULTCODE_EDQUOT    122	/* Quota exceeded */
#define ERESULTCODE_ENOMEDIUM    123	/* No medium found */
#define ERESULTCODE_EMEDIUMTYPE    124	/* Wrong medium type */
#define ERESULTCODE_ECANCELED    125	/* Operation Canceled */
#define ERESULTCODE_ENOKEY    126	/* Required key NOT available */
#define ERESULTCODE_EKEYEXPIRED    127	/* Key has expired */
#define ERESULTCODE_EKEYREVOKED    128	/* Key has been revoked */
#define ERESULTCODE_EKEYREJECTED    129	/* Key was rejected by service */
#define ERESULTCODE_EOWNERDEAD    130	/* Owner died */
#define ERESULTCODE_ENOTRECOVERABLE    131	/* State not recoverable */
#define ERESULTCODE_EDEFAULT    132	/* Resource did not change from default state (not Posix) */
#define ERESULTCODE_EPENDING    133	/* Operation or event is expected to occur */
#define ERESULTCODE_ETERMINATED    134	/* Operation has terminated but the ressources are allocated */
#define ERESULTCODE_EUNSPECIFIC    135	/* Error whichs nature is not further specified */
#define ERESULTCODE_EDISABLED    136	/* The requested function is temporarily disabled */
#define ERESULTCODE_EREJECTED    137	/* The requested service was not accepted. */
#define ERESULTCODE_ENOSUCCESS    138	/* The operation did not yield a successful result */
#define ERESULTCODE_EBREAKPT    139	/* This is a regular breakpoint, where operation may be resumed or not. */
#define ERESULTCODE_ETIMEINFO    140	/* Timeout which is not a fault but an anticipated result. */
#define ERESULTCODE_EAPP    200	/* Application specific error (not Posix) */
#define ERESULTCODE_EAPPMAX    999	/* top of the code range for applications */
#define ERESULTCODE_EMAX    32767	/* absolutely last error code */
/* Typed enum definition */
#define ERESULTCODE    RTS_IEC_WORD

/**
 * 
 *
 ***Function**
 *
 *This enumeration controls the details of asynchronous scheduling of an FB. 
 *
 ***Function Description**
 *
 *This type is used as input parameter for asynchronous scheduling of jobs.
 *The following values are used:
 *
 *eSchedulingMode.Synchronous:
 *    This mode represents execution within the synchrounous IEC task context. 
 *    The execution is not deferred to other tasks, but takes place 
 *    immediatelly after calling and blocks the calling application during execution.
 *    Note: This mode is mostly used when developing own asnchronous FBs. 
 *
 *
 *eSchedulingMode.RealTimeHigh (=1):
 *    Execution in a different asynchronous task with runs priorized over the IEC task but 
 *    subordinate to tasks for external interfaces. 
 *    Latency in the RealTime-scheduling group is expected to be substatially low, because 
 *    execution could not be delayed by external interface tasks.
 *    In contrast, tasks with priority 1-3 might possibly delay external interfaces. 
 *    Thus, this mode is not advisable for long running tasks.
 *
 *eSchedulingMode.RealTimeMedium/Low (=2/3): 
 *    These modes denote the essentially similar to RealTimeHigh, but with lower priority. 
 *    These tasks will not delay RealTimeHigh-tasks, but could be delayed by them.
 *
 *eSchedulingMode.AsyncHigh (=4):
 *    Tasks in this mode will not block field bus communication, but could be delayed by field bussed.
 *    Latency in this mode might be high, because execution might be delayed by external 
 *    influences - such as field busses.
 *
 *eSchedulingMode.AsyncMedium/Low (=7/14):
 *    Same properties as AsyncHigh but with subordinate priority.
 *    In typical scenarios, visualization applications (which need not to be realtime 
 *    but should keep a minimum of response time) would be scheduled to AsyncMedium 
 *    while long running deferred tasks (such as filecopy) would run in AsyncLow or Background.
 *
 *eSchedulingMode.Background (=15):
 *    Tasks in this mode are fed with the resources which remain to the system after otherwise
 *    priorized tasks are done. This is intended for longrunning work which has no time constraints 
 *    for latency or termination.
 *
 *	
 *Triggering on external events:
 *    Various PLCs allow to schedule the execution of tasks synchronous to certain external 
 *    events. It depends on the hardware which events are supported.
 *    An additional enumeration *eSchedulingModeEvent* is provided via the device description.
 *    The values from this enumeration may be safely inserted when eSchedulingMode is expected.
 *	
 *    In order to avoid false warnings, a type cast function is also provided from the library 
 *    that provides specific scheduling modes:  ::
 *	
 *	   eSchedMode := eSchedulingMode.Background;                                  // regular assignment
 *	   eSchedMode := SchedulingMode(eSchedulingModeEvent.Modbus_Watchdog_Expired); // device specific assignment
 *	 
 *Triggering on external events with additional prioritizing:
 *
 *    Some target hardware allows for combining external events with additional scheduling priority.
 *	In this case, the wrapping function ``SchedulingMode_EventPriority()`` is to be used for 
 *    combining both to a single scheduling mode value: :: 
 *
 *      eSchedMode := SchedulingMode_EventPriority(eSchedulingModeEvent.Modbus_Watchdog_Running, 
 *                                                 eSchedulingMode.AsyncLow);
 *      	
 *Other values than these are reserved for future usage and MUST NOT be used.
 *When scheduling modes are used in applications, however, they *must* always be referred to by 
 *symbolic names, *never* by plain numbers.
 *
 *.. note:: (The type casts ``SchedulingMode()`` and ``SchedulingMode_EventPriority()`` are defined in
 *          the target specific library resolved by the placeholder ``WagoTypesAsyncInternal``. 
 *          They are automatically loaded together with ``WagoSysAsync.library``.)
 *
 **Caveat:* 
 *
 *In certain very special situations the function ``SchedulingMode_EventPriority()`` might be fed 
 *with other priorities than defined here. In those cases it MUST be crosschecked against 
 *the library ``WagoTypesAsync_Internal_~`` if those exceptional values are valid.
 * 
 */
#define ESCHEDULINGMODE_REALTIMEHIGH    1	/* Highest priority for asynchronous tasks (see below) */
#define ESCHEDULINGMODE_REALTIMEMEDIUM    2	/* Medium priority for task with realtime requirements */
#define ESCHEDULINGMODE_REALTIMELOW    3	/* Lowest priority for task with realtime requirements */
#define ESCHEDULINGMODE_ASYNCHIGH    4	/* Highest priority for tasks without realtime properties */
#define ESCHEDULINGMODE_ASYNCMEDIUM    7	/* Medium priority for tasks without realtime properties */
#define ESCHEDULINGMODE_ASYNCLOW    14	/* Lowest priority prior to the main task */
#define ESCHEDULINGMODE_BACKGROUND    15	/* Standard for regular tasks */
#define ESCHEDULINGMODE_SYNCHRONOUS    -1	/* Running synchronously in the same task and context (no async scheduling) */
#define ESCHEDULINGMODE_NOSCHEDULING    -2	/* Not scheduled in any mode (for output purposes only) */
/* Typed enum definition */
#define ESCHEDULINGMODE    RTS_IEC_DINT

/**
 *  
 *
 ***Function**
 *
 *Mode for File-Seek
 *
 ***Function Description**
 *
 *When a positioning (``Seek()``) is performed within a file, you have to specify the reference
 *index for positioning the new write pointer.
 *
 ***Caveat:** When ``eSeekMode.fromEnd`` is applied, the corresponing positioning value will
 *typically carry a negative value (unless the desired position is beyound the end of the file). 
 *In mode ``fromActualPosition`` both negative and positive values are common.   
 *
 */
#define ESEEKMODE_FROMSTART    0	/* (SEEK_SET) Position the file pointer relative to start of file. */
#define ESEEKMODE_FROMEND    1	/* (SEEK_END) Position the file pointer relative to file end. */
#define ESEEKMODE_FROMACTUALPOSITION    2	/* (SEEK_CUR) Positioning relative to actual position. */
/* Typed enum definition */
#define ESEEKMODE    RTS_IEC_WORD

/**
 *  
 *
 ***Function**
 *
 *Indicates a level how severe a message, event, or report, etc. is.
 *This is used mainly for logfiles.
 *
 */
#define ESEVERITY_NONE    0x0	/* Everything ok, not worth further processing. */
#define ESEVERITY_INFO    0x1	/* Informational status only. */
#define ESEVERITY_WARNING    0x2	/* The state is abnormal but does not conflict with the regular process. */
#define ESEVERITY_ERROR    0x4	/* A conflict with the regular process is indicated. */
#define ESEVERITY_EXCEPTION    0x8	/* A conflict with which is so heavy that it requires abortion of the process. */
#define ESEVERITY_DEBUG    0x10	/* The message should not pop up in production code. For development purposeses only. */
#define ESEVERITY_ALL    0x1F	/* A mask, covering all messages. */
#define ESEVERITY_UNKNOWN    0x40	/* It is not clear which severity applies here. */
#define ESEVERITY_VOLATILE    0x80	/* The message should not be processed further. */
/* Typed enum definition */
#define ESEVERITY    RTS_IEC_DWORD

/**
 * <description>Enum: eSNMP_AuthenticationProtocol</description>
 */
#define ESNMP_AUTHENTICATIONPROTOCOL_SNMP_AUTHP_NONE    0	/* No Authentication Hash Type */
#define ESNMP_AUTHENTICATIONPROTOCOL_SNMP_AUTHP_MD5    1	/* Use MD5 to create Authentication Hash */
#define ESNMP_AUTHENTICATIONPROTOCOL_SNMP_AUTHP_SHA    20	/* Use SHA1 to create Authentication Hash */
/* Typed enum definition */
#define ESNMP_AUTHENTICATIONPROTOCOL    RTS_IEC_INT

/**
 * <description>Enum: eSNMP_PrivacyProtocol</description>
 */
#define ESNMP_PRIVACYPROTOCOL_SNMP_PRIVP_NONE    0	/* No Privacy Protocol Type */
#define ESNMP_PRIVACYPROTOCOL_SNMP_PRIVP_DES    1	/* Use DES encryption */
#define ESNMP_PRIVACYPROTOCOL_SNMP_PRIVP_AES    2	/* Use AES encryption */
/* Typed enum definition */
#define ESNMP_PRIVACYPROTOCOL    RTS_IEC_INT

/**
 * <description>Enum: eSNMP_SecurityLevel</description>
 */
#define ESNMP_SECURITYLEVEL_SNMP_SECURITY_NOAUTHNOPRIV    1	/* do not use Authentication or Privacy */
#define ESNMP_SECURITYLEVEL_SNMP_SECURITY_AUTHNOPRIV    2	/* Authenticate but no privacy */
#define ESNMP_SECURITYLEVEL_SNMP_SECURITY_AUTHPRIV    3	/* Authenticate and privacy */
/* Typed enum definition */
#define ESNMP_SECURITYLEVEL    RTS_IEC_INT

/**
 * <description>Enum: eSNMP_TLV_DATATYPE</description>
 */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_INTEGER    2	/* DINT */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_BITS    3	/* STRING */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_STRING    4	/* STRING */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_OBJECT_ID    6	/* STRING */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_IP_ADDRESS    64	/* STRING */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_COUNTER    65	/* UDINT */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_GAUGE    66	/* UDINT */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_TIMETICKS    67	/* UDINT */
#define ESNMP_TLV_DATATYPE_SNMP_TLV_UINTEGER    71	/* SNMP_TLV_COUNTER64	:= 70,
 ULINT
 UNUSABLE 
 UDINT */
/* Typed enum definition */
#define ESNMP_TLV_DATATYPE    RTS_IEC_INT

/**
 * <description>Enum: eSNMP_TRAP_TYPE</description>
 */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_COLDSTART    0	/* cold start */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_WARMSTART    1	/* warm start */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_LINKDOWN    2	/* link down */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_LINKUP    3	/* link up */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_AUTHFAILS    4	/* authentication failure */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_EGPNEIGHBORLOSS    5	/* egp neighbor loss */
#define ESNMP_TRAP_TYPE_SNMPT_TRAP_ENTERPRISESPECIFIC    6	/* enterprise specific */
/* Typed enum definition */
#define ESNMP_TRAP_TYPE    RTS_IEC_INT


/**
 * <description>typSNMP_TLV</description>
 */
typedef struct tagtypSNMP_TLV
{
	/* Computation of array size for 32bit and 64bit architectures.
	
	array elements                          32bit  padding    64bit  padding
	struct variable_list *next_variable        4                 8
	oid *name                                  4                 8
	size_t name_length                         4                 8
	u_char type                                1      3          1      7
	netsnmp_vardata val                        4                 8
	size_t val_len                             4                 8
	oid name_loc[MAX_OID_LEN = 128]          512              1024
	u_char buf[40]                            40                40
	void *data                                 4                 8
	void (*dataFreeHook)(void *)               4                 8
	int index                                  4                 4      4
	------------------------------------------------------------------------
	                                         588              1136

	32bit: 137 * 4 + 40 =  588
	64bit: 137 * 8 + 40 = 1136
	*/

	RTS_IEC_BYTE net_snmp_variable_list[137 * sizeof(void*) + 40];		/* this array reserves the memory for an instance of an net_snmpvariable_list element */
} typSNMP_TLV;


/**
 *  
 *
 ***Function**
 *
 *Meta-Information about files or direcories
 *
 *.. note:: The function ``FbSysDir.Read()`` and ``GetFileProperties()`` (in file libraries) use this structure
 *          for returning information about files and directories.
 *
 */
typedef struct tagtypFileProperties
{
	RTS_IEC_STRING sFileName[256];		/* Name of the actual file, canonical including full absolute path. */
	RTS_IEC_ULINT uliSize;		/* File Size. */
	RTS_IEC_DATE_AND_TIME dtLastModification;		/* Time of last modification (in GMT, i.e. no timezone). */
	RTS_IEC_BOOL xArchive;		/* Is an archive file. */
	RTS_IEC_BOOL xHidden;		/* Is hidden in application layer. */
	RTS_IEC_BOOL xReadOnly;		/* No write access. */
	RTS_IEC_BOOL xDirectory;		/* Is a directory. */
	RTS_IEC_BOOL xExclusive;		/* Exclusive access only. */
} typFileProperties;

/**
 * 
 *
 ***Function**
 *
 *Information about a timezone.
 * 
 ***Function Description**
 *
 *``iOffset:``
 *   For obtaining the local time with respect to this time zone, this offset (in minutes) has to be 
 *   added to the GMT value.   
 *   
 *   This iOffset corresponds directly to the value which is given e.g. in ``GMT+0100`` for central 
 *   european time (1 hour + 0 minutes = 60 minutes). 
 *       
 *   
 *``sName:``
 *   The name of the described time zone, e.g. 'CET' for central european time or 'CEST' for central 
 *   european summer time.  
 *    
 *
 *``bLetter:``
 *   This letter serves for differenciating daylight-saving-time from standard-time within the same time zone.
 *      
 *   The most common letters are  'S' = Standard time and 'D' = Daylight-saving-Time.
 *   Nevertheless, also other letters may used here for certain peculier local time zone modes. 
 *   It is depending on the timezone settings, which letters apply here.
 * 
 *   This letter is needed only for display purposes rather than for calculations, because   
 *   the component iOffset is also set to different values in ST and in DST.    
 *
 */
typedef struct tagtypTimeZoneDescription
{
	RTS_IEC_INT iOffset;		/* Minutes from GMT (e.g. +60 for CET and +120 for CEST) */
	RTS_IEC_STRING sName[33];		/* Name of the time zone, e.g. 'CEST' */
	RTS_IEC_BYTE bLetter;		/* 'S' = Standard time, 'D' = Daylight-saving-Time, etc */
} typTimeZoneDescription;

/**
 * 
 *
 ***Function**
 *
 *Paraphrasis of SysTimeRtc.SYSTIMEDATE. 
 *
 ***Function Description**
 *
 *This struct is a direct paraphrasis of ``SysTimeRtc.SYSTIMEDATE``, because that struct is defined 
 *abiguously between different library versions and thus is not usable as base structure.
 *
 *Here we have taken the original definitions as temporary replacement for the 
 *original structure (which is defined in SysTimeRtc) until this issue is solved.
 *
 *Use this type in new code rather than ``SysTimeRtc.SYSTIMEDATE``. 
 */
typedef struct tagtypRTS_SYSTIMEDATE
{
	RTS_IEC_UINT uiYear;		/* Year (e.g. 2006) */
	RTS_IEC_UINT uiMonth;		/* Month (1..12: January = 1, December = 12) */
	RTS_IEC_UINT uiDay;		/* Day of month (1..31) */
	RTS_IEC_UINT uiHour;		/* Hours after midnight (0..23) */
	RTS_IEC_UINT uiMinute;		/* Minutes after hour (0..59) */
	RTS_IEC_UINT uiSecond;		/* Seconds after minute (0..59) */
	RTS_IEC_UINT uiMilliseconds;		/* Milliseconds after second (0..999, optional) */
	RTS_IEC_UINT uiDayOfWeek;		/* Day of week (1..7: Monday = 1, Sunday = 7) */
	RTS_IEC_UINT uiYday;		/* Day of year (1..365): January 1 = 1 */
} typRTS_SYSTIMEDATE;

/**
 * 
 *
 ***Function**
 *
 *This struct contains all information to directly print a calendarial representation of the local time.
 *
 *Note (1): iYearOffsetForWoY denotes a year shift concerning the actually calculated calendar week.
 *It is 
 *
 *- ``0``  in regular cases,
 *- ``-1`` if the  week is last week of previous year, (e.g. at 01.01.2012, which is in week 52/2011).
 *- ``+1`` if the week is first week of following year (e.g. at 31.12.2013, which is in week 01/2014).
 *  
 *So when referencing the year, according the calender week, this value must be added to the year number.
 *
 *Note (2): ``bAmbiguityModifier`` is regularly set to ' ' if the structure is returned from some 
 *function in order to distinguish it from the default state ``0``.
 *It is 'A' OR 'B' when the hour is considered, when the timezone switches from DST to ST and 
 *the hour 02:00-02:59 appears twice. The hour 02:xx in DST is denoted with 'A' and the following one, 
 *(associated to ST) is denoted with 'B'  
 *  
 *Note (3) the first components of this structure are binary identical to ``SysTimeRtc.SYSTIMEDATE``,
 *but they could not be inherited from there directly due to technical reasons.
 * 
 */
typedef struct tagtypWagoTimeComponents
{
	typTimeZoneDescription TimeZone;		/* To what timezone does the local date belong? */
	RTS_IEC_BYTE bAmbiguityModifier;		/* Normally ' ', but 'A' OR 'B' when switching from DST to ST. */
	RTS_IEC_UINT uiMicroseconds;		/* Microseconds after integer milliseconds (if available) */
	RTS_IEC_UINT uiNanoseconds;		/* Nanoseconds after integer milliseconds (if available) */
	RTS_IEC_UDINT udiAbsoluteDays;		/* Integer number of days since 1.1.1970 local date */
	RTS_IEC_UINT uiWeekOfYear;		/* Calendar Week according to ISO8601 */
	RTS_IEC_INT iYearOffsetForWoY;		/* Offset for matching year and calendar week */
} typWagoTimeComponents;

/**
 *  
 *
 ***Function**
 *
 *A union of pointers of various types 
 *
 *This type is used when unspecific static typecasting is to be performed between pointers.
 * 
 */
typedef union
{
	RTS_IEC_BOOL *pBool;		/* Points to a BOOL; */
	RTS_IEC_BYTE *pByte;		/* Points to a BYTE; */
	RTS_IEC_SINT *pSint;		/* Points to an 8-Bit-Integer */
	RTS_IEC_INT *pInt;		/* Points to a 16-Bit-Integer */
	RTS_IEC_UINT *pUint;		/* Points to an unsigned 16-Bit-Integer */
	RTS_IEC_DINT *pDint;		/* Points to a 32-Bit-Integer */
	RTS_IEC_UDINT *pUdint;		/* Points to an unsigned 32-Bit-Integer */
	RTS_IEC_LINT *pLint;		/* Points to a 64-Bit-Integer */
	RTS_IEC_ULINT *pULint;		/* Points to an unsigned 64-Bit-Integer */
	RTS_IEC_REAL *pReal;		/* Points to a 32-Bit-Real */
	RTS_IEC_LREAL *pLReal;		/* Points to a 64-Bit-Real */
	RTS_IEC_TIME *pTime;		/* Points to a 32-Bit-TIME */
	RTS_IEC_DATE_AND_TIME *pDateAndTime;		/* Points to a 32-Bit-DATE_AND_TIME */
	RTS_IEC_LTIME *pLtime;		/* Points to a 64-Bit-TIME */
	RTS_IEC_STRING *pString;		/* Points to a String of 8-Byte characters */
	RTS_IEC_BYTE *p;		/* Points to anything */
} unPointer;

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoTypesCommon_C;

#ifdef CPLUSPLUS
class IWagoTypesCommon : public IBase
{
	public:
};
	#ifndef ITF_WagoTypesCommon
		#define ITF_WagoTypesCommon static IWagoTypesCommon *pIWagoTypesCommon = NULL;
	#endif
	#define EXTITF_WagoTypesCommon
#else	/*CPLUSPLUS*/
	typedef IWagoTypesCommon_C		IWagoTypesCommon;
	#ifndef ITF_WagoTypesCommon
		#define ITF_WagoTypesCommon
	#endif
	#define EXTITF_WagoTypesCommon
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOTYPESCOMMONITF_H_*/
