/*
 * wagotime.h
 *
 *  Created on: 01.08.2014
 *      Author: pacusr
 */

#ifndef WAGOTIME_H_
#define WAGOTIME_H_

#include <time.h>


typedef struct stWagoTimezoneDescription
{
    int   offset;
    char  name[32];
    char  letter;//isst indicator
}tWagoTimezoneDescription;

int update_tz_variable();

void wagoTimeGetZoneInfo(time_t posixTime, tWagoTimezoneDescription * td);

void wagoTimeLocaltime(time_t posixTime, struct tm *tm);

int wagoTimeSetZone(const char * dbKey);

#endif /* WAGOTIME_H_ */
