//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dpc31Stack_SYSI.h
///
///  \defgroup page_dpc31Stack_sysi System Interface (SYSI)
///  \ingroup  page_dpc31Stack_component
///
///  \version  $Id:
///
///  \brief    This module is the common interface of this component. It is possible to create and destroy objects of
///             the DPC31 Stack. Before using of the created object is possible the activation after the initialization
///             is necessary.
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPC31STACK_SYSI_H
#define DPC31STACK_SYSI_H

//----------------------------------------------------------------------------------------------------------------------
// Global Includes
//----------------------------------------------------------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>

#include "os_api.h"

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Stack_sysi_definitions Definitions
///  \ingroup page_dpc31Stack_sysi
///
///  These are the definitions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
/// \defgroup dpc31StackStatus Status codes
/// \ingroup dpc31StackStatus
///
/// The return value defines are 32 bit values and have the following format:
///
/// \code
///   3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0
///   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
///  +---+---------------------------+--------------------------------+
///  |Sev|      extended Code        |               Code             |
///  +---+---------------------------+--------------------------------+
/// \endcode
///
///  - Sev is the severity code
///   - 00 - Success
///   - 01 - Informational
///   - 10 - Warning
///   - 11 - Error
///  - extended Code describes the code more detailed (for further information see error code definitions)
///
/// \{
//----------------------------------------------------------------------------------------------------------------------
/** the processing of the function has been successfully finished */
#define DPC31STACK_SUCCESS                                        0x00000000U
/** an undefined error has occurred during the processing of the function */
#define DPC31STACK_ERROR_UNDEFINED                                0xC0000000U
/** the pointer of a parameter is invalid */
#define DPC31STACK_ERROR_NULL_POINTER                             0xC0000001U
/** the object state is not valid */
#define DPC31STACK_ERROR_INVALID_OBJ_STATE                        0xC0000002U
/** the function was called in the wrong sequence */
#define DPC31STACK_ERROR_INVALID_SEQUENCE                         0xC0000003U
/** the requested resource is not available */
#define DPC31STACK_ERROR_RESSOURCE_FAULT                          0xC0000004U
/** the settings are invalid */
#define DPC31STACK_ERROR_INVALID_SETTINGS                         0xC0000005U
/** the requested data are not available */
#define DPC31STACK_ERROR_DATA_NOT_AVAILABLE                       0xC0000006U
/** the requested resource is not available */
#define DPC31STACK_ERROR_RESSOURCE_NOT_AVAILABLE                  0xC0000007U
/** the object state is not valid */
#define DPC31STACK_ERROR_INVALID_PBC_HANDLE                       0xC0000008U
/** the object state is not valid */
#define DPC31STACK_ERROR_PBC_NOT_INITIALISED                      0xC0000009U
/** the specified data length is invalid */
#define DPC31STACK_ERROR_INVALID_DATA_LENGTH                      0xC000000AU
///  \}

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup dpc31StackSysiDefines Common defines
///  \ingroup page_dpc31Stack_sysi_definitions
///
///  The following defines are used in this module.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** the specific service was processed successfully */
#define DPC31STACK_CBFNC_OK     0x01U
///  \}

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Stack_sysi_data_types Data Types
///  \ingroup page_dpc31Stack_sysi
///
///  These are the data types of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup dpc31StackSettings_t
///
/// The \ref dpc31StackSettings_t structure describes the DPC31 stack component settings.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** priority of the processing thread engine */
    uint32_t  ulThreadPrio;
    /** maximum number of massages processed at the same time */
    uint32_t  ulMaxNoOfMsgEntries;
}dpc31StackSettings_t;

//----------------------------------------------------------------------------------------------------------------------
// Global Variables
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Stack_sysi_functions Functions
///  \ingroup page_dpc31Stack_sysi
///
///   These are the functions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//-- Function: dpc31Stack_Initialise --------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_sysi_functions
///
///  This function creates a new object of the DPC31 Stack. The memory is allocated here. Additionally all necessary
///   internal initialisation are processed in this function. If something went wrong the return value
///   is not "DPC31STACK_SUCCESS" and no memory has been allocated.
///
///  \param   pstDpc31StackSettings    settings of the component context
///
///  \return  @ref DPC31STACK_SUCCESS                 no error has occurred
///  \return  @ref DPC31STACK_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_Initialise (const dpc31StackSettings_t* pstDpc31StackSettings);

//-- Function: dpc31Stack_Activate ----------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_sysi_functions
///
///  This function activates the object of the DPC31 Stack.
///
///  \return  \ref DPC31STACK_SUCCESS                 no error has occurred
///  \return  \ref DPC31STACK_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  \ref DPC31STACK_ERROR_NULL_POINTER      the object handle is invalid
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_Activate (void);

//-- Function: dpc31Stack_Deactivate --------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_sysi_functions
///
///  This function deactivates the object of the DPC31 Stack.
///
///  \return  \ref DPC31STACK_SUCCESS                 no error has occurred
///  \return  \ref DPC31STACK_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  \ref DPC31STACK_ERROR_NULL_POINTER      the object handle is invalid
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_Deactivate (void);

//-- Function: dpc31Stack_Release -----------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_sysi_functions
///
///  This function destroys the object of the DPC31 Stack. The memory is released as well.
///
///  \return  \ref DPC31STACK_SUCCESS                 no error has occurred
///  \return  \ref DPC31STACK_ERROR_INVALID_SEQUENCE  the current state of the object is invalid
///  \return  \ref DPC31STACK_ERROR_NULL_POINTER      the object handle is invalid
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_Release (void);

#endif
//---- End of header ---------------------------------------------------------------------------------------------------
