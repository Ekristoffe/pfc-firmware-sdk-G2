//----------------------------------------------------------------------------------------------------------------------
/// Copyright (c) WAGO GmbH & Co. KG
///
/// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in
/// the subject matter of this material. All manufacturing, reproduction,
/// use, and sales rights pertaining to this subject matter are governed
/// by the license agreement. The recipient of this software implicitly
/// accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
///
///  \file     dpc31Stack_API.h
///
///  \defgroup page_dpc31Stack_api Application Programming Interface (API)
///  \ingroup  page_dpc31Stack_component
///
///  \version  $Id:
///
///  \brief    This module is the application interface for the PROFIBUS stack. All available
///             functions can only be accessed by using this interface. This software component encapsulates the
///             PROFIBUS DP protocol stack "V1SL" developed by SIEMENS AG with additional functional optimisations.
///             This makes the handling of the stack much easier. For a more detailed functional documentation please
///             use the V1SL user documentation.
///             ATTENTION: Do not modify this file! Changes can lead to undefined component behavior!
///
///  \author   Wauer : WAGO GmbH & Co. KG
//----------------------------------------------------------------------------------------------------------------------
#ifndef DPC31STACK_API_H
#define DPC31STACK_API_H

//----------------------------------------------------------------------------------------------------------------------
// Global Includes
//----------------------------------------------------------------------------------------------------------------------
#include <os_api.h>

#include "dpc31Stack_SYSI.h"

//----------------------------------------------------------------------------------------------------------------------
// Defines
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Stack_api_definitions Definitions
///  \ingroup page_dpc31Stack_api
///
///  These are the definitions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup dpc31StackDiagCtrlDefines Diagnostic control defines
///  \ingroup page_dpc31Stack_api_definitions
///
///  The following defines are used for diagnostic control when a new diagnostic telegram is set
///   by calling the function \ref dpc31Stack_C0SetDiag.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** reset bit 'extended diagnostic' */
#define DPC31STACK_EXT_DIAG_RESET                 0x00U
/** set bit 'extended diagnostic' */
#define DPC31STACK_EXT_DIAG_SET                   0x01U
/** don’t influence bit 'extended diagnostic' */
#define DPC31STACK_EXT_DIAG_UNCHANGE              0x02U
/** set bit 'extended diagnostic data overflow' */
#define DPC31STACK_EXT_DIAG_OVF_RESET             0x00U
/** set bit 'extended diagnostic data overflow' */
#define DPC31STACK_EXT_DIAG_OVF_SET               0x04U
/** don’t influence bit 'extended diagnostic data overflow' */
#define DPC31STACK_EXT_DIAG_OVF_UNCHANGE          0x08U
/** reset bit 'static diagnostic' */
#define DPC31STACK_STAT_DIAG_RESET                0x00U
/** set bit 'static diagnostic' (this is possible only in a compatibility mode of the slave) */
#define DPC31STACK_STAT_DIAG_SET                  0x10U
/** don’t influence bit 'static diagnostic' */
#define DPC31STACK_STAT_DIAG_UNCHANGE             0x20U
/** diagnostics will only be sent together with any alarm; if necessary, the slave waits for the next alarm */
#define DPC31STACK_SEND_DIAG_WITH_ALARM           0x40U
///  \}

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup dpc31StackSubnetCodeDefines Abort PDU subnet code defines
///  \ingroup page_dpc31Stack_api_definitions
///
///  The following defines are used to specify the subnet of an abort PDU.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** module is directly connected to PROFIBUS DP */
#define DPC31STACK_SUBNET_LOCAL                   0x01U
/** module is connected to the bus via an IM/Link */
#define DPC31STACK_SUBNET_REMOTE                  0x02U
///  \}

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup dpc31StackResonCodeDefines Abort PDU reason code defines
///  \ingroup page_dpc31Stack_api_definitions
///
///  The following defines are used to specify the reason of an abort PDU.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** sequence error */
#define DPC31STACK_ABORT_DPT_SEQU                 0x11U
/** invalid request PDU received */
#define DPC31STACK_ABORT_DPT_REQU                 0x12U
/** timeout of the connection */
#define DPC31STACK_ABORT_DPT_TIME                 0x13U
/** invalid response PDU received */
#define DPC31STACK_ABORT_DPT_RESP                 0x14U
/** invalid service from USER */
#define DPC31STACK_ABORT_DPT_USER                 0x15U
/** Send_Timeout requested too small */
#define DPC31STACK_ABORT_DPT_STO                  0x16U
/** invalid additional address info */
#define DPC31STACK_ABORT_DPT_ADDR                 0x17U
/** waiting for FDL_DATA_REPLY.con */
#define DPC31STACK_ABORT_DPT_OCON                 0x18U
/** resource error */
#define DPC31STACK_ABORT_DPT_RESS                 0x1FU
/** Layer7 protocol error */
#define DPC31STACK_ABORT_USER_PROT                0x2BU
/** invalid additional address info */
#define DPC31STACK_ABORT_USER_ADDR                0x2CU
/** valid user abort */
#define DPC31STACK_ABORT_USER_OK                  0x2DU
/** restart */
#define DPC31STACK_ABORT_USER_REST                0x2EU
/** resource error */
#define DPC31STACK_ABORT_USER_RESS                0x2FU
///  \}

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup dpc31StackResonCodeDefines Abort PDU reason code defines
///  \ingroup page_dpc31Stack_api_definitions
///
///  The following defines are used to specify the reason of an abort PDU.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** the baud rate is 12 MBaud */
#define DPC31STACK_BAUDRATE_12M                   0x00U
/** the baud rate is 6 MBaud */
#define DPC31STACK_BAUDRATE_6M                    0x01U
/** the baud rate is 3 MBaud */
#define DPC31STACK_BAUDRATE_3M                    0x02U
/** the baud rate is 1,5 MBaud */
#define DPC31STACK_BAUDRATE_1_5M                  0x03U
/** the baud rate is 500 kBaud */
#define DPC31STACK_BAUDRATE_500k                  0x04U
/** the baud rate is 187,5 kBaud */
#define DPC31STACK_BAUDRATE_187_5k                0x05U
/** the baud rate is 93,75 kBaud */
#define DPC31STACK_BAUDRATE_93_75k                0x06U
/** the baud rate is 45,45 kBaud */
#define DPC31STACK_BAUDRATE_45_45k                0x07U
/** the baud rate is 19,2 kBaud */
#define DPC31STACK_BAUDRATE_19_2k                 0x08U
/** the baud rate is 9,6 kBaud */
#define DPC31STACK_BAUDRATE_9_6k                  0x09U
/** the baud rate is invalid */
#define DPC31STACK_BAUDRATE_INVALID               0xFFU
///  \}

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup dpc31StackDxchDefines Process data exchange state defines
///  \ingroup page_dpc31Stack_api_definitions
///
///  The following defines are used to specify process data exchange state.
///
///  \{
//----------------------------------------------------------------------------------------------------------------------
/** the process data exchange state is INVALID */
#define DPC31STACK_DP_STATE_INVALID               0x00U
/** the process data exchange state is OFF */
#define DPC31STACK_DP_STATE_OFF                   0x01U
/** the process data exchange state is NO_DATA_EX */
#define DPC31STACK_DP_STATE_NO_DATA_EX            0x02U
/** the process data exchange state is DATA_EX */
#define DPC31STACK_DP_STATE_DATA_EX               0x03U
///  \}

//----------------------------------------------------------------------------------------------------------------------
// Typedefs
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///
///  \defgroup page_dpc31Stack_api_data_types Data Types
///  \ingroup page_dpc31Stack_api
///
///  These are the data types of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackOutpPrcDataState_t enumeration describes the output process data state.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** the output process data is in an undefined state */
  DPC31STACK_OUTPUT_STATE_UNDEFINED   = 0x00,
  /** the output process image data are valid */
  DPC31STACK_OUTPUT_STATE_DATA        = 0x02,
  /** the output process image data has been changed */
  DPC31STACK_OUTPUT_STATE_NEW         = 0x04,
  /** the output process image data are in the CLEAR state */
  DPC31STACK_OUTPUT_STATE_CLEAR       = 0x08,
  /** information of the CLEAR state in the last 'Global Control' command */
  DPC31STACK_OUTPUT_STATE_GC_CLEAR    = 0x10,
  /** information of the UNCLEAR state in the last 'Global Control' command */
  DPC31STACK_OUTPUT_STATE_GC_UNCLEAR  = 0x20
}dpc31StackOutpPrcDataState_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackLedState_t enumeration describes the possible states of the DPC31 specific bus state LED.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /* switch the bus state LED off */
  DPC31STACK_LED_OFF    = 0x04,
  /* switch the bus state LED on */
  DPC31STACK_LED_ON     = 0x08,
  /* flash the bus state LED */
  DPC31STACK_LED_FLASH  = 0x0C
}dpc31StackLedState_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackC0WdState_t structure describes the possible states of the C0 watchdog.
//----------------------------------------------------------------------------------------------------------------------
typedef enum
{
  /** the watchdog is deactivated */
  DPC31STACK_C0_WD_STATE_OFF           = 0x00,
  /** the watchdog is in the baudrate search mode */
  DPC31STACK_C0_WD_STATE_BAUD_SEARCH   = 0x40,
  /** the watchdog is in the baudrate monitoring mode */
  DPC31STACK_C0_WD_STATE_BAUD_CONTROL  = 0x80,
  /** the watchdog is in the DP mode; that means the DP data traffic with the parameterization master is monitored */
  DPC31STACK_C0_WD_STATE_DP_MODE       = 0xC0
}dpc31StackC0WdState_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackAlarmData_t structure describes the alarm data (see "V1SL_STRUC_ALARM").
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
  /** internal used pointer */
  const void* pInfoPtr1;
  /** internal used pointer */
  const void* pInfoPtr2;
  /** alarm type */
  uint8_t alarm_type;
  /** slot number */
  uint8_t slot_number;
  /** alarm specifier */
  uint8_t specifier;
  /** length of the user data */
  uint8_t user_data_len;
  /** pointer to the user data */
  void* user_data_ptr;
} dpc31StackAlarmData_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref alarmRelState_t structure describes the release states of the PROFIBUS alarm types.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
  /** update alarm release state */
  bool bUpdateAlarm;
  /** status alarms release state */
  bool bStatusAlarm;
  /** manufacturer alarm release state */
  bool bManufAlarm;
  /** diagnostic alarm release state */
  bool bDiagAlarm;
  /** process alarm release state */
  bool bProcAlarm;
  /** pull/plug alarm release state */
  bool bPullPlugAlarm;
}alarmRelState_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackPrmTgmInfo_t structure describes PROFIBUS parameter telegram information.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
  /** parameter telegram data buffer */
  uint8_t aucData[244];
  /** length of the parameter telegram */
  uint32_t ulDataLen;
  /** identification number of the parameter telegram */
  uint32_t ulDataId;
  /** change state of the parameter telegram data */
  bool bChanged;
} dpc31StackPrmTgmInfo_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackCfgTgmInfo_t structure describes PROFIBUS configuration telegram information.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
  /** configuration telegram data buffer */
    uint8_t aucData[244];
  /** length of the configuration telegram */
  uint32_t ulDataLen;
  /** identification number of the configuration telegram */
  uint32_t ulDataId;
  /** request of the application ready event */
  bool bApplReadyReq;
  /** state of the configuration difference allowed release */
  bool bCfgDiffAllowed;
  /** change state of the parameter telegram data */
  bool bChanged;
} dpc31StackCfgTgmInfo_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref pbcSettings_t structure describes the setting for the PROFIBUS controller.
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function will be called to report a serious error in the PROFIBUS stack.
///
///  \param   ulModule          name of the source code file where the error has been occurred
///  \param   ulLine            line in the source code file where the error has been occurred
///  \param   ulDetailIdent     detailed identification number of the error
///  \param   pHandle           user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*fatalError_t) (uint32_t ulModule, uint32_t ulLine, uint32_t ulDetailIdent, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates the activation or deactivation of the alarm state machine as well as the permissible
///   alarm types and the supported alarm queue.
///
///  \param   pstAlarmRelState      pointer to the alarm release state structure
///  \param   ucSequenceDepth       alarm sequence depth
///  \param   pHandle               user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*alarmStateReport_t) (alarmRelState_t* pstAlarmRelState, uint8_t ucSeqDepth, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges an alarm that was set previously.
///
///  \param   pstAlarmData          pointer to the alarm data transfered to V1SL
///  \param   pHandle               user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*alarmAck_t) (dpc31StackAlarmData_t* pstAlarmData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates that the DP process data exchange is active.
///
///  \param   pHandle               user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0DataExchangeActive_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates the return of the diagnostic buffer that was previously transferred with the input
///   function v1sl_c0_set_diag.
///
///  \param   pData           transferred diagnostic buffer pointer
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0DiagChanged_t) (void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates that the parameterization master fetched a previously set diagnostic information.
///
///  \param   pData           transferred diagnostic buffer pointer
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0DiagFetched_t) (void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates that the DP slave state has changed.
///
///  \param   ucState         current DP slave state
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0DpStateReport_t) (uint_t ulState, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates changes of the bus error LED state.
///
///  \param   ucState         current bus error LED state
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0LedStateReport_t) (dpc31StackLedState_t enmLedState, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function reports the receiving of new parameterization data.
///
///  \param   ulPrmId         identification number of the parameterization data
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0NewPrm_t) (uint32_t ulPrmId, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function reports the receiving of new configuration data.
///
///  \param   ulCfgId         identification number of the configuration data
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0ChkCfg_t) (uint32_t ulCfgId, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates the receiving of the control command CLEAR or UNCLEAR from the parameterization master.
///
///  \param   ucState         CLEAR state
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0Clear_t) (uint8_t ucState, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates the receiving of the control command SYNC or UNSYNC from the parameterization master.
///
///  \param   ucState         SYNC state
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0Sync_t) (uint8_t ucState, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates the receiving of the control command FREEZE or UNFREEZE from the parameterization master.
///
///  \param   ucState         FREEZE state
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0Freeze_t) (uint8_t ucState, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates the receipt of a new 'Set Slave Address' telegram.
///
///  \param   pData           pointer to the telegram data
///  \param   ulDataLen       length of the telegram data
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0NewSsa_t) (void* pData, uint_t ulDataLen, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges an opened C0 communication channel.
///
///  \param   ucReturnValue   status value of the opening process
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0OpenChannelDone_t) (uint32_t ucReturnValue, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges a closed C0 communication channel.
///
///  \param   ucReturnValue   status value of the closing process
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0CloseChannelDone_t) (uint32_t ucReturnValue, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges an finished withdraw process of the C0 channel.
///
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0WithdrawDone_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates that the DP watchdog has expired.
///
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0DpWdTimeout_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function signals that a new buffer for expected configuration data is available.
///
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0RealCfgBufferChanged_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates changes of the DP watchdog state.
///
///  \param   ucState         current DP watchdog state
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c0WatchDogStateReport_t) (dpc31StackC0WdState_t enmC0WdState, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function transfers the request for reading a data set.
///
///  \param   pData           pointer to the Read-REQ-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c1ReadDs_t) (void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function transfers the request for writing a data set.
///
///  \param   pData           pointer to the Write-REQ-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c1WriteDs_t) (void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function requests a connection establishment from the C2 firmware user.
///
///  \param   ulConId         reference of connection whose establishment was requested
///  \param   pData           pointer to Initiate-REQ-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2Initiate_t) (uint32_t ulConId, void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function informs the C2 firmware user of the shut down of the connection identified.
///
///  \param   ulConId         connection reference
///  \param   pData           pointer to the Abort-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2Abort_t) (uint32_t ulConId, void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges the input function v1sl_c2_close_channel().
///
///  \param   ucReturnVal     result of the channel closing
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2CloseChannelDone_t) (uint32_t ulReturnVal, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function transfers a Data_Transport-REQ-PDU to the user.
///
///  \param   ucConId         connection reference
///  \param   pData           pointer to the Data_Transport-REQ-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2DataTransport_t) (uint32_t ulConId, void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges the input function v1sl_c2_open_channel().
///
///  \param   ucReturnVal     result of the channel opening.
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2OpenChannelDone_t) (uint32_t ulReturnVal, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function transfers the request for reading a data set.
///
///  \param   ucConId         connection reference
///  \param   pData           pointer to the Read-REQ-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2ReadDs_t) (uint32_t ulConId, void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function acknowledges a connection shut down previously initiated by the user.
///
///  \param   ucConId         connection reference
///  \param   ucReturnVal     result of the connection abort
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2UserAbortDone_t) (uint32_t ulConId, uint8_t ucReturnVal, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function transfers the request for writing a data set to the user.
///
///  \param   ulConId         connection reference
///  \param   pData           pointer to the Write-REQ-PDU
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*c2WriteDs_t) (uint32_t ulConId, void* pData, handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates new fieldbus output process data.
///
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*pbcDxchIsr_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates new fieldbus SYNC event.
///
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*pbcSyncIsr_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
///  This function indicates a hardware reset request of the DPC31.
///
///  \param   pHandle         user defined handle
//----------------------------------------------------------------------------------------------------------------------
typedef void (*pbcReset_t) (handle_t pHandle);

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref cbFncSettings_t structure describes the settings of the callback functions.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** user defined handle to identify the callback function call */
    handle_t pHandle;
    /** for detailed description see the corresponding type definition \ref fatalError_t */
    fatalError_t pfFatalError;
    /** for detailed description see the corresponding type definition \ref alarmStateReport_t */
    alarmStateReport_t pfAlarmStateReport;
    /** for detailed description see the corresponding type definition \ref alarmAck_t */
    alarmAck_t pfAlarmAck;
    /** for detailed description see the corresponding type definition \ref c0DataExchangeActive_t */
    c0DataExchangeActive_t pfC0DataExchangeActive;
    /** for detailed description see the corresponding type definition \ref c0DiagChanged_t */
    c0DiagChanged_t pfC0DiagChanged;
    /** for detailed description see the corresponding type definition \ref c0DiagFetched_t */
    c0DiagFetched_t pfC0DiagFetched;
    /** for detailed description see the corresponding type definition \ref c0DpStateReport_t */
    c0DpStateReport_t pfC0DpStateReport;
    /** for detailed description see the corresponding type definition \ref c0LedStateReport_t */
    c0LedStateReport_t pfC0LedStateReport;
    /** for detailed description see the corresponding type definition \ref c0ChkCfg_t */
    c0ChkCfg_t pfC0ChkCfg;
    /** for detailed description see the corresponding type definition \ref c0Clear_t */
    c0Clear_t pfC0Clear;
    /** for detailed description see the corresponding type definition \ref c0Sync_t */
    c0Sync_t pfC0Sync;
    /** for detailed description see the corresponding type definition \ref c0Freeze_t */
    c0Freeze_t pfC0Freeze;
    /** for detailed description see the corresponding type definition \ref c0NewPrm_t */
    c0NewPrm_t pfC0NewPrm;
    /** for detailed description see the corresponding type definition \ref c0NewSsa_t */
    c0NewSsa_t pfC0NewSsa;
    /** for detailed description see the corresponding type definition \ref c0OpenChannelDone_t */
    c0OpenChannelDone_t pfC0OpenChannelDone;
    /** for detailed description see the corresponding type definition \ref c0CloseChannelDone_t */
    c0CloseChannelDone_t pfC0CloseChannelDone;
    /** for detailed description see the corresponding type definition \ref c0WithdrawDone_t */
    c0WithdrawDone_t pfC0WithdrawDone;
    /** for detailed description see the corresponding type definition \ref c0DpWdTimeout_t */
    c0DpWdTimeout_t pfC0DpWdTimeout;
    /** for detailed description see the corresponding type definition \ref c0RealCfgBufferChanged_t */
    c0RealCfgBufferChanged_t pfC0RealCfgBufferChanged;
    /** for detailed description see the corresponding type definition \ref c0WatchDogStateReport_t */
    c0WatchDogStateReport_t pfC0WatchDogStateReport;
    /** for detailed description see the corresponding type definition \ref c1ReadDs_t */
    c1ReadDs_t pfC1ReadDs;
    /** for detailed description see the corresponding type definition \ref c1WriteDs_t */
    c1WriteDs_t pfC1WriteDs;
    /** for detailed description see the corresponding type definition \ref c2Initiate_t */
    c2Initiate_t pfC2Initiate;
    /** for detailed description see the corresponding type definition \ref c2Abort_t */
    c2Abort_t pfC2Abort;
    /** for detailed description see the corresponding type definition \ref c2OpenChannelDone_t */
    c2OpenChannelDone_t pfC2OpenChannelDone;
    /** for detailed description see the corresponding type definition \ref c2CloseChannelDone_t */
    c2CloseChannelDone_t pfC2CloseChannelDone;
    /** for detailed description see the corresponding type definition \ref c2DataTransport_t */
    c2DataTransport_t pfC2DataTransport;
    /** for detailed description see the corresponding type definition \ref c2ReadDs_t */
    c2ReadDs_t pfC2ReadDs;
    /** for detailed description see the corresponding type definition \ref c2UserAbortDone_t */
    c2UserAbortDone_t pfC2UserAbortDone;
    /** for detailed description see the corresponding type definition \ref c2WriteDs_t */
    c2WriteDs_t pfC2WriteDs;
    /** for detailed description see the corresponding type definition \ref pbcDxchIsr_t */
    pbcDxchIsr_t pfPbcDxchIsr;
    /** for detailed description see the corresponding type definition \ref pbcSyncIsr_t */
    pbcSyncIsr_t pfpbcSyncIsr;
    /** for detailed description see the corresponding type definition \ref pbcReset_t */
    pbcReset_t pfpbcReset;
}cbFncSettings_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref pbcSettings_t structure describes the setting for the PROFIBUS controller.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** represents a time value, if the system does not trigger the user watchdog, the user watchdog will expire */
    uint16_t usPbcUserWdTimeoutMs;
}pbcSettings_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref c2Settings_t structure describes the setting for the PROFIBUS C2 channel.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
  /** number of C2 connections that can be utilized parallel via the communication channel */
  uint8_t ucConnectCount;
  /** maximum size of a data PDU buffer for C2 connections */
  uint32_t ulPduBufferSize;
  /** maximum length of the table, which defines the filters used for the subscriber functionality */
  uint8_t ucScFilterTableLen;
  /** length of link-buffer 0 */
  uint8_t ucScLink0Len;
  /** length of link-buffer 1 */
  uint8_t ucScLink1Len;
  /** length of link-buffer 2 */
  uint8_t ucScLink2Len;
  /** length of link-buffer 3 */
  uint8_t ucScLink3Len;
  /** length of link-buffer 4 */
  uint8_t ucScLink4Len;
  /** length of link-buffer 5 */
  uint8_t ucScLink5Len;
  /** length of link-buffer 6 */
  uint8_t ucScLink6Len;
  /** length of link-buffer 7 */
  uint8_t ucScLink7Len;
  /** maximum time stamp PDU data length */
  uint8_t ucTmPduSize;
}c2Settings_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref c1Settings_t structure describes the setting for the PROFIBUS C1 channel.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** alarm sequence mode configuration */
    uint8_t ucAlUserSequenceMode;
    /** maximum C1 PDU telegram data length */
    uint8_t ucC1PduBufferLen;
}c1Settings_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref c0Settings_t structure describes the setting for the PROFIBUS C0 channel.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** PROFIBUS station address  */
    uint8_t ucMacAddr;
    /** PNO identification number */
    uint16_t usPnoIdentNumber;
    /** release state of the FREEZE functionality */
    bool bFreezeReleased;
    /** release state of the SYNC functionality */
    bool bSyncReleased;
    /** release state of the Set-Slave-Address (SSA) functionality */
    bool bSsaReleased;
    /** maximum PROFIBUS parameterization telegram data length */
    uint32_t ulPrmBufferLen;
    /** maximum PROFIBUS configuration telegram data length */
    uint32_t ulCfgBufferLen;
    /** maximum fieldbus input process image data length */
    uint32_t ulInputBufferLen;
    /** maximum fieldbus output process image data length */
    uint32_t ulOutputBufferLen;
    /** maximum SSA telegram data length */
    uint32_t ulSsaBufferLen;
    /** maximum user diagnostics telegram data length */
    uint32_t ulUserDiagBufferLen;
}c0Settings_t;

//----------------------------------------------------------------------------------------------------------------------
/// \ingroup page_dpc31Stack_api_data_types
///
/// The \ref dpc31StackSettings_t structure describes the DPC31 Stack component settings.
//----------------------------------------------------------------------------------------------------------------------
typedef struct
{
    /** settings of the C0 channel */
    c0Settings_t stC0;
    /** settings of the C1 channel */
    c1Settings_t stC1;
    /** settings of the C2 channel */
    c2Settings_t stC2;
    /** registration of the callback functions */
    cbFncSettings_t stCbFnc;
    /** PROFIBUS controller settings */
    pbcSettings_t stPbc;
} dpc31StackPbcSettings_t;

//----------------------------------------------------------------------------------------------------------------------
// Global Variables
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
// Function prototypes
//----------------------------------------------------------------------------------------------------------------------

//----------------------------------------------------------------------------------------------------------------------
///  \defgroup page_dpc31Stack_api_functions Functions
///  \ingroup page_dpc31Stack_api
///
///   These are the functions of this module.
///
//----------------------------------------------------------------------------------------------------------------------

//-- Function: dpc31Stack_OpenPbc --------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
/// This function opens the connection to a PROFIBUS controller (PBC) specified by the pointer to the communication
///  memory of the PBC. It is necessary to perform a hardware reset of the PBC previously. In addition an instance
///  of the internal V1SL firmware is set up for the PBC. For further usage of the stack functionality the user have
///  to use the PBC handle which is returned by this function. This function also sets up the hardware properties
///  of the PBC like the interrupt polarization.
///  The internally used V1SL functions are: 'pbc_open_device'
///
///  \param   pstDpc31StackPbcSettings        PROFIBUS controller settings
///  \param   pDpc31Memory                    pointer to the communication memory of the DPC31
///  \param   pPbcHdl                         pointer where the PBC handle should be stored
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_OpenPbc (const dpc31StackPbcSettings_t* const pstDpc31StackPbcSettings,
                             void* pDpc31Memory,
                             handle_t pPbcHdl);

//-- Function: dpc31Stack_ClosePbc -------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
/// This function closes the connection to the PROFIBUS controller (PBC) specified by the PBC handle.
///  The internally used V1SL functions are: 'pbc_close_device'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_ClosePbc (handle_t pPbcHdl);

//-- Function: dpc31Stack_AlSetAlarm -----------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, V1SL accepts the transferred alarm data. In addition to the net
///   data, the alarm data also includes control information according to the DPV1
///   specification . The data is transmitted at the next possible time, as changeable
///   (dynamic) part of the diagnostic message.
///   The internally used V1SL functions are: 'v1sl_al_set_alarm'
///
///  \param   pstAlarmData    pointer to the alarm information structure
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_AlSetAlarm (dpc31StackAlarmData_t* pstAlarmData, handle_t pPbcHdl);

//-- Function: dpc31Stack_AlWithdrawAlarm ------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  With this call, the stack returns the alarms that were previously set by the user.
///  The internally used V1SL functions are: 'v1sl_al_withdraw_alarm'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_AlWithdrawAlarm (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0Withdraw -----------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the memory resources of a C0 slave instance are released.
///  The internally used V1SL functions are: 'v1sl_c0_withdraw'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0Withdraw (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0CloseChannel -------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function closes the communication channel.
///  The internally used V1SL functions are: 'v1sl_c0_close_channel'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0CloseChannel (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetInputPiData -----------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns a pointer to the current output data buffer of the
///   parameterization master. In addition, the function provides information about the status
///   of the data in this buffer, and about the general conditions that may be important to the
///   evaluation of the data:
///   • The length of the data buffer has is or is not equal to 0
///   • The data buffer contains new data that the user has not processed yet
///   • The data buffer contains data that was deleted
///   • Information on a currently received global control telegram
///  The internally used V1SL functions are: 'v1sl_c0_get_output_info'
///
///  \param   ppData         pointer to the pointer where the data location should be stored
///  \param   penmState      current state of the fieldbus output process image data
///  \param   pPbcHdl        PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
///
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetOutputPiData (void** ppData,
                                       dpc31StackOutpPrcDataState_t* penmState,
                                       handle_t pPbcHdl);

//-- Function: dpc31Stack_C0LeaveMaster --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function resets an active slave into the DP mode "DP_STATE_NO_DATA_EX" (for example,
///   if the configuration changes). With it, the slave requests
///   reparameterization by the master. The call is possible only in the DP mode "DP_STATE_NO_DATA_EX" or
///   "DP_STATE_DATA_EX".
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_LEAVE_MASTER)'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0LeaveMaster (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0OpenChannel --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function opens the C0 channel.
///  The internally used V1SL functions are: 'v1sl_c0_open_channel'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0OpenChannel (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetRealCfgPtr ------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user receives a pointer to the expected configuration data
///   buffer. Then, the user can copy the expected configuration data to the memory area referenced by the pointer.
///   The internally used V1SL functions are: 'v1sl_c0_get_real_cfg_ptr'
///
///  \param   ppRealCfgPtr      pointer to the memory where the real configuration buffer pointer should be stored
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetRealCfgPtr (void** ppRealCfgPtr,
                                     handle_t pPbcHdl);

//-- Function: dpc31Stack_C0RealCfgUpdate ------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functionse
///
///  By calling this function, the user’s current expected configuration is routed to the layer
///   below (PBC driver). After that, the parameterization master or a Class 2 master can read the expected
///   configuration data.
///   The internally used V1SL functions are: 'v1sl_c0_real_cfg_update'
///
///  \param   ulRealCfgDataLen  length of expected configuration data (in bytes)
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0RealCfgUpdate (uint32_t ulRealCfgDataLen,
                                     handle_t pPbcHdl);

//-- Function: dpc31Stack_C0Start --------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the slave goes from the DP mode V1SL_DP_STATE_OFF to the DP mode
///   V1SL_DP_STATE_NO_DATA_EX and can then be parameterized by a master.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_START)'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0Start (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0Stop ---------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, With this command, the slave enters the DP mode V1SL_DP_STATE_OFF and
///   after that, can’t be parameterized by any master.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_STOP)'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0Stop (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetSsaDone ---------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function informs the slave that processing a 'Set Slave Address' telegram is completed.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_SSA_DONE)'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetSsaDone (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetAppReady --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functionsy
///
///  This function informs the slave that the application is ready to receive process data.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_APP_READY)'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetAppReady (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetCfgData ---------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns the PROFIBUS configuration telegram information structure specified by the
///   identification number.
///
///  \param   ulReqCfgId        identification number of the configuration telegram
///  \param   pstCfgTgmInfo     return pointer to the configuration telegram information structure
///  \param   pPbcHdl           PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetCfgData (uint32_t ulReqCfgId,
                                  dpc31StackCfgTgmInfo_t* pstCfgTgmInfo,
                                  handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetCfgDataChangedState ---------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functionse
///
///  This function returns the data change state of the configuration data specified by the identification number.
///
///  \param   ulCfgId             identification number of the configuration data
///  \param   bPbCfgDataChanged   return pointer for the data change state
///  \param   pPbcHdl             PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetCfgDataChangedState (uint32_t ulReqCfgId,
                                              bool* bPbCfgDataChanged,
                                              handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetCfgValid --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function informs the slave of the successful comparison of received configuration data sent by the
///   master with its expected configuration. The configuration telegram data are specified by the identification
///   number. The valid state can only be set of the current configuration data telegram.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_CFG_OK)'
///
///  \param   ulCfgId         identification number of the configuration data to be set valid
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetCfgValid (uint32_t ulCfgId, handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetCfgInvalid ------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function rejects a wrong configuration data sent by the master message. The configuration telegram data
///   are specified by the identification number. The error state can only be set of the current
///   configuration data telegram.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_CFG_ERROR)'
///
///  \param   ulCfgId         identification number of the configuration data to be set invalid
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetCfgInvalid (uint32_t ulCfgId, handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetCfgUpdate -------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function informs the slave of the successful comparison of received configuration data sent by the
///   master with its expected configuration. Also the new configuration data sent by the master will
///   be available for other stations as the expected configuration of the slave from now on.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_CFG_UPDATE)'
///
///  \param   ulCfgId         identification number of the configuration data to be updated
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetCfgUpdate (uint32_t ulCfgId, handle_t pPbcHdl);

//-- Function: dpc31Stack_GetCurCfgId ----------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns the indentification number of the currently pending PROFIBUS configuration telegram data.
///
///  \param   pulCfgId        pointer to the value where the identification number should be stored
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns @ref DPC31STACK_SUCCESS on success. Another value such like
///            @ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_GetCurCfgId (uint32_t* pulCfgId, handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetDiag ------------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user provides diagnostic data to the slave. The diagnostic
///   data is sent at the next possible time as a static part with each diagnostic telegram.
///   The internally used V1SL functions are: 'v1sl_c0_set_diag'
///
///  \param   pData           pointer to the diagnostic data
///  \param   ulDataLen       length of the diagnostic data
///  \param   bExtDiag        state of the extended diagnostic flag
///  \param   bSendWithAlarm  send the diagnostic only with an alarm
///  \param   bDiagOvf        state of the diagnostic overflow flag
///  \param   pBufferHdl      user specified buffer handle
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetDiag (void* pData,
                               uint32_t ulDataLen,
                               bool bExtDiag,
                               bool bSendWithAlarm,
                               bool bDiagOvf,
                               void* pBufferHdl,
                               handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetOutputPiData ----------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function routes the fieldbus input process data specified by the user to the fieldbus.
///   The internally used V1SL functions are: 'v1sl_c0_get_input_ptr, v1sl_c0_input_update'
///
///  \param   pData           pointer to the process image data
///  \param   ulDataLen       length of the process image data
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetInputPiData (const void* const pData,
                                      uint32_t ulDataLen,
                                      handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetInputPiDataPtr --------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns the pointer to the fieldbus input process image data buffer.
///   The internally used V1SL functions are: 'v1sl_c0_get_input_ptr'
///
///  \param   ppInpPiDataBuf  pointer to the pointer where the buffer memory address should be stored
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetInputPiDataPtr (void** ppInpPiDataBuf,
                                         handle_t pPbcHdl);

//-- Function: dpc31Stack_C0UpdateInputPiData --------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function updates the fieldbus input process image data specified by the user by calling the function
///   \ref dpc31Stack_C0GetInputPiDataPtr.
///   The internally used V1SL functions are: 'v1sl_c0_input_update'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0UpdateInputPiData (handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetPrmData ---------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns the currently pending PROFIBUS parameter telegram data specified by the identification
///   number.
///
///  \param   ulReqPrmId        identification number of the requested PROFIBUS parameter data
///  \param   pstPrmTgmInfo     pointer to the structure where the requested telegram information should be stored
///  \param   pPbcHdl           PBC handle
///
///  \return  The routine returns @ref DPC31STACK_SUCCESS on success. Another value such like
///            @ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetPrmData (uint32_t ulReqPrmId,
                                  dpc31StackPrmTgmInfo_t* pstPrmTgmInfo,
                                  handle_t pPbcHdl);

//-- Function: dpc31Stack_C0GetPrmDataChangedState ---------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns the change state of the specified PROFIBUS parameter telegram data.
///
///  \param   ulReqPrmId          identification number of the requested PROFIBUS parameter data
///  \param   pbPbPrmDataChanged  pointer to the value where the change state should be stored
///  \param   pPbcHdl             PBC handle
///
///  \return  The routine returns @ref DPC31STACK_SUCCESS on success. Another value such like
///            @ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0GetPrmDataChangedState (uint32_t ulReqPrmId,
                                              bool* pbPbPrmDataChanged,
                                              handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetPrmValid --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function sets the status of the PROFIBUS parameter telegram data specified by the parameter identification
///   valid.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_PRM_OK)'
///
///  \param   ulPrmId             identification number of the processed PROFIBUS parameter data
///  \param   pPbcHdl             PBC handle
///
///  \return  The routine returns @ref DPC31STACK_SUCCESS on success. Another value such like
///            @ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetPrmValid (uint32_t ulPrmId,
                                   handle_t pPbcHdl);

//-- Function: dpc31Stack_C0SetPrmInvalid ------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function sets the status of the PROFIBUS parameter telegram data specified by the parameter identification
///   invalid.
///   The internally used V1SL functions are: 'v1sl_c0_control(V1SL_CONTROL_PRM_ERROR)'
///
///  \param   ulPrmId             identification number of the processed PROFIBUS parameter data
///  \param   pPbcHdl             PBC handle
///
///  \return  The routine returns @ref DPC31STACK_SUCCESS on success. Another value such like
///            @ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C0SetPrmInvalid (uint32_t ulPrmId,
                                     handle_t pPbcHdl);

//-- Function: dpc31Stack_GetCurPrmId ----------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function returns the indentification number of the currently pending PROFIBUS parameter telegram data.
///
///  \param   pulPrmId            pointer to the value where the identification number should be stored
///  \param   pPbcHdl             PBC handle
///
///  \return  The routine returns @ref DPC31STACK_SUCCESS on success. Another value such like
///            @ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_GetCurPrmId (uint32_t* pulPrmId,
                                 handle_t pPbcHdl);

//-- Function: dpc31Stack_C2CloseChannel -------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function closes the channel of the C2 connection.
///   The internally used V1SL functions are: 'v1sl_c2_close_channel'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2CloseChannel (handle_t pPbcHdl);

//-- Function: dpc31Stack_C2DataTransportDone --------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user signals to the slave that a previously requested ‘Data Transport’ service
///   has been completed.
///   The internally used V1SL functions are: 'v1sl_c2_data_transport_done'
///
///  \param   ucConId         reference of the connection used for the data transport
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2DataTransportDone (uint8_t ucConId,
                                         handle_t pPbcHdl);

//-- Function: dpc31Stack_C2InitiateDone -------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user responds to a connection establishment request.
///   The internally used V1SL functions are: 'v1sl_c2_initiate_done'
///
///  \param   ucConId         reference of the connection whose establishment was requested
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2InitiateDone (uint8_t ucConId,
                                    handle_t pPbcHdl);

//-- Function: dpc31Stack_C2OpenChannel --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user opens a communication channel to the C2 firmware.
///   The internally used V1SL functions are: 'v1sl_c2_open_channel'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2OpenChannel (handle_t pPbcHdl);

//-- Function: dpc31Stack_C2ReadDsDone ---------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user signals to the slave that the previously requested
///   service 'Read Data Set' is completed.
///   The internally used V1SL functions are: 'v1sl_c2_read_ds_done'
///
///  \param   ucConId      reference of the connection used for reading the data set.
///  \param   pPbcHdl      PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2ReadDsDone (uint8_t ucConId,
                                  handle_t pPbcHdl);

//-- Function: dpc31Stack_C2UserAbort ----------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user can initiate the shut down of a connection, regardless
///   of whether a request PDU that needs to be answered is present at the user.
///   The internally used V1SL functions are: 'v1sl_c2_user_abort'
///
///  \param   ucConId         reference of the connection to be canceled
///  \param   ucSubNet        identifies location of the connection shut down
///  \param   ucReason        cause for connection shut down
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2UserAbort (uint8_t ucConId,
                                 uint8_t ucSubNet,
                                 uint8_t ucReason,
                                 handle_t pPbcHdl);

//-- Function: dpc31Stack_C2WriteDsDone --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user signals to the slave that the previously requested
///   service 'Write Data Set' is completed.
///   The internally used V1SL functions are: 'v1sl_c2_write_ds_done'
///
///  \param   ucConId         reference of the connection used for writing the data set
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C2WriteDsDone (uint8_t ucConId,
                                   handle_t pPbcHdl);

//-- Function: dpc31Stack_PbcGetBaudrate -------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the system environment can determine the current baudrate on the bus.
///   The internally used V1SL functions are: 'pbc_get_baudrate'
///
///  \param   pucBaudRate     pointer to the memory where the current baudrate should be stored
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_PbcGetBaudrate (uint8_t* pucBaudRate,
                                    handle_t pPbcHdl);

//-- Function: dpc31Stack_PbcGetWdState --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the system environment determines the current state of the
///   'Baud Control Timer'.
///   The internally used V1SL functions are: 'pbc_get_wd_state'
///
///  \param   pucGetWdState   pointer to the memory where the current watchdog state should be stored
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_PbcGetWdState (uint8_t* pucGetWdState,
                                   handle_t pPbcHdl);

//-- Function: dpc31Stack_PbcEventsIrqHandler --------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function indicates new DPC31 events and processes them.
///   The internally used V1SL functions are: 'pbc_dpc31_int_handler'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
void dpc31Stack_PbcEventsIrqHandler (handle_t pPbcHdl);

//-- Function: dpc31Stack_PbcDxchEventIrqHandler -----------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function processes the data exchange event of the DPC31.
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
void dpc31Stack_PbcDxchEventIrqHandler (handle_t pPbcHdl);

//-- Function: dpc31Stack_PbcSyncEventIrqHandler -----------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function processes the SYNC event of the DPC31.
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
void dpc31Stack_PbcSyncEventIrqHandler (handle_t pPbcHdl);

//-- Function: dpc31Stack_TriggerWatchdog ------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  This function triggers the user watchdog of the DPC31.
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_TriggerWatchdog (handle_t pPbcHdl);

//-- Function: dpc31Stack_C1ReadDsDone -----------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user signals to the slave that a previously requested 'Read
///   Data Set' service is completed.
///   The internally used V1SL functions are: 'v1sl_c1_read_ds_done'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C1ReadDsDone (handle_t pPbcHdl);

//-- Function: dpc31Stack_C1WriteDsDone --------------------------------------------------------------------------------
///  \ingroup page_dpc31Stack_api_functions
///
///  By calling this function, the user signals to the slave that a ‘Write Data Set’ service that was
///   called previously is completed.
///   The internally used V1SL functions are: 'v1sl_c1_write_ds_done'
///
///  \param   pPbcHdl         PBC handle
///
///  \return  The routine returns \ref DPC31STACK_SUCCESS on success. Another value such like
///            \ref DPC31STACK_ERROR_NULL_POINTER indicates failure.
//----------------------------------------------------------------------------------------------------------------------
status_t dpc31Stack_C1WriteDsDone (handle_t pPbcHdl);

#endif
//---- End of header ---------------------------------------------------------------------------------------------------
