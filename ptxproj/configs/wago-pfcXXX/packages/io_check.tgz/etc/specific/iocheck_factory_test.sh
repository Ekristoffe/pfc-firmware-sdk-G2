#!/bin/bash
export PATH=$PATH:/usr/sbin

#set -x

# load general definitions and functions
. /etc/config-tools/config_tool_lib

stop_service()
{
  PROCESS_NAME="$1"
  INIT_SCRIPT="$2"
  TIMEOUT="$3"
  COUNTER="0"

  if [ -n "$(pidof ${PROCESS_NAME})" ]; then
    echo "${PROCESS_NAME} stopping..."
    if [ -e $INIT_SCRIPT ]; then
      $INIT_SCRIPT stop &> /dev/null
    else
      killall -SIGTERM $PROCESS_NAME &> /dev/null
    fi
    while [ -n "$(pidof ${NAME})" ]
      do
        if [ $COUNTER -eq $TIMEOUT ]; then
            echo "Unable to shutdown ${PROCESS_NAME}. Send SIGKILL..."
            killall -9 $PROCESS_NAME &> /dev/null
            break
        fi
        sleep 1
        COUNTER=$[ $COUNTER+1 ]
    done
  fi
}

# get pfc name:  PFC100 / PFC200
targetName=$(GetTargetName)

serial_dev_name=/dev/serial

#get devconf for device-specific testing
DEVCONF=$(/etc/config-tools/get_typelabel_value DEVCONF)

if [ $1 = "--testmode_start" ]; then
if [ -z "$(pidof dalshell)" ]; then
  echo starting testmode

  stop_service "pure-ftpd" "" "10"
  stop_service "plclinux_rt" "/etc/init.d/runtime" "30"
  stop_service "codesys3" "/etc/init.d/runtime" "30"
  stop_service "ledserverd" "/etc/init.d/ledserver" "10"
  stop_service "omsd" "/etc/init.d/omsdaemon" "10"

  case "$DEVCONF" in
  0x0028 | 0x0008 | 0x1007 | 0x1004 | 0x100A)
    ln -sf /etc/specific/pfc_batch_process.conf.0x0008 /etc/specific/pfc_batch_process.conf
    sleep 2
    ;;
  0x000A | 0x0182)
    ln -sf /etc/specific/pfc_batch_process.conf.0x000A /etc/specific/pfc_batch_process.conf
    sleep 2
    ;;
  0x000E)
    ln -sf /etc/specific/pfc_batch_process.conf.0x000E /etc/specific/pfc_batch_process.conf
    sleep 2
    ;;
  0x000C | 0x001C | 0x1006 | 0x100B)
    ln -sf /etc/specific/pfc_batch_process.conf.0x000C /etc/specific/pfc_batch_process.conf
    ;;
  0x000F)
    ln -sf /etc/specific/pfc_batch_process.conf.0x000F /etc/specific/pfc_batch_process.conf
    ;;
  0x004E)
    ln -sf /etc/specific/pfc_batch_process.conf.0x004E /etc/specific/pfc_batch_process.conf
    ;;
  0x100C)
    ln -sf /etc/specific/pfc_batch_process.conf.0x100C /etc/specific/pfc_batch_process.conf
    ;;
  esac

  # wait for getty
  let loop_cntr=0
  while [[ (-z $(fuser -k -STOP "$serial_dev_name")) && ($loop_cntr -lt 5) ]]; do
    let loop_cntr=$loop_cntr+1
    sleep 1
  done
  killall -SIGSTOP getty
  if [[ "$DEVCONF" != 0x100C ]]; then # PFC300(0x100C) is RS485 only
    /etc/config-tools/config_serial_interface -s mode=rs232
  fi

  # Target specific step for devices with SFP board
  # NOTE: This can be removed once the linux kernel is enabled to update the SFP board on its own
  if [[ "$DEVCONF" == 0x1004 ]]; then
    # Flash SFP co-processor firmware on 8211
    /etc/specific/sfp-flash /dev/ttyO1 /etc/specific/sfp.fw
  fi

  /usr/sbin/pure-ftpd -g /var/run/pure-ftpd.pid -C 10 -E &
  /usr/sbin/dalshell $1 $targetName $DEVCONF
else
  echo testmode is already started
fi
elif [ $1 = "--testmode_stop" ]; then

  echo stopping testmode

  stop_service "pure-ftpd" "" "10"
  stop_service "dalshell" "" "10"

  if [ "$DEVCONF" == "0x000C" ] || [ "$DEVCONF" == "0x001C" ] || [ "$DEVCONF" != "0x000F" ] || [ "$DEVCONF" != "0x004E" ]; then
    fuser -k -CONT "$serial_dev_name"
  fi

  echo start omsdaemon
  /etc/init.d/omsdaemon start &> /dev/null
  echo start ledserver
  /etc/init.d/ledserver start &> /dev/null
  echo start codesys
  /etc/init.d/runtime start &> /dev/null
fi
