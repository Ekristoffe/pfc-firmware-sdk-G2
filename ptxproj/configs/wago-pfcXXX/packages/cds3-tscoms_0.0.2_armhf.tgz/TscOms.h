//------------------------------------------------------------------------------
// Copyright (c) WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All
// manufacturing, reproduction, use and sales rights pertaining to this
// subject matter are governed by the license agreement. The recipient of this
// software implicitly accepts the terms of the license.
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///  \file     TscOms.h
///
///  \version  $Id$
///
///  \brief    <short description of the file contents>
///
///  \author   <author> : WAGO GmbH & Co. KG
//------------------------------------------------------------------------------
#ifndef TSCOMS_H_
#define TSCOMS_H_

//------------------------------------------------------------------------------
// include files
//------------------------------------------------------------------------------
#include "CmpStd.h"
#include "CmpItf.h"

//------------------------------------------------------------------------------
// defines; structure, enumeration and type definitions
//------------------------------------------------------------------------------
#define WATCH_THREAD_NAME     RTS_TASKNAME_OMS_WATCH_THREAD
#define TASKPRIO_WATCH_THREAD RTS_TASKPRIO_OMS_WATCH_THREAD
#define DEV_EVENT_PATH           "/dev/input/oms_switch"
#define DEV_EVENT_PATH_FALLBACK  "/dev/input/event0"
#define DENY_APP_START        1
#define TASK_EXIT_TIMEOUT     200
#define STOP_SWITCH_ACTIVE    1

typedef struct stResetOptions
{
    RTS_UI16 resetCold;
    RTS_UI16 resetWarm;
}tResetOptions;

#ifndef CPLUSPLUS
  typedef struct
  {
    IBase Base;
    ICmpEventCallback EventCallback;
  } CTscOms;
#endif
//------------------------------------------------------------------------------
// function prototypes
//------------------------------------------------------------------------------
static RTS_RESULT OmsRegisterEvents(void);
static RTS_RESULT OmsUnregisterEvents(void);
static RTS_RESULT OmsCreateThread(void);
static RTS_RESULT OmsDestroyThread(void);
static RTS_RESULT OmsInitStateMaschine(void);
static void OmsThreadLoop(SYS_TASK_PARAM*);
static void OmsReset(void*);
static void OmsResetCold(void*);
static void OmsResetWarm(void*);
static void OmsStartAllApplications(void*);
static void OmsStopAllApplications(void*);

//------------------------------------------------------------------------------
// macros
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// variables' and constants' definitions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// function implementation
//------------------------------------------------------------------------------


#endif /* TSCOMS_H_ */
//---- End of source file ------------------------------------------------------
