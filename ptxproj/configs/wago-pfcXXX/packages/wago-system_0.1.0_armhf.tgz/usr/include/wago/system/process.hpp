//----------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS are involved in the subject matter of this material. All manufacturing, reproduction, use and 
// sales rights pertaining to this subject matter are governed by the license agreement. The recipient of this software 
// implicitly accepts the terms of the license.
//----------------------------------------------------------------------------------------------------------------------
///---------------------------------------------------------------------------------------------------------------------
///  \file
///
///  \brief    Implementation class for WAGO system library, calling a system process.
///
///  \author   LHe : WAGO GmbH & Co. KG
///---------------------------------------------------------------------------------------------------------------------
#ifndef INCLUDE_WAGO_SYSTEM_PROCESS_HPP_
#define INCLUDE_WAGO_SYSTEM_PROCESS_HPP_

#include <string>
#include <vector>
#include "process_i.hpp"

namespace wago
{
namespace system
{

class process : public process_i
{

public:
    /**
     * Calls given command with args as arguments. If command has a result text, you can find it in result_text.
     * Return code will be returned.
     * Environment will be sanitized according to https://www.oreilly.com/library/view/secure-programming-cookbook/0596003943/ch01s01.html.
     * Open file descriptors will be managed according to https://www.oreilly.com/library/view/secure-programming-cookbook/0596003943/ch01s05.html.
     * Child process will be created according to https://www.oreilly.com/library/view/secure-programming-cookbook/0596003943/ch01s06.html.
     * Program will be securely executed according to https://www.oreilly.com/library/view/secure-programming-cookbook/0596003943/ch01s07.html.
     * @param command Command to process. Better use absolute path.
     * @param args Arguments for command to execute.
     * @param result_text Output text of command, if any.
     * @return Returns integer from the exit code of given command.
     */
    int execute(const std::string& command, const std::vector<std::string>& args, std::string& result_text) override;
    int execute(const std::string& command, const std::vector<std::string>& args = {}) override;
    int execute_multiline_output(const std::string& command, const std::vector<std::string>& args, std::string& result_text) override;
};

} // namespace wago_system_call
} // namespace wago

#endif // INCLUDE_WAGO_SYSTEM_PROCESS_HPP_

