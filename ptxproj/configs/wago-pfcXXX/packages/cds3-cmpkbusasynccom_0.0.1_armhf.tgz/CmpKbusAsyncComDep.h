/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

//---------------------------------------------------------------------------------------------------------------------
// Copyright (c) 2014-2022 WAGO GmbH & Co. KG
//
// PROPRIETARY RIGHTS of WAGO GmbH & Co. KG are involved in the subject matter of this material. All
// manufacturing, reproduction, use, and sales rights pertaining to this subject matter are governed by the license
// agreement. The recipient of this software implicitly accepts the terms of the license.
//---------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------
///
/// \file     CmpKbusAsyncComDep.m4 resp. CmpKbusAsyncComDep.h
///
/// \version  $Revision$
///
/// \brief    contains dependencies of CDS component KBUS asynchronous communication; component provides access for
///           RTS library 'WagoSysKbusAsyncCom_Internal.Library' 
///
/// \author   Horst Leber : WAGO GmbH & Co. KG
///
/// \copydoc  Copyright
///
//---------------------------------------------------------------------------------------------------------------------
#ifndef _CMPKBUSASYNCCOMDEP_H_
#define _CMPKBUSASYNCCOMDEP_H_

#define COMPONENT_NAME "CmpKbusAsyncCom" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_CmpKbusAsyncCom)
#define COMPONENT_NAME_UNQUOTED CmpKbusAsyncCom





#define CMP_VERSION         UINT32_C(0x00000001)
#define CMP_VERSION_STRING "0.0.0.1"
#define CMP_VERSION_RC      0,0,0,1

#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"

#include "WagoSysdefines.h"

#define CMPID_CmpKbusAsyncCom                               CMPKBUSASYNCCOM_CMPID
#define CLASSID_CCmpKbusAsyncCom  ADDVENDORID(CMP_VENDORID, CMPKBUSASYNCCOM_CLASSID_C)
#define ITFID_ICmpKbusAsyncCom    ADDVENDORID(CMP_VENDORID, CMPKBUSASYNCCOM_ITFID_I)








/**
 * \file WagoSysKbusAsyncCom_Internal_CommonItf.h
 */
#include "WagoSysKbusAsyncCom_Internal_CommonItf.h"

/**
 * \file WagoSysKbusAsyncCom_Internal_PFCItf.h
 */
#include "WagoSysKbusAsyncCom_Internal_PFCItf.h"









#include "CMItf.h"


#include "CmpDalItf.h"



        

     

     



#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICmpDal == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpDal, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpDal = (ICmpDal *)pIBase->QueryInterface(pIBase, ITFID_ICmpDal, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pICM == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCM, &initResult); \
            if (pIBase != NULL) \
            { \
                pICM = (ICM *)pIBase->QueryInterface(pIBase, ITFID_ICM, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pICmpDal = NULL; \
          pICM = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pICmpDal != NULL) \
        { \
            pIBase = (IBase *)pICmpDal->QueryInterface(pICmpDal, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpDal = NULL; \
            } \
        } \
          if (pICM != NULL) \
        { \
            pIBase = (IBase *)pICM->QueryInterface(pICM, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICM = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        if (ERR_OK == importResult ) importResult = GET_Dal_CallDeviceSpecificFunction(0);\
          if (ERR_OK == importResult ) importResult = GET_CMExit(0);\
           \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef CMPKBUSASYNCCOM_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)fustartwrreglist, "fustartwrreglist", 0xB7C6223F, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartwrreg, "fustartwrreg", 0x6CB2570E, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartwrparlist, "fustartwrparlist", 0xF60CCA66, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartwrpar, "fustartwrpar", 0x9BC05696, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartrdreglist, "fustartrdreglist", 0x6576A7F1, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartrdreg, "fustartrdreg", 0x300F77B7, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartrdparlist, "fustartrdparlist", 0x283DE285, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fustartrdpar, "fustartrdpar", 0xFFE6401B, 0x01020000 },\
          { (RTS_VOID_FCTPTR)furesetkbustiming, "furesetkbustiming", 0x9686100E, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollwrregstatus, "fupollwrregstatus", 0xD5B1BE2C, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollwrregliststatus, "fupollwrregliststatus", 0xBD81A398, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollwrparstatus, "fupollwrparstatus", 0x26AC7064, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollwrparliststatus, "fupollwrparliststatus", 0xEF3C2230, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollrdreglistdata, "fupollrdreglistdata", 0xFE8D4F0D, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollrdregdata, "fupollrdregdata", 0x75703D49, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollrdparlistdata, "fupollrdparlistdata", 0xCDD0A091, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fupollrdpardata, "fupollrdpardata", 0x5F27375A, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fuopenchannel, "fuopenchannel", 0x6380590C, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fugetunifiedid, "fugetunifiedid", 0x1C96FBCA, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fugetkbustiming, "fugetkbustiming", 0x7F46D946, 0x01020000 },\
          { (RTS_VOID_FCTPTR)fuclosechannel, "fuclosechannel", 0x62FD4229, 0x01020000 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef CMPKBUSASYNCCOM_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                                  
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(CMPKBUSASYNCCOM_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                                  \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CM     \
	ITF_CmpDal      \
    USE_CMExit      \
    USE_Dal_CallDeviceSpecificFunction     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_CM    \
	ITF_CmpDal     \
    USE_CMExit      \
    USE_Dal_CallDeviceSpecificFunction     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_CM    \
	EXTITF_CmpDal     \
    EXT_CMExit  \
    EXT_Dal_CallDeviceSpecificFunction 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry CmpKbusAsyncCom__Entry
#endif


#ifdef CPLUSPLUS

class CCmpKbusAsyncCom : public IWagoSysKbusAsyncCom_Internal_Common , public IWagoSysKbusAsyncCom_Internal_PFC 
{
    public:
        CCmpKbusAsyncCom() : hCmpKbusAsyncCom(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CCmpKbusAsyncCom()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoSysKbusAsyncCom_Internal_Common *)this);            
            else if (iid == ITFID_IWagoSysKbusAsyncCom_Internal_Common)
                pItf = dynamic_cast<IWagoSysKbusAsyncCom_Internal_Common *>(this); 
            else if (iid == ITFID_IWagoSysKbusAsyncCom_Internal_PFC)
                pItf = dynamic_cast<IWagoSysKbusAsyncCom_Internal_PFC *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hCmpKbusAsyncCom;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
