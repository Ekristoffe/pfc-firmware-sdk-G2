 /**
 * <interfacename>WagoSysKbusAsyncCom_Internal_Common</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSKBUSASYNCCOM_INTERNAL_COMMONITF_H_
#define _WAGOSYSKBUSASYNCCOM_INTERNAL_COMMONITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * return values 
 */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_STATUS_OK    0	/* request/evaluation OK */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_GEN_ERROR    1	/* unspecified internal error occurred */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_WRP_ENABLED    2	/* write protection is enabled */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_TERM_IDX    3	/* invalid module index / module not present */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_NO_REGISTER_COM    4	/* module does not support register communication */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_NO_PARAMETER_CHAN    5	/* module does not support parameter channel */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_TABLE_IDX    6	/* invalid table/channel index */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_REG_PAR_IDX    7	/* invalid register/parameter index */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_REQ_COUNT    8	/* number of requested words leads to invalid register/parameter index */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_WRONG_STATE    9	/* new request started during ongoing request */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_TIMEOUT_PAR    10	/* timeout during parameter access */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_PAR_COM    11	/* parameter communication error */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_AA_NO_REG_RD_ACC    12	/* during application is active module does not support register read access */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_AA_NO_REG_WR_ACC    13	/* during application is active module does not support register write access */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_AA_NO_PAR_ACC    14	/* during application is active module does not support parameter access */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_INV_HANDLE    15	/* parameter error invalid handle */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_VALUE_PTR    16	/* parameter error invalid pointer */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_CON_IN_USE    17	/* evaluation error connection is in use */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_INFO_CON_ACTIVE    18	/* evaluation information connection is active -> poll again */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_NOT_INIT    19	/* library module is not initialized */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_NO_KBUS_ACC    20	/* library module has no KBUS access */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_NO_HANDLE_GEN    21	/* library module has no handle generated */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_CONT_NOT_FIT    22	/* content does not fit to request */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_STS_NOT_FIT    23	/* status does not fit to request */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_TIMEOUT_TERM    24	/* parameter access status from module: TIMEOUT */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_BUF_OVF_TERM    25	/* parameter access status from module: BUFFER OVERFLOW */
#define EKBAC_LIB_STATUS_CODES_LPKD_REQ_EVA_ERROR_PRM_ERR_TERM    26	/* parameter access status from module: PARAMETER ERROR */
#define EKBAC_LIB_STATUS_CODES_NUMBER_OF_LPKD_REQ_EVA_VALUES    27	/* number of defined return values */
/* Typed enum definition */
#define EKBAC_LIB_STATUS_CODES    RTS_IEC_DINT

#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysKbusAsyncCom_Internal_Common_C;

#ifdef CPLUSPLUS
class IWagoSysKbusAsyncCom_Internal_Common : public IBase
{
	public:
};
	#ifndef ITF_WagoSysKbusAsyncCom_Internal_Common
		#define ITF_WagoSysKbusAsyncCom_Internal_Common static IWagoSysKbusAsyncCom_Internal_Common *pIWagoSysKbusAsyncCom_Internal_Common = NULL;
	#endif
	#define EXTITF_WagoSysKbusAsyncCom_Internal_Common
#else	/*CPLUSPLUS*/
	typedef IWagoSysKbusAsyncCom_Internal_Common_C		IWagoSysKbusAsyncCom_Internal_Common;
	#ifndef ITF_WagoSysKbusAsyncCom_Internal_Common
		#define ITF_WagoSysKbusAsyncCom_Internal_Common
	#endif
	#define EXTITF_WagoSysKbusAsyncCom_Internal_Common
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSKBUSASYNCCOM_INTERNAL_COMMONITF_H_*/
