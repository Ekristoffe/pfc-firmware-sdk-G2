 /**
 * <interfacename>WagoSysKbusAsyncCom_Internal_PFC</interfacename>
 * <description></description>
 *
 * <copyright></copyright>
 */


	
	
#ifndef _WAGOSYSKBUSASYNCCOM_INTERNAL_PFCITF_H_
#define _WAGOSYSKBUSASYNCCOM_INTERNAL_PFCITF_H_

#include "CmpStd.h"

 

 




/** EXTERN LIB SECTION BEGIN **/
/*  Comments are ignored for m4 compiler so restructured text can be used.  */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * <description>fuclosechannel</description>
 */
typedef struct tagfuclosechannel_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* any handle of the resource */
	RTS_IEC_DINT FuCloseChannel;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fuclosechannel_struct;

void CDECL CDECL_EXT fuclosechannel(fuclosechannel_struct *p);
typedef void (CDECL CDECL_EXT* PFFUCLOSECHANNEL_IEC) (fuclosechannel_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUCLOSECHANNEL_NOTIMPLEMENTED)
	#define USE_fuclosechannel
	#define EXT_fuclosechannel
	#define GET_fuclosechannel(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuclosechannel(p0) 
	#define CHK_fuclosechannel  FALSE
	#define EXP_fuclosechannel  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuclosechannel
	#define EXT_fuclosechannel
	#define GET_fuclosechannel(fl)  CAL_CMGETAPI( "fuclosechannel" ) 
	#define CAL_fuclosechannel  fuclosechannel
	#define CHK_fuclosechannel  TRUE
	#define EXP_fuclosechannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuclosechannel", (RTS_UINTPTR)fuclosechannel, 1, 0x62FD4229, 0x01020000) 
	#define EXTREF_ITF_fuclosechannel {(RTS_VOID_FCTPTR)fuclosechannel, "fuclosechannel", 0x62FD4229, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuclosechannel
	#define EXT_fuclosechannel
	#define GET_fuclosechannel(fl)  CAL_CMGETAPI( "fuclosechannel" ) 
	#define CAL_fuclosechannel  fuclosechannel
	#define CHK_fuclosechannel  TRUE
	#define EXP_fuclosechannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuclosechannel", (RTS_UINTPTR)fuclosechannel, 1, 0x62FD4229, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfuclosechannel
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfuclosechannel
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfuclosechannel  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfuclosechannel  fuclosechannel
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfuclosechannel  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfuclosechannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuclosechannel", (RTS_UINTPTR)fuclosechannel, 1, 0x62FD4229, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fuclosechannel
	#define EXT_fuclosechannel
	#define GET_fuclosechannel(fl)  CAL_CMGETAPI( "fuclosechannel" ) 
	#define CAL_fuclosechannel  fuclosechannel
	#define CHK_fuclosechannel  TRUE
	#define EXP_fuclosechannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuclosechannel", (RTS_UINTPTR)fuclosechannel, 1, 0x62FD4229, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fuclosechannel  PFFUCLOSECHANNEL_IEC pffuclosechannel;
	#define EXT_fuclosechannel  extern PFFUCLOSECHANNEL_IEC pffuclosechannel;
	#define GET_fuclosechannel(fl)  s_pfCMGetAPI2( "fuclosechannel", (RTS_VOID_FCTPTR *)&pffuclosechannel, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x62FD4229, 0x01020000)
	#define CAL_fuclosechannel  pffuclosechannel
	#define CHK_fuclosechannel  (pffuclosechannel != NULL)
	#define EXP_fuclosechannel   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuclosechannel", (RTS_UINTPTR)fuclosechannel, 1, 0x62FD4229, 0x01020000) 
#endif


/**
 * <description>fugetkbustiming</description>
 */
typedef struct tagfugetkbustiming_struct
{
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_DINT *diCurDuration;		/* VAR_IN_OUT */	/* current duration in [us] */
	RTS_IEC_DINT *diMinDuration;		/* VAR_IN_OUT */	/* minimum duration in [us] */
	RTS_IEC_DINT *diMaxDuration;		/* VAR_IN_OUT */	/* maximum duration in [us] */
	RTS_IEC_DINT *diAvrDuration;		/* VAR_IN_OUT */	/* average duration in [us] */
	RTS_IEC_DINT FuGetKbusTiming;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fugetkbustiming_struct;

void CDECL CDECL_EXT fugetkbustiming(fugetkbustiming_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETKBUSTIMING_IEC) (fugetkbustiming_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETKBUSTIMING_NOTIMPLEMENTED)
	#define USE_fugetkbustiming
	#define EXT_fugetkbustiming
	#define GET_fugetkbustiming(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetkbustiming(p0) 
	#define CHK_fugetkbustiming  FALSE
	#define EXP_fugetkbustiming  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetkbustiming
	#define EXT_fugetkbustiming
	#define GET_fugetkbustiming(fl)  CAL_CMGETAPI( "fugetkbustiming" ) 
	#define CAL_fugetkbustiming  fugetkbustiming
	#define CHK_fugetkbustiming  TRUE
	#define EXP_fugetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetkbustiming", (RTS_UINTPTR)fugetkbustiming, 1, 0x7F46D946, 0x01020000) 
	#define EXTREF_ITF_fugetkbustiming {(RTS_VOID_FCTPTR)fugetkbustiming, "fugetkbustiming", 0x7F46D946, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetkbustiming
	#define EXT_fugetkbustiming
	#define GET_fugetkbustiming(fl)  CAL_CMGETAPI( "fugetkbustiming" ) 
	#define CAL_fugetkbustiming  fugetkbustiming
	#define CHK_fugetkbustiming  TRUE
	#define EXP_fugetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetkbustiming", (RTS_UINTPTR)fugetkbustiming, 1, 0x7F46D946, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfugetkbustiming
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfugetkbustiming
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfugetkbustiming  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfugetkbustiming  fugetkbustiming
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfugetkbustiming  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfugetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetkbustiming", (RTS_UINTPTR)fugetkbustiming, 1, 0x7F46D946, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fugetkbustiming
	#define EXT_fugetkbustiming
	#define GET_fugetkbustiming(fl)  CAL_CMGETAPI( "fugetkbustiming" ) 
	#define CAL_fugetkbustiming  fugetkbustiming
	#define CHK_fugetkbustiming  TRUE
	#define EXP_fugetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetkbustiming", (RTS_UINTPTR)fugetkbustiming, 1, 0x7F46D946, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fugetkbustiming  PFFUGETKBUSTIMING_IEC pffugetkbustiming;
	#define EXT_fugetkbustiming  extern PFFUGETKBUSTIMING_IEC pffugetkbustiming;
	#define GET_fugetkbustiming(fl)  s_pfCMGetAPI2( "fugetkbustiming", (RTS_VOID_FCTPTR *)&pffugetkbustiming, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x7F46D946, 0x01020000)
	#define CAL_fugetkbustiming  pffugetkbustiming
	#define CHK_fugetkbustiming  (pffugetkbustiming != NULL)
	#define EXP_fugetkbustiming   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetkbustiming", (RTS_UINTPTR)fugetkbustiming, 1, 0x7F46D946, 0x01020000) 
#endif


/**
 * <description>fugetunifiedid</description>
 */
typedef struct tagfugetunifiedid_struct
{
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_UDINT *udiUID;				/* VAR_IN_OUT */	/* unified identification number */
	RTS_IEC_DINT FuGetUnifiedId;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fugetunifiedid_struct;

void CDECL CDECL_EXT fugetunifiedid(fugetunifiedid_struct *p);
typedef void (CDECL CDECL_EXT* PFFUGETUNIFIEDID_IEC) (fugetunifiedid_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUGETUNIFIEDID_NOTIMPLEMENTED)
	#define USE_fugetunifiedid
	#define EXT_fugetunifiedid
	#define GET_fugetunifiedid(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fugetunifiedid(p0) 
	#define CHK_fugetunifiedid  FALSE
	#define EXP_fugetunifiedid  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fugetunifiedid
	#define EXT_fugetunifiedid
	#define GET_fugetunifiedid(fl)  CAL_CMGETAPI( "fugetunifiedid" ) 
	#define CAL_fugetunifiedid  fugetunifiedid
	#define CHK_fugetunifiedid  TRUE
	#define EXP_fugetunifiedid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetunifiedid", (RTS_UINTPTR)fugetunifiedid, 1, 0x1C96FBCA, 0x01020000) 
	#define EXTREF_ITF_fugetunifiedid {(RTS_VOID_FCTPTR)fugetunifiedid, "fugetunifiedid", 0x1C96FBCA, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fugetunifiedid
	#define EXT_fugetunifiedid
	#define GET_fugetunifiedid(fl)  CAL_CMGETAPI( "fugetunifiedid" ) 
	#define CAL_fugetunifiedid  fugetunifiedid
	#define CHK_fugetunifiedid  TRUE
	#define EXP_fugetunifiedid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetunifiedid", (RTS_UINTPTR)fugetunifiedid, 1, 0x1C96FBCA, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfugetunifiedid
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfugetunifiedid
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfugetunifiedid  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfugetunifiedid  fugetunifiedid
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfugetunifiedid  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfugetunifiedid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetunifiedid", (RTS_UINTPTR)fugetunifiedid, 1, 0x1C96FBCA, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fugetunifiedid
	#define EXT_fugetunifiedid
	#define GET_fugetunifiedid(fl)  CAL_CMGETAPI( "fugetunifiedid" ) 
	#define CAL_fugetunifiedid  fugetunifiedid
	#define CHK_fugetunifiedid  TRUE
	#define EXP_fugetunifiedid  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetunifiedid", (RTS_UINTPTR)fugetunifiedid, 1, 0x1C96FBCA, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fugetunifiedid  PFFUGETUNIFIEDID_IEC pffugetunifiedid;
	#define EXT_fugetunifiedid  extern PFFUGETUNIFIEDID_IEC pffugetunifiedid;
	#define GET_fugetunifiedid(fl)  s_pfCMGetAPI2( "fugetunifiedid", (RTS_VOID_FCTPTR *)&pffugetunifiedid, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x1C96FBCA, 0x01020000)
	#define CAL_fugetunifiedid  pffugetunifiedid
	#define CHK_fugetunifiedid  (pffugetunifiedid != NULL)
	#define EXP_fugetunifiedid   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fugetunifiedid", (RTS_UINTPTR)fugetunifiedid, 1, 0x1C96FBCA, 0x01020000) 
#endif


/**
 * <description>fuopenchannel</description>
 */
typedef struct tagfuopenchannel_struct
{
	RTS_IEC_HANDLE *handle;				/* VAR_IN_OUT */	/* universal handle of the resource */
	RTS_IEC_DINT FuOpenChannel;			/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fuopenchannel_struct;

void CDECL CDECL_EXT fuopenchannel(fuopenchannel_struct *p);
typedef void (CDECL CDECL_EXT* PFFUOPENCHANNEL_IEC) (fuopenchannel_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUOPENCHANNEL_NOTIMPLEMENTED)
	#define USE_fuopenchannel
	#define EXT_fuopenchannel
	#define GET_fuopenchannel(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fuopenchannel(p0) 
	#define CHK_fuopenchannel  FALSE
	#define EXP_fuopenchannel  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fuopenchannel
	#define EXT_fuopenchannel
	#define GET_fuopenchannel(fl)  CAL_CMGETAPI( "fuopenchannel" ) 
	#define CAL_fuopenchannel  fuopenchannel
	#define CHK_fuopenchannel  TRUE
	#define EXP_fuopenchannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenchannel", (RTS_UINTPTR)fuopenchannel, 1, 0x6380590C, 0x01020000) 
	#define EXTREF_ITF_fuopenchannel {(RTS_VOID_FCTPTR)fuopenchannel, "fuopenchannel", 0x6380590C, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fuopenchannel
	#define EXT_fuopenchannel
	#define GET_fuopenchannel(fl)  CAL_CMGETAPI( "fuopenchannel" ) 
	#define CAL_fuopenchannel  fuopenchannel
	#define CHK_fuopenchannel  TRUE
	#define EXP_fuopenchannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenchannel", (RTS_UINTPTR)fuopenchannel, 1, 0x6380590C, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfuopenchannel
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfuopenchannel
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfuopenchannel  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfuopenchannel  fuopenchannel
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfuopenchannel  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfuopenchannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenchannel", (RTS_UINTPTR)fuopenchannel, 1, 0x6380590C, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fuopenchannel
	#define EXT_fuopenchannel
	#define GET_fuopenchannel(fl)  CAL_CMGETAPI( "fuopenchannel" ) 
	#define CAL_fuopenchannel  fuopenchannel
	#define CHK_fuopenchannel  TRUE
	#define EXP_fuopenchannel  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenchannel", (RTS_UINTPTR)fuopenchannel, 1, 0x6380590C, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fuopenchannel  PFFUOPENCHANNEL_IEC pffuopenchannel;
	#define EXT_fuopenchannel  extern PFFUOPENCHANNEL_IEC pffuopenchannel;
	#define GET_fuopenchannel(fl)  s_pfCMGetAPI2( "fuopenchannel", (RTS_VOID_FCTPTR *)&pffuopenchannel, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6380590C, 0x01020000)
	#define CAL_fuopenchannel  pffuopenchannel
	#define CHK_fuopenchannel  (pffuopenchannel != NULL)
	#define EXP_fuopenchannel   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fuopenchannel", (RTS_UINTPTR)fuopenchannel, 1, 0x6380590C, 0x01020000) 
#endif


/**
 * <description>fupollrdpardata</description>
 */
typedef struct tagfupollrdpardata_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT *uiValue;				/* VAR_IN_OUT */	/* content of addressed parameter */
	RTS_IEC_UINT *uiStatus;				/* VAR_IN_OUT */	/* content of status register 57 */
	RTS_IEC_DINT FuPollRdParData;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollrdpardata_struct;

void CDECL CDECL_EXT fupollrdpardata(fupollrdpardata_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLRDPARDATA_IEC) (fupollrdpardata_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLRDPARDATA_NOTIMPLEMENTED)
	#define USE_fupollrdpardata
	#define EXT_fupollrdpardata
	#define GET_fupollrdpardata(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollrdpardata(p0) 
	#define CHK_fupollrdpardata  FALSE
	#define EXP_fupollrdpardata  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollrdpardata
	#define EXT_fupollrdpardata
	#define GET_fupollrdpardata(fl)  CAL_CMGETAPI( "fupollrdpardata" ) 
	#define CAL_fupollrdpardata  fupollrdpardata
	#define CHK_fupollrdpardata  TRUE
	#define EXP_fupollrdpardata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdpardata", (RTS_UINTPTR)fupollrdpardata, 1, 0x5F27375A, 0x01020000) 
	#define EXTREF_ITF_fupollrdpardata {(RTS_VOID_FCTPTR)fupollrdpardata, "fupollrdpardata", 0x5F27375A, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollrdpardata
	#define EXT_fupollrdpardata
	#define GET_fupollrdpardata(fl)  CAL_CMGETAPI( "fupollrdpardata" ) 
	#define CAL_fupollrdpardata  fupollrdpardata
	#define CHK_fupollrdpardata  TRUE
	#define EXP_fupollrdpardata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdpardata", (RTS_UINTPTR)fupollrdpardata, 1, 0x5F27375A, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollrdpardata
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollrdpardata
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollrdpardata  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollrdpardata  fupollrdpardata
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollrdpardata  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollrdpardata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdpardata", (RTS_UINTPTR)fupollrdpardata, 1, 0x5F27375A, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollrdpardata
	#define EXT_fupollrdpardata
	#define GET_fupollrdpardata(fl)  CAL_CMGETAPI( "fupollrdpardata" ) 
	#define CAL_fupollrdpardata  fupollrdpardata
	#define CHK_fupollrdpardata  TRUE
	#define EXP_fupollrdpardata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdpardata", (RTS_UINTPTR)fupollrdpardata, 1, 0x5F27375A, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollrdpardata  PFFUPOLLRDPARDATA_IEC pffupollrdpardata;
	#define EXT_fupollrdpardata  extern PFFUPOLLRDPARDATA_IEC pffupollrdpardata;
	#define GET_fupollrdpardata(fl)  s_pfCMGetAPI2( "fupollrdpardata", (RTS_VOID_FCTPTR *)&pffupollrdpardata, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x5F27375A, 0x01020000)
	#define CAL_fupollrdpardata  pffupollrdpardata
	#define CHK_fupollrdpardata  (pffupollrdpardata != NULL)
	#define EXP_fupollrdpardata   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdpardata", (RTS_UINTPTR)fupollrdpardata, 1, 0x5F27375A, 0x01020000) 
#endif


/**
 * <description>fupollrdparlistdata</description>
 */
typedef struct tagfupollrdparlistdata_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiParameterCnt;		/* VAR_INPUT */	/* number of parameters to write (1 .. 256) */
	RTS_IEC_UINT *aValue;				/* VAR_IN_OUT */	/* content of addressed registers */
	RTS_IEC_UINT *uiStatus;				/* VAR_IN_OUT */	/* content of status register 57 */
	RTS_IEC_DINT FuPollRdParListData;	/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollrdparlistdata_struct;

void CDECL CDECL_EXT fupollrdparlistdata(fupollrdparlistdata_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLRDPARLISTDATA_IEC) (fupollrdparlistdata_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLRDPARLISTDATA_NOTIMPLEMENTED)
	#define USE_fupollrdparlistdata
	#define EXT_fupollrdparlistdata
	#define GET_fupollrdparlistdata(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollrdparlistdata(p0) 
	#define CHK_fupollrdparlistdata  FALSE
	#define EXP_fupollrdparlistdata  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollrdparlistdata
	#define EXT_fupollrdparlistdata
	#define GET_fupollrdparlistdata(fl)  CAL_CMGETAPI( "fupollrdparlistdata" ) 
	#define CAL_fupollrdparlistdata  fupollrdparlistdata
	#define CHK_fupollrdparlistdata  TRUE
	#define EXP_fupollrdparlistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdparlistdata", (RTS_UINTPTR)fupollrdparlistdata, 1, 0xCDD0A091, 0x01020000) 
	#define EXTREF_ITF_fupollrdparlistdata {(RTS_VOID_FCTPTR)fupollrdparlistdata, "fupollrdparlistdata", 0xCDD0A091, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollrdparlistdata
	#define EXT_fupollrdparlistdata
	#define GET_fupollrdparlistdata(fl)  CAL_CMGETAPI( "fupollrdparlistdata" ) 
	#define CAL_fupollrdparlistdata  fupollrdparlistdata
	#define CHK_fupollrdparlistdata  TRUE
	#define EXP_fupollrdparlistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdparlistdata", (RTS_UINTPTR)fupollrdparlistdata, 1, 0xCDD0A091, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollrdparlistdata
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollrdparlistdata
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollrdparlistdata  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollrdparlistdata  fupollrdparlistdata
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollrdparlistdata  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollrdparlistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdparlistdata", (RTS_UINTPTR)fupollrdparlistdata, 1, 0xCDD0A091, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollrdparlistdata
	#define EXT_fupollrdparlistdata
	#define GET_fupollrdparlistdata(fl)  CAL_CMGETAPI( "fupollrdparlistdata" ) 
	#define CAL_fupollrdparlistdata  fupollrdparlistdata
	#define CHK_fupollrdparlistdata  TRUE
	#define EXP_fupollrdparlistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdparlistdata", (RTS_UINTPTR)fupollrdparlistdata, 1, 0xCDD0A091, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollrdparlistdata  PFFUPOLLRDPARLISTDATA_IEC pffupollrdparlistdata;
	#define EXT_fupollrdparlistdata  extern PFFUPOLLRDPARLISTDATA_IEC pffupollrdparlistdata;
	#define GET_fupollrdparlistdata(fl)  s_pfCMGetAPI2( "fupollrdparlistdata", (RTS_VOID_FCTPTR *)&pffupollrdparlistdata, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xCDD0A091, 0x01020000)
	#define CAL_fupollrdparlistdata  pffupollrdparlistdata
	#define CHK_fupollrdparlistdata  (pffupollrdparlistdata != NULL)
	#define EXP_fupollrdparlistdata   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdparlistdata", (RTS_UINTPTR)fupollrdparlistdata, 1, 0xCDD0A091, 0x01020000) 
#endif


/**
 * <description>fupollrdregdata</description>
 */
typedef struct tagfupollrdregdata_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* register number in module */
	RTS_IEC_UINT *uiValue;				/* VAR_IN_OUT */	/* content of addressed register */
	RTS_IEC_DINT FuPollRdRegData;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollrdregdata_struct;

void CDECL CDECL_EXT fupollrdregdata(fupollrdregdata_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLRDREGDATA_IEC) (fupollrdregdata_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLRDREGDATA_NOTIMPLEMENTED)
	#define USE_fupollrdregdata
	#define EXT_fupollrdregdata
	#define GET_fupollrdregdata(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollrdregdata(p0) 
	#define CHK_fupollrdregdata  FALSE
	#define EXP_fupollrdregdata  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollrdregdata
	#define EXT_fupollrdregdata
	#define GET_fupollrdregdata(fl)  CAL_CMGETAPI( "fupollrdregdata" ) 
	#define CAL_fupollrdregdata  fupollrdregdata
	#define CHK_fupollrdregdata  TRUE
	#define EXP_fupollrdregdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdregdata", (RTS_UINTPTR)fupollrdregdata, 1, 0x75703D49, 0x01020000) 
	#define EXTREF_ITF_fupollrdregdata {(RTS_VOID_FCTPTR)fupollrdregdata, "fupollrdregdata", 0x75703D49, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollrdregdata
	#define EXT_fupollrdregdata
	#define GET_fupollrdregdata(fl)  CAL_CMGETAPI( "fupollrdregdata" ) 
	#define CAL_fupollrdregdata  fupollrdregdata
	#define CHK_fupollrdregdata  TRUE
	#define EXP_fupollrdregdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdregdata", (RTS_UINTPTR)fupollrdregdata, 1, 0x75703D49, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollrdregdata
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollrdregdata
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollrdregdata  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollrdregdata  fupollrdregdata
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollrdregdata  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollrdregdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdregdata", (RTS_UINTPTR)fupollrdregdata, 1, 0x75703D49, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollrdregdata
	#define EXT_fupollrdregdata
	#define GET_fupollrdregdata(fl)  CAL_CMGETAPI( "fupollrdregdata" ) 
	#define CAL_fupollrdregdata  fupollrdregdata
	#define CHK_fupollrdregdata  TRUE
	#define EXP_fupollrdregdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdregdata", (RTS_UINTPTR)fupollrdregdata, 1, 0x75703D49, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollrdregdata  PFFUPOLLRDREGDATA_IEC pffupollrdregdata;
	#define EXT_fupollrdregdata  extern PFFUPOLLRDREGDATA_IEC pffupollrdregdata;
	#define GET_fupollrdregdata(fl)  s_pfCMGetAPI2( "fupollrdregdata", (RTS_VOID_FCTPTR *)&pffupollrdregdata, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x75703D49, 0x01020000)
	#define CAL_fupollrdregdata  pffupollrdregdata
	#define CHK_fupollrdregdata  (pffupollrdregdata != NULL)
	#define EXP_fupollrdregdata   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdregdata", (RTS_UINTPTR)fupollrdregdata, 1, 0x75703D49, 0x01020000) 
#endif


/**
 * <description>fupollrdreglistdata</description>
 */
typedef struct tagfupollrdreglistdata_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* first register to read */
	RTS_IEC_USINT usiRegisterCnt;		/* VAR_INPUT */	/* number of registers to read (1 .. 64) */
	RTS_IEC_UINT *aValue;				/* VAR_IN_OUT */	/* content of addressed registers */
	RTS_IEC_DINT FuPollRdRegListData;	/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollrdreglistdata_struct;

void CDECL CDECL_EXT fupollrdreglistdata(fupollrdreglistdata_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLRDREGLISTDATA_IEC) (fupollrdreglistdata_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLRDREGLISTDATA_NOTIMPLEMENTED)
	#define USE_fupollrdreglistdata
	#define EXT_fupollrdreglistdata
	#define GET_fupollrdreglistdata(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollrdreglistdata(p0) 
	#define CHK_fupollrdreglistdata  FALSE
	#define EXP_fupollrdreglistdata  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollrdreglistdata
	#define EXT_fupollrdreglistdata
	#define GET_fupollrdreglistdata(fl)  CAL_CMGETAPI( "fupollrdreglistdata" ) 
	#define CAL_fupollrdreglistdata  fupollrdreglistdata
	#define CHK_fupollrdreglistdata  TRUE
	#define EXP_fupollrdreglistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdreglistdata", (RTS_UINTPTR)fupollrdreglistdata, 1, 0xFE8D4F0D, 0x01020000) 
	#define EXTREF_ITF_fupollrdreglistdata {(RTS_VOID_FCTPTR)fupollrdreglistdata, "fupollrdreglistdata", 0xFE8D4F0D, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollrdreglistdata
	#define EXT_fupollrdreglistdata
	#define GET_fupollrdreglistdata(fl)  CAL_CMGETAPI( "fupollrdreglistdata" ) 
	#define CAL_fupollrdreglistdata  fupollrdreglistdata
	#define CHK_fupollrdreglistdata  TRUE
	#define EXP_fupollrdreglistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdreglistdata", (RTS_UINTPTR)fupollrdreglistdata, 1, 0xFE8D4F0D, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollrdreglistdata
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollrdreglistdata
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollrdreglistdata  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollrdreglistdata  fupollrdreglistdata
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollrdreglistdata  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollrdreglistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdreglistdata", (RTS_UINTPTR)fupollrdreglistdata, 1, 0xFE8D4F0D, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollrdreglistdata
	#define EXT_fupollrdreglistdata
	#define GET_fupollrdreglistdata(fl)  CAL_CMGETAPI( "fupollrdreglistdata" ) 
	#define CAL_fupollrdreglistdata  fupollrdreglistdata
	#define CHK_fupollrdreglistdata  TRUE
	#define EXP_fupollrdreglistdata  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdreglistdata", (RTS_UINTPTR)fupollrdreglistdata, 1, 0xFE8D4F0D, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollrdreglistdata  PFFUPOLLRDREGLISTDATA_IEC pffupollrdreglistdata;
	#define EXT_fupollrdreglistdata  extern PFFUPOLLRDREGLISTDATA_IEC pffupollrdreglistdata;
	#define GET_fupollrdreglistdata(fl)  s_pfCMGetAPI2( "fupollrdreglistdata", (RTS_VOID_FCTPTR *)&pffupollrdreglistdata, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xFE8D4F0D, 0x01020000)
	#define CAL_fupollrdreglistdata  pffupollrdreglistdata
	#define CHK_fupollrdreglistdata  (pffupollrdreglistdata != NULL)
	#define EXP_fupollrdreglistdata   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollrdreglistdata", (RTS_UINTPTR)fupollrdreglistdata, 1, 0xFE8D4F0D, 0x01020000) 
#endif


/**
 * <description>fupollwrparliststatus</description>
 */
typedef struct tagfupollwrparliststatus_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiParameterCnt;		/* VAR_INPUT */	/* number of parameters to write (1 .. 256) */
	RTS_IEC_UINT *uiStatus;				/* VAR_IN_OUT */	/* content of status register 57 */
	RTS_IEC_DINT FuPollWrParListStatus;	/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollwrparliststatus_struct;

void CDECL CDECL_EXT fupollwrparliststatus(fupollwrparliststatus_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLWRPARLISTSTATUS_IEC) (fupollwrparliststatus_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLWRPARLISTSTATUS_NOTIMPLEMENTED)
	#define USE_fupollwrparliststatus
	#define EXT_fupollwrparliststatus
	#define GET_fupollwrparliststatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollwrparliststatus(p0) 
	#define CHK_fupollwrparliststatus  FALSE
	#define EXP_fupollwrparliststatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollwrparliststatus
	#define EXT_fupollwrparliststatus
	#define GET_fupollwrparliststatus(fl)  CAL_CMGETAPI( "fupollwrparliststatus" ) 
	#define CAL_fupollwrparliststatus  fupollwrparliststatus
	#define CHK_fupollwrparliststatus  TRUE
	#define EXP_fupollwrparliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparliststatus", (RTS_UINTPTR)fupollwrparliststatus, 1, 0xEF3C2230, 0x01020000) 
	#define EXTREF_ITF_fupollwrparliststatus {(RTS_VOID_FCTPTR)fupollwrparliststatus, "fupollwrparliststatus", 0xEF3C2230, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollwrparliststatus
	#define EXT_fupollwrparliststatus
	#define GET_fupollwrparliststatus(fl)  CAL_CMGETAPI( "fupollwrparliststatus" ) 
	#define CAL_fupollwrparliststatus  fupollwrparliststatus
	#define CHK_fupollwrparliststatus  TRUE
	#define EXP_fupollwrparliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparliststatus", (RTS_UINTPTR)fupollwrparliststatus, 1, 0xEF3C2230, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollwrparliststatus
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollwrparliststatus
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollwrparliststatus  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollwrparliststatus  fupollwrparliststatus
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollwrparliststatus  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollwrparliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparliststatus", (RTS_UINTPTR)fupollwrparliststatus, 1, 0xEF3C2230, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollwrparliststatus
	#define EXT_fupollwrparliststatus
	#define GET_fupollwrparliststatus(fl)  CAL_CMGETAPI( "fupollwrparliststatus" ) 
	#define CAL_fupollwrparliststatus  fupollwrparliststatus
	#define CHK_fupollwrparliststatus  TRUE
	#define EXP_fupollwrparliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparliststatus", (RTS_UINTPTR)fupollwrparliststatus, 1, 0xEF3C2230, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollwrparliststatus  PFFUPOLLWRPARLISTSTATUS_IEC pffupollwrparliststatus;
	#define EXT_fupollwrparliststatus  extern PFFUPOLLWRPARLISTSTATUS_IEC pffupollwrparliststatus;
	#define GET_fupollwrparliststatus(fl)  s_pfCMGetAPI2( "fupollwrparliststatus", (RTS_VOID_FCTPTR *)&pffupollwrparliststatus, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xEF3C2230, 0x01020000)
	#define CAL_fupollwrparliststatus  pffupollwrparliststatus
	#define CHK_fupollwrparliststatus  (pffupollwrparliststatus != NULL)
	#define EXP_fupollwrparliststatus   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparliststatus", (RTS_UINTPTR)fupollwrparliststatus, 1, 0xEF3C2230, 0x01020000) 
#endif


/**
 * <description>fupollwrparstatus</description>
 */
typedef struct tagfupollwrparstatus_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiValue;				/* VAR_INPUT */	/* content of addressed parameter */
	RTS_IEC_UINT *uiStatus;				/* VAR_IN_OUT */	/* content of status register 57 */
	RTS_IEC_DINT FuPollWrParStatus;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollwrparstatus_struct;

void CDECL CDECL_EXT fupollwrparstatus(fupollwrparstatus_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLWRPARSTATUS_IEC) (fupollwrparstatus_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLWRPARSTATUS_NOTIMPLEMENTED)
	#define USE_fupollwrparstatus
	#define EXT_fupollwrparstatus
	#define GET_fupollwrparstatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollwrparstatus(p0) 
	#define CHK_fupollwrparstatus  FALSE
	#define EXP_fupollwrparstatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollwrparstatus
	#define EXT_fupollwrparstatus
	#define GET_fupollwrparstatus(fl)  CAL_CMGETAPI( "fupollwrparstatus" ) 
	#define CAL_fupollwrparstatus  fupollwrparstatus
	#define CHK_fupollwrparstatus  TRUE
	#define EXP_fupollwrparstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparstatus", (RTS_UINTPTR)fupollwrparstatus, 1, 0x26AC7064, 0x01020000) 
	#define EXTREF_ITF_fupollwrparstatus {(RTS_VOID_FCTPTR)fupollwrparstatus, "fupollwrparstatus", 0x26AC7064, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollwrparstatus
	#define EXT_fupollwrparstatus
	#define GET_fupollwrparstatus(fl)  CAL_CMGETAPI( "fupollwrparstatus" ) 
	#define CAL_fupollwrparstatus  fupollwrparstatus
	#define CHK_fupollwrparstatus  TRUE
	#define EXP_fupollwrparstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparstatus", (RTS_UINTPTR)fupollwrparstatus, 1, 0x26AC7064, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollwrparstatus
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollwrparstatus
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollwrparstatus  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollwrparstatus  fupollwrparstatus
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollwrparstatus  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollwrparstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparstatus", (RTS_UINTPTR)fupollwrparstatus, 1, 0x26AC7064, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollwrparstatus
	#define EXT_fupollwrparstatus
	#define GET_fupollwrparstatus(fl)  CAL_CMGETAPI( "fupollwrparstatus" ) 
	#define CAL_fupollwrparstatus  fupollwrparstatus
	#define CHK_fupollwrparstatus  TRUE
	#define EXP_fupollwrparstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparstatus", (RTS_UINTPTR)fupollwrparstatus, 1, 0x26AC7064, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollwrparstatus  PFFUPOLLWRPARSTATUS_IEC pffupollwrparstatus;
	#define EXT_fupollwrparstatus  extern PFFUPOLLWRPARSTATUS_IEC pffupollwrparstatus;
	#define GET_fupollwrparstatus(fl)  s_pfCMGetAPI2( "fupollwrparstatus", (RTS_VOID_FCTPTR *)&pffupollwrparstatus, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x26AC7064, 0x01020000)
	#define CAL_fupollwrparstatus  pffupollwrparstatus
	#define CHK_fupollwrparstatus  (pffupollwrparstatus != NULL)
	#define EXP_fupollwrparstatus   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrparstatus", (RTS_UINTPTR)fupollwrparstatus, 1, 0x26AC7064, 0x01020000) 
#endif


/**
 * <description>fupollwrregliststatus</description>
 */
typedef struct tagfupollwrregliststatus_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* first register to write */
	RTS_IEC_USINT usiRegisterCnt;		/* VAR_INPUT */	/* number of registers to write (1 .. 64) */
	RTS_IEC_DINT FuPollWrRegListStatus;	/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollwrregliststatus_struct;

void CDECL CDECL_EXT fupollwrregliststatus(fupollwrregliststatus_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLWRREGLISTSTATUS_IEC) (fupollwrregliststatus_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLWRREGLISTSTATUS_NOTIMPLEMENTED)
	#define USE_fupollwrregliststatus
	#define EXT_fupollwrregliststatus
	#define GET_fupollwrregliststatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollwrregliststatus(p0) 
	#define CHK_fupollwrregliststatus  FALSE
	#define EXP_fupollwrregliststatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollwrregliststatus
	#define EXT_fupollwrregliststatus
	#define GET_fupollwrregliststatus(fl)  CAL_CMGETAPI( "fupollwrregliststatus" ) 
	#define CAL_fupollwrregliststatus  fupollwrregliststatus
	#define CHK_fupollwrregliststatus  TRUE
	#define EXP_fupollwrregliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregliststatus", (RTS_UINTPTR)fupollwrregliststatus, 1, 0xBD81A398, 0x01020000) 
	#define EXTREF_ITF_fupollwrregliststatus {(RTS_VOID_FCTPTR)fupollwrregliststatus, "fupollwrregliststatus", 0xBD81A398, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollwrregliststatus
	#define EXT_fupollwrregliststatus
	#define GET_fupollwrregliststatus(fl)  CAL_CMGETAPI( "fupollwrregliststatus" ) 
	#define CAL_fupollwrregliststatus  fupollwrregliststatus
	#define CHK_fupollwrregliststatus  TRUE
	#define EXP_fupollwrregliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregliststatus", (RTS_UINTPTR)fupollwrregliststatus, 1, 0xBD81A398, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollwrregliststatus
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollwrregliststatus
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollwrregliststatus  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollwrregliststatus  fupollwrregliststatus
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollwrregliststatus  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollwrregliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregliststatus", (RTS_UINTPTR)fupollwrregliststatus, 1, 0xBD81A398, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollwrregliststatus
	#define EXT_fupollwrregliststatus
	#define GET_fupollwrregliststatus(fl)  CAL_CMGETAPI( "fupollwrregliststatus" ) 
	#define CAL_fupollwrregliststatus  fupollwrregliststatus
	#define CHK_fupollwrregliststatus  TRUE
	#define EXP_fupollwrregliststatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregliststatus", (RTS_UINTPTR)fupollwrregliststatus, 1, 0xBD81A398, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollwrregliststatus  PFFUPOLLWRREGLISTSTATUS_IEC pffupollwrregliststatus;
	#define EXT_fupollwrregliststatus  extern PFFUPOLLWRREGLISTSTATUS_IEC pffupollwrregliststatus;
	#define GET_fupollwrregliststatus(fl)  s_pfCMGetAPI2( "fupollwrregliststatus", (RTS_VOID_FCTPTR *)&pffupollwrregliststatus, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xBD81A398, 0x01020000)
	#define CAL_fupollwrregliststatus  pffupollwrregliststatus
	#define CHK_fupollwrregliststatus  (pffupollwrregliststatus != NULL)
	#define EXP_fupollwrregliststatus   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregliststatus", (RTS_UINTPTR)fupollwrregliststatus, 1, 0xBD81A398, 0x01020000) 
#endif


/**
 * <description>fupollwrregstatus</description>
 */
typedef struct tagfupollwrregstatus_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* register number in module */
	RTS_IEC_UINT uiValue;				/* VAR_INPUT */	/* content of addressed register */
	RTS_IEC_DINT FuPollWrRegStatus;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fupollwrregstatus_struct;

void CDECL CDECL_EXT fupollwrregstatus(fupollwrregstatus_struct *p);
typedef void (CDECL CDECL_EXT* PFFUPOLLWRREGSTATUS_IEC) (fupollwrregstatus_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUPOLLWRREGSTATUS_NOTIMPLEMENTED)
	#define USE_fupollwrregstatus
	#define EXT_fupollwrregstatus
	#define GET_fupollwrregstatus(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fupollwrregstatus(p0) 
	#define CHK_fupollwrregstatus  FALSE
	#define EXP_fupollwrregstatus  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fupollwrregstatus
	#define EXT_fupollwrregstatus
	#define GET_fupollwrregstatus(fl)  CAL_CMGETAPI( "fupollwrregstatus" ) 
	#define CAL_fupollwrregstatus  fupollwrregstatus
	#define CHK_fupollwrregstatus  TRUE
	#define EXP_fupollwrregstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregstatus", (RTS_UINTPTR)fupollwrregstatus, 1, 0xD5B1BE2C, 0x01020000) 
	#define EXTREF_ITF_fupollwrregstatus {(RTS_VOID_FCTPTR)fupollwrregstatus, "fupollwrregstatus", 0xD5B1BE2C, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fupollwrregstatus
	#define EXT_fupollwrregstatus
	#define GET_fupollwrregstatus(fl)  CAL_CMGETAPI( "fupollwrregstatus" ) 
	#define CAL_fupollwrregstatus  fupollwrregstatus
	#define CHK_fupollwrregstatus  TRUE
	#define EXP_fupollwrregstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregstatus", (RTS_UINTPTR)fupollwrregstatus, 1, 0xD5B1BE2C, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfupollwrregstatus
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfupollwrregstatus
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfupollwrregstatus  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfupollwrregstatus  fupollwrregstatus
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfupollwrregstatus  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfupollwrregstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregstatus", (RTS_UINTPTR)fupollwrregstatus, 1, 0xD5B1BE2C, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fupollwrregstatus
	#define EXT_fupollwrregstatus
	#define GET_fupollwrregstatus(fl)  CAL_CMGETAPI( "fupollwrregstatus" ) 
	#define CAL_fupollwrregstatus  fupollwrregstatus
	#define CHK_fupollwrregstatus  TRUE
	#define EXP_fupollwrregstatus  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregstatus", (RTS_UINTPTR)fupollwrregstatus, 1, 0xD5B1BE2C, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fupollwrregstatus  PFFUPOLLWRREGSTATUS_IEC pffupollwrregstatus;
	#define EXT_fupollwrregstatus  extern PFFUPOLLWRREGSTATUS_IEC pffupollwrregstatus;
	#define GET_fupollwrregstatus(fl)  s_pfCMGetAPI2( "fupollwrregstatus", (RTS_VOID_FCTPTR *)&pffupollwrregstatus, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xD5B1BE2C, 0x01020000)
	#define CAL_fupollwrregstatus  pffupollwrregstatus
	#define CHK_fupollwrregstatus  (pffupollwrregstatus != NULL)
	#define EXP_fupollwrregstatus   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fupollwrregstatus", (RTS_UINTPTR)fupollwrregstatus, 1, 0xD5B1BE2C, 0x01020000) 
#endif


/**
 * <description>furesetkbustiming</description>
 */
typedef struct tagfuresetkbustiming_struct
{
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_DINT FuResetKbusTiming;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} furesetkbustiming_struct;

void CDECL CDECL_EXT furesetkbustiming(furesetkbustiming_struct *p);
typedef void (CDECL CDECL_EXT* PFFURESETKBUSTIMING_IEC) (furesetkbustiming_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FURESETKBUSTIMING_NOTIMPLEMENTED)
	#define USE_furesetkbustiming
	#define EXT_furesetkbustiming
	#define GET_furesetkbustiming(fl)  ERR_NOTIMPLEMENTED
	#define CAL_furesetkbustiming(p0) 
	#define CHK_furesetkbustiming  FALSE
	#define EXP_furesetkbustiming  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_furesetkbustiming
	#define EXT_furesetkbustiming
	#define GET_furesetkbustiming(fl)  CAL_CMGETAPI( "furesetkbustiming" ) 
	#define CAL_furesetkbustiming  furesetkbustiming
	#define CHK_furesetkbustiming  TRUE
	#define EXP_furesetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetkbustiming", (RTS_UINTPTR)furesetkbustiming, 1, 0x9686100E, 0x01020000) 
	#define EXTREF_ITF_furesetkbustiming {(RTS_VOID_FCTPTR)furesetkbustiming, "furesetkbustiming", 0x9686100E, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_furesetkbustiming
	#define EXT_furesetkbustiming
	#define GET_furesetkbustiming(fl)  CAL_CMGETAPI( "furesetkbustiming" ) 
	#define CAL_furesetkbustiming  furesetkbustiming
	#define CHK_furesetkbustiming  TRUE
	#define EXP_furesetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetkbustiming", (RTS_UINTPTR)furesetkbustiming, 1, 0x9686100E, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfuresetkbustiming
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfuresetkbustiming
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfuresetkbustiming  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfuresetkbustiming  furesetkbustiming
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfuresetkbustiming  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfuresetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetkbustiming", (RTS_UINTPTR)furesetkbustiming, 1, 0x9686100E, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_furesetkbustiming
	#define EXT_furesetkbustiming
	#define GET_furesetkbustiming(fl)  CAL_CMGETAPI( "furesetkbustiming" ) 
	#define CAL_furesetkbustiming  furesetkbustiming
	#define CHK_furesetkbustiming  TRUE
	#define EXP_furesetkbustiming  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetkbustiming", (RTS_UINTPTR)furesetkbustiming, 1, 0x9686100E, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_furesetkbustiming  PFFURESETKBUSTIMING_IEC pffuresetkbustiming;
	#define EXT_furesetkbustiming  extern PFFURESETKBUSTIMING_IEC pffuresetkbustiming;
	#define GET_furesetkbustiming(fl)  s_pfCMGetAPI2( "furesetkbustiming", (RTS_VOID_FCTPTR *)&pffuresetkbustiming, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9686100E, 0x01020000)
	#define CAL_furesetkbustiming  pffuresetkbustiming
	#define CHK_furesetkbustiming  (pffuresetkbustiming != NULL)
	#define EXP_furesetkbustiming   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"furesetkbustiming", (RTS_UINTPTR)furesetkbustiming, 1, 0x9686100E, 0x01020000) 
#endif


/**
 * <description>fustartrdpar</description>
 */
typedef struct tagfustartrdpar_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiPassWord;			/* VAR_INPUT */	/* password to conrol write protection */
	RTS_IEC_DINT FuStartRdPar;			/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartrdpar_struct;

void CDECL CDECL_EXT fustartrdpar(fustartrdpar_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTRDPAR_IEC) (fustartrdpar_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTRDPAR_NOTIMPLEMENTED)
	#define USE_fustartrdpar
	#define EXT_fustartrdpar
	#define GET_fustartrdpar(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartrdpar(p0) 
	#define CHK_fustartrdpar  FALSE
	#define EXP_fustartrdpar  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartrdpar
	#define EXT_fustartrdpar
	#define GET_fustartrdpar(fl)  CAL_CMGETAPI( "fustartrdpar" ) 
	#define CAL_fustartrdpar  fustartrdpar
	#define CHK_fustartrdpar  TRUE
	#define EXP_fustartrdpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdpar", (RTS_UINTPTR)fustartrdpar, 1, 0xFFE6401B, 0x01020000) 
	#define EXTREF_ITF_fustartrdpar {(RTS_VOID_FCTPTR)fustartrdpar, "fustartrdpar", 0xFFE6401B, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartrdpar
	#define EXT_fustartrdpar
	#define GET_fustartrdpar(fl)  CAL_CMGETAPI( "fustartrdpar" ) 
	#define CAL_fustartrdpar  fustartrdpar
	#define CHK_fustartrdpar  TRUE
	#define EXP_fustartrdpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdpar", (RTS_UINTPTR)fustartrdpar, 1, 0xFFE6401B, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartrdpar
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartrdpar
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartrdpar  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartrdpar  fustartrdpar
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartrdpar  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartrdpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdpar", (RTS_UINTPTR)fustartrdpar, 1, 0xFFE6401B, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartrdpar
	#define EXT_fustartrdpar
	#define GET_fustartrdpar(fl)  CAL_CMGETAPI( "fustartrdpar" ) 
	#define CAL_fustartrdpar  fustartrdpar
	#define CHK_fustartrdpar  TRUE
	#define EXP_fustartrdpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdpar", (RTS_UINTPTR)fustartrdpar, 1, 0xFFE6401B, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartrdpar  PFFUSTARTRDPAR_IEC pffustartrdpar;
	#define EXT_fustartrdpar  extern PFFUSTARTRDPAR_IEC pffustartrdpar;
	#define GET_fustartrdpar(fl)  s_pfCMGetAPI2( "fustartrdpar", (RTS_VOID_FCTPTR *)&pffustartrdpar, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xFFE6401B, 0x01020000)
	#define CAL_fustartrdpar  pffustartrdpar
	#define CHK_fustartrdpar  (pffustartrdpar != NULL)
	#define EXP_fustartrdpar   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdpar", (RTS_UINTPTR)fustartrdpar, 1, 0xFFE6401B, 0x01020000) 
#endif


/**
 * <description>fustartrdparlist</description>
 */
typedef struct tagfustartrdparlist_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiParameterCnt;		/* VAR_INPUT */	/* number of parameters to write (1 .. 256) */
	RTS_IEC_UINT uiPassWord;			/* VAR_INPUT */	/* password to conrol write protection */
	RTS_IEC_DINT FuStartRdParList;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartrdparlist_struct;

void CDECL CDECL_EXT fustartrdparlist(fustartrdparlist_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTRDPARLIST_IEC) (fustartrdparlist_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTRDPARLIST_NOTIMPLEMENTED)
	#define USE_fustartrdparlist
	#define EXT_fustartrdparlist
	#define GET_fustartrdparlist(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartrdparlist(p0) 
	#define CHK_fustartrdparlist  FALSE
	#define EXP_fustartrdparlist  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartrdparlist
	#define EXT_fustartrdparlist
	#define GET_fustartrdparlist(fl)  CAL_CMGETAPI( "fustartrdparlist" ) 
	#define CAL_fustartrdparlist  fustartrdparlist
	#define CHK_fustartrdparlist  TRUE
	#define EXP_fustartrdparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdparlist", (RTS_UINTPTR)fustartrdparlist, 1, 0x283DE285, 0x01020000) 
	#define EXTREF_ITF_fustartrdparlist {(RTS_VOID_FCTPTR)fustartrdparlist, "fustartrdparlist", 0x283DE285, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartrdparlist
	#define EXT_fustartrdparlist
	#define GET_fustartrdparlist(fl)  CAL_CMGETAPI( "fustartrdparlist" ) 
	#define CAL_fustartrdparlist  fustartrdparlist
	#define CHK_fustartrdparlist  TRUE
	#define EXP_fustartrdparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdparlist", (RTS_UINTPTR)fustartrdparlist, 1, 0x283DE285, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartrdparlist
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartrdparlist
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartrdparlist  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartrdparlist  fustartrdparlist
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartrdparlist  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartrdparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdparlist", (RTS_UINTPTR)fustartrdparlist, 1, 0x283DE285, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartrdparlist
	#define EXT_fustartrdparlist
	#define GET_fustartrdparlist(fl)  CAL_CMGETAPI( "fustartrdparlist" ) 
	#define CAL_fustartrdparlist  fustartrdparlist
	#define CHK_fustartrdparlist  TRUE
	#define EXP_fustartrdparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdparlist", (RTS_UINTPTR)fustartrdparlist, 1, 0x283DE285, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartrdparlist  PFFUSTARTRDPARLIST_IEC pffustartrdparlist;
	#define EXT_fustartrdparlist  extern PFFUSTARTRDPARLIST_IEC pffustartrdparlist;
	#define GET_fustartrdparlist(fl)  s_pfCMGetAPI2( "fustartrdparlist", (RTS_VOID_FCTPTR *)&pffustartrdparlist, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x283DE285, 0x01020000)
	#define CAL_fustartrdparlist  pffustartrdparlist
	#define CHK_fustartrdparlist  (pffustartrdparlist != NULL)
	#define EXP_fustartrdparlist   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdparlist", (RTS_UINTPTR)fustartrdparlist, 1, 0x283DE285, 0x01020000) 
#endif


/**
 * <description>fustartrdreg</description>
 */
typedef struct tagfustartrdreg_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* register number in module */
	RTS_IEC_DINT FuStartRdReg;			/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartrdreg_struct;

void CDECL CDECL_EXT fustartrdreg(fustartrdreg_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTRDREG_IEC) (fustartrdreg_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTRDREG_NOTIMPLEMENTED)
	#define USE_fustartrdreg
	#define EXT_fustartrdreg
	#define GET_fustartrdreg(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartrdreg(p0) 
	#define CHK_fustartrdreg  FALSE
	#define EXP_fustartrdreg  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartrdreg
	#define EXT_fustartrdreg
	#define GET_fustartrdreg(fl)  CAL_CMGETAPI( "fustartrdreg" ) 
	#define CAL_fustartrdreg  fustartrdreg
	#define CHK_fustartrdreg  TRUE
	#define EXP_fustartrdreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreg", (RTS_UINTPTR)fustartrdreg, 1, 0x300F77B7, 0x01020000) 
	#define EXTREF_ITF_fustartrdreg {(RTS_VOID_FCTPTR)fustartrdreg, "fustartrdreg", 0x300F77B7, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartrdreg
	#define EXT_fustartrdreg
	#define GET_fustartrdreg(fl)  CAL_CMGETAPI( "fustartrdreg" ) 
	#define CAL_fustartrdreg  fustartrdreg
	#define CHK_fustartrdreg  TRUE
	#define EXP_fustartrdreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreg", (RTS_UINTPTR)fustartrdreg, 1, 0x300F77B7, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartrdreg
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartrdreg
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartrdreg  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartrdreg  fustartrdreg
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartrdreg  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartrdreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreg", (RTS_UINTPTR)fustartrdreg, 1, 0x300F77B7, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartrdreg
	#define EXT_fustartrdreg
	#define GET_fustartrdreg(fl)  CAL_CMGETAPI( "fustartrdreg" ) 
	#define CAL_fustartrdreg  fustartrdreg
	#define CHK_fustartrdreg  TRUE
	#define EXP_fustartrdreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreg", (RTS_UINTPTR)fustartrdreg, 1, 0x300F77B7, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartrdreg  PFFUSTARTRDREG_IEC pffustartrdreg;
	#define EXT_fustartrdreg  extern PFFUSTARTRDREG_IEC pffustartrdreg;
	#define GET_fustartrdreg(fl)  s_pfCMGetAPI2( "fustartrdreg", (RTS_VOID_FCTPTR *)&pffustartrdreg, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x300F77B7, 0x01020000)
	#define CAL_fustartrdreg  pffustartrdreg
	#define CHK_fustartrdreg  (pffustartrdreg != NULL)
	#define EXP_fustartrdreg   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreg", (RTS_UINTPTR)fustartrdreg, 1, 0x300F77B7, 0x01020000) 
#endif


/**
 * <description>fustartrdreglist</description>
 */
typedef struct tagfustartrdreglist_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* first register to read */
	RTS_IEC_USINT usiRegisterCnt;		/* VAR_INPUT */	/* number of registers to read (1 .. 64) */
	RTS_IEC_DINT FuStartRdRegList;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartrdreglist_struct;

void CDECL CDECL_EXT fustartrdreglist(fustartrdreglist_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTRDREGLIST_IEC) (fustartrdreglist_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTRDREGLIST_NOTIMPLEMENTED)
	#define USE_fustartrdreglist
	#define EXT_fustartrdreglist
	#define GET_fustartrdreglist(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartrdreglist(p0) 
	#define CHK_fustartrdreglist  FALSE
	#define EXP_fustartrdreglist  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartrdreglist
	#define EXT_fustartrdreglist
	#define GET_fustartrdreglist(fl)  CAL_CMGETAPI( "fustartrdreglist" ) 
	#define CAL_fustartrdreglist  fustartrdreglist
	#define CHK_fustartrdreglist  TRUE
	#define EXP_fustartrdreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreglist", (RTS_UINTPTR)fustartrdreglist, 1, 0x6576A7F1, 0x01020000) 
	#define EXTREF_ITF_fustartrdreglist {(RTS_VOID_FCTPTR)fustartrdreglist, "fustartrdreglist", 0x6576A7F1, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartrdreglist
	#define EXT_fustartrdreglist
	#define GET_fustartrdreglist(fl)  CAL_CMGETAPI( "fustartrdreglist" ) 
	#define CAL_fustartrdreglist  fustartrdreglist
	#define CHK_fustartrdreglist  TRUE
	#define EXP_fustartrdreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreglist", (RTS_UINTPTR)fustartrdreglist, 1, 0x6576A7F1, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartrdreglist
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartrdreglist
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartrdreglist  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartrdreglist  fustartrdreglist
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartrdreglist  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartrdreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreglist", (RTS_UINTPTR)fustartrdreglist, 1, 0x6576A7F1, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartrdreglist
	#define EXT_fustartrdreglist
	#define GET_fustartrdreglist(fl)  CAL_CMGETAPI( "fustartrdreglist" ) 
	#define CAL_fustartrdreglist  fustartrdreglist
	#define CHK_fustartrdreglist  TRUE
	#define EXP_fustartrdreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreglist", (RTS_UINTPTR)fustartrdreglist, 1, 0x6576A7F1, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartrdreglist  PFFUSTARTRDREGLIST_IEC pffustartrdreglist;
	#define EXT_fustartrdreglist  extern PFFUSTARTRDREGLIST_IEC pffustartrdreglist;
	#define GET_fustartrdreglist(fl)  s_pfCMGetAPI2( "fustartrdreglist", (RTS_VOID_FCTPTR *)&pffustartrdreglist, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6576A7F1, 0x01020000)
	#define CAL_fustartrdreglist  pffustartrdreglist
	#define CHK_fustartrdreglist  (pffustartrdreglist != NULL)
	#define EXP_fustartrdreglist   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartrdreglist", (RTS_UINTPTR)fustartrdreglist, 1, 0x6576A7F1, 0x01020000) 
#endif


/**
 * <description>fustartwrpar</description>
 */
typedef struct tagfustartwrpar_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiPassWord;			/* VAR_INPUT */	/* password to conrol write protection */
	RTS_IEC_UINT uiValue;				/* VAR_INPUT */	/* content of addressed parameter */
	RTS_IEC_DINT FuStartWrPar;			/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartwrpar_struct;

void CDECL CDECL_EXT fustartwrpar(fustartwrpar_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTWRPAR_IEC) (fustartwrpar_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTWRPAR_NOTIMPLEMENTED)
	#define USE_fustartwrpar
	#define EXT_fustartwrpar
	#define GET_fustartwrpar(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartwrpar(p0) 
	#define CHK_fustartwrpar  FALSE
	#define EXP_fustartwrpar  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartwrpar
	#define EXT_fustartwrpar
	#define GET_fustartwrpar(fl)  CAL_CMGETAPI( "fustartwrpar" ) 
	#define CAL_fustartwrpar  fustartwrpar
	#define CHK_fustartwrpar  TRUE
	#define EXP_fustartwrpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrpar", (RTS_UINTPTR)fustartwrpar, 1, 0x9BC05696, 0x01020000) 
	#define EXTREF_ITF_fustartwrpar {(RTS_VOID_FCTPTR)fustartwrpar, "fustartwrpar", 0x9BC05696, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartwrpar
	#define EXT_fustartwrpar
	#define GET_fustartwrpar(fl)  CAL_CMGETAPI( "fustartwrpar" ) 
	#define CAL_fustartwrpar  fustartwrpar
	#define CHK_fustartwrpar  TRUE
	#define EXP_fustartwrpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrpar", (RTS_UINTPTR)fustartwrpar, 1, 0x9BC05696, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartwrpar
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartwrpar
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartwrpar  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartwrpar  fustartwrpar
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartwrpar  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartwrpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrpar", (RTS_UINTPTR)fustartwrpar, 1, 0x9BC05696, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartwrpar
	#define EXT_fustartwrpar
	#define GET_fustartwrpar(fl)  CAL_CMGETAPI( "fustartwrpar" ) 
	#define CAL_fustartwrpar  fustartwrpar
	#define CHK_fustartwrpar  TRUE
	#define EXP_fustartwrpar  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrpar", (RTS_UINTPTR)fustartwrpar, 1, 0x9BC05696, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartwrpar  PFFUSTARTWRPAR_IEC pffustartwrpar;
	#define EXT_fustartwrpar  extern PFFUSTARTWRPAR_IEC pffustartwrpar;
	#define GET_fustartwrpar(fl)  s_pfCMGetAPI2( "fustartwrpar", (RTS_VOID_FCTPTR *)&pffustartwrpar, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x9BC05696, 0x01020000)
	#define CAL_fustartwrpar  pffustartwrpar
	#define CHK_fustartwrpar  (pffustartwrpar != NULL)
	#define EXP_fustartwrpar   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrpar", (RTS_UINTPTR)fustartwrpar, 1, 0x9BC05696, 0x01020000) 
#endif


/**
 * <description>fustartwrparlist</description>
 */
typedef struct tagfustartwrparlist_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiParameterNo;		/* VAR_INPUT */	/* parameter number in module */
	RTS_IEC_UINT uiParameterCnt;		/* VAR_INPUT */	/* number of parameters to write (1 .. 256) */
	RTS_IEC_UINT uiPassWord;			/* VAR_INPUT */	/* password to conrol write protection */
	RTS_IEC_UINT *aValue;				/* VAR_IN_OUT */	/* content for addressed registers */
	RTS_IEC_DINT FuStartWrParList;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartwrparlist_struct;

void CDECL CDECL_EXT fustartwrparlist(fustartwrparlist_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTWRPARLIST_IEC) (fustartwrparlist_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTWRPARLIST_NOTIMPLEMENTED)
	#define USE_fustartwrparlist
	#define EXT_fustartwrparlist
	#define GET_fustartwrparlist(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartwrparlist(p0) 
	#define CHK_fustartwrparlist  FALSE
	#define EXP_fustartwrparlist  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartwrparlist
	#define EXT_fustartwrparlist
	#define GET_fustartwrparlist(fl)  CAL_CMGETAPI( "fustartwrparlist" ) 
	#define CAL_fustartwrparlist  fustartwrparlist
	#define CHK_fustartwrparlist  TRUE
	#define EXP_fustartwrparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrparlist", (RTS_UINTPTR)fustartwrparlist, 1, 0xF60CCA66, 0x01020000) 
	#define EXTREF_ITF_fustartwrparlist {(RTS_VOID_FCTPTR)fustartwrparlist, "fustartwrparlist", 0xF60CCA66, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartwrparlist
	#define EXT_fustartwrparlist
	#define GET_fustartwrparlist(fl)  CAL_CMGETAPI( "fustartwrparlist" ) 
	#define CAL_fustartwrparlist  fustartwrparlist
	#define CHK_fustartwrparlist  TRUE
	#define EXP_fustartwrparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrparlist", (RTS_UINTPTR)fustartwrparlist, 1, 0xF60CCA66, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartwrparlist
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartwrparlist
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartwrparlist  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartwrparlist  fustartwrparlist
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartwrparlist  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartwrparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrparlist", (RTS_UINTPTR)fustartwrparlist, 1, 0xF60CCA66, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartwrparlist
	#define EXT_fustartwrparlist
	#define GET_fustartwrparlist(fl)  CAL_CMGETAPI( "fustartwrparlist" ) 
	#define CAL_fustartwrparlist  fustartwrparlist
	#define CHK_fustartwrparlist  TRUE
	#define EXP_fustartwrparlist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrparlist", (RTS_UINTPTR)fustartwrparlist, 1, 0xF60CCA66, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartwrparlist  PFFUSTARTWRPARLIST_IEC pffustartwrparlist;
	#define EXT_fustartwrparlist  extern PFFUSTARTWRPARLIST_IEC pffustartwrparlist;
	#define GET_fustartwrparlist(fl)  s_pfCMGetAPI2( "fustartwrparlist", (RTS_VOID_FCTPTR *)&pffustartwrparlist, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xF60CCA66, 0x01020000)
	#define CAL_fustartwrparlist  pffustartwrparlist
	#define CHK_fustartwrparlist  (pffustartwrparlist != NULL)
	#define EXP_fustartwrparlist   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrparlist", (RTS_UINTPTR)fustartwrparlist, 1, 0xF60CCA66, 0x01020000) 
#endif


/**
 * <description>fustartwrreg</description>
 */
typedef struct tagfustartwrreg_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* register number in module */
	RTS_IEC_UINT uiPassWord;			/* VAR_INPUT */	/* password to conrol write protection */
	RTS_IEC_UINT uiValue;				/* VAR_INPUT */	/* content of addressed register */
	RTS_IEC_DINT FuStartWrReg;			/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartwrreg_struct;

void CDECL CDECL_EXT fustartwrreg(fustartwrreg_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTWRREG_IEC) (fustartwrreg_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTWRREG_NOTIMPLEMENTED)
	#define USE_fustartwrreg
	#define EXT_fustartwrreg
	#define GET_fustartwrreg(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartwrreg(p0) 
	#define CHK_fustartwrreg  FALSE
	#define EXP_fustartwrreg  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartwrreg
	#define EXT_fustartwrreg
	#define GET_fustartwrreg(fl)  CAL_CMGETAPI( "fustartwrreg" ) 
	#define CAL_fustartwrreg  fustartwrreg
	#define CHK_fustartwrreg  TRUE
	#define EXP_fustartwrreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreg", (RTS_UINTPTR)fustartwrreg, 1, 0x6CB2570E, 0x01020000) 
	#define EXTREF_ITF_fustartwrreg {(RTS_VOID_FCTPTR)fustartwrreg, "fustartwrreg", 0x6CB2570E, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartwrreg
	#define EXT_fustartwrreg
	#define GET_fustartwrreg(fl)  CAL_CMGETAPI( "fustartwrreg" ) 
	#define CAL_fustartwrreg  fustartwrreg
	#define CHK_fustartwrreg  TRUE
	#define EXP_fustartwrreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreg", (RTS_UINTPTR)fustartwrreg, 1, 0x6CB2570E, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartwrreg
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartwrreg
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartwrreg  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartwrreg  fustartwrreg
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartwrreg  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartwrreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreg", (RTS_UINTPTR)fustartwrreg, 1, 0x6CB2570E, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartwrreg
	#define EXT_fustartwrreg
	#define GET_fustartwrreg(fl)  CAL_CMGETAPI( "fustartwrreg" ) 
	#define CAL_fustartwrreg  fustartwrreg
	#define CHK_fustartwrreg  TRUE
	#define EXP_fustartwrreg  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreg", (RTS_UINTPTR)fustartwrreg, 1, 0x6CB2570E, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartwrreg  PFFUSTARTWRREG_IEC pffustartwrreg;
	#define EXT_fustartwrreg  extern PFFUSTARTWRREG_IEC pffustartwrreg;
	#define GET_fustartwrreg(fl)  s_pfCMGetAPI2( "fustartwrreg", (RTS_VOID_FCTPTR *)&pffustartwrreg, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0x6CB2570E, 0x01020000)
	#define CAL_fustartwrreg  pffustartwrreg
	#define CHK_fustartwrreg  (pffustartwrreg != NULL)
	#define EXP_fustartwrreg   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreg", (RTS_UINTPTR)fustartwrreg, 1, 0x6CB2570E, 0x01020000) 
#endif


/**
 * <description>fustartwrreglist</description>
 */
typedef struct tagfustartwrreglist_struct
{
	RTS_IEC_HANDLE handle;				/* VAR_INPUT */	/* universal handle of the resource */
	RTS_IEC_USINT usiSlotNo;			/* VAR_INPUT */	/* slot number of module */
	RTS_IEC_USINT usiChannelNo;			/* VAR_INPUT */	/* channel number in module */
	RTS_IEC_USINT usiRegisterNo;		/* VAR_INPUT */	/* first register to write */
	RTS_IEC_USINT usiRegisterCnt;		/* VAR_INPUT */	/* number of registers to write (1 .. 64) */
	RTS_IEC_UINT uiPassWord;			/* VAR_INPUT */	/* password to conrol write protection */
	RTS_IEC_UINT *aValue;				/* VAR_IN_OUT */	/* content for addressed registers */
	RTS_IEC_DINT FuStartWrRegList;		/* VAR_OUTPUT, Enum: EKBAC_LIB_STATUS_CODES */
} fustartwrreglist_struct;

void CDECL CDECL_EXT fustartwrreglist(fustartwrreglist_struct *p);
typedef void (CDECL CDECL_EXT* PFFUSTARTWRREGLIST_IEC) (fustartwrreglist_struct *p);
#if defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_NOTIMPLEMENTED) || defined(FUSTARTWRREGLIST_NOTIMPLEMENTED)
	#define USE_fustartwrreglist
	#define EXT_fustartwrreglist
	#define GET_fustartwrreglist(fl)  ERR_NOTIMPLEMENTED
	#define CAL_fustartwrreglist(p0) 
	#define CHK_fustartwrreglist  FALSE
	#define EXP_fustartwrreglist  ERR_OK
#elif defined(STATIC_LINK)
	#define USE_fustartwrreglist
	#define EXT_fustartwrreglist
	#define GET_fustartwrreglist(fl)  CAL_CMGETAPI( "fustartwrreglist" ) 
	#define CAL_fustartwrreglist  fustartwrreglist
	#define CHK_fustartwrreglist  TRUE
	#define EXP_fustartwrreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreglist", (RTS_UINTPTR)fustartwrreglist, 1, 0xB7C6223F, 0x01020000) 
	#define EXTREF_ITF_fustartwrreglist {(RTS_VOID_FCTPTR)fustartwrreglist, "fustartwrreglist", 0xB7C6223F, 0x01020000}
#elif defined(MIXED_LINK) && !defined(WAGOSYSKBUSASYNCCOM_INTERNAL_PFC_EXTERNAL)
	#define USE_fustartwrreglist
	#define EXT_fustartwrreglist
	#define GET_fustartwrreglist(fl)  CAL_CMGETAPI( "fustartwrreglist" ) 
	#define CAL_fustartwrreglist  fustartwrreglist
	#define CHK_fustartwrreglist  TRUE
	#define EXP_fustartwrreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreglist", (RTS_UINTPTR)fustartwrreglist, 1, 0xB7C6223F, 0x01020000) 
#elif defined(CPLUSPLUS_ONLY)
	#define USE_WagoSysKbusAsyncCom_Internal_PFCfustartwrreglist
	#define EXT_WagoSysKbusAsyncCom_Internal_PFCfustartwrreglist
	#define GET_WagoSysKbusAsyncCom_Internal_PFCfustartwrreglist  ERR_OK
	#define CAL_WagoSysKbusAsyncCom_Internal_PFCfustartwrreglist  fustartwrreglist
	#define CHK_WagoSysKbusAsyncCom_Internal_PFCfustartwrreglist  TRUE
	#define EXP_WagoSysKbusAsyncCom_Internal_PFCfustartwrreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreglist", (RTS_UINTPTR)fustartwrreglist, 1, 0xB7C6223F, 0x01020000) 
#elif defined(CPLUSPLUS)
	#define USE_fustartwrreglist
	#define EXT_fustartwrreglist
	#define GET_fustartwrreglist(fl)  CAL_CMGETAPI( "fustartwrreglist" ) 
	#define CAL_fustartwrreglist  fustartwrreglist
	#define CHK_fustartwrreglist  TRUE
	#define EXP_fustartwrreglist  s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreglist", (RTS_UINTPTR)fustartwrreglist, 1, 0xB7C6223F, 0x01020000) 
#else /* DYNAMIC_LINK */
	#define USE_fustartwrreglist  PFFUSTARTWRREGLIST_IEC pffustartwrreglist;
	#define EXT_fustartwrreglist  extern PFFUSTARTWRREGLIST_IEC pffustartwrreglist;
	#define GET_fustartwrreglist(fl)  s_pfCMGetAPI2( "fustartwrreglist", (RTS_VOID_FCTPTR *)&pffustartwrreglist, (fl) | CM_IMPORT_EXTERNAL_LIB_FUNCTION, 0xB7C6223F, 0x01020000)
	#define CAL_fustartwrreglist  pffustartwrreglist
	#define CHK_fustartwrreglist  (pffustartwrreglist != NULL)
	#define EXP_fustartwrreglist   s_pfCMRegisterAPI2( (const CMP_EXT_FUNCTION_REF*)"fustartwrreglist", (RTS_UINTPTR)fustartwrreglist, 1, 0xB7C6223F, 0x01020000) 
#endif


#ifdef __cplusplus
}
#endif

/** EXTERN LIB SECTION END **/




typedef struct
{
	IBase_C *pBase;
} IWagoSysKbusAsyncCom_Internal_PFC_C;

#ifdef CPLUSPLUS
class IWagoSysKbusAsyncCom_Internal_PFC : public IBase
{
	public:
};
	#ifndef ITF_WagoSysKbusAsyncCom_Internal_PFC
		#define ITF_WagoSysKbusAsyncCom_Internal_PFC static IWagoSysKbusAsyncCom_Internal_PFC *pIWagoSysKbusAsyncCom_Internal_PFC = NULL;
	#endif
	#define EXTITF_WagoSysKbusAsyncCom_Internal_PFC
#else	/*CPLUSPLUS*/
	typedef IWagoSysKbusAsyncCom_Internal_PFC_C		IWagoSysKbusAsyncCom_Internal_PFC;
	#ifndef ITF_WagoSysKbusAsyncCom_Internal_PFC
		#define ITF_WagoSysKbusAsyncCom_Internal_PFC
	#endif
	#define EXTITF_WagoSysKbusAsyncCom_Internal_PFC
#endif

#ifdef CPLUSPLUS_ONLY
  #undef CPLUSPLUS_ONLY
#endif

#endif /*_WAGOSYSKBUSASYNCCOM_INTERNAL_PFCITF_H_*/
