/***********************************************************************
 * DO NOT MODIFY!
 * This is a generated file. Do not modify it's contents directly
 ***********************************************************************/

/**
 *  <name>Component libcurl layer</name>
 *  <description> 
 *    This module almost transparently transports libcurl's interface to IEC code.
 *  </description>
 *  <copyright>
 *    (c) 2015 WAGO GmbH & Co. KG.
 *  </copyright>
 */
#ifndef _TSCCURLDEP_H_
#define _TSCCURLDEP_H_

#define COMPONENT_NAME "TscCurl" COMPONENT_NAME_POSTFIX
#define COMPONENT_ID    ADDVENDORID(CMP_VENDORID, CMPID_TscCurl)
#define COMPONENT_NAME_UNQUOTED TscCurl





#include "CmpItf.h"
#include <WagoSysdefines.h>

#define CLASSID_TscCurl     ADDVENDORID(CMP_VENDORID, TSCCURL_CLASSID_C)
#define CMPID_TscCurl       TSCCURL_CMPID
#define ITFID_TscCurl       ADDVENDORID(CMP_VENDORID, TSCCURL_CLASSID_C)

#define CMP_VERSION         UINT32_C(0x00000100)
#define CMP_VERSION_STRING "0.0.1.0"
#define CMP_VERSION_RC      0,0,1,0
#define CMP_VENDORID       RTS_VENDORID_WAGO

#ifndef WIN32_RESOURCES

#include "CmpLogItf.h"
#include "CMUtilsItf.h"				






/**
 * \file WagoSysCurl_Internal_PFCItf.h
 */
#include "WagoSysCurl_Internal_PFCItf.h"







#include "SysOutItf.h"


/* USE_ITF(`SysMutexItf.m4') */
#include "SysFileItf.h"



        
     
     

/* REQUIRED_IMPORTS(SysMutexCreate, SysMutexDelete, SysMutexEnter, SysMutexLeave) */


#ifdef CPLUSPLUS
    #define INIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT initResult;\
        if (pICmpLog == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCmpLog, &initResult); \
            if (pIBase != NULL) \
            { \
                pICmpLog = (ICmpLog *)pIBase->QueryInterface(pIBase, ITFID_ICmpLog, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pICMUtils == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CCMUtils, &initResult); \
            if (pIBase != NULL) \
            { \
                pICMUtils = (ICMUtils *)pIBase->QueryInterface(pIBase, ITFID_ICMUtils, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
        if (pISysFile == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysFile, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysFile = (ISysFile *)pIBase->QueryInterface(pIBase, ITFID_ISysFile, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
          if (pISysOut == NULL && s_pfCMCreateInstance != NULL) \
        { \
            pIBase = (IBase *)s_pfCMCreateInstance(CLASSID_CSysOut, &initResult); \
            if (pIBase != NULL) \
            { \
                pISysOut = (ISysOut *)pIBase->QueryInterface(pIBase, ITFID_ISysOut, &initResult); \
                pIBase->Release(pIBase); \
            } \
        } \
           \
    }
    #define INIT_LOCALS_STMT \
    {\
        pICmpLog = NULL; \
        pICMUtils = NULL; \
        pISysFile = NULL; \
          pISysOut = NULL; \
           \
    }
    #define EXIT_STMT \
    {\
        IBase *pIBase;\
        RTS_RESULT exitResult;\
        if (pICmpLog != NULL) \
        { \
            pIBase = (IBase *)pICmpLog->QueryInterface(pICmpLog, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICmpLog = NULL; \
            } \
        } \
        if (pICMUtils != NULL) \
        { \
            pIBase = (IBase *)pICMUtils->QueryInterface(pICMUtils, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pICMUtils = NULL; \
            } \
        } \
        if (pISysFile != NULL) \
        { \
            pIBase = (IBase *)pISysFile->QueryInterface(pISysFile, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysFile = NULL; \
            } \
        } \
          if (pISysOut != NULL) \
        { \
            pIBase = (IBase *)pISysOut->QueryInterface(pISysOut, ITFID_IBase, &exitResult); \
            if (pIBase != NULL) \
            { \
                 pIBase->Release(pIBase); \
                 if (pIBase->Release(pIBase) == 0) /* The object will be deleted here! */ \
                    pISysOut = NULL; \
            } \
        } \
           \
    }
#else
    #define INIT_STMT
    #define INIT_LOCALS_STMT
    #define EXIT_STMT
#endif



#if defined(STATIC_LINK)
    #define IMPORT_STMT
#else
    #define IMPORT_STMT \
    {\
        RTS_RESULT importResult = ERR_OK;\
        RTS_RESULT TempResult = ERR_OK;\
        INIT_STMT   \
        TempResult = GET_LogAdd(CM_IMPORT_OPTIONAL_FUNCTION); \
        TempResult = GET_CMUtlMemCpy(CM_IMPORT_OPTIONAL_FUNCTION); \
        /*Obsolete required include LogAdd*/ \
		   \
        /* To make LINT happy */\
        TempResult = TempResult;\
        if (ERR_OK != importResult) return importResult;\
    }
#endif



#ifndef TSCCURL_DISABLE_EXTREF
#define EXPORT_EXTREF_STMT \
        { (RTS_VOID_FCTPTR)fbcurl__curl_slist_append2, "fbcurl__curl_slist_append2", 0xC388A4D1, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__fb_init, "fbcurl__fb_init", 0x1B40323E, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_set_filepath, "fbcurl__curl_set_filepath", 0x010C8AC7, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_slist, "fbcurl__curl_easy_setopt_slist", 0xA808A865, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_init, "fbcurl__curl_easy_init", 0x8AD3008A, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_abort, "fbcurl__curl_easy_abort", 0xA65EDF85, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_cleanup, "fbcurl__curl_easy_cleanup", 0x747D008E, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_dint, "fbcurl__curl_easy_setopt_dint", 0x7216DD37, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_set_logfile, "fbcurl__curl_set_logfile", 0x57B5D369, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_perform, "fbcurl__curl_easy_perform", 0xC3DB6CB8, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_reset, "fbcurl__curl_easy_reset", 0x3CD2811A, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_set_ram, "fbcurl__curl_set_ram", 0x0EF50014, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__main, "fbcurl__main", 0x00C82D1B, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_getresponsecode, "fbcurl__curl_easy_getresponsecode", 0x5F90EE00, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_slist_free_all, "fbcurl__curl_slist_free_all", 0x21D758DC, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_slist_append, "fbcurl__curl_slist_append", 0x6D8DA28D, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_bool, "fbcurl__curl_easy_setopt_bool", 0xADFBFBA9, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_string, "fbcurl__curl_easy_setopt_string", 0x7BBBC567, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__fb_exit, "fbcurl__fb_exit", 0x3DC3DD5E, 0x01000000 },\
          { (RTS_VOID_FCTPTR)fbcurl__curl_easy_setopt_string2, "fbcurl__curl_easy_setopt_string2", 0xD661A698, 0x01000000 },\
          
#else
#define EXPORT_EXTREF_STMT
#endif
#ifndef TSCCURL_DISABLE_EXTREF2
#define EXPORT_EXTREF2_STMT \
                                                
#else
#define EXPORT_EXTREF2_STMT
#endif
#if !defined(TSCCURL_DISABLE_CMPITF) && !defined(STATIC_LINK) && !defined(CPLUSPLUS) && !defined(CPLUSPLUS_ONLY)
#define EXPORT_CMPITF_STMT \
    {\
                                                \
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#else
#define EXPORT_CMPITF_STMT \
    {\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    }
#endif
#define EXPORT_CPP_STMT


#if defined(STATIC_LINK)
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#else
    #define EXPORT_STMT\
    {\
        RTS_RESULT ExpResult;\
        if (NULL == s_pfCMRegisterAPI)\
            return ERR_NOTINITIALIZED;\
        ExpResult = s_pfCMRegisterAPI(s_ExternalsTable, 0, 1, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
        ExpResult = s_pfCMRegisterAPI(s_ItfTable, 0, 0, COMPONENT_ID);\
        if (ERR_OK != ExpResult)\
            return ExpResult;\
    }
#endif

#define USE_STMT \
    /*lint -save --e{528} --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    static const CMP_EXT_FUNCTION_REF s_ExternalsTable[] =\
    {\
        EXPORT_EXTREF_STMT\
        EXPORT_EXTREF2_STMT\
        { ((RTS_VOID_FCTPTR)(void *)0), "", 0, 0 }\
    };\
    static const CMP_EXT_FUNCTION_REF s_ItfTable[] = EXPORT_CMPITF_STMT; \
    /*lint -restore */  \
    static int CDECL ExportFunctions(void); \
    static int CDECL ImportFunctions(void); \
    static IBase* CDECL CreateInstance(CLASSID cid, RTS_RESULT *pResult); \
    static RTS_RESULT CDECL DeleteInstance(IBase *pIBase); \
    static RTS_UI32 CDECL CmpGetVersion(void); \
    static RTS_RESULT CDECL HookFunction(RTS_UI32 ulHook, RTS_UINTPTR ulParam1, RTS_UINTPTR ulParam2); \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut     \
	ITF_SysFile      \
    /*obsolete USE_LogAdd*/     
#define USEIMPORT_STMT \
    /*lint -save --e{551} */ \
    static volatile PF_REGISTER_API s_pfCMRegisterAPI; \
    static volatile PF_REGISTER_API2 s_pfCMRegisterAPI2; \
    static volatile PF_GET_API s_pfCMGetAPI; \
    static volatile PF_GET_API2 s_pfCMGetAPI2; \
    static volatile PF_REGISTER_CLASS s_pfCMRegisterClass; \
    static volatile PF_CREATEINSTANCE s_pfCMCreateInstance; \
    static volatile PF_CALL_HOOK s_pfCMCallHook; \
    /*lint -restore */  \
    ITF_CmpLog   \
    ITF_CMUtils  \
    USE_CMUtlMemCpy  \
    USE_LogAdd \
	ITF_SysOut    \
	ITF_SysFile     \
    /*obsolete USE_LogAdd*/     
#define USEEXTERN_STMT \
    EXT_CMUtlMemCpy  \
    EXT_LogAdd \
	EXTITF_SysOut    \
	EXTITF_SysFile     \
    /*obsolete EXT_LogAdd*/ 
#ifndef COMPONENT_NAME
    #error COMPONENT_NAME is not defined. This prevents the component from being linked statically. Use SET_COMPONENT_NAME(<name_of_your_component>) to set the name of the component in your .m4 component description.
#endif




#if defined(STATIC_LINK) || defined(MIXED_LINK) || defined(DYNAMIC_LINK) || defined(CPLUSPLUS_STATIC_LINK)
    #define ComponentEntry TscCurl__Entry
#endif


#ifdef CPLUSPLUS

class CTscCurl : public IWagoSysCurl_Internal_PFC 
{
    public:
        CTscCurl() : hTscCurl(RTS_INVALID_HANDLE), iRefCount(0)
        {
        }
        virtual ~CTscCurl()
        {
        }
        virtual unsigned long AddRef(IBase *pIBase = NULL)
        {
            iRefCount++;
            return iRefCount;
        }
        virtual unsigned long Release(IBase *pIBase = NULL)
        {
            iRefCount--;
            if (iRefCount == 0)
            {
                delete this;
                return 0;
            }
            return iRefCount;
        }

        
        virtual void* QueryInterface(IBase *pIBase, ITFID iid, RTS_RESULT *pResult)
        {
            void *pItf;
            if (iid == ITFID_IBase)
                pItf = dynamic_cast<IBase *>((IWagoSysCurl_Internal_PFC *)this);            
            else if (iid == ITFID_IWagoSysCurl_Internal_PFC)
                pItf = dynamic_cast<IWagoSysCurl_Internal_PFC *>(this); 
            else
            {
                if (pResult != NULL)
                    *pResult = ERR_NOTIMPLEMENTED;
                return NULL;
            }
            if (pResult != (RTS_RESULT *)1)
                (reinterpret_cast<IBase *>(pItf))->AddRef();
            if (pResult != NULL && pResult != (RTS_RESULT *)1)
                *pResult = ERR_OK;
            return pItf;
        }

    public:
        RTS_HANDLE hTscCurl;
        int iRefCount;
};


#endif /*CPLUSPLUS*/
#endif /*WIN32_RESOURCES*/
#endif /*_DEP_H_*/
